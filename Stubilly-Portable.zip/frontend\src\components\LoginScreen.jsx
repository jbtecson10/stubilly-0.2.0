import { useState } from "react";
import { api } from "../api/client";

export default function LoginScreen({ onLogin, backendLabel }) {
  const [serial, setSerial] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!serial.trim() || !password) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api.login(serial.trim(), password, navigator.userAgent.slice(0, 120));
      onLogin(res.token, res.user);
    } catch (err) {
      setError(err.message || "Couldn't sign in — is the server reachable?");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="setup-screen">
      <div className="setup-card login-card">
        <h1 className="setup-title">Sign in to Stubilly</h1>
        <p className="setup-subtitle">
          Enter your serial or ID number to start your session.
          {backendLabel && ` Connected to ${backendLabel}.`}
        </p>
        <form onSubmit={handleSubmit} className="login-form">
          <label className="setup-field">
            <span>Serial / ID number</span>
            <input
              className="setup-custom-input login-input"
              type="text"
              value={serial}
              onChange={(e) => setSerial(e.target.value)}
              placeholder="e.g. 2024-0021"
              autoFocus
            />
          </label>
          <label className="setup-field">
            <span>Password</span>
            <input
              className="setup-custom-input login-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Your password"
            />
          </label>
          {error && <p className="login-error">{error}</p>}
          <div className="setup-actions">
            <button type="submit" className="btn-primary" disabled={!serial.trim() || !password || busy}>
              {busy ? "Signing in…" : "Sign in"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}