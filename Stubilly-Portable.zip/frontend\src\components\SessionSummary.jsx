import { useCallback, useEffect, useState } from "react";
import { api } from "../api/client";
import AnalyticsDashboard from "./AnalyticsDashboard";

function minutes(sec) {
  return Math.round((sec ?? 0) / 60);
}

function ordinal(n) {
  if (n === 1) return "st";
  if (n === 2) return "nd";
  if (n === 3) return "rd";
  return "th";
}

const TREND_LABEL = {
  improved: "Improved vs last run",
  declined: "Lower than last run",
  steady: "Holding steady",
  first_run: "First run — baseline set",
};

const DIFFICULTY_LABEL = {
  easy: "Easy",
  medium: "Medium",
  hard: "Hard",
};

export default function SessionSummary({ session, onNewSession, onShowHistory }) {
  const [stats, setStats] = useState(null);
  const [report, setReport] = useState(null);
  const [patterns, setPatterns] = useState(null);

  // Post-session quiz: fetched if one exists, auto-generated if not (the
  // generation is server-side and uses only THIS session's study content;
  // difficulty was chosen automatically from the session's focus %).
  const [quiz, setQuiz] = useState(null);
  const [quizLoading, setQuizLoading] = useState(true);
  const [quizError, setQuizError] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [quizSkipped, setQuizSkipped] = useState(false);
  const [showDashboard, setShowDashboard] = useState(false);

  const loadQuiz = useCallback(() => {
    setQuizLoading(true);
    setQuizError(null);
    api
      .getSessionQuiz(session.id)
      .then((existing) => {
        setQuiz(existing);
        setQuizLoading(false);
      })
      .catch((e) => {
        if (e?.status === 404) {
          // No quiz yet — build one now (idempotent on the server).
          api
            .generateSessionQuiz(session.id)
            .then((generated) => {
              setQuiz(generated);
              setQuizLoading(false);
            })
            .catch((genErr) => {
              setQuizError(`Couldn't build the quiz (${genErr.message}).`);
              setQuizLoading(false);
            });
        } else {
          setQuizError(`Couldn't load the quiz (${e.message}).`);
          setQuizLoading(false);
        }
      });
  }, [session.id]);

  useEffect(() => {
    api
      .getSessionStats(session.id)
      .then(setStats)
      .catch(() => setStats(null));
    // Focus report (theoretical framework OUTPUT): the pre/post evaluation
    // for this run + the distraction patterns behind it.
    api
      .getSessionEvaluation(session.id)
      .then(setReport)
      .catch(() => setReport(null));
    api
      .getPatterns(14)
      .then(setPatterns)
      .catch(() => setPatterns(null));
    setQuiz(null);
    setAnswers([]);
    setQuizSkipped(false);
    loadQuiz();
  }, [session.id, loadQuiz]);

  const setAnswer = (qIndex, optionIndex) =>
    setAnswers((prev) => {
      const next = [...prev];
      next[qIndex] = optionIndex;
      return next;
    });

  const allAnswered =
    quiz?.questions?.length > 0 &&
    quiz.questions.every((_, i) => Number.isInteger(answers[i]));

  const submitQuiz = () => {
    if (!quiz || !allAnswered || submitting) return;
    setSubmitting(true);
    api
      .submitSessionQuiz(
        session.id,
        quiz.questions.map((_, i) => answers[i])
      )
      .then((graded) => {
        setQuiz(graded);
        setSubmitting(false);
        // Tell anything else open (the progress dashboard) to refetch —
        // the score is now part of the academic record.
        window.dispatchEvent(
          new CustomEvent("stubilly:quiz-completed", {
            detail: { sessionId: session.id, score: graded.score },
          })
        );
      })
      .catch((e) => {
        setQuizError(`Couldn't grade the quiz (${e.message}).`);
        setSubmitting(false);
      });
  };

  const focusedMin = minutes(session.total_focused_seconds);
  const distractedMin = minutes(session.total_distracted_seconds);
  const total = focusedMin + distractedMin || 1;
  const focusedPct = stats ? stats.focused_pct : Math.round((focusedMin / total) * 100);

  const quizCompleted = quiz?.status === "completed";
  const quizPercent =
    quizCompleted && quiz.total_questions > 0
      ? Math.round((quiz.score / quiz.total_questions) * 100)
      : null;

  return (
    <div className="setup-screen">
      <div className="setup-main">
        <div className="setup-card">
        <h1 className="setup-title">Nice work.</h1>
        <p className="setup-subtitle">
          Here's how this session went
          {stats?.task_study_count > 1 && ` — your ${stats.session_number}${ordinal(stats.session_number)} on this task`}
          .
        </p>

        <div className="summary-hero">
          <div className="summary-ring" aria-hidden="true">
            <svg viewBox="0 0 120 120" role="presentation">
              <circle className="summary-ring-track" cx="60" cy="60" r="52" />
              <circle
                className="summary-ring-fill"
                cx="60"
                cy="60"
                r="52"
                style={{
                  strokeDasharray: `${2 * Math.PI * 52}`,
                  strokeDashoffset: `${2 * Math.PI * 52 * (1 - focusedPct / 100)}`,
                }}
              />
            </svg>
            <div className="summary-ring-center">
              <span className="summary-ring-value">{Math.round(focusedPct)}</span>
              <span className="summary-ring-unit">%</span>
              <span className="summary-ring-label">focus</span>
            </div>
          </div>
          <div className="summary-stats">
            <div className="summary-stat">
              <span className="summary-stat-value">{minutes(stats?.duration_sec ?? 0)}m</span>
              <span className="summary-stat-label">total</span>
            </div>
            <div className="summary-stat">
              <span className="summary-stat-value">{focusedMin}m</span>
              <span className="summary-stat-label">focused</span>
            </div>
            <div className="summary-stat">
              <span className="summary-stat-value">{session.intervention_count}</span>
              <span className="summary-stat-label">nudges</span>
            </div>
          </div>
        </div>

        <p className="summary-subnote">
          {focusedMin}m focused · {distractedMin}m distracted
          {stats?.sleeping_sec > 0 && ` · ${minutes(stats.sleeping_sec)}m eyes closed`}
        </p>
        {session.blocked_sites?.length > 0 && (
          <p className="summary-subnote summary-blocked">
            {session.blocked_sites.length} site
            {session.blocked_sites.length === 1 ? "" : "s"} blocked this session
          </p>
        )}

        {(report || patterns) && (
          <section className="summary-report" aria-label="Focus report">
            <div className="summary-report-head">
              <h2 className="summary-report-title">Focus report</h2>
              {report?.trend && (
                <span className={`summary-trend summary-trend-${report.trend}`}>
                  {TREND_LABEL[report.trend] || report.trend}
                </span>
              )}
            </div>

            {report && (
              <>
                <div className="summary-report-grid">
                  <div className="summary-report-stat">
                    <span className="summary-report-value">
                      {Math.round(report.focus_pct)}%
                    </span>
                    <span className="summary-report-label">focus</span>
                  </div>
                  <div className="summary-report-stat">
                    <span className="summary-report-value">{report.check_in_count}</span>
                    <span className="summary-report-label">check-ins</span>
                  </div>
                  <div className="summary-report-stat">
                    <span className="summary-report-value">{report.paralysis_count}</span>
                    <span className="summary-report-label">stuck assists</span>
                  </div>
                  <div className="summary-report-stat">
                    <span className="summary-report-value">
                      {report.duration_minutes ? `${Math.round(report.duration_minutes)}m` : "—"}
                    </span>
                    <span className="summary-report-label">studied</span>
                  </div>
                </div>

                {report.prior_avg_focus_pct != null && report.delta_vs_prior != null && (
                  <p className="summary-report-compare">
                    {report.subject ? `“${report.subject}” runs average ` : "Your runs on this task average "}
                    {Math.round(report.prior_avg_focus_pct)}% focus — this run was{" "}
                    {report.delta_vs_prior >= 0 ? "up" : "down"}{" "}
                    {Math.abs(Math.round(report.delta_vs_prior))} point
                    {Math.abs(Math.round(report.delta_vs_prior)) === 1 ? "" : "s"}.
                  </p>
                )}
                {report.verdict && <p className="summary-report-verdict">{report.verdict}</p>}
              </>
            )}

            {patterns && patterns.total_events > 0 && (
              <div className="summary-report-patterns">
                <h3 className="summary-report-subtitle">Where focus slips</h3>
                {patterns.top_off_task?.length > 0 ? (
                  <ul className="report-list">
                    {patterns.top_off_task.slice(0, 3).map((t) => (
                      <li key={t.name} className="report-list-item">
                        <span className="report-list-name">{t.name}</span>
                        <span className="report-list-time">
                          {Math.max(1, Math.round((t.seconds || 0) / 60))} min off task
                        </span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="summary-report-compare">No off-task apps recorded — nice.</p>
                )}
                {patterns.focus_start_pct != null && patterns.focus_end_pct != null && (
                  <p className="summary-report-compare">
                    Focus held from {Math.round(patterns.focus_start_pct)}% at the start to{" "}
                    {Math.round(patterns.focus_end_pct)}% at the end.
                  </p>
                )}
                {patterns.intervention_reliability &&
                  (patterns.intervention_reliability.helpful > 0 ||
                    patterns.intervention_reliability.dismissed > 0) && (
                    <p className="summary-report-compare">
                      Nudges you answered: {patterns.intervention_reliability.helpful || 0} helpful ·{" "}
                      {patterns.intervention_reliability.dismissed || 0} dismissed.
                    </p>
                  )}
              </div>
            )}
          </section>
        )}

        {!quizSkipped && (
          <section className="summary-quiz" aria-label="Session quiz">
            <div className="summary-report-head">
              <h2 className="summary-report-title">Quick quiz</h2>
              {quiz && (
                <span className={`quiz-difficulty quiz-difficulty-${quiz.difficulty}`}>
                  {DIFFICULTY_LABEL[quiz.difficulty] || quiz.difficulty}
                </span>
              )}
            </div>

            {quizLoading && (
              <p className="summary-quiz-note">
                Building your quiz from what you studied this session…
              </p>
            )}

            {!quizLoading && quizError && (
              <p className="summary-quiz-note summary-quiz-error">
                {quizError}{" "}
                <button className="btn-text" onClick={loadQuiz}>
                  Try again
                </button>
              </p>
            )}

            {!quizLoading && quiz && quiz.status === "pending" && (
              <>
                <p className="summary-quiz-note">
                  Difficulty was set automatically to <b>{quiz.difficulty}</b> from your{" "}
                  {Math.round(quiz.focus_pct)}% focus this session.
                </p>
                <ol className="quiz-questions">
                  {quiz.questions.map((q, i) => (
                    <li key={q.id} className="quiz-question">
                      <p className="quiz-prompt">
                        {i + 1}. {q.prompt}
                      </p>
                      <div className="quiz-options">
                        {q.options.map((opt, oi) => (
                          <button
                            key={oi}
                            type="button"
                            className={
                              "quiz-option" +
                              (answers[i] === oi ? " quiz-option-selected" : "")
                            }
                            onClick={() => setAnswer(i, oi)}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </li>
                  ))}
                </ol>
                <div className="quiz-actions">
                  <button
                    className="btn-primary"
                    disabled={!allAnswered || submitting}
                    onClick={submitQuiz}
                  >
                    {submitting ? "Scoring…" : "Submit answers"}
                  </button>
                  <button className="btn-text" onClick={() => setQuizSkipped(true)}>
                    Skip for now
                  </button>
                </div>
              </>
            )}

            {!quizLoading && quizCompleted && (
              <div className="quiz-result">
                <div className="quiz-score-row">
                  <span className="quiz-score">
                    {quiz.score}/{quiz.total_questions}
                  </span>
                  <span className="quiz-score-percent">{quizPercent}%</span>
                </div>
                <p className="summary-quiz-note">
                  Recorded — your subject and quiz results now appear in View progress.
                </p>
                <ul className="quiz-review">
                  {quiz.questions.map((q, i) => {
                    const given = quiz.answers?.[i];
                    const correct = given === q.correct_index;
                    return (
                      <li
                        key={q.id}
                        className={`quiz-review-item ${correct ? "quiz-review-correct" : "quiz-review-wrong"}`}
                      >
                        <span className="quiz-review-mark">{correct ? "✓" : "✗"}</span>
                        <div className="quiz-review-body">
                          <p className="quiz-prompt">{q.prompt}</p>
                          {!correct && (
                            <p className="quiz-review-answer">
                              Your answer: {q.options[given] ?? "—"}
                            </p>
                          )}
                          <p className="quiz-review-answer quiz-review-answer-correct">
                            Correct: {q.options[q.correct_index]}
                          </p>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            )}
          </section>
        )}

        {quizSkipped && quiz && quiz.status === "pending" && (
          <p className="summary-quiz-note summary-quiz-skipnote">
            Quiz skipped — it stays saved for this session.{" "}
            <button className="btn-text" onClick={() => setQuizSkipped(false)}>
              Take it now
            </button>
          </p>
        )}

        <div className="summary-actions">
          <button className="btn-primary" onClick={onNewSession}>
            Start another session
          </button>
          <button className="btn-secondary summary-link" onClick={() => setShowDashboard(true)}>
            View progress
          </button>
          <button className="btn-secondary summary-link" onClick={onShowHistory}>
            View all past sessions
          </button>
        </div>

        {showDashboard && <AnalyticsDashboard onClose={() => setShowDashboard(false)} />}
        </div>
      </div>
    </div>
  );
}