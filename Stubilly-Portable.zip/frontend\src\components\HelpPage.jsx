import { useMemo, useState } from "react";
import {
  Search,
  Rocket,
  Shield,
  Clock,
  Users,
  Settings,
  ChevronDown,
  MessageSquare,
  Mail,
} from "lucide-react";
import StudentPage from "./StudentPage";

/*
 * Help = a documentation / guide center (not a live system page). It mirrors
 * the ValSNED reference: a "How can we help you?" hero with search, a row of
 * category cards, grouped FAQ accordions, and a "Still need help?" contact
 * card. Everything below is static guidance — search just filters it.
 */
const CATEGORIES = [
  {
    id: "start",
    label: "Getting started",
    icon: Rocket,
    tint: "green",
    blurb: "Start your first study session, set a task, and pick a companion.",
    faqs: [
      {
        q: "How do I start a study session?",
        a: "On the Study page, describe your task in the box, optionally set a subject, deadline and priority, choose a focus length and companion, then press Start session. Stubilly breaks the task into steps and keeps you company while you work.",
      },
      {
        q: "What do subject, deadline and priority do?",
        a: "They are the declared inputs for the session. Subject groups your work in Progress, deadline drives urgency in nudges, and priority helps the AI order your steps. All three are optional.",
      },
      {
        q: "How do I choose a companion?",
        a: "Open Companions in the sidebar to browse every buddy and what they are good at, then pick one. Your choice is used for the next session's chat and encouragement style.",
      },
    ],
  },
  {
    id: "focus",
    label: "Focus & blocking",
    icon: Shield,
    tint: "blue",
    blurb: "Guards, site blocking and how Stubilly keeps you on task.",
    faqs: [
      {
        q: "What are focus guards?",
        a: "Guards are the protection modes for a session: strict blocking, blocking through breaks, automatic blocking and live shutdown. Turn on the ones you want from the Focus guards page or the Study setup.",
      },
      {
        q: "How does site blocking work?",
        a: "When enabled, blocked sites are redirected through your system's hosts file so every browser and app is affected. It needs administrator rights and stays in effect until an administrator removes it. Blocking is lifted during breaks.",
      },
      {
        q: "What is live shutdown?",
        a: "Live shutdown force-closes off-task applications after prolonged distraction. Unsaved work in those apps may be lost, so only enable it if you accept that risk.",
      },
    ],
  },
  {
    id: "sessions",
    label: "Sessions & history",
    icon: Clock,
    tint: "amber",
    blurb: "Review past sessions, continue saved steps and read your progress.",
    faqs: [
      {
        q: "Where can I see my past sessions?",
        a: "Open History in the sidebar. Every session is listed with its task, times and outcome. Select one to see full detail, including saved steps, chat and notes.",
      },
      {
        q: "What does Progress show?",
        a: "Progress is your analytics dashboard: focused vs distracted time, streaks, subject breakdowns and trends over the week, month or all time.",
      },
      {
        q: "Can I continue a previous session?",
        a: "Yes. From a session in History you can continue its saved steps, study the same task again, or resume a session that was left in progress.",
      },
    ],
  },
  {
    id: "companions",
    label: "Companions",
    icon: Users,
    tint: "purple",
    blurb: "Meet the AI study buddies and what each one is good at.",
    faqs: [
      {
        q: "What is a companion?",
        a: "A companion is a local AI personality that keeps you company during a session — cheering you on, nudging you back, or quietly mentoring. All chat is processed locally and never leaves your machine.",
      },
      {
        q: "Do I have to pick one?",
        a: "No. If you do not choose, Fokus (the deep-work guardian) is used by default. You can switch any time from the Companions page.",
      },
    ],
  },
  {
    id: "account",
    label: "Account & settings",
    icon: Settings,
    tint: "red",
    blurb: "Sign in, custom subjects, notifications and signing out.",
    faqs: [
      {
        q: "How do I add my own subjects?",
        a: "Open Settings and use the 'Your subjects' field to add custom subjects. They appear in the Study subject dropdown alongside the built-in presets, synced to your account.",
      },
      {
        q: "How do I sign out?",
        a: "Click the account card at the bottom of the sidebar and choose Sign out. On a managed account this ends your session on the server; locally it clears the current session from this device.",
      },
    ],
  },
];

const TINT_CLASS = {
  green: "spage-help-ic--green",
  blue: "spage-help-ic--blue",
  amber: "spage-help-ic--amber",
  purple: "spage-help-ic--purple",
  red: "spage-help-ic--red",
};

export default function HelpPage({ onBack }) {
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState(null);

  // Flatten every FAQ (with its category) so search can filter across groups.
  const allFaqs = useMemo(
    () =>
      CATEGORIES.flatMap((cat) =>
        cat.faqs.map((f, i) => ({ ...f, cat: cat.label, key: `${cat.id}-${i}` }))
      ),
    []
  );

  const q = query.trim().toLowerCase();
  const searching = q.length > 0;

  // When searching, show a flat filtered list. Otherwise show grouped cards.
  const searchHits = useMemo(
    () =>
      searching
        ? allFaqs.filter(
            (f) => f.q.toLowerCase().includes(q) || f.a.toLowerCase().includes(q) || f.cat.toLowerCase().includes(q)
          )
        : [],
    [allFaqs, q, searching]
  );

  return (
    <StudentPage title="Help" subtitle="Guides, answers and examples for studying with Stubilly." onBack={onBack} wide>
      {/* Hero */}
      <div className="spage-help-hero">
        <h2 className="spage-help-hero-title">How can we help you?</h2>
        <p className="spage-help-hero-sub">
          Search the guides, browse a topic below, or read the quick answers.
        </p>
        <label className="spage-help-search">
          <Search size={18} className="spage-help-search-ic" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search topics, keywords, or answers…"
            aria-label="Search help topics"
          />
        </label>
      </div>

      {/* Category cards (hidden while searching) */}
      {!searching && (
        <div className="spage-help-cards">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            return (
              <button
                type="button"
                key={cat.id}
                className="spage-help-card"
                onClick={() => {
                  const first = `${cat.id}-0`;
                  setOpenId((cur) => (cur === first ? null : first));
                  document.getElementById(`faq-${first}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
                }}
              >
                <span className={`spage-help-ic ${TINT_CLASS[cat.tint]}`}>
                  <Icon size={20} />
                </span>
                <span className="spage-help-card-title">{cat.label}</span>
                <span className="spage-help-card-blurb">{cat.blurb}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* FAQ groups or search results */}
      {searching ? (
        <div className="spage-help-group">
          <div className="spage-help-group-head">
            <Search size={16} />
            <span>
              {searchHits.length} result{searchHits.length === 1 ? "" : "s"} for “{query}”
            </span>
          </div>
          {searchHits.length === 0 ? (
            <p className="spage-help-empty">
              No matches yet — try a different word, or browse the topics above.
            </p>
          ) : (
            searchHits.map((f) => (
              <FaqRow
                key={f.key}
                id={`search-${f.key}`}
                q={f.q}
                a={f.a}
                cat={f.cat}
                open={openId === `search-${f.key}`}
                onToggle={() => setOpenId((cur) => (cur === `search-${f.key}` ? null : `search-${f.key}`))}
              />
            ))
          )}
        </div>
      ) : (
        CATEGORIES.map((cat) => (
          <div className="spage-help-group" key={cat.id}>
            <div className="spage-help-group-head">
              <cat.icon size={16} />
              <span>{cat.label}</span>
            </div>
            {cat.faqs.map((f, i) => {
              const key = `${cat.id}-${i}`;
              return (
                <FaqRow
                  key={key}
                  id={`faq-${key}`}
                  q={f.q}
                  a={f.a}
                  open={openId === key}
                  onToggle={() => setOpenId((cur) => (cur === key ? null : key))}
                />
              );
            })}
          </div>
        ))
      )}

      {/* Contact card */}
      <div className="spage-help-contact">
        <span className="spage-help-contact-ic">
          <MessageSquare size={26} />
        </span>
        <h3>Still need help?</h3>
        <p>
          For sign-in issues, account recovery or something that looks like a bug, reach out and
          the admin team will follow up.
        </p>
        <span className="spage-help-contact-mail">
          <Mail size={16} />
          <span>support@stubilly.local</span>
        </span>
      </div>
    </StudentPage>
  );
}

function FaqRow({ id, q, a, cat, open, onToggle }) {
  return (
    <div className={`spage-help-faq${open ? " is-open" : ""}`} id={id}>
      <button type="button" className="spage-help-faq-q" onClick={onToggle} aria-expanded={open}>
        <span className="spage-help-faq-qtext">
          {cat && <em className="spage-help-faq-cat">{cat}</em>}
          {q}
        </span>
        <ChevronDown size={18} className="spage-help-faq-chev" />
      </button>
      {open && <div className="spage-help-faq-a">{a}</div>}
    </div>
  );
}
