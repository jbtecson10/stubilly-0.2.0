import { useState } from "react";
import { ShieldCheck, ShieldAlert, ShieldOff, Settings2 } from "lucide-react";
import WhitelistSettings from "./WhitelistSettings";

function formatDuration(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function AppMonitorBadge({ monitor, readOnly = false, monitoringEnabled }) {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { activeWindow, available, onTask, offTaskSeconds, whitelist, addWhitelistEntry, removeWhitelistEntry } =
    monitor;

  // The guardian's switch: monitoring off means the account itself is not
  // being tracked (not a missing webcam) — say so instead of "unavailable".
  const monitoringOff = monitoringEnabled === false;

  // Monitoring is either ACTIVE ("tracking" the foreground app — Family
  // Link's "tracking your action" phrasing), OFF by choice, or honestly
  // unavailable. Active always states the on/off-task verdict, so a focused
  // student sees a clear "On task" rather than only the app name.
  const label = monitoringOff
    ? "Monitoring off"
    : !available
      ? "Monitoring unavailable"
      : onTask
        ? activeWindow?.appName
          ? `On task · ${activeWindow.appName}`
          : "On task"
        : activeWindow?.appName
          ? `Off task · ${activeWindow.appName}`
          : "Off task";

  const Icon = monitoringOff || !available ? ShieldOff : onTask ? ShieldCheck : ShieldAlert;

  return (
    <div className="app-monitor">
      <button
        className={`app-monitor-pill${
          monitoringOff || !available ? " app-monitor-pill-off" : onTask ? "" : " app-monitor-pill-alert"
        }`}
        onClick={() => !readOnly && setSettingsOpen((v) => !v)}
        title={
          monitoringOff
            ? "Activity monitoring is turned off for this account by the guardian"
            : readOnly
              ? "Allowed apps/sites are managed by your administrator"
              : available
                ? "Monitoring active — tracking your action. Click to edit the allowed apps/sites list"
                : "Background window monitoring isn't available on this build"
        }
      >
        <Icon size={14} />
        <span className="app-monitor-label">{label}</span>
        {available && !monitoringOff && !onTask && offTaskSeconds > 0 && (
          <span className="app-monitor-timer">{formatDuration(offTaskSeconds)}</span>
        )}
        {!readOnly && <Settings2 size={13} className="app-monitor-gear" />}
      </button>

      {settingsOpen && (
        <WhitelistSettings
          entries={whitelist}
          onAdd={addWhitelistEntry}
          onRemove={removeWhitelistEntry}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}
