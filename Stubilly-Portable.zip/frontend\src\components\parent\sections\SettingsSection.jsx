import { LogOut, Moon, Sun } from "lucide-react";

/**
 * Settings section: account info, light/dark theme toggle and Sign out.
 * (Sign out also lives on the rail's account card — same place as the
 * student sidebar — so it's reachable from every section.)
 */
export default function SettingsSection({ user, onLogout, theme, toggleTheme }) {
  return (
    <>
      <h1 className="setup-title">Settings</h1>
      <p className="setup-subtitle">
        Your account, appearance, and how to sign out.
      </p>
      <div className="parent-students">
        <div className="parent-student">
          <div className="parent-student-head">
            <span className="parent-student-name">Account</span>
          </div>
          <div className="parent-student-meta">
            <span>{user?.full_name || user?.serial_number || "—"}</span>
            {user?.email && <span>{user.email}</span>}
          </div>
          <p className="parent-ctl-help">
            You're signed in as this child's guardian. You can also sign out from
            the account card at the bottom of the left menu.
          </p>
          <div className="parent-card-actions">
            <button type="button" className="btn-secondary btn-signout" onClick={onLogout}>
              <LogOut size={15} aria-hidden="true" />
              Sign out
            </button>
          </div>
        </div>
        <div className="parent-student">
          <div className="parent-student-head">
            <span className="parent-student-name">Appearance</span>
          </div>
          <div className="parent-student-meta">
            <span>Theme: {theme === "dark" ? "Dark" : "Light"}</span>
          </div>
          <p className="parent-ctl-help">
            Light or dark appearance — pick what's easier on your eyes. Your choice
            is remembered on this device.
          </p>
          <div className="parent-card-actions">
            <button type="button" className="btn-secondary" onClick={toggleTheme}>
              {theme === "dark" ? (
                <Sun size={15} aria-hidden="true" />
              ) : (
                <Moon size={15} aria-hidden="true" />
              )}
              {theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
