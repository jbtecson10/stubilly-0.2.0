# components/ — UI panels

| Component | Purpose |
|---|---|
| `SessionSetup.jsx` | The "start a session" screen: task input, Pomodoro config, strict-blocking toggles (auto-block / live-kill / no-break-exceptions), Ollama status, history actions. |
| `WebcamPanel.jsx` | Live webcam frame + current focus state overlay; shows a clear "No camera detected" panel when none exists. |
| `SessionTimer.jsx` | Elapsed time for the running session. |
| `PomodoroBar.jsx` | The work/break countdown bar. |
| `CompanionNote.jsx` | One-line tagline that changes with the focus state ("You're focused — keep going…"). |
| `TaskChecklist.jsx` | The AI-generated micro-task checklist (updates live from chat). |
| `ChatCompanion.jsx` | The body-doubling chat UI (streamed typed replies, typing indicator, reconnect hint). |
| `NotesPanel.jsx` | Auto-captured study notes (written by the companion in the background). |
| `SessionSummary.jsx` | End-of-session stats screen. |
| `SessionHistory.jsx` | Past sessions: resume / continue-with-saved-steps / study-again, plus per-session block/allow management. |
| `AnalyticsDashboard.jsx` | Weekly/monthly/yearly productivity charts + streak + best day/session. |
| `AppMonitorBadge.jsx` | Header badge: foreground-app vs whitelist, quick allow/un-allow of the current window. |
| `BlockingBadge.jsx` | Header badge: the live blocklist + add a site. |
| `HardBlockBadge.jsx` | Header badge: shows the fixed hard-block policy is active. |
| `HardBlockNotice.jsx` | On-screen "stay focused" notification when a hard-blocked app/site is hit. |
| `OllamaStatusBanner.jsx` | "Ollama offline" warning with a download link. |
| `LoginScreen.jsx` | Student sign-in / first-account creation (managed mode). |
| `AuthScreen.jsx` | Unified sign-in — accepts a student's email/serial OR an administrator's username (backend falls back to the admin table). |
| `AdminHub.jsx` | **The administration dashboard**: user management, policies, passwords, live status, sessions, analytics, account card + Sign out. Opens from the sign-in form once an admin logs in. |
| `WhitelistSettings.jsx` | Allowed-sites settings. |

Start reading: **`SessionSetup.jsx`** (setup), **`AdminHub.jsx`** (admin side).