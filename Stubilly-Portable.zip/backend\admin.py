"""
Administration hub router: user accounts, login/logout tracking, per-user
block/allow policies, and the admin-only monitoring endpoints.

Auth model:
  - Student endpoints (/auth/login, /auth/logout, /auth/me, /policy/current)
    are gated by a bearer token issued at login (see auth.py).
  - Admin endpoints are gated by an admin token issued after an
    administrator's username + password are verified against the admins
    table. Every admin has the same full access; accounts are stored
    separately from students and each admin can read their OWN password from
    the hub (other admins' rows expose names only, never passwords).

  - /auth/register is admin-only UNLESS no users exist yet (bootstrap): the
    first account ever created on a server is what flips the deployment from
    legacy single-user mode into managed mode.
  - /auth/admin-bootstrap mirrors that for administrators: the first admin
    is created through it (the hub shows a "create the first administrator"
    form until one exists), and afterwards new admins are created by an
    existing admin from the hub.

Policy model:
  - Each user carries blocked_sites (domains) and allowed_sites (sites/apps)
    that the admin hub owns. The student app downloads them via
    /policy/current at session start and keeps polling while a session is
    active, so an admin change applies both at start-time and mid-session.
"""
from datetime import datetime, timezone, timedelta
import hmac
import ipaddress
import json
import logging
import os
import re
import secrets
import time
from typing import Optional

import httpx
from fastapi import APIRouter, Depends, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from sqlalchemy import func, or_
from sqlalchemy.orm import Session

import auth as auth_service
import ml_model
import models
import schemas
import site_blocking
import window_probe
from database import get_db

logger = logging.getLogger("stubilly.admin")

router = APIRouter()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def bearer_token(authorization: Optional[str]) -> Optional[str]:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token.strip():
        return None
    return token.strip()


def _require_user(authorization: Optional[str], db: Session) -> models.User:
    user_id = auth_service.get_user_from_token(bearer_token(authorization))
    user = db.query(models.User).filter(models.User.id == user_id).first() if user_id else None
    if not user or not user.is_active:
        raise HTTPException(401, "Not authorized")
    return user


def _require_admin(authorization: Optional[str]) -> None:
    if not auth_service.is_admin_token(bearer_token(authorization)):
        raise HTTPException(401, "Admin token required")


def _require_admin_identity(authorization: Optional[str], db: Session) -> models.Admin:
    """Like _require_admin but returns the requesting Admin row, so routes
    that need to know who "me" is (e.g. /admin/admins showing only one's own
    password) resolve it directly from the token."""
    admin_id = auth_service.get_admin_id(bearer_token(authorization))
    admin = db.query(models.Admin).filter(models.Admin.id == admin_id).first() if admin_id else None
    if not admin or not admin.is_active:
        raise HTTPException(401, "Admin token required")
    return admin


def _now_naive():
    return datetime.now(timezone.utc).replace(tzinfo=None)


# ---------------------------------------------------------------------------
# New-account notifications (Admin Hub feed + linked guardian alert)
# ---------------------------------------------------------------------------

# main.py owns the guardian-alert emitter (it holds the live parent sockets);
# it injects the callback at import so neither module imports the other.
_parent_alert_emitter = None


def set_parent_alert_emitter(fn) -> None:
    global _parent_alert_emitter
    _parent_alert_emitter = fn


def _notify_admin_new_account(db: Session, user: models.User, created_by: str) -> None:
    """Persist + push an Admin Hub notification for EVERY new account 窶・
    self-registered, guardian-created, or administrator-created 窶・so the
    admin hears about sign-ups even if they weren't watching."""
    try:
        label = user.email or user.serial_number
        if created_by == "self":
            kind = "account_created"
            message = f"New account registered: {label}"
        elif created_by == "parent":
            kind = "account_created_by_guardian"
            message = f"Guardian created a student account: {label}"
        else:
            kind = "account_created_by_admin"
            message = f"Administrator created an account: {label}"
        row = models.AdminNotification(
            kind=kind,
            message=message,
            payload=json.dumps({
                "user_id": user.id,
                # The bell searches by NAME as well as email, and shows it next
                # to the message when it is not already in there.
                "full_name": user.full_name,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role or "student",
                "created_by": created_by,
            }),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        site_blocking.broadcast_admin_presence({
            "type": "notification",
            "notification": {
                "id": row.id,
                "kind": row.kind,
                "message": row.message,
                "payload": json.loads(row.payload or "{}"),
                "read_at": None,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            },
        })
    except Exception:
        logger.exception("admin account notification failed")


def _notify_parent_new_student(db: Session, student: models.User) -> None:
    """Guardian alert when a student account linked to them is created by
    someone else (admin or self-signup). A guardian's OWN creation is never
    echoed back to them 窶・it appears in their list the moment it's made."""
    if _parent_alert_emitter is None or not student.parent_id:
        return
    try:
        label = student.full_name or student.email or student.serial_number
        _parent_alert_emitter(
            db, student.id, "student_linked",
            f"New student account linked to you: {label}",
            {},
        )
    except Exception:
        logger.exception("parent student-linked alert failed")


# ---------------------------------------------------------------------------
# Role / age / consent / settings helpers (framework input layer)
# ---------------------------------------------------------------------------

# Per-account preferences, applied by the focus client (check-in cadence,
# nudge tone, voice delivery) and read at session start. Null settings on the
# user row means "everything default".
DEFAULT_SETTINGS: dict = {
    "check_in_interval_sec": 300,  # adaptive progress check-in every 5 min
    "tone": "gentle",              # "gentle" | "firm"
    "webcam_enabled": True,        # camera monitoring allowed
    "voice_mode": False,           # speak interventions via speechSynthesis
    "adaptive_check_in": False,    # AI-written, context-aware check-in wording
    "learning_profile": {},        # gradually learned behavior per account
    "custom_subjects": [],         # student's own subject labels (dropdown extras)
    # --- Parental controls (Family-Link style; parent-owned keys) ---
    # Written only through the guardian endpoints; students never see or
    # set these via /me/settings. Effective at session start and enforced
    # mid-session by the focus loop.
    "daily_screen_limit_min": None,  # None = unlimited; int 0..1440 (0 = none allowed)
    "downtime_start": None,          # "HH:MM" local; None = no downtime
    "downtime_end": None,            # overnight windows wrap (22:00 -> 07:00)
    "device_paused": False,          # guardian hit Pause: no new session, running one ends
    "monitoring_enabled": True,      # window sampler + click timeline for the guardian
}
_SETTING_TYPES = {
    "check_in_interval_sec": int,
    "tone": str,
    "webcam_enabled": bool,
    "voice_mode": bool,
    "adaptive_check_in": bool,
    "custom_subjects": list,
    # Nullable parent-owned values: accept the real type or explicit null.
    "daily_screen_limit_min": (int, type(None)),
    "downtime_start": (str, type(None)),
    "downtime_end": (str, type(None)),
    "device_paused": bool,
    "monitoring_enabled": bool,
}
_HH_MM_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")

# Student-defined subject labels that augment the frontend's built-in presets.
# Capped so a hand-edited or malicious row can't bloat every settings response.
CUSTOM_SUBJECT_MAX_LEN = 80
CUSTOM_SUBJECT_MAX_COUNT = 12


def sanitize_custom_subjects(raw) -> list:
    """Coerce a stored/requested custom_subjects value into a clean list of
    unique, trimmed strings. Non-lists become []; non-string/empty entries are
    dropped; duplicates (case-insensitive) collapse to first occurrence; each
    entry is length-capped and the list is capped at CUSTOM_SUBJECT_MAX_COUNT."""
    if not isinstance(raw, list):
        return []
    seen: set = set()
    out: list = []
    for item in raw:
        if not isinstance(item, str):
            continue
        label = item.strip()[:CUSTOM_SUBJECT_MAX_LEN].strip()
        if not label:
            continue
        key = label.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(label)
        if len(out) >= CUSTOM_SUBJECT_MAX_COUNT:
            break
    return out


def effective_settings(user: Optional[models.User]) -> dict:
    """User settings merged over DEFAULT_SETTINGS 窶・malformed/unknown keys
    are dropped so a hand-edited row can never crash the client."""
    merged = dict(DEFAULT_SETTINGS)
    if user is not None and user.settings:
        try:
            stored = json.loads(user.settings)
        except (ValueError, TypeError):
            stored = {}
        if isinstance(stored, dict):
            for key, typ in _SETTING_TYPES.items():
                if key in stored and isinstance(stored[key], typ):
                    merged[key] = stored[key]
    # Guard rails: interval is 0 (off) or 60..3600 seconds; tone is 2 values.
    try:
        interval = int(merged["check_in_interval_sec"])
    except (ValueError, TypeError):
        interval = DEFAULT_SETTINGS["check_in_interval_sec"]
    merged["check_in_interval_sec"] = max(0, min(3600, interval))
    if merged["tone"] not in ("gentle", "firm"):
        merged["tone"] = "gentle"
    # Parental controls: clamp/validate so a hand-edited row can't break
    # enforcement (limit 0..1440, "HH:MM" times, boolean pause).
    limit = merged.get("daily_screen_limit_min")
    if limit is not None:
        if isinstance(limit, bool):
            limit = None
        else:
            try:
                limit = max(0, min(1440, int(limit)))
            except (ValueError, TypeError):
                limit = None
    merged["daily_screen_limit_min"] = limit
    for key in ("downtime_start", "downtime_end"):
        raw = merged.get(key)
        if not isinstance(raw, str) or not _HH_MM_RE.match(raw.strip()):
            merged[key] = None
        else:
            merged[key] = raw.strip()
    if merged.get("downtime_start") and merged.get("downtime_end") \
            and merged["downtime_start"] == merged["downtime_end"]:
        merged["downtime_end"] = None  # zero-width window = no downtime
    merged["device_paused"] = bool(merged.get("device_paused"))
    merged["custom_subjects"] = sanitize_custom_subjects(merged.get("custom_subjects"))
    return merged


def parse_dob(value: Optional[str]) -> Optional[datetime]:
    """ISO date string (\"YYYY-MM-DD\") -> naive UTC datetime, or None.
    Raises 400 on garbage so the client gets a clear message."""
    raw = (value or "").strip()
    if not raw:
        return None
    try:
        parsed = datetime.strptime(raw[:10], "%Y-%m-%d")
    except ValueError:
        raise HTTPException(400, "date_of_birth must be YYYY-MM-DD")
    if parsed.year < 1900 or parsed > _now_naive():
        raise HTTPException(400, "date_of_birth is out of range")
    return parsed


def is_minor_dob(dob: Optional[datetime]) -> bool:
    """Under 18 as of today? Unknown (no DOB) = not flagged as minor 窶・the
    system never blocks an adult, it only adds a consent step when we know."""
    if not dob:
        return False
    today = _now_naive().date()
    age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    return age < 18


def consent_allows_monitoring(user: models.User) -> bool:
    """May this account's webcam/attention monitoring run right now?
    Adults always may; minors only when a real consent grant is on file."""
    if not user.is_minor:
        return True
    return user.consent_granted is True


def require_parent(authorization: Optional[str], db: Session) -> models.User:
    """Parent/guardian role gate: a signed-in user whose role is "parent".
    Raises 401/403 otherwise. The parent module ONLY ever gets focus data."""
    user = _require_user(authorization, db)
    if (user.role or "student") != "parent":
        logger.warning(
            "Parent access denied: user_id=%s, role=%s, email=%s",
            user.id,
            user.role or "student",
            user.email or user.serial_number,
        )
        raise HTTPException(403, "Parent/guardian account required")
    return user


def _normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def _user_by_identifier(db: Session, identifier: str) -> Optional[models.User]:
    """Resolves a login identifier 窶・email OR serial number 窶・case-insensitively."""
    ident = (identifier or "").strip()
    if not ident:
        return None
    needle = ident.lower()
    user = (
        db.query(models.User)
        .filter(func.lower(models.User.email) == needle)
        .first()
        if models.User.email is not None
        else None
    )
    if user is None:
        user = (
            db.query(models.User)
            .filter(func.lower(models.User.serial_number) == needle)
            .first()
        )
    return user


def _next_serial_number(db: Session) -> str:
    """Auto-generates a unique serial/ID number (the year + a random 4-digit
    suffix) for self-service registrations that only provide an email."""
    for _ in range(20):
        candidate = f"{datetime.now().year}-{secrets.randbelow(10000):04d}"
        exists = (
            db.query(models.User)
            .filter(func.lower(models.User.serial_number) == candidate.lower())
            .first()
        )
        if not exists:
            return candidate
    raise HTTPException(500, "Couldn't generate a unique serial number")


def db_has_users(db: Session) -> bool:
    """True once any account exists (managed mode). Used by WebSocket owners
    to reject unauthenticated sockets without a round-trip per user."""
    return (db.query(func.count(models.User.id)).scalar() or 0) > 0


RESET_CODE_TTL_SEC = 900  # 15 minutes to redeem a recovery code


def _issue_reset_code(db: Session, user: models.User) -> str:
    code = f"{secrets.randbelow(1_000_000):06d}"
    user.reset_code = code
    user.reset_code_expires = _now_naive() + timedelta(seconds=RESET_CODE_TTL_SEC)
    db.commit()
    db.refresh(user)
    logger.info("Password recovery code %s issued for user #%s", code, user.id)
    return code


# Focus/app events older than this are ignored for live status 窶・a stale
# open session (crash, abandoned tab) must not keep claiming "Focusing".
_STATUS_EVENT_MAX_AGE_SEC = 300


def _user_status(db: Session, user: models.User) -> tuple[str, Optional[str]]:
    """Live "what is this student doing right now" state for the hub. Only
    meaningful while the student is online 窶・offline always wins. For online
    students: their most recent active session decides, and within it the
    newest *recent* focus/app event decides between focusing and off-task.
    Focus events older than _STATUS_EVENT_MAX_AGE_SEC are ignored so a
    crashed run can't leave the student stuck on "Focusing" forever."""
    if user.id not in auth_service.user_ids_online():
        return "offline", None
    active = (
        db.query(models.StudySession)
        .filter(models.StudySession.user_id == user.id, models.StudySession.ended_at.is_(None))
        .order_by(models.StudySession.started_at.desc())
        .first()
    )
    if not active:
        return "signed_in", None
    cutoff = datetime.now(timezone.utc).timestamp() - _STATUS_EVENT_MAX_AGE_SEC
    latest = (
        db.query(models.FocusEvent)
        .filter(models.FocusEvent.session_id == active.id)
        .order_by(models.FocusEvent.timestamp.desc(), models.FocusEvent.id.desc())
        .first()
    )
    if latest:
        ts = latest.timestamp
        if ts is not None:
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            if ts.timestamp() < cutoff:
                # Open session but no live webcam/app ticks recently 窶・the
                # student is signed in, not actively studying from our view.
                return "signed_in", None
        # Debounced verdict: ONE manic tick (a glance sideways, an accidental
        # alt-tab for half a second) must not flip the admin screen to "Off
        # task" and back every few seconds — that is the "precise" version of
        # realtime presence. Read the latest 3 RECENT events and let the
        # majority decide; the flip still lands within a couple of ticks
        # (~2-4s). Stale events from an earlier run of the same session (a
        # re-attached token after a crash) are excluded from the vote — they
        # should not decide what the student is doing RIGHT NOW.
        cutoff_naive = datetime.utcnow() - timedelta(seconds=_STATUS_EVENT_MAX_AGE_SEC)
        window = (
            db.query(models.FocusEvent)
            .filter(
                models.FocusEvent.session_id == active.id,
                models.FocusEvent.timestamp >= cutoff_naive,
            )
            .order_by(models.FocusEvent.timestamp.desc(), models.FocusEvent.id.desc())
            .limit(3)
            .all()
        )
        off = sum(
            1
            for ev in window
            if ev.state in ("distracted", "sleeping", "absent") or ev.app_state == "off_task"
        )
        if off >= 2:
            return "off_task", active.task_description
        return "focusing", active.task_description
    return "studying", active.task_description


# Users whose most recent departure was a REAL sign-out (they called
# /auth/logout), so the hub can announce it immediately instead of waiting out
# the grace window it uses for tabs that merely went quiet. Entries are consumed
# by the presence broadcast that follows.
_EXPLICIT_LEAVES: dict[int, float] = {}


def _mark_explicit_leave(user_id: int) -> None:
    _EXPLICIT_LEAVES[user_id] = time.time()


def _broadcast_presence(db: Session, user: models.User) -> None:
    """Push this user's live status to every open Admin Hub socket so the
    hub updates without waiting for its poll (login/logout/social edges)."""
    try:
        status, task = _user_status(db, user)
        online = status != "offline"
        explicit_leave = False
        if not online and _EXPLICIT_LEAVES.pop(user.id, None) is not None:
            explicit_leave = True
        site_blocking.broadcast_admin_presence({
            "type": "presence",
            "user_id": user.id,
            "online": online,
            "status": status,
            "current_task": task,
            # True only for a sign-out the user actually performed, so the hub
            # can say "signed out" right now rather than after its grace window.
            "explicit_leave": explicit_leave,
        })
    except Exception:
        logger.debug("presence broadcast failed for user %s", user.id, exc_info=True)


def _user_out(user: models.User, db: Session, include_secret: bool = False) -> schemas.UserOut:
    last_login = (
        db.query(func.max(models.LoginEvent.login_at))
        .filter(models.LoginEvent.user_id == user.id)
        .scalar()
    )
    status, current_task = _user_status(db, user)
    return schemas.UserOut(
        id=user.id,
        serial_number=user.serial_number,
        email=user.email,
        full_name=user.full_name or "",
        is_active=user.is_active,
        blocked_sites=schemas.parse_stored_list(user.blocked_sites),
        allowed_sites=schemas.parse_stored_list(user.allowed_sites),
        last_login_at=last_login,
        # "Online" = the student's app is alive right now 窶・a live, recently
        # touched token. Not based on open login_events: a crashed app can
        # leave a stale open event behind and would otherwise read as
        # "online" forever. The frontend polls /policy/current every ~5s
        # while signed in, so a healthy student never flickers offline and a
        # closed app flips offline within ~30s.
        online=status != "offline",
        status=status,
        current_task=current_task,
        password=user.password_plain if include_secret else None,
        created_at=user.created_at,
        # --- role / age / consent / preferences (framework input) ---
        role=user.role or "student",
        date_of_birth=user.date_of_birth,
        is_minor=bool(user.is_minor),
        parent_id=user.parent_id,
        consent_granted=user.consent_granted,
        consent_at=user.consent_at,
        tutorial_seen=True if user.tutorial_seen is None else bool(user.tutorial_seen),
        settings=effective_settings(user),
    )


def _close_open_logins(db: Session, user_id: int, before: Optional[datetime] = None) -> int:
    """Closes every open login event for a user (crash recovery). Returns
    how many rows were closed."""
    q = db.query(models.LoginEvent).filter(
        models.LoginEvent.user_id == user_id,
        models.LoginEvent.logout_at.is_(None),
    )
    if before is not None:
        q = q.filter(models.LoginEvent.login_at <= before)
    rows = q.all()
    now = _now_naive()
    for row in rows:
        row.logout_at = now
    if rows:
        db.commit()
    return len(rows)


# ---------------------------------------------------------------------------
# Bootstrap + student auth
# ---------------------------------------------------------------------------

@router.get("/auth/bootstrap", response_model=schemas.BootstrapInfo)
def bootstrap(db: Session = Depends(get_db)):
    user_count = db.query(func.count(models.User.id)).scalar() or 0
    admin_count = db.query(func.count(models.Admin.id)).scalar() or 0
    return schemas.BootstrapInfo(
        requires_login=user_count > 0,
        has_admins=admin_count > 0,
        host="stubilly-admin",
    )


@router.post("/auth/register", response_model=schemas.UserOut)
def register(req: schemas.RegisterRequest, db: Session = Depends(get_db)):
    """Create an account 窶・SELF-SERVICE and open to anyone. Students sign up
    with an email (their login handle + password-recovery target) and get an
    auto-generated serial/ID number; a legacy admin-created student can also be
    carried in with just a serial number. The administrator no longer has to
    build student accounts; the hub only creates other administrators now.

    The FIRST account ever created still flips the deployment from legacy
    single-user mode into managed mode (its pre-auth session history is
    adopted exactly as before)."""
    password = req.password or ""
    serial = (req.serial_number or "").strip()
    email = _normalize_email(req.email)
    if not serial and not email:
        raise HTTPException(400, "An email (or serial/ID number) is required")
    if not password or len(password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    if email and not serial:
        serial = _next_serial_number(db)

    if db.query(models.User).filter(func.lower(models.User.serial_number) == serial.lower()).first():
        raise HTTPException(409, "A user with that serial/ID number already exists")
    if email:
        existing = (
            db.query(models.User)
            .filter(func.lower(models.User.email) == email)
            .first()
        )
        if existing:
            raise HTTPException(409, "An account with that email already exists")

    user_count = db.query(func.count(models.User.id)).scalar() or 0

    # --- Role gate (framework, input step 1): ONLY the administrator
    # provisions parent/guardian accounts. The public sign-up form is
    # student-only 窶・the format is admin 竊・guardian 竊・student.
    role = (req.role or "student").strip().lower()
    if role != "student":
        raise HTTPException(403, "Parent/guardian accounts are created by the administrator")
    # --- Age gate: self-registration is18+ (whoever signs up here created
    # the account themselves). The FIRST account ever (bootstrap owner of
    # this machine) is exempt 窶・it predates the managed flow. Under-18
    # students are created by their guardian (POST /parent/students) or by
    # the administrator (POST /admin/users).
    dob = parse_dob(req.date_of_birth)
    if user_count > 0:
        if not (req.date_of_birth or "").strip():
            raise HTTPException(
                400, "date_of_birth is required 窶・self-registration is for ages 18 and over"
            )
        if dob is None:
            raise HTTPException(400, "date_of_birth must be a real date (YYYY-MM-DD)")
        if is_minor_dob(dob):
            raise HTTPException(
                400,
                "Self-registration is for students 18 or older 窶・a parent or the "
                "administrator must create accounts for younger students",
            )
    parent_id = req.parent_id or None
    if parent_id is not None:
        parent = db.query(models.User).filter(models.User.id == parent_id).first()
        if not parent:
            raise HTTPException(404, "Linked parent account not found")
        if (parent.role or "student") != "parent":
            raise HTTPException(400, "parent_id must reference a parent-role account")
        if role == "parent":
            raise HTTPException(400, "A parent account cannot itself be linked to another parent")

    user = models.User(
        serial_number=serial,
        email=email or None,
        full_name=req.full_name.strip() or None,
        password_hash=auth_service.hash_password(password),
        password_plain=password,
        blocked_sites=None,
        allowed_sites=None,
        role=role,
        date_of_birth=dob,
        is_minor=is_minor_dob(dob),
        parent_id=parent_id,
        # Consent is NOT granted here: a minor's first grant must come from
        # the linked guardian (POST /parent/consent); an adult self-consents
        # via POST /me/consent. NULL = never asked.
        consent_granted=None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # Bootstrap migration: this is the FIRST account ever on the server, so
    # it's the machine's original owner. Claim any legacy unowned sessions
    # (recorded before accounts were turned on) for them 窶・their pre-auth
    # history stays theirs and, because the app scopes every session/progress
    # view to the account, accounts created later can never see it.
    if user_count == 0:
        db.query(models.StudySession).filter(models.StudySession.user_id.is_(None)).update(
            {models.StudySession.user_id: user.id}
        )
        db.commit()
        db.refresh(user)

    # Who joined: the admin hears about every account; a linked guardian
    # hears about students linked to them.
    _notify_admin_new_account(db, user, "self")
    if user.parent_id:
        _notify_parent_new_student(db, user)

    return _user_out(user, db)


@router.post("/auth/login", response_model=schemas.LoginResponse)
def login(req: schemas.LoginRequest, request: Request, db: Session = Depends(get_db)):
    # Brute-force guard: identical shape whether the identifier exists or
    # not (401 for wrong credentials, 429 once the cap is burned) so this
    # can't be used to enumerate accounts either.
    ident_key = f"login:{(req.serial_number or '').strip().lower()}"
    ip = request.client.host if request.client else "?"
    ip_key = f"loginip:{ip}"
    if auth_service.is_locked(ident_key, auth_service.login_max_fails()) or \
            auth_service.is_locked(ip_key, auth_service.login_max_fails_ip()):
        raise HTTPException(429, "Too many failed login attempts 窶・wait a few minutes and try again")
    identifier = (req.serial_number or "").strip()
    user = _user_by_identifier(db, identifier)
    if user is not None:
        if not auth_service.verify_password(req.password, user.password_hash):
            auth_service.note_fail(ident_key)
            auth_service.note_fail(ip_key)
            raise HTTPException(401, "Invalid email/serial number or password")
        auth_service.clear_fails(ident_key)
        auth_service.clear_fails(ip_key)
        if not user.is_active:
            raise HTTPException(403, "This account has been deactivated by the administrator")

        # Crash recovery: close any straggling open login so "online" status and
        # the login ledger stay truthful, then open a fresh one.
        _close_open_logins(db, user.id)
        db.add(models.LoginEvent(user_id=user.id, login_at=_now_naive(), device=req.device))
        db.commit()

        token = auth_service.issue_user_token(user.id)
        out = _user_out(user, db)
        _broadcast_presence(db, user)
        # Re-assert hosts from the stored admin policy: an open focus session
        # (or any other still-running run) gets the block immediately; with no
        # open session this clears leftover hosts lines so login alone never
        # leaves sites blocked after end session.
        try:
            enforcement = site_blocking.refresh_enforcement(effects=False)
            if not enforcement.get("ok"):
                logger.warning("site blocking refresh on login: %s", enforcement.get("error"))
        except Exception:
            logger.exception("site blocking refresh on login failed")
        return schemas.LoginResponse(token=token, user=out)

    # No such student — check the administrator table (kept entirely separate
    # from the student table). The same "Email or ID number" field carries the
    # admin's username here; only an exact username + password match on an
    # active administrator issues an admin token, so a student can never mint
    # one and an admin can never be confused for a student account.
    admin = (
        db.query(models.Admin)
        .filter(func.lower(models.Admin.username) == identifier.lower())
        .first()
    )
    if (
        admin is not None
        and admin.is_active
        and hmac.compare_digest(
            (req.password or "").encode("utf-8"),
            (admin.password or "").encode("utf-8"),
        )
    ):
        auth_service.clear_fails(ident_key)
        auth_service.clear_fails(ip_key)
        return schemas.LoginResponse(
            admin_token=auth_service.issue_admin_token(admin.id),
            admin=_admin_out(admin, include_secret=True),
        )

    auth_service.note_fail(ident_key)
    auth_service.note_fail(ip_key)
    raise HTTPException(401, "Invalid email/serial number or password")


@router.post("/auth/logout")
def logout(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    token = bearer_token(authorization)
    user_id = auth_service.get_user_from_token(token, touch=False)
    if user_id is not None:
        _close_open_logins(db, user_id)
        # Revoke THIS token only (logout of this tab/session). Multiple testers
        # share accounts in the prototype, so ending one session must never
        # knock another tester/logged-in tab out.
        auth_service.revoke_user_token(token)
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if user is not None:
            # Tell the hub this was a real sign-out, not a tab that went quiet:
            # it announces it at once instead of waiting out the grace window.
            _mark_explicit_leave(user_id)
            _broadcast_presence(db, user)
    return {"ok": True}


@router.get("/auth/me", response_model=schemas.UserOut)
def me(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    user = _require_user(authorization, db)
    return _user_out(user, db)


@router.post("/auth/tutorial-seen")
def auth_tutorial_seen(
    authorization: Optional[str] = Header(None), db: Session = Depends(get_db)
):
    """Mark the first-run coach-mark tutorial as finished for this account.

    Only newly created accounts carry tutorial_seen=False; once this endpoint
    is hit (or the user skips), the flag flips True and the walkthrough never
    shows again — on any browser. Legacy rows that predate the column keep
    NULL and are treated as already-seen by the schema."""
    user = _require_user(authorization, db)
    user.tutorial_seen = True
    db.add(user)
    db.commit()
    return {"ok": True, "tutorial_seen": True}


@router.post("/auth/keepalive")
def auth_keepalive(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    """Cheap "I'm still here" that keeps an idle tab signed in.

    A signed-in student or parent who simply leaves the app open makes no
    other authenticated call, so the token aged out and the app greeted them
    with "Your session expired - please sign in again". The app pings this
    endpoint on a timer and whenever the tab is looked at again, and the live
    WebSockets touch the token from the server side.

    A token that only went quiet (frozen tab, sleeping laptop) is resumed
    here rather than reported as expired. A real sign-out, or an account that
    has since been removed, is NOT resumed: the token is gone from both
    registries, and the account is re-checked below.

    Answers {"ok": false} with HTTP 200 for a dead session so a hiccup here
    never trips every caller at once - the next real request is what reports
    401 and sends the UI back to sign-in."""
    token = bearer_token(authorization)
    user_id = auth_service.touch_user_token(token)
    if user_id is None:
        user_id = auth_service.reactivate_user_token(token)
    if user_id is not None:
        user = db.query(models.User).filter(models.User.id == user_id).first()
        if user is None or not user.is_active:
            # The account was removed while the tab was idle: end the session
            # for real instead of handing back a token for nobody.
            auth_service.revoke_all_user_tokens(user_id)
            user_id = None
    return {"ok": user_id is not None}


# ---------------------------------------------------------------------------
# Self-service password recovery + change
# ---------------------------------------------------------------------------

def _host_is_local(request: Request) -> bool:
    """True only when the request clearly originates from this machine or
    the home LAN (loopback names, private IPs, or the TestClient's
    `testserver` Host). Anything else 窶・above all the public Tailscale
    funnel hostname 窶・counts as REMOTE, and remote callers never receive a
    reset code in the HTTP response. Without this check, two unauthenticated
    requests over the public link (`forgot-password` 竊・read `reset_code` 竊・
    `reset-password`) handed an internet attacker a full account takeover."""
    raw = (request.headers.get("host") or "").split(",")[0].strip().lower()
    if raw.startswith("["):
        host = raw[1:raw.find("]")] if "]" in raw else raw[1:]
    else:
        host = raw.split(":")[0].strip()
    if host in ("localhost", "127.0.0.1", "::1", "0.0.0.0", "testserver"):
        return True
    try:
        return ipaddress.ip_address(host).is_private
    except ValueError:
        return False


def _notify_admin_event(db: Session, kind: str, message: str, payload: dict) -> None:
    """Persist + push a generic Admin Hub notification (same channel the
    account-created alerts use) so the administrator sees security events
    such as a remote password-reset attempt in real time."""
    try:
        row = models.AdminNotification(
            kind=kind,
            message=message,
            payload=json.dumps(payload),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        site_blocking.broadcast_admin_presence({
            "type": "notification",
            "notification": {
                "id": row.id,
                "kind": row.kind,
                "message": row.message,
                "payload": json.loads(row.payload or "{}"),
                "read_at": None,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            },
        })
    except Exception:
        logger.exception("admin security notification failed")


# ---------------------------------------------------------------------------
# "Request an account" loop (public) + admin approval gate
# ---------------------------------------------------------------------------

def _iso_dt(dt: Optional[datetime]) -> Optional[str]:
    return dt.isoformat(sep=" ", timespec="seconds") if dt else None


def _account_request_out(row: models.AccountRequest) -> schemas.AccountRequestOut:
    return schemas.AccountRequestOut(
        id=row.id,
        full_name=row.full_name,
        email=row.email,
        role=row.role,
        message=row.message or "",
        status=row.status,
        created_at=_iso_dt(row.created_at),
        decided_at=_iso_dt(row.decided_at),
        decided_by=row.decided_by,
    )


@router.post("/auth/request-account")
def request_account(req: schemas.AccountRequestIn, db: Session = Depends(get_db)):
    """Public form alternative to self-sign-up: anyone may ASK for an account
    (parent or student); the administrator's bell rings instantly and the
    APPROVE action mints the account with the exact password they chose here
    (stored hashed only - approval reuses the hash, plaintext never lands on
    the server). The requester polls GET /auth/account-request?email= from
    the login screen and signs in once approved."""
    name = (req.full_name or "").strip()
    email = _normalize_email(req.email)
    if not name:
        raise HTTPException(400, "Your name is required")
    if not email or "@" not in email:
        raise HTTPException(400, "A valid email is required")
    password = req.password or ""
    if len(password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    role = (req.role or "parent").strip().lower()
    if role not in ("parent", "student"):
        raise HTTPException(400, "Role must be parent or student")

    existing_user = (
        db.query(models.User)
        .filter(func.lower(models.User.email) == email)
        .first()
    )
    if existing_user:
        raise HTTPException(409, "That email already has an account - sign in instead")
    pending = (
        db.query(models.AccountRequest)
        .filter(
            func.lower(models.AccountRequest.email) == email,
            models.AccountRequest.status == "pending",
        )
        .first()
    )
    if pending:
        raise HTTPException(409, "That email already has a request awaiting review")
    decided = (
        db.query(models.AccountRequest)
        .filter(func.lower(models.AccountRequest.email) == email)
        .order_by(models.AccountRequest.id.desc())
        .first()
    )
    if decided and decided.status == "approved":
        raise HTTPException(409, "That email was already approved - sign in instead")

    row = models.AccountRequest(
        full_name=name,
        email=email,
        role=role,
        password_hash=auth_service.hash_password(password),
        message=(req.message or "").strip()[:2000],
        status="pending",
    )
    db.add(row)
    db.commit()
    db.refresh(row)

    _notify_admin_event(
        db,
        "account_request",
        f"Account request: {name}",
        {
            "request_id": row.id,
            "name": row.full_name,
            "email": row.email,
            "role": row.role,
            "message": row.message,
        },
    )
    return {"status": "pending", "email": email}


@router.get("/auth/account-request", response_model=schemas.AccountRequestStatusOut)
def account_request_status(email: str, db: Session = Depends(get_db)):
    """Unauthenticated status poll for the requester at the login screen."""
    clean = _normalize_email(email)
    if not clean:
        return schemas.AccountRequestStatusOut(status="none", email="")
    row = (
        db.query(models.AccountRequest)
        .filter(func.lower(models.AccountRequest.email) == clean)
        .order_by(models.AccountRequest.id.desc())
        .first()
    )
    if not row:
        return schemas.AccountRequestStatusOut(status="none", email=clean)
    return schemas.AccountRequestStatusOut(
        status=row.status,
        email=clean,
        created_at=_iso_dt(row.created_at),
        decided_at=_iso_dt(row.decided_at),
    )


@router.get("/admin/account-requests", response_model=list[schemas.AccountRequestOut])
def admin_account_requests(
    status: str = "pending",
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    _require_admin(authorization)
    q = db.query(models.AccountRequest).order_by(models.AccountRequest.id.desc())
    if status and status != "all":
        q = q.filter(models.AccountRequest.status == status)
    return [_account_request_out(r) for r in q.limit(200).all()]


@router.post("/admin/account-requests/{request_id}/approve", response_model=schemas.UserOut)
def admin_account_request_approve(
    request_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """The approval half of the loop: mint the account with the requester's
    chosen password hash, then close the request. Mirrors register()'s
    provisioning (auto serial, consent NULL) with role taken from the
    request so BOTH parent and student paths work here - this IS the
    administrator provisioning, gated on their click."""
    _require_admin(authorization)
    admin = _require_admin_identity(authorization, db)
    row = db.get(models.AccountRequest, request_id)
    if not row:
        raise HTTPException(404, "Request not found")
    if row.status != "pending":
        raise HTTPException(409, f"Request already {row.status}")

    email = _normalize_email(row.email)
    if email and db.query(models.User).filter(func.lower(models.User.email) == email).first():
        row.status = "denied"
        row.decided_at = _now_naive()
        row.decided_by = admin.username
        db.commit()
        raise HTTPException(409, "That email already has an account")

    serial = _next_serial_number(db)
    user = models.User(
        serial_number=serial,
        email=email or None,
        full_name=row.full_name or None,
        password_hash=row.password_hash,
        # Never materialize plaintext: the request stored the hash already.
        password_plain=None,
        blocked_sites=None,
        allowed_sites=None,
        role=(row.role or "parent"),
        date_of_birth=None,
        is_minor=False,
        parent_id=None,
        consent_granted=None,
    )
    db.add(user)
    row.status = "approved"
    row.decided_at = _now_naive()
    row.decided_by = admin.username
    db.commit()
    db.refresh(row)

    _notify_admin_event(
        db,
        "account_request_approved",
        f"Account request approved: {row.full_name}",
        {
            "request_id": row.id,
            "user_id": user.id,
            "email": email,
            "role": user.role,
        },
    )
    return _user_out(user, db)


@router.post("/admin/account-requests/{request_id}/deny", response_model=schemas.AccountRequestDecisionOut)
def admin_account_request_deny(
    request_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    _require_admin(authorization)
    admin = _require_admin_identity(authorization, db)
    row = db.get(models.AccountRequest, request_id)
    if not row:
        raise HTTPException(404, "Request not found")
    if row.status != "pending":
        raise HTTPException(409, f"Request already {row.status}")
    row.status = "denied"
    row.decided_at = _now_naive()
    row.decided_by = admin.username
    db.commit()
    db.refresh(row)
    _notify_admin_event(
        db,
        "account_request_denied",
        f"Account request denied: {row.full_name}",
        {"request_id": row.id, "email": row.email, "role": row.role},
    )
    return schemas.AccountRequestDecisionOut(
        id=row.id, status=row.status, user_id=None, email=row.email
    )


@router.post("/auth/forgot-password", response_model=schemas.ResetCodeResponse)
def forgot_password(req: schemas.ForgotPasswordRequest, request: Request, db: Session = Depends(get_db)):
    """Issue a one-time recovery code for an account's email. Stubilly has no
    mail server, so on the LOCAL machine the code is returned in the
    response and printed to the backend log 窶・the person doing recovery is
    the person at the machine. A REMOTE caller (the public funnel, any
    non-local Host header) gets an identical `ok` response but NO code: the
    code still exists (and is logged here) for whoever is physically at the
    PC, and the administrator is notified of the remote attempt instead.
    The answer is deliberately identical (ok / found) whether or not the
    email exists, so this can't be used to enumerate which emails have
    accounts."""
    email = _normalize_email(req.email)
    if not email:
        raise HTTPException(400, "Email is required")
    found = None
    user = (
        db.query(models.User)
        .filter(func.lower(models.User.email) == email)
        .first()
    )
    if user and not user.is_active:
        user = None
    if user is not None:
        found = _issue_reset_code(db, user)
    if not found:
        return schemas.ResetCodeResponse(ok=True, reset_code=None)
    if _host_is_local(request):
        return schemas.ResetCodeResponse(ok=True, reset_code=found)
    # Remote request: withhold the code, tell the administrator.
    _notify_admin_event(
        db,
        "password_reset_remote",
        f"Remote password-reset request for {email} 窶・code withheld, only visible at the machine",
        {"user_id": user.id if user else None, "email": email,
         "host": request.headers.get("host")},
    )
    return schemas.ResetCodeResponse(ok=True, reset_code=None)


@router.post("/auth/reset-password")
def reset_password(req: schemas.ResetPasswordRequest, request: Request, db: Session = Depends(get_db)):
    """Redeem a recovery code: verify it, then set a brand-new password
    (the "forgot password 竊・reset and re-change their password" path).
    Failed redemptions are throttled per email (5 per window) so the
    6-digit code can't be ground down inside its 15-minute TTL."""
    email = _normalize_email(req.email)
    code = (req.code or "").strip()
    new_password = req.new_password or ""
    if not email or not code:
        raise HTTPException(400, "Email and recovery code are required")
    if len(new_password) < 8:
        raise HTTPException(400, "New password must be at least 8 characters")
    rkey = f"reset:{email}"
    if auth_service.is_locked(rkey, auth_service.reset_max_fails()):
        raise HTTPException(429, "Too many failed recovery attempts 窶・wait a few minutes and try again")
    user = (
        db.query(models.User)
        .filter(func.lower(models.User.email) == email)
        .first()
    )
    if not user or not user.reset_code or user.reset_code != code:
        auth_service.note_fail(rkey)
        raise HTTPException(400, "Invalid or expired recovery code")
    # reset_code_expires is stored as naive UTC (same clock as _now_naive()).
    if user.reset_code_expires is None or user.reset_code_expires < _now_naive():
        auth_service.note_fail(rkey)
        raise HTTPException(400, "That recovery code has expired 窶・request a new one")
    auth_service.clear_fails(rkey)
    user.password_hash = auth_service.hash_password(new_password)
    user.password_plain = new_password
    user.reset_code = None
    user.reset_code_expires = None
    db.commit()
    return {"ok": True}


@router.post("/auth/change-password")
def change_password(
    req: schemas.ChangePasswordRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Signed-in user changes their own password ("rechange my account
    password"): proves the current password, then sets a new one."""
    user = _require_user(authorization, db)
    if not req.current_password or not auth_service.verify_password(req.current_password, user.password_hash):
        raise HTTPException(403, "Current password is incorrect")
    new_password = req.new_password or ""
    if len(new_password) < 8:
        raise HTTPException(400, "New password must be at least 8 characters")
    user.password_hash = auth_service.hash_password(new_password)
    user.password_plain = new_password
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------------------
# Social sign-in (Google + GitHub, OAuth 2.0 authorization-code flow)
#
# Client credentials live in backend/.env (GOOGLE_CLIENT_ID/SECRET,
# GITHUB_CLIENT_ID/SECRET). Unconfigured providers simply aren't advertised.
# OAuth needs a web browser, so this is only surfaced in the web base / dev
# server (browser origin) 窶・never in the packaged Electron shell.
# ---------------------------------------------------------------------------

SOCIAL_STATE_TTL_SEC = 600
# state token -> (provider, redirect_uri, issued_at seconds)
_SOCIAL_STATES: dict[str, tuple[str, str, float]] = {}


def _social_configured() -> list[str]:
    providers = []
    if os.environ.get("GOOGLE_CLIENT_ID") and os.environ.get("GOOGLE_CLIENT_SECRET"):
        providers.append("google")
    if os.environ.get("GITHUB_CLIENT_ID") and os.environ.get("GITHUB_CLIENT_SECRET"):
        providers.append("github")
    return providers


@router.get("/auth/social/status", response_model=schemas.SocialProvidersOut)
def social_status():
    return schemas.SocialProvidersOut(providers=_social_configured())


@router.get("/auth/social/login/{provider}")
async def social_login_start(
    provider: str,
    redirect_uri: str = "",
    request: Request = None,
):
    """Starts the provider's OAuth dance. `redirect_uri` is where the browser
    should land back afterwards (with the session token) 窶・the SPA's own
    origin. The provider always sends the code to the BACKEND's callback
    endpoint (state-validated), never directly to the SPA."""
    if provider not in ("google", "github"):
        raise HTTPException(404, f"Unknown social provider '{provider}'")
    if provider not in _social_configured():
        raise HTTPException(404, f"'{provider}' sign-in is not configured (set its client id/secret in backend/.env)")
    if not redirect_uri:
        redirect_uri = str(request.base_url).rstrip("/")
    if not (redirect_uri.startswith("http://") or redirect_uri.startswith("https://")):
        raise HTTPException(400, "redirect_uri must be an http(s) URL")
    base = str(request.base_url).rstrip("/")
    callback_uri = f"{base}/auth/social/callback"
    state = secrets.token_urlsafe(24)
    _SOCIAL_STATES[state] = (provider, redirect_uri, time.time())

    if provider == "google":
        params = {
            "client_id": os.environ["GOOGLE_CLIENT_ID"],
            "redirect_uri": callback_uri,
            "response_type": "code",
            "scope": "openid email profile",
            "state": state,
            "prompt": "select_account",
        }
        auth_url = "https://accounts.google.com/o/oauth2/v2/auth"
    else:
        params = {
            "client_id": os.environ["GITHUB_CLIENT_ID"],
            "redirect_uri": callback_uri,
            "scope": "read:user user:email",
            "state": state,
        }
        auth_url = "https://github.com/login/oauth/authorize"

    from urllib.parse import urlencode
    return RedirectResponse(f"{auth_url}?{urlencode(params)}", status_code=302)


async def _exchange_google_profile(code: str, redirect_uri: str) -> tuple[str, str]:
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(
            "https://oauth2.googleapis.com/token",
            data={
                "client_id": os.environ["GOOGLE_CLIENT_ID"],
                "client_secret": os.environ["GOOGLE_CLIENT_SECRET"],
                "code": code,
                "grant_type": "authorization_code",
                "redirect_uri": redirect_uri,
            },
        )
        r.raise_for_status()
        tokens = r.json()
        r2 = await client.get(
            "https://www.googleapis.com/oauth2/v2/userinfo",
            headers={"Authorization": f"Bearer {tokens['access_token']}"},
        )
        r2.raise_for_status()
        profile = r2.json()
    email = (profile.get("email") or "").lower()
    if not email or not profile.get("verified_email"):
        raise HTTPException(401, "Google account has no verified email")
    return email, (profile.get("name") or "").strip()


async def _exchange_github_profile(code: str) -> tuple[str, str]:
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.post(
            "https://github.com/login/oauth/access_token",
            headers={"Accept": "application/json"},
            data={
                "client_id": os.environ["GITHUB_CLIENT_ID"],
                "client_secret": os.environ["GITHUB_CLIENT_SECRET"],
                "code": code,
            },
        )
        r.raise_for_status()
        tokens = r.json()
        access_token = tokens.get("access_token")
        if not access_token:
            raise HTTPException(401, "GitHub rejected the authorization code")
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Accept": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        r2 = await client.get("https://api.github.com/user", headers=headers)
        r2.raise_for_status()
        profile = r2.json()
        email = (profile.get("email") or "").lower()
        if not email:
            r3 = await client.get("https://api.github.com/user/emails", headers=headers)
            r3.raise_for_status()
            for entry in r3.json():
                if entry.get("primary") and entry.get("verified") and entry.get("email"):
                    email = entry["email"].lower()
                    break
    if not email:
        raise HTTPException(401, "GitHub account has no primary verified email")
    return email, (profile.get("name") or profile.get("login") or "").strip()


@router.get("/auth/social/callback")
async def social_callback(
    request: Request,
    code: str = "",
    state: str = "",
    error: str = "",
    db: Session = Depends(get_db),
):
    """Provider redirects the browser here after the user consents. Validates
    the state, exchanges the code for a profile, finds-or-creates the Stubilly
    account, signs the browser in, and sends it back to the SPA with a session
    token in the URL fragment: `#{origin}#social/token=...`."""
    entry = _SOCIAL_STATES.pop(state, None) if state else None
    if error:
        # The user cancelled at the provider 窶・return quietly, no session.
        if entry:
            return RedirectResponse(f"{entry[1]}#social/error=cancelled", status_code=302)
        raise HTTPException(400, f"Social sign-in failed: {error}")
    if not entry:
        raise HTTPException(400, "This sign-in link has expired or is invalid 窶・try again")
    provider, redirect_uri, issued_at = entry
    if time.time() - issued_at > SOCIAL_STATE_TTL_SEC:
        raise HTTPException(400, "This sign-in link has expired 窶・try again")
    if not code:
        raise HTTPException(400, "Provider returned no authorization code")

    try:
        if provider == "google":
            base = str(request.base_url).rstrip("/")
            email, name = await _exchange_google_profile(code, f"{base}/auth/social/callback")
        else:
            email, name = await _exchange_github_profile(code)
    except HTTPException:
        raise
    except Exception as e:  # httpx/network failures 窶・surface a friendly message
        logger.warning("Social exchange failed (%s): %s", provider, e)
        raise HTTPException(502, f"Couldn't reach {provider} 窶・try again")

    user = db.query(models.User).filter(func.lower(models.User.email) == email).first()
    if user:
        if not user.is_active:
            raise HTTPException(403, "This account has been deactivated by the administrator")
    else:
        # First visit via this provider: provision an account on the spot.
        serial = _next_serial_number(db)
        password = secrets.token_urlsafe(18)
        user = models.User(
            serial_number=serial,
            email=email,
            full_name=name or None,
            password_hash=auth_service.hash_password(password),
            password_plain=password,
            blocked_sites=None,
            allowed_sites=None,
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    _close_open_logins(db, user.id)
    db.add(models.LoginEvent(user_id=user.id, login_at=_now_naive(), device="browser"))
    db.commit()

    token = auth_service.issue_user_token(user.id)
    db.refresh(user)
    _broadcast_presence(db, user)
    return RedirectResponse(f"{redirect_uri}#social/token={token}", status_code=302)


# ---------------------------------------------------------------------------
# Admin: unlock the hidden hub
# ---------------------------------------------------------------------------

def _admin_out(admin: models.Admin, include_secret: bool = False) -> schemas.AdminOut:
    return schemas.AdminOut(
        id=admin.id,
        name=admin.name,
        username=admin.username,
        is_active=admin.is_active,
        created_at=admin.created_at,
        password=admin.password if include_secret else None,
    )


@router.post("/auth/admin-bootstrap", response_model=schemas.AdminLoginResponse)
def admin_bootstrap(req: schemas.AdminBootstrapRequest, db: Session = Depends(get_db)):
    """Create the FIRST administrator ever. This is the "please create an
    admin" door the hub shows when no admins exist yet 窶・once at least one
    admin exists this endpoint refuses and new admins are added by an
    existing admin instead."""
    admin_count = db.query(func.count(models.Admin.id)).scalar() or 0
    if admin_count > 0:
        raise HTTPException(403, "An administrator already exists 窶・log in with that account")
    name = req.name.strip()
    username = req.username.strip()
    password = req.password
    if not name or not username or not password or len(password) < 8:
        raise HTTPException(400, "Name, username and an 8+ character password are required")
    if db.query(models.Admin).filter(func.lower(models.Admin.username) == username.lower()).first():
        raise HTTPException(409, "That admin username is already taken")
    admin = models.Admin(name=name, username=username, password=password)
    db.add(admin)
    db.commit()
    db.refresh(admin)
    return schemas.AdminLoginResponse(
        admin_token=auth_service.issue_admin_token(admin.id),
        admin=_admin_out(admin, include_secret=True),
    )


@router.post("/admin/login", response_model=schemas.AdminLoginResponse)
def admin_login(req: schemas.AdminLoginRequest, request: Request, db: Session = Depends(get_db)):
    username = req.username.strip()
    ident_key = f"login:{username.lower()}"
    ip = request.client.host if request.client else "?"
    ip_key = f"loginip:{ip}"
    if auth_service.is_locked(ident_key, auth_service.login_max_fails()) or \
            auth_service.is_locked(ip_key, auth_service.login_max_fails_ip()):
        raise HTTPException(429, "Too many failed login attempts 窶・wait a few minutes and try again")
    admin = (
        db.query(models.Admin)
        .filter(func.lower(models.Admin.username) == username.lower())
        .first()
    )
    # Timing-safe compare (admin passwords are stored plainly by design 窶・
    # each admin reads their own back in the hub 窶・so constant-time here).
    if not admin or not admin.is_active or \
            not hmac.compare_digest(req.password.encode("utf-8"), (admin.password or "").encode("utf-8")):
        auth_service.note_fail(ident_key)
        auth_service.note_fail(ip_key)
        raise HTTPException(401, "Invalid administrator username or password")
    auth_service.clear_fails(ident_key)
    auth_service.clear_fails(ip_key)
    return schemas.AdminLoginResponse(
        admin_token=auth_service.issue_admin_token(admin.id),
        admin=_admin_out(admin, include_secret=True),
    )


@router.post("/admin/logout")
def admin_logout(authorization: Optional[str] = Header(None)):
    token = bearer_token(authorization)
    admin_id = auth_service.get_admin_id(token)
    if not admin_id:
        raise HTTPException(401, "Admin token required")
    # Revoke THIS token only 窶・session-scoped logout so one tester leaving
    # the admin hub never signs out the other admins logged in elsewhere.
    auth_service.revoke_admin_token(token)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Admin: user management + monitoring
# ---------------------------------------------------------------------------

@router.get("/admin/admins", response_model=list[schemas.AdminOut])
def admin_list_admins(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    """All administrator accounts. Names are shared with every admin; a
    password is returned ONLY for the calling admin's own row 窶・nobody can
    read another admin's password, but everyone sees each other's name."""
    me = _require_admin_identity(authorization, db)
    admins = db.query(models.Admin).order_by(models.Admin.created_at.desc()).all()
    return [_admin_out(a, include_secret=(a.id == me.id)) for a in admins]


@router.post("/admin/admins", response_model=schemas.AdminOut)
def admin_create_admin(
    req: schemas.AdminCreateRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Add another administrator with full, shared access (teaching staff
    all get the same hub powers). Requires an existing, active admin."""
    _require_admin(authorization)
    name = req.name.strip()
    username = req.username.strip()
    password = req.password
    if not name or not username or not password or len(password) < 8:
        raise HTTPException(400, "Name, username and an 8+ character password are required")
    if db.query(models.Admin).filter(func.lower(models.Admin.username) == username.lower()).first():
        raise HTTPException(409, "That admin username is already taken")
    admin = models.Admin(name=name, username=username, password=password)
    db.add(admin)
    db.commit()
    db.refresh(admin)
    return _admin_out(admin)


@router.delete("/admin/admins/{admin_id}")
def admin_delete_admin(
    admin_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    me = _require_admin_identity(authorization, db)
    if admin_id == me.id:
        raise HTTPException(400, "You can't delete your own account")
    admin = db.query(models.Admin).filter(models.Admin.id == admin_id).first()
    if not admin:
        raise HTTPException(404, "Admin not found")
    admin_count = db.query(func.count(models.Admin.id)).scalar() or 0
    if admin_count <= 1:
        raise HTTPException(400, "Can't delete the last administrator")
    # Revoke all tokens for this admin before deletion
    auth_service.revoke_all_admin_tokens(admin_id)
    db.delete(admin)
    db.commit()
    return {"ok": True}


@router.put("/admin/admins/me/password", response_model=schemas.AdminOut)
def admin_change_own_password(
    req: schemas.AdminPasswordRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    me = _require_admin_identity(authorization, db)
    if not req.password or len(req.password) < 8:
        raise HTTPException(400, "New password must be at least 8 characters")
    me.password = req.password
    db.commit()
    db.refresh(me)
    return _admin_out(me, include_secret=True)


@router.put("/admin/users/{user_id}/password", response_model=schemas.UserOut)
def admin_set_user_password(
    user_id: int,
    req: schemas.AdminPasswordRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """(Re)set a student's password. Also the way accounts created before
    plaintext capture existed get an admin-visible password: once set here
    the hub can read it like any other."""
    _require_admin(authorization)
    if not req.password or len(req.password) < 8:
        raise HTTPException(400, "New password must be at least 8 characters")
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.password_hash = auth_service.hash_password(req.password)
    user.password_plain = req.password
    db.commit()
    db.refresh(user)
    return _user_out(user, db, include_secret=True)


@router.get("/admin/users", response_model=list[schemas.UserOut])
def admin_list_users(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    _require_admin(authorization)
    users = db.query(models.User).order_by(models.User.created_at.desc()).all()
    return [_user_out(u, db, include_secret=True) for u in users]


@router.get("/admin/users/search", response_model=list[schemas.UserOut])
def admin_search_users(
    q: str = "",
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Quick lookup by full or partial serial number / email / name 窶・the fast
    path the admin types into first."""
    _require_admin(authorization)
    query = db.query(models.User)
    term = q.strip()
    if term:
        needle = f"%{term.lower()}%"
        query = query.filter(
            or_(
                func.lower(models.User.serial_number).like(needle),
                func.lower(models.User.email).like(needle),
                func.lower(models.User.full_name).like(needle),
            )
        )
    # Cap only guards pathological result sets 窶・500 keeps every realistic
    # classroom visible so a student beyond the first page still shows status.
    matches = query.order_by(models.User.created_at.desc()).limit(500).all()
    return [_user_out(u, db, include_secret=True) for u in matches]


@router.get("/admin/users/{user_id}", response_model=schemas.UserDetailOut)
def admin_get_user(user_id: int, authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    _require_admin(authorization)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")

    history = (
        db.query(models.LoginEvent)
        .filter(models.LoginEvent.user_id == user_id)
        .order_by(models.LoginEvent.login_at.desc())
        .limit(50)
        .all()
    )
    session_count = db.query(func.count(models.StudySession.id)).filter(
        models.StudySession.user_id == user_id
    ).scalar() or 0
    active_session_count = db.query(func.count(models.StudySession.id)).filter(
        models.StudySession.user_id == user_id,
        models.StudySession.ended_at.is_(None),
    ).scalar() or 0

    return schemas.UserDetailOut(
        user=_user_out(user, db, include_secret=True),
        session_count=session_count,
        active_session_count=active_session_count,
        login_history=[schemas.LoginEventOut.model_validate(e) for e in history],
    )


def _apply_policy_update(
    db: Session, user: models.User, req: schemas.PolicyUpdateRequest
) -> schemas.PolicyOut:
    """Shared block/allow-list apply path for the ADMIN and the student's
    own GUARDIAN (same rules, same live behavior). Saves apply LIVE
    mid-session via refresh_enforcement 窶・with no open session the hosts
    section stays empty (stored for the next session start). End session
    clears the hosts block entirely.

    Newly added blocked domains are still armed (kept for compatibility);
    attempt notifications no longer depend on that one-time arm 窶・every
    hit on an actively blocked host records and pushes blocked_attempt."""
    clean = lambda raw: [str(x).strip() for x in raw if str(x).strip()]
    old_blocked = {site_blocking._normalize_domain(x) for x in schemas.parse_stored_list(user.blocked_sites)}
    old_blocked.discard("")
    old_allowed = {site_blocking._normalize_domain(x) for x in schemas.parse_stored_list(user.allowed_sites)}
    old_allowed.discard("")

    new_blocked_list = clean(req.blocked_sites)
    new_allowed_list = clean(req.allowed_sites)
    new_blocked = {site_blocking._normalize_domain(x) for x in new_blocked_list}
    new_blocked.discard("")
    new_allowed = {site_blocking._normalize_domain(x) for x in new_allowed_list}
    new_allowed.discard("")

    user.blocked_sites = json.dumps(new_blocked_list) if new_blocked_list else None
    user.allowed_sites = json.dumps(new_allowed_list) if new_allowed_list else None
    user.policy_updated_at = _now_naive()
    db.commit()
    db.refresh(user)

    # Realtime notification arming: only domains the caller JUST added for
    # this user. Then prune globally so a domain stays armed only while
    # some student still has it effectively blocked (another student's
    # allow must not cancel this arm; removing/unblocking does).
    # NOTE: record_attempt no longer gates on these arms 窶・kept so older
    # callers / tests that inspect arm state keep working.
    newly_blocked = new_blocked - old_blocked
    if newly_blocked:
        site_blocking.arm_alerts(sorted(newly_blocked))
    still_blocked: set[str] = set()
    for u in db.query(models.User).all():
        b = {site_blocking._normalize_domain(x) for x in schemas.parse_stored_list(u.blocked_sites)}
        a = {site_blocking._normalize_domain(x) for x in schemas.parse_stored_list(u.allowed_sites)}
        still_blocked |= (b - a)
    still_blocked.discard("")
    site_blocking.prune_alerts(still_blocked)

    # Re-assert system-wide (hosts-file) enforcement immediately 窶・this is
    # what makes a block/unblock/apply apply LIVE in every browser (not
    # only mid-session) 窶・and push the new policy to the user's open
    # focus socket so their UI updates without waiting for the 5s poll.
    enforcement = site_blocking.refresh_enforcement()
    if not enforcement.get("ok"):
        logger.warning("site blocking enforcement failed: %s", enforcement.get("error"))
    site_blocking.broadcast_policy_refresh(user.id)

    return schemas.PolicyOut(
        blocked_sites=schemas.parse_stored_list(user.blocked_sites),
        allowed_sites=schemas.parse_stored_list(user.allowed_sites),
        updated_at=user.policy_updated_at,
    )


@router.put("/admin/users/{user_id}/policy", response_model=schemas.PolicyOut)
def admin_update_policy(
    user_id: int,
    req: schemas.PolicyUpdateRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Admin owns the block/allow lists (students cannot edit them in
    managed mode). See _apply_policy_update for the live-apply behavior."""
    _require_admin(authorization)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    return _apply_policy_update(db, user, req)


@router.get("/admin/users/{user_id}/login-history", response_model=list[schemas.LoginEventOut])
def admin_login_history(user_id: int, authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    _require_admin(authorization)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    rows = (
        db.query(models.LoginEvent)
        .filter(models.LoginEvent.user_id == user_id)
        .order_by(models.LoginEvent.login_at.desc())
        .limit(100)
        .all()
    )
    return [schemas.LoginEventOut.model_validate(r) for r in rows]


@router.get("/admin/users/{user_id}/sessions", response_model=list[schemas.AdminSessionOut])
def admin_user_sessions(
    user_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """One student's own past sessions 窶・the admin's per-account history view.
    Same shape as the all-accounts monitor list so the hub renders it the
    same way, but filtered down to a single user."""
    _require_admin(authorization)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    rows = (
        db.query(models.StudySession)
        .filter(models.StudySession.user_id == user_id)
        .order_by(models.StudySession.started_at.desc())
        .all()
    )
    return [
        schemas.AdminSessionOut(
            id=s.id,
            user_id=s.user_id,
            serial_number=user.serial_number,
            full_name=user.full_name or "",
            task_description=s.task_description,
            started_at=s.started_at,
            ended_at=s.ended_at,
            total_focused_seconds=s.total_focused_seconds or 0.0,
            total_distracted_seconds=s.total_distracted_seconds or 0.0,
            intervention_count=s.intervention_count or 0,
            subject=s.subject,
            deadline=s.deadline,
            priority=s.priority,
        )
        for s in rows
    ]


@router.get("/admin/sessions", response_model=list[schemas.AdminSessionOut])
def admin_list_sessions(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    """Every session across all accounts, newest first, with the account it
    belonged to 窶・the admin's bird's-eye monitor view."""
    _require_admin(authorization)
    rows = (
        db.query(models.StudySession, models.User.serial_number, models.User.full_name)
        .outerjoin(models.User, models.StudySession.user_id == models.User.id)
        .order_by(models.StudySession.started_at.desc())
        .all()
    )
    out = []
    for s, serial, name in rows:
        out.append(schemas.AdminSessionOut(
            id=s.id,
            user_id=s.user_id,
            serial_number=serial or "",
            full_name=name or "",
            task_description=s.task_description,
            started_at=s.started_at,
            ended_at=s.ended_at,
            total_focused_seconds=s.total_focused_seconds or 0.0,
            total_distracted_seconds=s.total_distracted_seconds or 0.0,
            intervention_count=s.intervention_count or 0,
            subject=s.subject,
            deadline=s.deadline,
            priority=s.priority,
        ))
    return out


# ---------------------------------------------------------------------------
# Student-facing policy (applied at session start + polled mid-session)
# ---------------------------------------------------------------------------

@router.get("/policy/current", response_model=schemas.PolicyOut)
def policy_current(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    user = _require_user(authorization, db)
    return schemas.PolicyOut(
        blocked_sites=schemas.parse_stored_list(user.blocked_sites),
        allowed_sites=schemas.parse_stored_list(user.allowed_sites),
        updated_at=user.policy_updated_at,
    )

# ---------------------------------------------------------------------------
# User settings (framework INPUT: check-in cadence / tone / webcam / voice)
# ---------------------------------------------------------------------------

def _settings_out(user: models.User) -> schemas.UserSettingsOut:
    s = effective_settings(user)
    return schemas.UserSettingsOut(
        check_in_interval_sec=s["check_in_interval_sec"],
        tone=s["tone"],
        webcam_enabled=bool(s["webcam_enabled"]),
        voice_mode=bool(s["voice_mode"]),
        adaptive_check_in=bool(s["adaptive_check_in"]),
        monitoring_enabled=bool(s["monitoring_enabled"]),
        custom_subjects=list(s.get("custom_subjects", [])),
    )


@router.get("/me/settings", response_model=schemas.UserSettingsOut)
def get_my_settings(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    user = _require_user(authorization, db)
    return _settings_out(user)


@router.put("/me/settings", response_model=schemas.UserSettingsOut)
def update_my_settings(
    req: schemas.UserSettingsUpdate,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Partial update 窶・only the keys present in the payload change."""
    user = _require_user(authorization, db)
    stored = {}
    if user.settings:
        try:
            parsed = json.loads(user.settings)
            if isinstance(parsed, dict):
                stored = parsed
        except (ValueError, TypeError):
            stored = {}

    if req.check_in_interval_sec is not None:
        # 0 disables periodic check-ins; anything else is clamped to 1..3600.
        stored["check_in_interval_sec"] = max(0, min(3600, int(req.check_in_interval_sec)))
    if req.tone is not None:
        if req.tone not in ("gentle", "firm"):
            raise HTTPException(400, "tone must be 'gentle' or 'firm'")
        stored["tone"] = req.tone
    if req.webcam_enabled is not None:
        stored["webcam_enabled"] = bool(req.webcam_enabled)
    if req.voice_mode is not None:
        stored["voice_mode"] = bool(req.voice_mode)
    if req.adaptive_check_in is not None:
        stored["adaptive_check_in"] = bool(req.adaptive_check_in)
    if req.custom_subjects is not None:
        # Sanitized on write too, so the stored blob is always clean.
        stored["custom_subjects"] = sanitize_custom_subjects(req.custom_subjects)

    user.settings = json.dumps(stored)
    db.commit()
    db.refresh(user)
    return _settings_out(user)


# ---------------------------------------------------------------------------
# Age / consent (framework process step 2)
# ---------------------------------------------------------------------------

def _write_consent(
    db: Session,
    user: models.User,
    granted: bool,
    granted_by: Optional[int],
    scope: Optional[str],
    note: Optional[str],
) -> models.ConsentRecord:
    """Updates the account's CURRENT consent and appends an audit row."""
    now = _now_naive()
    user.consent_granted = granted
    user.consent_at = now
    user.consent_granted_by = granted_by
    user.consent_scope = scope or None
    age_band = "minor" if user.is_minor else ("adult" if user.date_of_birth else "unknown")
    record = models.ConsentRecord(
        user_id=user.id,
        granted_by=granted_by,
        granted_at=now,
        granted=granted,
        scope=scope,
        age_band=age_band,
        note=note,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@router.post("/me/consent", response_model=schemas.ConsentRecordOut)
def record_my_consent(
    req: schemas.ConsentRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Self-consent. Adults may always consent for themselves; a MINOR may
    only withdraw their own consent here 窶・granting on a minor account
    requires the linked guardian (POST /parent/consent), because the whole
    point of the age gate is that a child can't authorise their own
    monitoring."""
    user = _require_user(authorization, db)
    if user.is_minor and req.granted:
        raise HTTPException(
            403,
            "A parent/guardian must grant monitoring consent for a minor account",
        )
    granted_by = user.id
    record = _write_consent(db, user, bool(req.granted), granted_by, req.scope, req.note)
    return record


@router.get("/me/consent/records", response_model=list[schemas.ConsentRecordOut])
def my_consent_history(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    user = _require_user(authorization, db)
    return (
        db.query(models.ConsentRecord)
        .filter(models.ConsentRecord.user_id == user.id)
        .order_by(models.ConsentRecord.granted_at.desc())
        .all()
    )


# ---------------------------------------------------------------------------
# Parent / guardian module
#   OUTPUT only: focus summaries + alerts + realtime notification.
#   Deliberately NO chat, NO notes, NO window content 窶・see conceptual
#   framework ("parent dashboard: real-time notification, no chat content").
# ---------------------------------------------------------------------------

def _student_rows(db: Session, parent: models.User) -> list[models.User]:
    return (
        db.query(models.User)
        .filter(models.User.parent_id == parent.id)
        .order_by(models.User.full_name.asc())
        .all()
    )


def _last_finished_session(db: Session, student_id: int):
    return (
        db.query(models.StudySession)
        .filter(
            models.StudySession.user_id == student_id,
            models.StudySession.ended_at.isnot(None),
        )
        .order_by(models.StudySession.ended_at.desc())
        .first()
    )


def _student_out(db: Session, student: models.User) -> schemas.ParentStudentOut:
    status, task = _user_status(db, student)
    last = _last_finished_session(db, student.id)
    last_focus_pct = None
    last_off_task_minutes = None
    if last is not None:
        duration = (last.total_focused_seconds or 0.0) + (last.total_distracted_seconds or 0.0)
        if duration > 0:
            last_focus_pct = round(100.0 * (last.total_focused_seconds or 0.0) / duration, 1)
        last_off_task_minutes = round((last.total_distracted_seconds or 0.0) / 60.0, 1)
    recent_alerts = (
        db.query(func.count(models.ParentAlert.id))
        .filter(
            models.ParentAlert.student_id == student.id,
            models.ParentAlert.read_at.is_(None),
        )
        .scalar()
        or 0
    )
    controls = effective_settings(student)
    return schemas.ParentStudentOut(
        id=student.id,
        serial_number=student.serial_number,
        full_name=student.full_name or "",
        is_minor=bool(student.is_minor),
        consent_granted=student.consent_granted,
        status=status,
        current_task=task,
        last_session_at=last.ended_at if last else None,
        last_focus_pct=last_focus_pct,
        last_off_task_minutes=last_off_task_minutes,
        recent_alert_count=int(recent_alerts),
        # Parental controls the guardian can view/edit on this card.
        blocked_sites=schemas.parse_stored_list(student.blocked_sites),
        allowed_sites=schemas.parse_stored_list(student.allowed_sites),
        daily_screen_limit_min=controls.get("daily_screen_limit_min"),
        downtime_start=controls.get("downtime_start"),
        downtime_end=controls.get("downtime_end"),
        device_paused=bool(controls.get("device_paused")),
        monitoring_enabled=bool(controls.get("monitoring_enabled", True)),
    )


@router.post("/parent/students", response_model=schemas.UserOut)
def parent_create_student(
    req: schemas.ParentCreateStudentRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """USERS flow: a guardian creates their own student account. The account
    is created already linked to this parent (parent_id set), so monitoring
    consent must be granted by the guardian before the first session runs.
    Only a parent-role caller may do this; anyone else gets 403."""
    parent = require_parent(authorization, db)

    password = req.password or ""
    if len(password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    name = (req.full_name or "").strip()
    if not name:
        raise HTTPException(400, "full_name is required")
    email = _normalize_email(req.email)
    if not email or "@" not in email:
        raise HTTPException(400, "A valid email is required")
    if db.query(models.User).filter(func.lower(models.User.email) == email).first():
        raise HTTPException(
            409,
            "An account with that email already exists 窶・"
            "use \"Link existing\" to attach it to you.",
        )

    dob = parse_dob(req.date_of_birth)
    user = models.User(
        serial_number=_next_serial_number(db),
        email=email,
        full_name=name,
        password_hash=auth_service.hash_password(password),
        password_plain=password,
        blocked_sites=None,
        allowed_sites=None,
        role="student",
        date_of_birth=dob,
        is_minor=is_minor_dob(dob),
        parent_id=parent.id,
        # NULL = consent never asked yet: this guardian grants it next.
        consent_granted=None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    # The admin hears about the new account; the guardian isn't echoed their
    # own creation (it's already in the list in front of them).
    _notify_admin_new_account(db, user, "parent")
    return _user_out(user, db)


@router.get("/parent/students", response_model=list[schemas.ParentStudentOut])
def parent_students(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    parent = require_parent(authorization, db)
    return [_student_out(db, s) for s in _student_rows(db, parent)]


def _parent_session_out(db: Session, s: models.StudySession) -> schemas.ParentSessionOut:
    """One session for the guardian's history view: when, on what, how it
    went, and what it was made of (screen seconds + the sites/app opened
    during it + the AI micro-task list). Activity rows only 窶・never content.
    started_at/ended_at are stored as (naive) UTC; activity rows as local
    time 窶・durations never mix the two."""
    is_active = s.ended_at is None
    end = s.ended_at or _now_naive()
    duration = 0.0
    if s.started_at is not None:
        try:
            duration = max(0.0, (end - s.started_at).total_seconds())
        except TypeError:
            duration = 0.0
    focus = s.total_focused_seconds or 0.0
    distract = s.total_distracted_seconds or 0.0
    focus_pct = (
        round(100.0 * focus / (focus + distract), 1)
        if (focus + distract) > 0 else None
    )
    acts = (
        db.query(models.SessionActivity)
        .filter(models.SessionActivity.session_id == s.id)
        .order_by(models.SessionActivity.seconds.desc())
        .all()
    )
    screen = sum(a.seconds for a in acts if a.kind == "screen")
    sites = [
        schemas.ParentSiteTop(site=a.name, seconds=round(a.seconds, 1))
        for a in acts if a.kind == "site" and a.name
    ][:10]
    apps = [
        schemas.ParentAppTop(app=a.name, seconds=round(a.seconds, 1))
        for a in acts if a.kind == "app" and a.name
    ][:10]
    window_rows = (
        db.query(models.WindowVisit)
        .filter(models.WindowVisit.session_id == s.id,
                models.WindowVisit.seconds > 0)
        .order_by(models.WindowVisit.seconds.desc())
        .limit(6)
        .all()
    )
    windows = [
        schemas.ParentWindowTime(
            app=w.app, title=w.title, seconds=round(w.seconds, 1)
        )
        for w in window_rows
    ]
    tasks = [
        schemas.ParentSessionTaskOut(
            description=t.description,
            estimated_minutes=t.estimated_minutes,
            completed=bool(t.completed),
        )
        for t in sorted(s.tasks, key=lambda t: t.order_index or 0)
    ]
    return schemas.ParentSessionOut(
        id=s.id,
        task_description=s.task_description or "",
        started_at=s.started_at,
        ended_at=s.ended_at,
        is_active=is_active,
        duration_seconds=round(duration, 1),
        focus_pct=focus_pct,
        off_task_minutes=round(distract / 60.0, 1),
        screen_seconds=round(screen, 1),
        top_sites=sites,
        top_apps=apps,
        recent_windows=windows,
        tasks=tasks,
    )


@router.post("/parent/students/link", response_model=schemas.ParentStudentOut)
def parent_link_existing_student(
    req: schemas.ParentLinkStudentRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Guardian attaches an ALREADY-EXISTING student account 窶・self-signed
    up, administrator-created, or studying right now 窶・to themselves by
    email or serial number. The account must not already belong to another
    guardian (409); linking twice is idempotent. This is the Family-Link
    "your child already has a Google account" flow."""
    parent = require_parent(authorization, db)
    ident = (req.identifier or "").strip()
    if not ident:
        raise HTTPException(400, "An email or student ID is required")
    student = _user_by_identifier(db, ident)
    if student is None or (student.role or "student") != "student":
        raise HTTPException(404, "No student account found with that email or ID")
    if student.parent_id == parent.id:
        return _student_out(db, student)  # already yours
    if student.parent_id is not None:
        raise HTTPException(409, "That student is already linked to another guardian")
    student.parent_id = parent.id
    db.commit()
    db.refresh(student)
    _notify_parent_new_student(db, student)
    return _student_out(db, student)


@router.get(
    "/parent/students/{student_id}/sessions",
    response_model=list[schemas.ParentSessionOut],
)
def parent_student_sessions(
    student_id: int,
    authorization: Optional[str] = Header(None),
    limit: int = 30,
    db: Session = Depends(get_db),
):
    """The guardian's per-session history for one linked student 窶・newest
    first, each with focus numbers, screen time, the sites/app used during
    it and the task list. Focus/activity data only, never chat or notes."""
    parent = require_parent(authorization, db)
    _linked_student(db, parent, student_id)
    rows = (
        db.query(models.StudySession)
        .filter(models.StudySession.user_id == student_id)
        .order_by(models.StudySession.started_at.desc())
        .limit(max(1, min(120, limit)))
        .all()
    )
    return [_parent_session_out(db, s) for s in rows]


@router.get(
    "/parent/students/{student_id}/activity",
    response_model=schemas.ParentActivityOut,
)
def parent_student_activity(
    student_id: int,
    authorization: Optional[str] = Header(None),
    date: Optional[str] = None,
    db: Session = Depends(get_db),
):
    """One local calendar day of a linked student's activity: the day's
    screen-time estimate, site/app time-on rows and every session that
    overlapped the day. `date` is YYYY-MM-DD local (defaults to today)."""
    parent = require_parent(authorization, db)
    _linked_student(db, parent, student_id)
    day = (date or "").strip() or datetime.now().strftime("%Y-%m-%d")
    try:
        day_start_local = datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        raise HTTPException(400, "date must be YYYY-MM-DD")
    day_end_local = day_start_local + timedelta(days=1)
    # Sessions are stored as naive UTC; convert the local day boundaries so
    # a day's sessions are matched exactly (spanning midnights included).
    day_start_utc = day_start_local.astimezone(timezone.utc).replace(tzinfo=None)
    day_end_utc = day_end_local.astimezone(timezone.utc).replace(tzinfo=None)

    site_rows = (
        db.query(models.SiteVisit)
        .filter(models.SiteVisit.user_id == student_id,
                models.SiteVisit.day == day)
        .order_by(models.SiteVisit.seconds.desc())
        .all()
    )
    app_rows = (
        db.query(models.AppVisit)
        .filter(models.AppVisit.user_id == student_id,
                models.AppVisit.day == day)
        .order_by(models.AppVisit.seconds.desc())
        .all()
    )
    screen = (
        db.query(models.ScreenTime)
        .filter(models.ScreenTime.user_id == student_id,
                models.ScreenTime.day == day)
        .first()
    )
    window_rows = (
        db.query(
            models.WindowVisit.app,
            models.WindowVisit.title,
            func.sum(models.WindowVisit.seconds).label("secs"),
        )
        .filter(models.WindowVisit.user_id == student_id,
                models.WindowVisit.day == day)
        .group_by(models.WindowVisit.app, models.WindowVisit.title)
        .order_by(func.sum(models.WindowVisit.seconds).desc())
        .all()
    )
    event_rows = (
        db.query(models.ActivityEvent)
        .filter(
            models.ActivityEvent.user_id == student_id,
            models.ActivityEvent.at < day_end_utc,
            models.ActivityEvent.at >= day_start_utc,
        )
        .order_by(models.ActivityEvent.at.desc())
        .limit(120)
        .all()
    )
    sessions = (
        db.query(models.StudySession)
        .filter(
            models.StudySession.user_id == student_id,
            models.StudySession.started_at < day_end_utc,
            or_(
                models.StudySession.ended_at.is_(None),
                models.StudySession.ended_at > day_start_utc,
            ),
        )
        .order_by(models.StudySession.started_at.desc())
        .limit(50)
        .all()
    )
    return schemas.ParentActivityOut(
        date=day,
        screen_seconds=round(screen.seconds, 1) if screen else 0.0,
        top_sites=[
            schemas.ParentSiteTop(site=r.site, seconds=round(r.seconds, 1))
            for r in site_rows
        ][:15],
        top_apps=[
            schemas.ParentAppTop(app=r.app, seconds=round(r.seconds, 1))
            for r in app_rows
        ][:15],
        top_windows=[
            schemas.ParentWindowTime(
                app=r[0], title=r[1], seconds=round(r[2] or 0.0, 1)
            )
            for r in window_rows
            if (r[2] or 0.0) > 0
        ][:15],
        sessions=[_parent_session_out(db, s) for s in sessions],
        events=[
            schemas.ParentActivityEvent(
                at=e.at, kind=e.kind, label=e.label, session_id=e.session_id
            )
            for e in event_rows
        ],
    )


@router.get("/parent/overview", response_model=schemas.ParentOverviewOut)
def parent_overview(authorization: Optional[str] = Header(None), db: Session = Depends(get_db)):
    """Dashboard header: linked students + unread alert count + 7-day
    aggregate (no per-message/chat data anywhere in this payload)."""
    parent = require_parent(authorization, db)
    students = _student_rows(db, parent)
    ids = [s.id for s in students]
    unread = 0
    total_sessions = 0
    focus_pcts: list[float] = []
    if ids:
        unread = (
            db.query(func.count(models.ParentAlert.id))
            .filter(models.ParentAlert.parent_id == parent.id,
                    models.ParentAlert.read_at.is_(None))
            .scalar()
            or 0
        )
        cutoff = _now_naive() - timedelta(days=7)
        rows = (
            db.query(models.StudySession)
            .filter(models.StudySession.user_id.in_(ids),
                    models.StudySession.ended_at.isnot(None),
                    models.StudySession.started_at >= cutoff)
            .all()
        )
        total_sessions = len(rows)
        for r in rows:
            dur = (r.total_focused_seconds or 0.0) + (r.total_distracted_seconds or 0.0)
            if dur > 0:
                focus_pcts.append(100.0 * (r.total_focused_seconds or 0.0) / dur)
    return schemas.ParentOverviewOut(
        students=[_student_out(db, s) for s in students],
        unread_alerts=int(unread),
        total_sessions=total_sessions,
        avg_focus_pct=round(sum(focus_pcts) / len(focus_pcts), 1) if focus_pcts else None,
    )


@router.get("/parent/alerts", response_model=list[schemas.ParentAlertOut])
def parent_alerts(
    authorization: Optional[str] = Header(None),
    unread: Optional[int] = None,
    student_id: Optional[int] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    parent = require_parent(authorization, db)
    q = db.query(models.ParentAlert).filter(models.ParentAlert.parent_id == parent.id)
    if unread:
        q = q.filter(models.ParentAlert.read_at.is_(None))
    # Per-student stream: with several students linked the dashboard asks
    # only for the one it is showing, keeping payloads small as the family
    # grows. Rows are already scoped to THIS guardian (no probing).
    if student_id:
        q = q.filter(models.ParentAlert.student_id == student_id)
    rows = q.order_by(models.ParentAlert.created_at.desc()).limit(max(1, min(500, limit))).all()
    names = {
        u.id: (u.full_name or u.serial_number)
        for u in db.query(models.User).filter(models.User.id.in_([r.student_id for r in rows])).all()
    } if rows else {}
    return [
        schemas.ParentAlertOut(
            id=r.id,
            student_id=r.student_id,
            student_name=names.get(r.student_id, ""),
            session_id=r.session_id,
            kind=r.kind,
            message=r.message,
            payload=json.loads(r.payload) if r.payload else {},
            read_at=r.read_at,
            created_at=r.created_at,
        )
        for r in rows
    ]


@router.post("/parent/alerts/read-all")
def parent_mark_all_alerts_read(
    authorization: Optional[str] = Header(None),
    student_id: Optional[int] = None,
    db: Session = Depends(get_db),
):
    """Bulk read for the guardian feed: with several students linked, a
    one-by-one click storm is a chore 窶・mark everything (or just one
    student's stream) read in a single call."""
    parent = require_parent(authorization, db)
    q = db.query(models.ParentAlert).filter(
        models.ParentAlert.parent_id == parent.id,
        models.ParentAlert.read_at.is_(None),
    )
    if student_id:
        q = q.filter(models.ParentAlert.student_id == student_id)
    updated = q.update(
        {models.ParentAlert.read_at: _now_naive()}, synchronize_session=False
    )
    db.commit()
    return {"updated": int(updated)}


@router.post("/parent/alerts/{alert_id}/read", response_model=schemas.ParentAlertOut)
def parent_mark_alert_read(
    alert_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    parent = require_parent(authorization, db)
    row = (
        db.query(models.ParentAlert)
        .filter(models.ParentAlert.id == alert_id,
                models.ParentAlert.parent_id == parent.id)
        .first()
    )
    if not row:
        raise HTTPException(404, "Alert not found")
    if row.read_at is None:
        row.read_at = _now_naive()
        db.commit()
        db.refresh(row)
    student = db.query(models.User).filter(models.User.id == row.student_id).first()
    return schemas.ParentAlertOut(
        id=row.id,
        student_id=row.student_id,
        student_name=(student.full_name or student.serial_number) if student else "",
        session_id=row.session_id,
        kind=row.kind,
        message=row.message,
        payload=json.loads(row.payload) if row.payload else {},
        read_at=row.read_at,
        created_at=row.created_at,
    )


@router.get("/parent/sites", response_model=schemas.ParentSitesOut)
def parent_sites(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Family-Link-style presence for each linked student: the site and
    app they were last seen on (live if within 2 minutes), whether they
    are inside Stubilly or elsewhere, today's time-on-site and app
    rankings, and the day's screen-time estimate. Presence only 窶・never
    page or window content."""
    parent = require_parent(authorization, db)
    now = datetime.now()
    day = now.strftime("%Y-%m-%d")
    students = (
        db.query(models.User)
        .filter(models.User.parent_id == parent.id)
        .order_by(models.User.id)
        .all()
    )
    out: list[schemas.ParentStudentSites] = []
    for st in students:
        current = (
            db.query(models.SiteVisit)
            .filter(models.SiteVisit.user_id == st.id)
            .order_by(models.SiteVisit.last_seen.desc())
            .first()
        )
        live = (
            current is not None
            and current.last_seen is not None
            and (now - current.last_seen).total_seconds() <= 120
        )
        current_app = (
            db.query(models.AppVisit)
            .filter(models.AppVisit.user_id == st.id)
            .order_by(models.AppVisit.last_seen.desc())
            .first()
        )
        app_live = (
            current_app is not None
            and current_app.last_seen is not None
            and (now - current_app.last_seen).total_seconds() <= 120
        )
        top_rows = (
            db.query(models.SiteVisit.site,
                     func.sum(models.SiteVisit.seconds).label("secs"))
            .filter(models.SiteVisit.user_id == st.id,
                    models.SiteVisit.day == day)
            .group_by(models.SiteVisit.site)
            .order_by(func.sum(models.SiteVisit.seconds).desc())
            .limit(8)
            .all()
        )
        app_rows = (
            db.query(models.AppVisit.app,
                     func.sum(models.AppVisit.seconds).label("secs"))
            .filter(models.AppVisit.user_id == st.id,
                    models.AppVisit.day == day)
            .group_by(models.AppVisit.app)
            .order_by(func.sum(models.AppVisit.seconds).desc())
            .limit(8)
            .all()
        )
        screen_row = (
            db.query(models.ScreenTime)
            .filter(models.ScreenTime.user_id == st.id,
                    models.ScreenTime.day == day)
            .first()
        )
        win = (
            db.query(models.WindowVisit)
            .filter(models.WindowVisit.user_id == st.id)
            .order_by(models.WindowVisit.last_seen.desc())
            .first()
        )
        win_live = (
            win is not None
            and win.last_seen is not None
            and (now - win.last_seen).total_seconds() <= 60
        )
        out.append(schemas.ParentStudentSites(
            id=st.id,
            name=st.full_name or st.serial_number,
            current_site=current.site if live else None,
            current_site_at=current.last_seen if live else None,
            current_app=current_app.app if app_live else None,
            current_app_at=current_app.last_seen if app_live else None,
            # Are they actually studying right now? Live sighting inside
            # Stubilly = yes; live sighting elsewhere = no; nothing fresh
            # = unknown (None).
            in_stubilly=(current.site == "stubilly") if live else None,
            # The window title in front right now (fresh = last 60s).
            current_window=win.title if win_live else None,
            current_window_at=win.last_seen if win_live else None,
            monitoring_enabled=bool(
                effective_settings(st).get("monitoring_enabled", True)
            ),
            screen_seconds_today=round(screen_row.seconds, 1) if screen_row else 0.0,
            top_sites=[schemas.ParentSiteTop(site=r[0], seconds=round(r[1] or 0.0, 1))
                       for r in top_rows if (r[1] or 0.0) > 0],
            top_apps=[schemas.ParentAppTop(app=r[0], seconds=round(r[1] or 0.0, 1))
                      for r in app_rows if (r[1] or 0.0) > 0],
        ))
    return schemas.ParentSitesOut(students=out)


def _linked_student(db: Session, parent: models.User, student_id: int) -> models.User:
    """Ownership gate for parent-scoped student operations: the student
    must exist AND be linked to THIS guardian, else 404 (no probing)."""
    student = db.query(models.User).filter(models.User.id == student_id).first()
    if student is None or student.parent_id != parent.id:
        raise HTTPException(404, "Linked student not found")
    return student


@router.put("/parent/students/{student_id}/policy", response_model=schemas.PolicyOut)
def parent_update_policy(
    student_id: int,
    req: schemas.PolicyUpdateRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """The guardian's own block/allow-list editor 窶・same live-apply path
    the administrator uses (hosts re-asserted, policy pushed to any open
    focus socket), scoped to students linked to THIS parent."""
    parent = require_parent(authorization, db)
    return _apply_policy_update(db, _linked_student(db, parent, student_id), req)


@router.put("/parent/students/{student_id}/limits", response_model=schemas.ParentStudentOut)
def parent_update_limits(
    student_id: int,
    req: schemas.ParentLimitsUpdate,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Parent-owned screen rules: daily screen-time limit, downtime
    window, and the device pause switch. Partial update 窶・a key is only
    touched when it is PRESENT in the payload (explicit null clears it).
    Enforced at session start and re-checked on every focus tick, so a
    pause or a reached limit ends a running session within a tick."""
    parent = require_parent(authorization, db)
    student = _linked_student(db, parent, student_id)

    stored: dict = {}
    if student.settings:
        try:
            parsed = json.loads(student.settings)
            if isinstance(parsed, dict):
                stored = parsed
        except (ValueError, TypeError):
            stored = {}

    if "daily_screen_limit_min" in req.model_fields_set:
        value = req.daily_screen_limit_min
        if value is not None and (isinstance(value, bool) or value < 0 or value > 1440):
            raise HTTPException(400, "daily_screen_limit_min must be 0..1440 (or null to clear)")
        stored["daily_screen_limit_min"] = value
    for key in ("downtime_start", "downtime_end"):
        if key in req.model_fields_set:
            raw = (getattr(req, key) or "").strip()
            if raw and not _HH_MM_RE.match(raw):
                raise HTTPException(400, f"{key} must be HH:MM (24h)")
            stored[key] = raw or None
    if "device_paused" in req.model_fields_set:
        stored["device_paused"] = bool(req.device_paused)
    if "monitoring_enabled" in req.model_fields_set:
        stored["monitoring_enabled"] = bool(req.monitoring_enabled)

    # start == end would be a zero-width window; effective_settings treats
    # it as "no downtime" 窶・normalize here too so the card shows it off.
    if stored.get("downtime_start") and stored.get("downtime_start") == stored.get("downtime_end"):
        stored["downtime_end"] = None

    student.settings = json.dumps(stored)
    db.commit()
    db.refresh(student)
    return _student_out(db, student)


@router.get("/me/live-window", response_model=schemas.LiveWindowOut)
def me_live_window(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """One-shot foreground-window snapshot taken by the backend itself
    (Windows API, no Electron needed). This is the browser-mode bridge:
    the client polls it every couple of seconds so the monitoring badge,
    on/off-task classification and presence all work in any browser 窶・
    on the student's own machine only, presence never content."""
    _require_user(authorization, db)
    return schemas.LiveWindowOut(**window_probe.read_foreground())


@router.post("/me/activity", response_model=schemas.ActivityBatchOut)
def me_activity(
    req: schemas.ActivityBatchIn,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """The client's click/view breadcrumb flush 窶・what the guardian's
    Activity timeline is built from. Parent-owned switch respected: with
    monitoring off nothing is stored (403 so the client stops queueing).
    Server timestamps each event (client clocks are untrusted); labels are
    element text/aria only 窶・never field values, keys, or page HTML."""
    user = _require_user(authorization, db)
    if not effective_settings(user).get("monitoring_enabled", True):
        raise HTTPException(403, "Activity monitoring is off")
    events = req.events or []
    if len(events) > 50:
        raise HTTPException(400, "batch too large (max 50 events)")
    if not events:
        return schemas.ActivityBatchOut(accepted=0)

    now = datetime.utcnow()
    valid_session_ids: set = set()
    added = 0
    for ev in events:
        kind = (ev.kind or "").strip().lower()[:32] or "click"
        if kind not in ("click", "view"):
            raise HTTPException(400, "kind must be 'click' or 'view'")
        label = (ev.label or "").strip()[:160]
        if not label:
            continue
        session_id = None
        if ev.session_id is not None:
            if ev.session_id not in valid_session_ids:
                owns = (
                    db.query(models.StudySession.id)
                    .filter(
                        models.StudySession.id == ev.session_id,
                        models.StudySession.user_id == user.id,
                    )
                    .first()
                )
                if owns is None:
                    raise HTTPException(400, "session_id does not belong to you")
                valid_session_ids.add(ev.session_id)
            session_id = ev.session_id
        db.add(
            models.ActivityEvent(
                user_id=user.id,
                session_id=session_id,
                at=now,
                kind=kind,
                label=label,
            )
        )
        added += 1
    # Retention: 30 days of breadcrumbs, at most 2000 rows per account.
    cutoff = now - timedelta(days=30)
    db.query(models.ActivityEvent).filter(
        models.ActivityEvent.user_id == user.id,
        models.ActivityEvent.at < cutoff,
    ).delete(synchronize_session=False)
    over = (
        db.query(func.count(models.ActivityEvent.id))
        .filter(models.ActivityEvent.user_id == user.id)
        .scalar()
        or 0
    ) - 2000
    if over > 0:
        oldest = (
            db.query(models.ActivityEvent)
            .filter(models.ActivityEvent.user_id == user.id)
            .order_by(models.ActivityEvent.at.asc())
            .limit(over)
            .all()
        )
        for row in oldest:
            db.delete(row)
    db.commit()
    return schemas.ActivityBatchOut(accepted=added)


@router.post("/parent/consent", response_model=schemas.ConsentRecordOut)
def parent_record_consent(
    req: schemas.ParentConsentRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """The guardian authorises (or withdraws) monitoring for a linked
    student. This is the ONLY path that can set consent_granted=True on a
    minor account."""
    parent = require_parent(authorization, db)
    student = db.query(models.User).filter(models.User.id == req.user_id).first()
    if not student:
        raise HTTPException(404, "Student account not found")
    if student.parent_id != parent.id:
        raise HTTPException(403, "That account is not linked to you")
    record = _write_consent(
        db, student, bool(req.granted), parent.id, req.scope, req.note
    )
    return record


# ---------------------------------------------------------------------------
# Admin: account creation (the ONLY door that makes guardian accounts)
# ---------------------------------------------------------------------------

@router.post("/admin/users", response_model=schemas.UserOut)
def admin_create_user(
    req: schemas.AdminCreateUserRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """The account factory. Format: the administrator creates parent /
    guardian accounts (the only way a guardian comes to exist) and may also
    create student accounts directly 窶・including minors linked to a
    guardian. Both creations notify the Admin Hub feed; a linked student
    also alerts their guardian."""
    _require_admin(authorization)

    role = (req.role or "student").strip().lower()
    if role not in ("student", "parent"):
        raise HTTPException(400, "role must be 'student' or 'parent'")
    password = req.password or ""
    if len(password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")

    email = _normalize_email(req.email)
    serial = (req.serial_number or "").strip()
    if email and not serial:
        serial = _next_serial_number(db)
    if not serial and not email:
        raise HTTPException(400, "An email (or serial/ID number) is required")
    if db.query(models.User).filter(func.lower(models.User.serial_number) == serial.lower()).first():
        raise HTTPException(409, "A user with that serial/ID number already exists")
    if email and (
        db.query(models.User).filter(func.lower(models.User.email) == email).first()
    ):
        raise HTTPException(409, "An account with that email already exists")

    dob = parse_dob(req.date_of_birth) if req.date_of_birth else None
    parent_id = req.parent_id or None
    if parent_id is not None:
        parent = db.query(models.User).filter(models.User.id == parent_id).first()
        if not parent:
            raise HTTPException(404, "Linked parent account not found")
        if (parent.role or "student") != "parent":
            raise HTTPException(400, "parent_id must reference a parent-role account")
        if role == "parent":
            raise HTTPException(400, "A parent account cannot itself be linked to another parent")

    user = models.User(
        serial_number=serial,
        email=email or None,
        full_name=(req.full_name or "").strip() or None,
        password_hash=auth_service.hash_password(password),
        password_plain=password,
        blocked_sites=None,
        allowed_sites=None,
        role=role,
        date_of_birth=dob,
        is_minor=is_minor_dob(dob),
        parent_id=parent_id,
        consent_granted=None,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    _notify_admin_new_account(db, user, "admin")
    if user.parent_id and role == "student":
        _notify_parent_new_student(db, user)
    return _user_out(user, db, include_secret=True)


# ---------------------------------------------------------------------------
# Admin: new-account notification feed
# ---------------------------------------------------------------------------

def _notif_out(row: models.AdminNotification) -> schemas.AdminNotificationOut:
    try:
        payload = json.loads(row.payload) if row.payload else {}
    except (ValueError, TypeError):
        payload = {}
    return schemas.AdminNotificationOut(
        id=row.id,
        kind=row.kind,
        message=row.message,
        payload=payload if isinstance(payload, dict) else {},
        read_at=row.read_at,
        created_at=row.created_at,
    )


@router.get("/admin/notifications", response_model=list[schemas.AdminNotificationOut])
def admin_notifications(
    limit: int = 50,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Newest-first feed of account-lifecycle notifications (replayed on
    hub open so nothing is missed while the hub was closed). Entries the
    calling admin has dismissed are filtered out for them only."""
    me = _require_admin_identity(authorization, db)
    dismissed_ids = [
        r[0]
        for r in db.query(models.AdminNotificationDismissal.notification_id)
        .filter(models.AdminNotificationDismissal.admin_id == me.id)
        .all()
    ]
    q = db.query(models.AdminNotification)
    if dismissed_ids:
        q = q.filter(~models.AdminNotification.id.in_(dismissed_ids))
    rows = (
        q.order_by(models.AdminNotification.created_at.desc())
        .limit(max(1, min(200, limit)))
        .all()
    )
    return [_notif_out(r) for r in rows]


@router.post("/admin/notifications/{notification_id}/read", response_model=schemas.AdminNotificationOut)
def admin_notification_read(
    notification_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    _require_admin(authorization)
    row = (
        db.query(models.AdminNotification)
        .filter(models.AdminNotification.id == notification_id)
        .first()
    )
    if not row:
        raise HTTPException(404, "Notification not found")
    if row.read_at is None:
        row.read_at = _now_naive()
        db.commit()
        db.refresh(row)
    return _notif_out(row)


@router.post("/admin/notifications/read-all")
def admin_notifications_read_all(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    _require_admin(authorization)
    db.query(models.AdminNotification).filter(
        models.AdminNotification.read_at.is_(None)
    ).update({models.AdminNotification.read_at: _now_naive()}, synchronize_session=False)
    db.commit()
    return {"ok": True}


@router.post("/admin/notifications/dismiss")
def admin_notifications_dismiss(
    req: schemas.AdminNotificationDismissRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Selective delete: drop THESE ids from the calling admin's bell only.
    Idempotent - unknown or already-dismissed ids are skipped, never 404."""
    me = _require_admin_identity(authorization, db)
    ids = list(dict.fromkeys(i for i in req.ids if isinstance(i, int)))[:500]
    if not ids:
        raise HTTPException(400, "No notification ids supplied")
    existing = {
        r[0]
        for r in db.query(models.AdminNotification.id)
        .filter(models.AdminNotification.id.in_(ids))
        .all()
    }
    if not existing:
        return {"ok": True, "dismissed": 0}
    already = {
        r[0]
        for r in db.query(models.AdminNotificationDismissal.notification_id)
        .filter(
            models.AdminNotificationDismissal.admin_id == me.id,
            models.AdminNotificationDismissal.notification_id.in_(sorted(existing)),
        )
        .all()
    }
    added = 0
    for nid in sorted(existing - already):
        db.add(
            models.AdminNotificationDismissal(
                admin_id=me.id, notification_id=nid
            )
        )
        added += 1
    if added:
        db.commit()
    return {"ok": True, "dismissed": added}


@router.post("/admin/notifications/clear")
def admin_notifications_clear(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Clear-all: dismiss every notification in the feed FOR THIS ADMIN ONLY.
    Other admins' bells are untouched."""
    me = _require_admin_identity(authorization, db)
    all_ids = [r[0] for r in db.query(models.AdminNotification.id).all()]
    already = {
        r[0]
        for r in db.query(models.AdminNotificationDismissal.notification_id)
        .filter(models.AdminNotificationDismissal.admin_id == me.id)
        .all()
    }
    added = 0
    for nid in all_ids:
        if nid not in already:
            db.add(
                models.AdminNotificationDismissal(
                    admin_id=me.id, notification_id=nid
                )
            )
            added += 1
    if added:
        db.commit()
    return {"ok": True, "dismissed": added}


@router.delete("/admin/notifications/{notification_id}")
def admin_notification_delete(
    notification_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Remove a notification from the Admin Hub feed. Used when the account a
    notification references has been deleted, so the bell stops offering a
    navigation target that can never resolve."""
    _require_admin(authorization)
    row = (
        db.query(models.AdminNotification)
        .filter(models.AdminNotification.id == notification_id)
        .first()
    )
    if not row:
        raise HTTPException(404, "Notification not found")
    db.delete(row)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------------------
# Admin: link/role/consent maintenance for the parent module
# ---------------------------------------------------------------------------

@router.put("/admin/users/{user_id}", response_model=schemas.UserOut)
def admin_update_user(
    user_id: int,
    req: schemas.AdminCreateUserRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Update an existing account's role, DOB/age band, and parent link 窶・
    the maintenance path for the parent module (re-link a student to a new
    guardian, mark an account as guardian, backfill a DOB)."""
    _require_admin(authorization)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")

    role = (req.role or user.role or "student").strip().lower()
    if role not in ("student", "parent"):
        raise HTTPException(400, "role must be 'student' or 'parent'")
    dob = parse_dob(req.date_of_birth) if req.date_of_birth else user.date_of_birth
    minor = is_minor_dob(dob)

    parent_id = req.parent_id if req.parent_id is not None else user.parent_id
    if parent_id is not None:
        if parent_id == user.id:
            raise HTTPException(400, "An account cannot be its own guardian")
        parent = db.query(models.User).filter(models.User.id == parent_id).first()
        if not parent or (parent.role or "student") != "parent":
            raise HTTPException(400, "parent_id must reference a parent-role account")
        if role == "parent":
            raise HTTPException(400, "A parent account cannot be linked to another parent")
    # A minor without a linked guardian is allowed to stay that way 窶・they
    # remain blocked from monitored sessions until a guardian is linked OR
    # an administrator grants monitoring consent explicitly (see
    # PUT /admin/users/{user_id}/consent below).

    user.role = role
    user.date_of_birth = dob
    user.is_minor = minor
    user.parent_id = parent_id
    db.commit()
    db.refresh(user)
    return _user_out(user, db, include_secret=True)


@router.put("/admin/users/{user_id}/consent", response_model=schemas.ConsentRecordOut)
def admin_record_consent(
    user_id: int,
    req: schemas.AdminConsentRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Administrator grants or revokes monitoring consent on a student
    account 窶・the one path that can unlock an INDEPENDENT (unlinked)
    minor, since a guardian must normally grant it (POST /parent/consent).
    The audit row's granted_by stays NULL by design (an admin is not a
    users row); the administrator's name is recorded in the note."""
    admin = _require_admin_identity(authorization, db)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    if (user.role or "student") != "student":
        raise HTTPException(400, "Monitoring consent applies to student accounts")
    note = req.note or (
        f"Granted by administrator {admin.name or admin.username}"
        if req.granted
        else f"Revoked by administrator {admin.name or admin.username}"
    )
    record = _write_consent(
        db, user, bool(req.granted), None, req.scope, note
    )
    # The student's waiting screen (and the next /auth/me) sees the fresh
    # flag immediately; no broadcast needed 窶・the recheck poll picks it up.
    return record


@router.delete("/admin/users/{user_id}")
def admin_delete_user(
    user_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Permanent removal of a parent or student account. A guardian's
    children are UNLINKED (never cascade-deleted) so they survive as
    independent accounts; all study data owned by the account is purged
    so no orphaned rows linger."""
    admin = _require_admin_identity(authorization, db)
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")

    label = user.email or user.serial_number
    snapshot = {
        "user_id": user.id,
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role or "student",
        "removed_by": admin.name or admin.username,
    }

    # Children of a removed guardian become independent accounts.
    db.query(models.User).filter(models.User.parent_id == user_id).update(
        {models.User.parent_id: None}, synchronize_session=False
    )

    session_ids = [
        row[0]
        for row in db.query(models.StudySession.id)
        .filter(models.StudySession.user_id == user_id)
        .all()
    ]
    if session_ids:
        quiz_ids = [
            row[0]
            for row in db.query(models.Quiz.id)
            .filter(models.Quiz.session_id.in_(session_ids))
            .all()
        ]
        if quiz_ids:
            db.query(models.QuizQuestion).filter(
                models.QuizQuestion.quiz_id.in_(quiz_ids)
            ).delete(synchronize_session=False)
        for model in (
            models.FocusEvent,
            models.Intervention,
            models.MicroTask,
            models.ChatMessage,
            models.StudyNote,
            models.Quiz,
            models.SessionActivity,
        ):
            db.query(model).filter(model.session_id.in_(session_ids)).delete(
                synchronize_session=False
            )

    db.query(models.ParentAlert).filter(
        or_(
            models.ParentAlert.parent_id == user_id,
            models.ParentAlert.student_id == user_id,
        )
    ).delete(synchronize_session=False)
    for model in (
        models.LoginEvent,
        models.ConsentRecord,
        models.SiteVisit,
        models.AppVisit,
        models.ScreenTime,
        models.WindowVisit,
        models.ActivityEvent,
        # Remembered sign-in tokens. SQLite runs with foreign_keys=ON, so these
        # rows must go before the account or the delete fails.
        models.UserSession,
    ):
        db.query(model).filter(model.user_id == user_id).delete(
            synchronize_session=False
        )

    db.delete(user)
    db.commit()

    # Revoke the removed account's tokens the moment it is gone. Otherwise the
    # token stays "live" for up to USER_TOKEN_TTL_SEC, and because SQLite
    # reuses row ids after a delete, a NEW account that lands on the same id
    # would inherit that presence 窶・the hub would show it as already signed in
    # and swallow its real sign-in notification.
    auth_service.revoke_all_user_tokens(user_id)

    # Clean up any admin notifications that reference this deleted user
    # (prevents 404 errors when clicking on notifications for deleted users)
    try:
        db.query(models.AdminNotification).filter(
            models.AdminNotification.payload.like(f'%"user_id": {user_id}%')
        ).delete(synchronize_session=False)
        db.commit()
    except Exception:
        logger.exception("failed to clean up notifications for deleted user")

    # Drop their online presence immediately, then log the removal in the
    # Admin Hub notification feed (same shape as account-created events).
    site_blocking.broadcast_admin_presence({
        "type": "presence",
        "user_id": user_id,
        "online": False,
        "status": "offline",
    })
    try:
        removal_payload = dict(snapshot)
        # An "account removed" notice must never offer a navigation target:
        # the user it describes no longer exists, so clicking would 404.
        removal_payload.pop("user_id", None)
        row = models.AdminNotification(
            kind="account_removed",
            message=f"Account removed by {snapshot['removed_by']}: {label}",
            payload=json.dumps(removal_payload),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        site_blocking.broadcast_admin_presence({
            "type": "notification",
            "notification": {
                "id": row.id,
                "kind": row.kind,
                "message": row.message,
                "payload": json.loads(row.payload or "{}"),
                "read_at": None,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            },
        })
    except Exception:
        logger.exception("admin account-removed notification failed")
    return {"ok": True, "id": user_id, "label": label}


# ---------------------------------------------------------------------------
# Admin chat: shared realtime admin-to-admin room (Admin Hub)
# ---------------------------------------------------------------------------

def _chat_out(row: models.AdminMessage, db: Session | None = None) -> schemas.AdminChatMessageOut:
    """One chat row for the hub. `db` is only needed to resolve the quoted
    reply; it is optional so callers that already hold a row can skip it."""
    reply_name = reply_body = None
    if row.reply_to_id:
        if db is not None:
            target = (db.query(models.AdminMessage)
                      .filter(models.AdminMessage.id == row.reply_to_id).first())
            if target is not None:
                reply_name = target.sender_name
                reply_body = "" if target.deleted_at else (target.body or "")
        else:
            reply_name = None
    return schemas.AdminChatMessageOut(
        id=row.id,
        admin_id=row.admin_id,
        sender_name=row.sender_name,
        body=row.body,
        created_at=row.created_at,
        reply_to_id=row.reply_to_id,
        reply_to_name=reply_name,
        reply_to_body=reply_body,
        edited_at=row.edited_at,
        deleted_at=row.deleted_at,
        attachment_kind=row.attachment_kind,
        attachment_token=row.attachment_path,
        attachment_name=row.attachment_name,
        attachment_mime=row.attachment_mime,
        attachment_size=row.attachment_size,
        attachment_seconds=row.attachment_seconds,
        pinned=bool(row.pinned or 0),
        important_label=row.important_label,
    )


# ---------------------------------------------------------------------------
# Admin chat attachments (pictures + voice notes, Telegram-style)
# ---------------------------------------------------------------------------
# Files live on disk, metadata on the message row. Names are generated by the
# server (32 hex chars) and validated again on every read, so nothing a
# browser sends can ever point outside the folder.
_CHAT_IMAGE_TYPES = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
}
_CHAT_AUDIO_TYPES = {
    "audio/webm": ".webm",
    "audio/ogg": ".ogg",
    "audio/mp4": ".m4a",
    "audio/mpeg": ".mp3",
    "audio/wav": ".wav",
    "audio/x-wav": ".wav",
    "audio/aac": ".aac",
}
_CHAT_MAX_IMAGE_BYTES = 8 * 1024 * 1024
_CHAT_MAX_AUDIO_BYTES = 16 * 1024 * 1024
_CHAT_TOKEN_RE = re.compile(r"^[0-9a-f]{32}\.[a-z0-9]{1,5}$")
_CHAT_MEDIA_JANITOR_AFTER = 24 * 60 * 60      # unreferenced files expire
_last_media_janitor = 0.0


def _chat_media_dir() -> str:
    """Where chat pictures/voice notes are stored. Lives next to the database
    so the packaged app (per-user app-data) and the dev server both have a
    writable folder, and so a backup of one folder carries both."""
    base = os.environ.get("STUBILLY_DB_PATH")
    folder = os.path.dirname(base) if base else os.path.join(
        os.environ.get("LOCALAPPDATA", os.path.dirname(base or ".")), "Stubilly")
    media = os.path.join(folder, "media")
    try:
        os.makedirs(media, exist_ok=True)
    except OSError:
        pass
    return media


def _chat_safe_display_name(raw: str | None, fallback: str) -> str:
    """The name shown under the picture. Display only - never a path."""
    name = os.path.basename((raw or "").strip())
    name = re.sub(r"[\x00-\x1f<>\"/\\|?*]", "", name).strip()
    return (name[:80] or fallback)


def _chat_attachment(token: str | None):
    """Turn an upload token into the message columns it fills, or None when
    there is no attachment. An unknown token is refused loudly (the browser
    thinks it sent a picture; silently posting text-only would hide that)."""
    if not token:
        return None
    if not _CHAT_TOKEN_RE.match(token or ""):
        raise HTTPException(400, "That attachment reference is not valid")
    if not os.path.isfile(os.path.join(_chat_media_dir(), token)):
        raise HTTPException(400, "That attachment could not be found - try sending it again")
    # Freshly uploaded: no message points at it yet, so the metadata comes from
    # the pending map (same process, seconds apart).
    pending = _PENDING_UPLOADS.get(token)
    if pending is not None:
        meta = pending[1]
        return (meta["kind"], meta["token"], meta["name"], meta["mime"],
                meta["size"], meta.get("seconds"))
    # After a server restart the pending map is gone but the file and its
    # message are not, so fall back to the message row.
    db = next(get_db())
    try:
        row = (db.query(models.AdminMessage)
               .filter(models.AdminMessage.attachment_path == token).first())
        if row is not None:
            return (row.attachment_kind, row.attachment_path, row.attachment_name,
                    row.attachment_mime, row.attachment_size, row.attachment_seconds)
    finally:
        db.close()
    raise HTTPException(400, "That attachment could not be found - try sending it again")


async def _chat_save_upload(file: UploadFile, seconds: float | None):
    """Stream one uploaded picture/voice note to the media folder and return
    its token. Reads in chunks and stops at the cap, so an oversized upload
    never lands on disk."""
    mime = (file.content_type or "").split(";")[0].strip().lower()
    if mime in _CHAT_IMAGE_TYPES:
        ext, kind, cap = _CHAT_IMAGE_TYPES[mime], "image", _CHAT_MAX_IMAGE_BYTES
    elif mime in _CHAT_AUDIO_TYPES:
        ext, kind, cap = _CHAT_AUDIO_TYPES[mime], "audio", _CHAT_MAX_AUDIO_BYTES
    else:
        raise HTTPException(
            400, "Only pictures (PNG, JPEG, GIF, WebP) and voice notes "
                 "(WebM, OGG, M4A, MP3, WAV, AAC) can be sent")

    token = f"{secrets.token_hex(16)}{ext}"
    path = os.path.join(_chat_media_dir(), token)
    written = 0
    try:
        with open(path, "wb") as fh:
            while True:
                chunk = await file.read(256 * 1024)
                if not chunk:
                    break
                written += len(chunk)
                if written > cap:
                    raise HTTPException(
                        413, f"That file is too large (max {cap // (1024 * 1024)} MB)")
                fh.write(chunk)
        if written == 0:
            raise HTTPException(400, "That file was empty")
    except HTTPException:
        _chat_unlink(path)
        raise
    except OSError as exc:
        _chat_unlink(path)
        raise HTTPException(500, f"Could not save the attachment: {exc}")

    name = _chat_safe_display_name(file.filename, f"{kind}-note")
    meta = {"token": token, "kind": kind, "name": name, "mime": mime,
            "size": written, "seconds": seconds if kind == "audio" else None}
    _chat_remember_upload(meta)
    return meta


def _chat_unlink(path: str) -> None:
    try:
        if path and os.path.isfile(path):
            os.remove(path)
    except OSError:
        pass


def _chat_delete_media(row: models.AdminMessage) -> None:
    """Remove the file behind a deleted message. The row keeps the reference,
    so the tombstone can still say 'photo deleted' and a media GET returns
    404 instead of a broken image."""
    if not row.attachment_path:
        return
    _chat_unlink(os.path.join(_chat_media_dir(), row.attachment_path))


# An upload that is never followed by a message is garbage; remember it for
# the janitor (token -> (uploaded_at, metadata)). The row is the real index
# once the message exists, so pending entries only live for minutes.
_PENDING_UPLOADS: dict[str, tuple] = {}


def _chat_remember_upload(meta: dict) -> None:
    _PENDING_UPLOADS[meta["token"]] = (time.time(), meta)


def _chat_media_janitor(force: bool = False) -> None:
    """Delete media files that no message points at, once every 10 minutes.
    An interrupted "upload then send" never leaves files behind forever."""
    global _last_media_janitor
    now = time.time()
    if not force and now - _last_media_janitor < 600:
        return
    _last_media_janitor = now
    folder = _chat_media_dir()
    try:
        entries = os.listdir(folder)
    except OSError:
        return
    db = next(get_db())
    try:
        used = {p for (p,) in db.query(models.AdminMessage.attachment_path)
                .filter(models.AdminMessage.attachment_path.isnot(None)).all()}
        for name in entries:
            if name in used or name in _PENDING_UPLOADS:
                continue
            path = os.path.join(folder, name)
            try:
                if os.path.isfile(path) and now - os.path.getmtime(path) > _CHAT_MEDIA_JANITOR_AFTER:
                    os.remove(path)
            except OSError:
                pass
        cutoff = now - _CHAT_MEDIA_JANITOR_AFTER
        for token, entry in list(_PENDING_UPLOADS.items()):
            if entry[0] < cutoff:
                _PENDING_UPLOADS.pop(token, None)
    except Exception:
        logger.warning("chat media janitor pass failed", exc_info=True)
    finally:
        db.close()


@router.post("/admin/chat/media")
async def admin_chat_upload(
    file: UploadFile = File(...),
    seconds: Optional[float] = Form(None),
    authorization: Optional[str] = Header(None),
):
    """Upload one picture or voice note for a chat message (multipart/form-data).

    Returns the token the sender then posts with the message, so an existing
    text-only client and an existing probe keep working untouched."""
    _require_admin(authorization)
    meta = await _chat_save_upload(file, seconds)
    return meta


@router.get("/admin/chat/media/{token}")
def admin_chat_media(
    token: str,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Serve an attachment. Admin-only: the token is unguessable, but the
    folder still holds whatever the staff share in this room."""
    _require_admin(authorization)
    if not _CHAT_TOKEN_RE.match(token or ""):
        raise HTTPException(404, "Attachment not found")
    path = os.path.join(_chat_media_dir(), token)
    if not os.path.isfile(path):
        raise HTTPException(404, "Attachment not found")
    row = (db.query(models.AdminMessage)
           .filter(models.AdminMessage.attachment_path == token).first())
    mime = (row.attachment_mime if row is not None and row.attachment_mime
            else ("image/png" if token.endswith((".png",)) else "application/octet-stream"))
    name = _chat_safe_display_name(row.attachment_name if row is not None else None, token)
    return FileResponse(path, media_type=mime, filename=name)


@router.get("/admin/chat/messages", response_model=list[schemas.AdminChatMessageOut])
def admin_chat_messages(
    limit: int = 200,
    before_id: Optional[int] = None,
    after_id: Optional[int] = None,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Chat history, oldest-first (replayed when the hub opens).

    Additive paging: `before_id` returns the page of messages OLDER than that
    id (scroll-up loading), `after_id` the page NEWER (catch-up). Each is the
    same oldest-first window the default call returns. A reply-jump uses
    `before_id` repeatedly until the quoted message is found, so jumping to a
    reply older than the newest 200 no longer silently does nothing."""
    _require_admin(authorization)
    # Self-throttled to once every 10 minutes; clears files left behind by an
    # upload that was never sent.
    _chat_media_janitor()
    q = db.query(models.AdminMessage)
    if before_id is not None:
        q = q.filter(models.AdminMessage.id < before_id)
    elif after_id is not None:
        q = q.filter(models.AdminMessage.id > after_id)
    rows = (
        q.order_by(models.AdminMessage.created_at.desc(), models.AdminMessage.id.desc())
        .limit(max(1, min(500, limit)))
        .all()
    )
    return [_chat_out(r, db) for r in reversed(rows)]


@router.post("/admin/chat/messages", response_model=schemas.AdminChatMessageOut)
def admin_chat_send(
    req: schemas.AdminChatMessageIn,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Post one message to the shared admin room; pushed live to every open
    Admin Hub socket over /ws/admin (type "chat_message").

    Optionally REPLIES to an earlier message (Telegram's quoted reply) and/or
    carries one picture or voice note that was uploaded first through
    POST /admin/chat/media. A caption is allowed with an attachment, so the
    only rejected message is one with neither text nor file."""
    admin = _require_admin_identity(authorization, db)
    body = (req.body or "").strip()
    attachment = _chat_attachment(req.attachment_token)
    if not body and not attachment:
        raise HTTPException(400, "Message cannot be empty")
    if len(body) > 2000:
        raise HTTPException(400, "Message too long (max 2000 characters)")

    reply_to_id = req.reply_to_id
    if reply_to_id is not None:
        target = (db.query(models.AdminMessage)
                  .filter(models.AdminMessage.id == reply_to_id).first())
        # A quote of a message that no longer exists is simply dropped rather
        # than rejected, so a stale client can still send its message.
        reply_to_id = target.id if target is not None else None

    row = models.AdminMessage(
        admin_id=admin.id,
        sender_name=admin.name or admin.username,
        body=body,
        reply_to_id=reply_to_id,
    )
    if attachment is not None:
        (row.attachment_kind, row.attachment_path, row.attachment_name,
         row.attachment_mime, row.attachment_size,
         row.attachment_seconds) = attachment
    db.add(row)
    db.commit()
    db.refresh(row)
    out = _chat_out(row, db)
    site_blocking.broadcast_admin_presence({
        "type": "chat_message_updated",
        "message": json.loads(out.model_dump_json()),
    })
    return out


# ---------------------------------------------------------------------------
# Smart intervention: proposal-ticket approval gate + AUTO toggle
# ---------------------------------------------------------------------------

_OPEN_TICKET_STATUSES = ("proposed", "suggested", "deferred")
_DECIDED_TICKET_STATUSES = ("blocked", "allowed_once", "denied")


def _ticket_out(row: models.BlockTicket, student_name: Optional[str]) -> schemas.BlockTicketOut:
    return schemas.BlockTicketOut(
        id=row.id,
        session_id=row.session_id,
        user_id=row.user_id,
        student_name=student_name,
        key=row.key,
        kind=row.kind,
        app=row.app or "",
        site=row.site,
        title=row.title,
        label=row.label,
        confidence=row.confidence or 0.0,
        sighting_count=row.sighting_count or 0,
        seconds=row.seconds or 0.0,
        task=row.task,
        status=row.status,
        strength=row.strength or "normal",
        evidence=row.evidence,
        auto_blocked=bool(row.auto_blocked),
        created_at=_iso_dt(row.created_at),
        decided_at=_iso_dt(row.decided_at),
        decided_by=row.decided_by,
    )


@router.get("/admin/block-tickets", response_model=list[schemas.BlockTicketOut])
def admin_block_tickets(
    status: str = "open",
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """status: open (default: proposed/suggested/deferred), a single status,
    decided (blocked/allowed_once/denied), or all."""
    _require_admin(authorization)
    q = (
        db.query(models.BlockTicket)
        .order_by(models.BlockTicket.id.desc())
    )
    if status in ("open", "", None):
        q = q.filter(models.BlockTicket.status.in_(_OPEN_TICKET_STATUSES))
    elif status == "decided":
        q = q.filter(models.BlockTicket.status.in_(_DECIDED_TICKET_STATUSES))
    elif status != "all":
        q = q.filter(models.BlockTicket.status == status)
    rows = q.limit(200).all()
    names: dict[int, str] = {}
    user_ids = sorted({r.user_id for r in rows})
    if user_ids:
        for u in db.query(models.User).filter(models.User.id.in_(user_ids)).all():
            names[u.id] = (u.full_name or u.email or "").strip()
    return [_ticket_out(r, names.get(r.user_id)) for r in rows]


@router.post("/admin/block-tickets/{ticket_id}/decision", response_model=schemas.BlockTicketOut)
def admin_block_ticket_decision(
    ticket_id: int,
    req: schemas.BlockTicketDecisionIn,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """The blueprint's approval gate: Block / Allow once / Deny / Defer.
    Block on a SITE appends the domain to that user's blocked_sites and
    re-arms the hosts-file enforcement; Block on an APP is enforced by the
    window monitor (session-scoped graceful close) because app windows can't
    be hosted-filed. Every decision is logged on the row + bell + guardian."""
    _require_admin(authorization)
    admin = _require_admin_identity(authorization, db)
    action = (req.action or "").strip().lower()
    if action not in ("block", "allow_once", "deny", "defer"):
        raise HTTPException(400, "action must be block, allow_once, deny or defer")
    row = db.get(models.BlockTicket, ticket_id)
    if not row:
        raise HTTPException(404, "Ticket not found")
    if row.status in _DECIDED_TICKET_STATUSES:
        raise HTTPException(409, f"Ticket already {row.status}")

    student = db.get(models.User, row.user_id)
    student_name = (student.full_name or student.email or "").strip() if student else None
    if action == "block":
        row.status = "blocked"
        if student and row.kind == "site" and row.site:
            current = schemas.parse_stored_list(student.blocked_sites)
            if row.site not in current:
                current.append(row.site)
                student.blocked_sites = json.dumps(current)
                student.policy_updated_at = _now_naive()
                db.commit()
            # Recompute + write the hosts file for every live session.
            site_blocking.refresh_enforcement(effects=True)
    elif action == "allow_once":
        row.status = "allowed_once"
    elif action == "deny":
        row.status = "denied"
    else:
        row.status = "deferred"
    row.decided_at = _now_naive()
    row.decided_by = admin.username
    db.commit()
    db.refresh(row)

    # Definitive labels (block = off-task confirmed, deny = on-task) feed
    # the learned relevance model; retrain happens in a background thread.
    if action in ("block", "deny"):
        ml_model.schedule_retrain()

    # Audit bell (the hub's notification history) + guardian alert + the
    # student's own nudge when their target actually got blocked.
    _notify_admin_event(
        db,
        "block_decision",
        f"Ticket {action}: {row.key} ({student_name or row.user_id})",
        {
            "ticket_id": row.id,
            "action": action,
            "key": row.key,
            "kind": row.kind,
            "label": row.label,
            "strength": row.strength,
            "user_id": row.user_id,
        },
    )
    if action == "block":
        if _parent_alert_emitter is not None:
            try:
                _parent_alert_emitter(
                    db,
                    row.user_id,
                    "blocked",
                    f"Blocked {row.site or row.app or row.key} for "
                    f"{student_name or 'your student'}",
                    {"ticket_id": row.id, "key": row.key, "kind": row.kind},
                    row.session_id,
                )
            except Exception:
                logger.exception("block parent alert failed")
        site_blocking.notify_user_blocked(
            row.user_id, row.site or row.app or row.key, reason="admin_blocked"
        )
    return _ticket_out(row, student_name)


def _intervention_settings_row(db: Session) -> models.AppSetting:
    row = db.get(models.AppSetting, "intervention")
    if not row:
        row = models.AppSetting(key="intervention", value=json.dumps({"auto_block": False}))
        db.add(row)
        db.commit()
        db.refresh(row)
    return row


@router.get("/admin/intervention-settings", response_model=schemas.InterventionSettingsOut)
def admin_intervention_settings(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    _require_admin(authorization)
    row = _intervention_settings_row(db)
    try:
        data = json.loads(row.value or "{}")
    except ValueError:
        data = {}
    return schemas.InterventionSettingsOut(auto_block=bool(data.get("auto_block", False)))


@router.put("/admin/intervention-settings", response_model=schemas.InterventionSettingsOut)
def admin_intervention_settings_update(
    req: schemas.InterventionSettingsIn,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    _require_admin(authorization)
    row = _intervention_settings_row(db)
    row.value = json.dumps({"auto_block": bool(req.auto_block)})
    db.commit()
    db.refresh(row)
    _notify_admin_event(
        db,
        "intervention_settings",
        "Intervention AUTO-block " + ("enabled" if req.auto_block else "disabled"),
        {"auto_block": bool(req.auto_block)},
    )
    return schemas.InterventionSettingsOut(auto_block=bool(req.auto_block))


@router.get("/admin/ml-model")
def admin_ml_model(authorization: Optional[str] = Header(None)):
    """Option B dashboard: accuracy snapshot + the bias-variance dial.
    Cold start returns trained=false and the default threshold — the UI
    shows rules-only mode until >= MIN_LABELED decided tickets exist."""
    _require_admin(authorization)
    return ml_model.model_info()


@router.put("/admin/ml-model/threshold")
def admin_ml_model_threshold(
    req: schemas.MlThresholdIn,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Persist the dial (clamped to [0.05, 0.95]) and apply it live —
    live_relevance gates the model floor on the next tick."""
    _require_admin(authorization)
    ml_model.set_threshold(db, req.threshold)
    return ml_model.model_info()


@router.put("/admin/chat/messages/{message_id}", response_model=schemas.AdminChatMessageOut)
def admin_chat_edit(
    message_id: int,
    req: schemas.AdminChatMessageEdit,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Edit the text of a message. Only the author may edit their own words
    (an admin cannot rewrite a colleague's message), and a deleted message is
    final. Broadcasts "chat_message_updated" so other hubs correct themselves
    instead of keeping the old text until they reload."""
    admin = _require_admin_identity(authorization, db)
    row = db.query(models.AdminMessage).filter(models.AdminMessage.id == message_id).first()
    if row is None:
        raise HTTPException(404, "Message not found")
    if row.admin_id != admin.id:
        raise HTTPException(403, "You can only edit your own messages")
    if row.deleted_at is not None:
        raise HTTPException(400, "That message was deleted")
    body = (req.body or "").strip()
    if not body:
        raise HTTPException(400, "Message cannot be empty")
    if len(body) > 2000:
        raise HTTPException(400, "Message too long (max 2000 characters)")
    row.body = body
    row.edited_at = _now_naive()
    db.commit()
    db.refresh(row)
    out = _chat_out(row, db)
    site_blocking.broadcast_admin_presence({
        "type": "chat_message_updated",
        "message": json.loads(out.model_dump_json()),
    })
    return out


@router.delete("/admin/chat/messages/{message_id}")
def admin_chat_delete(
    message_id: int,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Delete a message (Telegram-style: it disappears for everyone).

    Implemented as a tombstone so every open hub removes the same message by
    id; hard-deleting the row would leave the bubble on screen until reload.
    Only the author may delete their own message, and the file behind a
    picture/voice note is removed too. Broadcasts "chat_message_deleted"."""
    admin = _require_admin_identity(authorization, db)
    row = db.query(models.AdminMessage).filter(models.AdminMessage.id == message_id).first()
    if row is None:
        raise HTTPException(404, "Message not found")
    if row.admin_id != admin.id:
        raise HTTPException(403, "You can only delete your own messages")
    if row.deleted_at is not None:
        return {"ok": True, "already": True}
    row.deleted_at = _now_naive()
    row.body = ""
    row.edited_at = None
    db.commit()
    _chat_delete_media(row)
    site_blocking.broadcast_admin_presence({
        "type": "chat_message_deleted",
        "message_id": row.id,
    })
    return {"ok": True}


@router.put("/admin/chat/messages/{message_id}/flags", response_model=schemas.AdminChatMessageOut)
def admin_chat_flags(
    message_id: int,
    req: schemas.AdminChatFlagsIn,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Pin and/or label a message IMPORTANT. Unlike edit/delete this is open
    to any admin (a room keeps each other's anchors honest), does NOT mark the
    message as edited, and broadcasts "chat_message_updated" so every hub sees
    the pin/label change instantly. `pinned`/`important_label` are both
    optional so one call can touch only what it means to change."""
    _require_admin(authorization)
    row = db.query(models.AdminMessage).filter(models.AdminMessage.id == message_id).first()
    if row is None:
        raise HTTPException(404, "Message not found")
    if row.deleted_at is not None:
        raise HTTPException(400, "That message was deleted")
    if "pinned" in req.model_fields_set:
        row.pinned = 1 if req.pinned else 0
    if "important_label" in req.model_fields_set:
        label = (req.important_label or "").strip()
        if len(label) > 28:
            raise HTTPException(400, "Important label too long (max 28 characters)")
        row.important_label = label or None
    db.commit()
    db.refresh(row)
    out = _chat_out(row, db)
    site_blocking.broadcast_admin_presence({
        "type": "chat_message_updated",
        "message": json.loads(out.model_dump_json()),
    })
    return out
