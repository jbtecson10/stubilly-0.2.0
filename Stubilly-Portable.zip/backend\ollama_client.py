"""
Thin wrapper around Ollama's local REST API.

Why route through the backend instead of calling Ollama straight from
Electron (as the raw fetch() approach does): this is the one place that
enforces JSON-only output, retries on malformed responses, and lets you
swap models without touching frontend code.
"""
import httpx
import json
import logging
from typing import AsyncIterator, Optional

logger = logging.getLogger("stubilly.ollama")

OLLAMA_BASE_URL = "http://localhost:11434"
DEFAULT_MODEL = "llama3.2:3b"

# The companion chat is latency-sensitive (it's supposed to feel like typing
# with a friend), so its calls use a separate, tighter set of knobs than the
# task-breakdown/nudge calls above: fewer tokens, a smaller context window
# (faster prefill on a CPU), and ten-minute keep-alive so the model stays
# resident between turns instead of paying a cold-load penalty on every reply.
CHAT_OPTIONS = {"num_predict": 300, "num_ctx": 8192}
NOTE_OPTIONS = {"num_predict": 80}

# Task breakdown/refinement choices: the small local model tends to (a) drift
# toward generic study advice and (b) truncate long JSON answers on the
# default ~128-token cap, which silently falls through to the one-step
# fallback. Deterministic temperature + a real token budget for the JSON makes
# the checklist reliably topic-specific and complete.
TASK_OPTIONS = {"num_predict": 320, "num_ctx": 4096, "temperature": 0}

# Post-session quiz generation: needs room for ~5 MCQs as JSON, and a little
# temperature so questions aren't near-identical — but still low enough that
# the model stays anchored to the session material instead of inventing a
# generic exam.
QUIZ_OPTIONS = {"num_predict": 900, "num_ctx": 4096, "temperature": 0.3}


def _extract_json_docs(text: str) -> list:
    """
    Leniently parse JSON out of a raw model answer. The small local model
    occasionally emits multiple JSON documents back-to-back (e.g. an object,
    a newline, then another object), which a plain json.loads rejects and turns
    into a silent fallback. This scans for every JSON value in the text and
    returns them all, so the checklist/refine logic can act on what the model
    actually produced instead of discarding it.
    """
    cleaned = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    try:
        parsed = json.loads(cleaned)
        return [parsed]
    except json.JSONDecodeError:
        pass
    docs = []
    decoder = json.JSONDecoder()
    idx = 0
    while idx < len(cleaned):
        while idx < len(cleaned) and cleaned[idx] not in "[{":
            idx += 1
        if idx >= len(cleaned):
            break
        try:
            doc, end = decoder.raw_decode(cleaned, idx)
            docs.append(doc)
            idx = end
        except json.JSONDecodeError:
            idx += 1
    return docs


class OllamaUnavailableError(Exception):
    pass


async def _chat(
    messages: list[dict],
    model: str = DEFAULT_MODEL,
    timeout: float = 30.0,
    options: dict | None = None,
) -> str:
    """Low-level call to /api/chat. Raises OllamaUnavailableError if Ollama isn't running."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                f"{OLLAMA_BASE_URL}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": False,
                    # Keep the model resident for a while after this call so a
                    # follow-up reply doesn't pay the cold-load penalty.
                    "keep_alive": "10m",
                    "options": options or {},
                },
            )
            resp.raise_for_status()
            data = resp.json()
            return data["message"]["content"]
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException) as e:
        raise OllamaUnavailableError(
            "Can't reach Ollama at localhost:11434 — is it running? (run `ollama serve`)"
        ) from e
    except httpx.HTTPStatusError as e:
        raise OllamaUnavailableError(f"Ollama returned an error: {e}") from e


async def generate_microtasks(task_description: str, model: str = DEFAULT_MODEL) -> list[dict]:
    """
    Build the "Today's steps" checklist from the topic the student just typed.
    Every step is forced to be ABOUT that topic — the prompt forbids generic,
    topic-free advice and names the topic back so the steps stay anchored.
    Returns a list of {"description": str, "estimated_minutes": int}.
    Falls back to a single step (the task itself) if Ollama is unreachable or
    returns bad JSON, so the session never blocks on the LLM being down.
    """
    system_prompt = (
        "You create the 'Today's steps' checklist for a student, based ONLY on the exact "
        "topic they typed for this session (it is quoted below). Every step must be "
        "directly about THAT topic — concrete, specific, startable within ~10 minutes, "
        "and written so a reader can tell which topic it serves. Steps that could apply "
        "to any subject ('review notes', 'practice problems', 'stay focused') are "
        "forbidden unless they name precisely what to review or practice, drawn from the "
        "topic itself.\n"
        "Produce the MINIMUM number of crucial, high-impact steps (usually 2-4) that "
        "move this topic forward the most right now. Respond with ONLY a JSON array, "
        "no preamble, no markdown fences, no explanation.\n"
        'Format: [{"description": "...", "estimated_minutes": 8}, ...]'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f'Topic: "{task_description}"'},
            ],
            model=model,
            options=TASK_OPTIONS,
        )
        docs = _extract_json_docs(raw)
        candidates = []
        for d in docs:
            if isinstance(d, list):
                candidates.extend(d)
            elif isinstance(d, dict) and isinstance(d.get("tasks"), list):
                candidates.extend(d["tasks"])
        if candidates and all("description" in t for t in candidates):
            seen = set()
            deduped = []
            for t in candidates[:8]:
                desc = str(t["description"]).strip()
                key = desc.lower()
                if not desc or key in seen:
                    continue
                seen.add(key)
                deduped.append({
                    "description": desc,
                    "estimated_minutes": t.get("estimated_minutes") if isinstance(t.get("estimated_minutes"), int) else 10,
                })
            if deduped:
                return deduped[:4]
        raise ValueError("Malformed task list from model")
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Falling back to generic task breakdown: {e}")
        return [{"description": task_description, "estimated_minutes": 25}]


async def generate_quiz(
    task_description: str,
    subject: str | None = None,
    steps: list[str] | None = None,
    notes: list[str] | None = None,
    chat_excerpt: list[str] | None = None,
    difficulty: str = "medium",
    num_questions: int = 5,
    model: str = DEFAULT_MODEL,
) -> list[dict]:
    """
    Author a multiple-choice quiz on what the student actually studied in the
    session: their task, declared subject, checklist steps, captured notes and
    a chat excerpt. `difficulty` ("easy" | "medium" | "hard") is decided by
    the caller from focus performance — it shifts the cognitive level of the
    questions (recall -> application -> analysis), not the topic.

    Returns a list of {"prompt", "options": [str, ...], "correct_index": int}.
    Returns [] on any failure (LLM down / unusable JSON) — the caller then
    builds a deterministic quiz from the checklist so the flow never dead-ends.
    """
    steps = [s for s in (steps or []) if s][:8]
    notes = [n for n in (notes or []) if n][:6]
    chat_excerpt = [m for m in (chat_excerpt or []) if m][:6]

    level = {
        "easy": "recall — remember or recognise facts explicitly present in the material",
        "medium": "application — apply the material to a short, concrete situation",
        "hard": "analysis and synthesis — connect ideas, compare approaches, or "
                "reason through a multi-step scenario from the material",
    }.get(difficulty, "application")

    material_parts = [f"Session task: {task_description}"]
    if subject:
        material_parts.append(f"Declared subject: {subject}")
    if steps:
        material_parts.append("Study plan steps:\n" + "\n".join(f"- {s}" for s in steps))
    if notes:
        material_parts.append("Notes captured during the session:\n" + "\n".join(f"- {n}" for n in notes))
    if chat_excerpt:
        material_parts.append("Chat excerpt:\n" + "\n".join(chat_excerpt))
    material = "\n\n".join(material_parts)

    system_prompt = (
        "You write a short multiple-choice quiz for a student, testing what they "
        "studied in ONE study session. Use ONLY the material provided — never "
        "invent facts that are not in it, and make every question answerable "
        "from that material alone.\n"
        f"Difficulty: {difficulty} ({level}).\n"
        f"Produce exactly {num_questions} distinct questions, each with "
        "2-4 plausible options and exactly ONE correct option. Options must be "
        "short. Vary which option is correct. Do not reference 'the material "
        "above' — embed what's needed in the question text.\n"
        "Respond with ONLY a JSON array, no preamble, no markdown fences, no "
        "explanation.\n"
        'Format: [{"prompt": "...", "options": ["...", "..."], "correct_index": 0}, ...]'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": material},
            ],
            model=model,
            options=QUIZ_OPTIONS,
        )
        docs = _extract_json_docs(raw)
        candidates: list = []
        for d in docs:
            if isinstance(d, list):
                candidates.extend(d)
            elif isinstance(d, dict) and isinstance(d.get("questions"), list):
                candidates.extend(d["questions"])
        validated = []
        seen = set()
        for q in candidates:
            if not isinstance(q, dict):
                continue
            prompt = str(q.get("prompt") or "").strip()
            opts = q.get("options")
            if not prompt or not isinstance(opts, list):
                continue
            options = [str(o).strip() for o in opts if str(o).strip()]
            try:
                correct = int(q.get("correct_index"))
            except (TypeError, ValueError):
                continue
            if len(options) < 2 or len(options) > 4 or not (0 <= correct < len(options)):
                continue
            key = prompt.lower()
            if key in seen:
                continue
            seen.add(key)
            validated.append({
                "prompt": prompt,
                "options": options,
                "correct_index": correct,
            })
            if len(validated) >= num_questions:
                break
        if not validated:
            raise ValueError("No usable questions in model output")
        return validated
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Quiz generation falling back to checklist questions: {e}")
        return []


async def refine_tasks(
    task_description: str,
    current_tasks: list[str],
    transcript: str,
    model: str = DEFAULT_MODEL,
) -> list[dict] | None:
    """
    The live "today's steps" adjuster: after a chat turn, decides whether the
    conversation revealed something that genuinely changes the student's plan
    (a new must-do step, a step that is now obsolete, or one that needs to be
    reworded to be precise) and, only then, returns the full target checklist.

    Deliberately conservative — the model returns changed:false for the vast
    majority of turns (chit-chat, a helpful explanation, a quick answer all
    leave the plan untouched). The caller also compares against the current
    checklist and skips the write if nothing actually changed, so the panel
    never churns. Returns None when the plan should stay as-is.
    """
    current_bullets = "\n".join(f"- {t}" for t in current_tasks) or "- (empty)"
    system_prompt = (
        "You keep a student's live focus-session checklist. It holds ONLY the crucial, "
        "highest-impact steps needed right now — 2-4 sharp items, no filler, no busywork. "
        "Given the student's task, their CURRENT checklist, and the most recent conversation, "
        "say the plan CHANGED when the conversation reveals any of these concrete signals:\n"
        "  - a new assignment or deliverable is due (e.g. 'worksheet on X due today');\n"
        "  - the professor/exam specified a subtopic or skill that must be added;\n"
        "  - the student reports a blocker, a mistake, or a discovered gap in what they planned;\n"
        "  - the student explicitly re-prioritizes ('I need to finish X first').\n"
        "When changed, the target checklist is the FULL new plan (2-4 items, importance order), "
        "keeping whatever is still relevant verbatim-ish and swapping in what the chat proved must "
        "change. If the student has clearly switched to a different subject than the session task, "
        "the new checklist follows THEIR stated subject, not the old one. DO NOT change the plan for "
        "small talk, thanks, generic encouragement, or "
        "explanations of what is already on the checklist  Ethose return changed:false. "
        "When unsure, keep the plan as-is.\n"
        'Respond with ONLY JSON, no markdown fences: {"changed": true/false}. When true, include '
        '"tasks": [{"description": "...", "estimated_minutes": int}, ...], descriptions short, '
        "action-first, each startable within ~10 minutes."
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"Task: {task_description}\n\n"
                        f"Current checklist:\n{current_bullets}\n\n"
                        f"Recent conversation:\n{transcript}"
                    ),
                },
            ],
            model=model,
            timeout=20.0,
            options=TASK_OPTIONS,
        )
        docs = _extract_json_docs(raw)
        changed = any(d.get("changed") if isinstance(d, dict) else False for d in docs)
        if not changed:
            return None
        tasks = None
        for d in docs:
            if isinstance(d, dict) and isinstance(d.get("tasks"), list):
                tasks = d["tasks"]
                break
        valid = isinstance(tasks, list) and tasks and all(
            isinstance(t.get("description"), str) and t["description"].strip() for t in tasks
        )
        return tasks if valid else None
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError, TypeError) as e:
        logger.info(f"Checklist refine skipped: {e}")
        return None


async def generate_nudge_message(task_description: str, distracted_seconds: int, model: str = DEFAULT_MODEL) -> str:
    """Short, encouraging nudge shown when the student has been distracted for a while."""
    system_prompt = (
        "You are Stubilly, a warm, non-judgmental study companion. The student has been "
        "distracted for a bit. Write ONE short sentence (under 20 words) gently nudging them "
        "back to their task. No preamble, just the sentence."
    )
    try:
        return await _chat(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": f"Task: {task_description}. Distracted for {distracted_seconds} seconds.",
                },
            ],
            model=model,
        )
    except OllamaUnavailableError:
        return "Hey — still with me? Let's get back to it."


async def generate_check_in_prompt(
    task_description: str,
    minutes_in: int,
    tone: str = "gentle",
    focus_pct: Optional[float] = None,
    model: str = DEFAULT_MODEL,
) -> str:
    """Generative periodic check-in: ONE short, context-aware question about
    the student's task. `focus_pct` (0-100, optional) tailors the wording — a
    struggling run asks how the student is doing, a solid one invites the next
    step. Falls back to a plain static line when the model is unavailable."""
    focus_note = (
        f"Their measured focus so far is about {int(focus_pct)}% (lower = distracted). "
        if focus_pct is not None
        else "No focus readings yet this run. "
    )
    if tone == "firm":
        sys = (
            "You are Stubilly, a direct, action-oriented study coach. Write ONE short "
            "sentence (under 18 words) for a periodic progress check-in. Ask the student "
            "where they stand on their task or what the next concrete step is — "
            "straight to the point, no fluff, never accusatory."
        )
    else:
        sys = (
            "You are Stubilly, a warm, non-judgmental study companion. Write ONE short, "
            "encouraging sentence (under 18 words) for a periodic progress check-in. "
            "Ask how the student is doing on their task or what they need to keep going — "
            "supportive, no preamble."
        )
    try:
        text = await _chat(
            [
                {"role": "system", "content": sys},
                {
                    "role": "user",
                    "content": (
                        f"Task: {task_description}. Minutes in so far: {minutes_in}. "
                        f"{focus_note}Write just the check-in question."
                    ),
                },
            ],
            model=model,
        )
    except OllamaUnavailableError:
        return (
            f"Check-in — about {minutes_in} min on \"{task_description[:60]}\". "
            "How's it going?"
        )
    if not text or not str(text).strip():
        return (
            f"Check-in — about {minutes_in} min on \"{task_description[:60]}\". "
            "How's it going?"
        )
    return str(text).strip()


async def generate_study_links(task_description: str, model: str = DEFAULT_MODEL) -> list[str]:
    """2-3 suggested search queries/topics related to the task, for a distracted student."""
    system_prompt = (
        "Given a student's task, suggest 2-3 short, specific search queries or documentation "
        "topics that would help them. Respond with ONLY a JSON array of strings, no explanation. "
        'Format: ["query 1", "query 2"]'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": task_description},
            ],
            model=model,
        )
        cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        links = json.loads(cleaned)
        if isinstance(links, list):
            return links
        raise ValueError
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError):
        return []


def build_companion_system_prompt(task_description: str, focus_state: str = "", seconds_in_state: int = 0) -> str:
    """
    Plain, friendly study-assistant system prompt. No persona framing, no
    "break it down one step at a time" script — just a supportive helper that
    answers clearly and briefly. Chat speed comes from the streaming path and
    the keep-alive, not from prompt tricks.
    """
    return (
        "You are Stubilly, a friendly and supportive study assistant.\n"
        f"The student's current task: {task_description}\n\n"
        "Keep replies short and practical — usually 1-3 sentences. Answer questions "
        "directly. If they seem off-task or discouraged, give a brief, warm reminder "
        "to refocus. Never lecture, never repeat yourself. If they ask for detail, "
        "give a bit more; otherwise stay brief."
    )


async def warm_model(model: str = DEFAULT_MODEL) -> None:
    """
    Fire-and-forget: asks Ollama to load the companion model into memory (with
    a ten-minute keep-alive) so the first chat reply of a session doesn't pay
    the cold-load penalty. Callers must NOT await this on a latency-critical
    path — it exists to run in the background. Never raises.
    """
    try:
        async with httpx.AsyncClient(timeout=90.0) as client:
            await client.post(
                f"{OLLAMA_BASE_URL}/api/generate",
                json={
                    "model": model,
                    "prompt": "",
                    "stream": False,
                    "keep_alive": "10m",
                    "options": {"num_predict": 1},
                },
            )
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException, httpx.HTTPStatusError):
        pass  # Ollama offline — the stream path already handles that gracefully


async def stream_companion_reply(
    messages: list[dict],
    model: str = DEFAULT_MODEL,
    fail_fast: bool = False,
) -> AsyncIterator[str]:
    """
    Streams the companion's reply token-by-token from Ollama's /api/chat
    (stream=True), instead of waiting for the whole message. This is the
    main lever for making the chat *feel* fast: the student sees words
    appear within a few hundred ms instead of staring at a blank bubble
    until the full reply is ready.

    Yields plain-text chunks as they arrive. When ``fail_fast`` is False
    (default) it never raises  Eon any failure it yields one friendly
    fallback line, since a broken companion chat shouldn't interrupt the
    study session. When ``fail_fast`` is True (hybrid-chain local probe)
    connection/HTTP errors raise instead, so the caller can fall through
    to a cloud provider rather than showing the fallback line as a real
    answer.
    """
    try:
        # A generous but FINITE timeout. timeout=None meant a stalled stream
        # (Ollama alive but never finishing a token) could keep the student's
        # bubble open forever with no answer and no error; 45s of silence is
        # treated as a failure and answered with the fallback line instead.
        stream_timeout = httpx.Timeout(connect=10.0, read=45.0, write=10.0, pool=10.0)
        async with httpx.AsyncClient(timeout=stream_timeout) as client:
            async with client.stream(
                "POST",
                f"{OLLAMA_BASE_URL}/api/chat",
                json={
                    "model": model,
                    "messages": messages,
                    "stream": True,
                    "keep_alive": "10m",
                    "options": CHAT_OPTIONS,
                },
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line:
                        continue
                    try:
                        chunk = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    piece = chunk.get("message", {}).get("content", "")
                    if piece:
                        yield piece
                    if chunk.get("done"):
                        break
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException):
        if fail_fast:
            raise OllamaUnavailableError("Ollama unreachable") from None
        yield "I can't reach my brain right now (Ollama's offline) — but I'm still here with you."
    except httpx.HTTPStatusError:
        if fail_fast:
            raise OllamaUnavailableError("Ollama HTTP error") from None
        yield "Something glitched on my end — mind trying that again?"


async def extract_note(
    task_description: str,
    user_text: str,
    companion_reply: str,
    model: str = DEFAULT_MODEL,
    existing_notes: list[str] | None = None,
) -> Optional[str]:
    """
    The "automated note-taking": after a chat exchange, quietly checks
    whether it contained a genuinely important point worth keeping — a key
    fact/definition tied to the current lecture or task, a decision, a
    blocker, or a precise next action — and returns ONE short note if so.

    High bar on purpose: a note earns its way in only when it is crucial
    (not just interesting), specific enough to be useful on its own, related
    to the student's actual task/topic, AND not already covered by the notes
    this session. Explanations and helpful small talk produce nothing. Called
    as a fire-and-forget background task so this never adds latency to the
    visible chat reply.
    """
    existing = existing_notes or []
    existing_bullets = "\n".join(f"- {n}" for n in existing[:8]) or "- (none yet)"
    system_prompt = (
        "You capture selective study notes from ONE turn of a conversation. Given the "
        "student's task, decide if what was just said contains something crucial worth "
        "saving. A note is worth saving ONLY if ALL of: "
        "(1) it is a key fact, definition, method, decision, blocker, or precise next action "
        "directly tied to the student's task/lecture topic; "
        "(2) it is specific enough to be useful on its own later; "
        "(3) it is NOT already covered by the notes already captured this session.\n"
        "Most turns produce nothing — chit-chat, generic encouragement, re-explaining the task, "
        "and near-duplicates are NOT captured. Be strict.\n"
        'Respond with ONLY JSON, no markdown fences: {"worth_saving": true or false, '
        '"note": "short note, or empty string"}. If worth_saving, the note must be under 18 '
        "words, written as a standalone fact (not \"the student said...\")."
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"Task: {task_description}\n"
                        f"Student said: {user_text}\n"
                        f"Companion replied: {companion_reply}\n"
                        f"Already captured this session:\n{existing_bullets}"
                    ),
                },
            ],
            model=model,
            timeout=15.0,
        )
        cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        result = json.loads(cleaned)
        if result.get("worth_saving") and result.get("note"):
            return str(result["note"]).strip()
        return None
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError, TypeError) as e:
        logger.info(f"Note extraction skipped: {e}")
        return None


async def check_ollama_health() -> bool:
    """Used by the /health endpoint so the frontend can show a clear 'Ollama not running' banner."""
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(f"{OLLAMA_BASE_URL}/api/tags")
            return resp.status_code == 200
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException, httpx.HTTPStatusError):
        return False


# --- smart intervention: window label (SYNC, monitor-thread safe) ---------

CLASSIFY_OPTIONS = {"num_predict": 40, "num_ctx": 512, "temperature": 0}
CLASSIFY_TIMEOUT = 4.0


def _heuristic(app: str, title: str, site: str) -> dict:
    # Local import keeps ollama_client usable without the intervention module.
    import intervention
    return intervention.heuristic_label(app, title, site)


def classify_window(
    app: str, title: str, site: str, model: str = DEFAULT_MODEL
) -> dict:
    """Label ONE foreground window for the intervention counter. SYNC on
    purpose: the window monitor is a plain thread with no event loop, and a
    4s-bound call fits its 2.5s cadence (skipped ticks are free — sight-ings
    are gap-based). Returns {label, confidence, source} with
    label in {school_work, social_media, video, game, neutral}.

    Ollama down, slow, or returning junk -> intervention.heuristic_label
    (deterministic keyword tables) so classification NEVER blocks the monitor
    or throws. Never raises."""
    blob = " | ".join(str(x) for x in (app, site, title) if x)
    if not blob.strip():
        return {"label": "neutral", "confidence": 0.6, "source": "heuristic"}
    prompt = (
        "Classify what a student's foreground window is doing. "
        "Labels: school_work, social_media, video, game, neutral.\n"
        "Respond with ONLY JSON: {\"label\": \"...\", \"confidence\": 0.0-1.0}\n"
        f"Window: {blob[:400]}"
    )
    try:
        with httpx.Client(timeout=CLASSIFY_TIMEOUT) as client:
            resp = client.post(
                f"{OLLAMA_BASE_URL}/api/chat",
                json={
                    "model": model,
                    "messages": [{"role": "user", "content": prompt}],
                    "stream": False,
                    "keep_alive": "10m",
                    "options": CLASSIFY_OPTIONS,
                },
            )
            resp.raise_for_status()
            raw = resp.json()["message"]["content"]
        import intervention
        for doc in _extract_json_docs(raw):
            if isinstance(doc, dict):
                label = str(doc.get("label") or "").strip().lower()
                if label in intervention.ALL_LABELS:
                    try:
                        conf = float(doc.get("confidence") or 0)
                    except (TypeError, ValueError):
                        conf = 0.5
                    conf = max(0.0, min(1.0, conf))
                    return {"label": label, "confidence": conf, "source": "llama"}
        return _heuristic(app, title, site)
    except Exception as e:
        logger.debug(f"classify_window fallback: {e}")
        return _heuristic(app, title, site)
