import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { api } from "../api/client";
import CompanionAvatar from "./CompanionAvatar";

/**
 * Companion picker shown on the session setup screen. Fetches the five
 * companions from GET /companions once, renders them as a horizontal
 * scroll-snap carousel, and reports the chosen id up via onChange. Falls
 * back to a local static list if the backend is briefly unreachable so
 * setup never blocks on it.
 */
const FALLBACK = [
  { id: "billy", name: "Billy", tagline: "Your hype coach", emoji: "🔥", color: "#f59e0b", personality: "Energetic, positive, celebrates every win with you." },
  { id: "fokus", name: "Fokus", tagline: "Deep-work guardian", emoji: "🎯", color: "#3b82f6", personality: "Calm, disciplined, minimal words, maximum focus." },
  { id: "shola", name: "Shola", tagline: "Patient mentor", emoji: "🌿", color: "#10b981", personality: "Wise, patient, breaks big tasks into gentle steps." },
  { id: "conan", name: "Conan", tagline: "Strategist", emoji: "⚡", color: "#8b5cf6", personality: "Analytical, strategic, loves a good plan." },
  { id: "akira", name: "Akira", tagline: "Chill flow partner", emoji: "🌊", color: "#06b6d4", personality: "Laid-back, creative, keeps the mood light." },
  { id: "tien", name: "Tien", tagline: "Ultra-sharp polymath", emoji: "🧠", color: "#ef4444", personality: "Ultra-smart and sharp - solves problems, plans fast, executes with you." },
];

export const FALLBACK_COMPANIONS = FALLBACK;

// How far each arrow press scrolls: one card plus its gap.
const SCROLL_STEP = 218;

export default function CompanionPicker({ value, onChange }) {
  const [companions, setCompanions] = useState(FALLBACK);
  const trackRef = useRef(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await api.listCompanions();
        if (!cancelled && Array.isArray(data?.companions) && data.companions.length) {
          setCompanions(data.companions);
        }
      } catch {
        // Backend briefly down — the fallback list keeps setup usable.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const selected = value || "fokus";

  const scrollBy = useCallback((dir) => {
    trackRef.current?.scrollBy({ left: dir * SCROLL_STEP, behavior: "smooth" });
  }, []);

  // Effortless mouse-wheel / trackpad scrolling: a vertical wheel gesture over
  // the strip pans it horizontally so the buddy row can be swept without
  // hunting for the thin scrollbar or dragging. We only claim the event when
  // there is somewhere to scroll in that direction, so the wheel still scrolls
  // the page normally once the carousel hits either end.
  const handleWheel = useCallback((e) => {
    const track = trackRef.current;
    if (!track) return;
    // Prefer the axis the user actually moved on; fall back to whichever axis
    // has room to travel (so a plain vertical wheel still pans the row).
    const delta = e.deltaX !== 0 ? e.deltaX : e.deltaY;
    if (delta === 0) return;
    const max = track.scrollWidth - track.clientWidth;
    if (max <= 0) return;
    if ((delta < 0 && track.scrollLeft <= 0) || (delta > 0 && track.scrollLeft >= max - 1)) {
      return; // At an edge - let the page scroll take over.
    }
    e.preventDefault();
    track.scrollLeft += delta;
  }, []);

  // Keep the chosen card in view whenever the selection changes (including
  // the initial "fokus" default), so the carousel lands on the active buddy.
  useEffect(() => {
    const idx = companions.findIndex((c) => c.id === selected);
    const track = trackRef.current;
    if (idx < 0 || !track) return;
    const card = track.children[idx];
    if (!card) return;
    const left = card.offsetLeft - (track.clientWidth - card.clientWidth) / 2;
    track.scrollTo({ left: Math.max(0, left), behavior: "smooth" });
  }, [selected, companions]);

  return (
    <div className="companion-picker" role="radiogroup" aria-label="Choose your AI companion">
      <div className="companion-picker-label">
        <span className="companion-picker-title">Pick your companion</span>
        <span className="companion-picker-hint">Voice + chat — switches anytime next session</span>
      </div>
      <div className="companion-carousel">
        <button
          type="button"
          className="companion-carousel-btn"
          aria-label="Scroll companions left"
          onClick={() => scrollBy(-1)}
        >
          <ChevronLeft size={18} />
        </button>
        <div
          className="companion-carousel-viewport"
          ref={trackRef}
          onWheel={handleWheel}
        >
          {companions.map((c) => {
            const isSelected = c.id === selected;
            return (
              <button
                key={c.id}
                type="button"
                role="radio"
                aria-checked={isSelected}
                className={`companion-card${isSelected ? " companion-card-selected" : ""}`}
                style={{
                  "--companion-color": c.color,
                  "--companion-soft": c.color_soft || `${c.color}1f`,
                }}
                onClick={() => onChange(c.id)}
              >
                <CompanionAvatar companionId={c.id} color={c.color} size={56} state={isSelected ? "talking" : "idle"} />
                <div className="companion-card-text">
                  <span className="companion-card-name">
                    {c.name}
                    <span className="companion-card-emoji">{c.emoji}</span>
                  </span>
                  <span className="companion-card-tagline">{c.tagline}</span>
                  <span className="companion-card-personality">{c.personality}</span>
                </div>
              </button>
            );
          })}
        </div>
        <button
          type="button"
          className="companion-carousel-btn"
          aria-label="Scroll companions right"
          onClick={() => scrollBy(1)}
        >
          <ChevronRight size={18} />
        </button>
      </div>
    </div>
  );
}
