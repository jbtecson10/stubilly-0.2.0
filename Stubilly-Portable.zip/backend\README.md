# backend/ — FastAPI server + SQLite database + Ollama

This is the **brain and the data store**. It receives focus ticks and chat
messages, decides when to intervene, and persists everything to SQLite.

| File | Purpose |
|---|---|
| `main.py` | **Every route + WebSocket.** Sessions, focus stream, analytics, companion chat, notes. The API itself. |
| `models.py` | DB tables (ORM): users, admins, login_events, sessions, focus_events, interventions, tasks, chat_messages, study_notes. |
| `schemas.py` | Pydantic request/response contracts — the "shape" of the API. |
| `auth.py` | Password hashing (PBKDF2) + in-memory login/online tokens. |
| `admin.py` | Admin hub endpoints: accounts, policies, live status, sessions. |
| `state_machine.py` | **When to nudge/alarm** — all the thresholds live here. |
| `ollama_client.py` | Talks to local Ollama (task breakdown, nudge text, study links, notes, plan refinement). |
| `companion_llm.py` | Companion chat LLM: Gemini → Grok → Ollama fallback. |
| `database.py` | SQLite engine/session wiring. |
| `migrate.py` | Auto-adds missing columns to older DBs (SQLite can't via create_all). |
| `run_server.py` | Entry point for the packaged exe; sets DB path + bind host. |
| `build.sh` / `stubilly-backend.spec` | Build the backend into a standalone exe. |
| `dist/default-config.json` | **Central server address baked into the installer.** |
| `stubilly.db` | The live database (real data — careful with it). |

Start reading: **`main.py`** (the API), then **`state_machine.py`** (the rules).