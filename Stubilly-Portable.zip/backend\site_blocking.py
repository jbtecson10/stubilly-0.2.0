"""
System-wide site blocking for the web base 窶・the server-side counterpart of
what frontend/electron/hosts-blocker.cjs does for the desktop app.

Redirects admin-blocked domains to the intercept IP (127.0.0.2 by default;
override with STUBILLY_INTERCEPT_IP) inside the OS hosts file. That sits
below every browser, extension, and app on THIS machine, so the block holds
for Chrome/Firefox/Edge and native apps alike 窶・not just tabs inside
Stubilly. Lightweight HTTP/HTTPS interceptors on that IP record each
attempt and (HTTP only) 302 the browser back to /blocked?site=... so
Stubilly can show its blocked-site alarm.

Enforcement is derived from the admins' policy on every refresh, never
stored twice:

    effective = union over students of (their blocked_sites - their allowed_sites)
    active only while a session is LIVE: a row with ended_at IS NULL whose
    runtime has an attached focus WebSocket, or that is inside the detach
    grace window (session just started / a reload is reconnecting)

i.e. an allowed site only exempts the student it was granted to 窶・one
student's allow can NEVER cancel a different student's block (the hosts
file is machine-wide, so netting globally would let any one allow silently
unblock everyone). Known media/CDN hostnames of each blocked base domain
are folded in (YouTube streams from googlevideo.com etc. 窶・blocking only
youtube.com leaks).

Lifecycle (admin owns the lists; students cannot edit them in managed mode):
  - Admin saves policy -> stored; applied live only while a session is live
  - Login / session start re-assert the same union for live sessions
  - BREAK          -> whole section lifted for the break, restored after
  - END SESSION    -> hosts block cleared entirely (sites accessible again)
  - No live session-> hosts block empty (a stale row nobody is attached to
    never keeps the machine blocked 窶・see the detach grace below)
  - Web base stop  -> shutdown clears the hosts block (remove app = free)

The detach grace (STUBILLY_BLOCK_DETACH_GRACE_SEC, default 120s) keeps the
block through a page reload, a network blip, or the moment between
/session/start and the focus socket attaching 窶・but once it elapses with no
socket attached, the scheduled refresh lifts the block even though the row
is still open (the session resumes enforcing the moment a socket comes
back). This is what stops an abandoned session from blocking sites while
the student is staring at the sign-in or setup screen.

refresh_enforcement() recomputes and applies it. It is called:
  - at server startup (re-assert after crash/reboot; clears stale blocks),
  - on login and when a session starts,
  - whenever an admin saves a policy (block, unblock, allow 窶・applies live),
  - when a break starts/ends over the focus WebSocket,
  - when a focus socket attaches (session becomes live again after resume)
    and when it drops (break state can't be trusted from a dead socket),
  - when a session is finalized (end session => block fully lifts),
  - after the detach grace expires for a session nobody reconnected to,
  - on app shutdown (clear hosts so removing/stopping the web base frees
    every blocked site).

Admin changes are ALSO pushed to that user's open focus socket as
{"type": "policy_refresh"} (broadcast_policy_refresh) so the signed-in UI
updates instantly; the 5-second /policy/current poll remains as fallback.

Every interceptor hit on an actively blocked host is recorded and pushed
to open /ws/notifications tabs (and included as ?site= on the HTTP 302
back to Stubilly). Client-side dedup collapses the HTTP+WS double delivery
of one attempt; repeated visits re-alarm after the short dedup window.

Writing the real hosts file needs administrator rights 窶・run-web.bat
self-elevates for exactly that reason. Failures are logged and returned as
{"ok": False, "error": ...}: the policy still saves, and the next successful
refresh applies it. Tests point STUBILLY_HOSTS_PATH at a temp file, which
needs no elevation and skips the DNS-flush / Secure-DNS registry side
effects so a test run never touches the machine's real settings.
"""
import asyncio
import logging
import os
import re
import socket
import subprocess
import sys
import tempfile
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import models
import schemas
import state_machine
from database import get_db

logger = logging.getLogger("stubilly.site_blocking")

# Same markers as the desktop blocker, so both tools edit disjoint, clearly
# delimited regions and never touch anything else in the hosts file.
BLOCK_START = "# STUBILLY-BLOCK-START (auto-managed 窶・do not edit inside this block)"
BLOCK_END = "# STUBILLY-BLOCK-END"


def block_markers(block_id: str, _start: str = BLOCK_START, _end: str = BLOCK_END) -> tuple[str, str]:
    """Marker pair for one deployment. Empty id = the shared default markers
    (byte-identical to the desktop blocker's). A non-empty id inserts itself
    into both markers ("...-START-LC (..." / "...-END-LC") so two Stubilly
    servers can keep DISJOINT sections in one hosts file and each strip or
    write touches only its own block. The default-arg capture keeps the
    pristine markers even after the module reassigns BLOCK_START/BLOCK_END."""
    if not block_id:
        return _start, _end
    return (
        _start.replace("-START ", f"-START-{block_id} ", 1),
        f"{_end}-{block_id}",
    )


BLOCK_START, BLOCK_END = block_markers(os.environ.get("STUBILLY_BLOCK_ID", "").strip())

# Base domain -> extra media/CDN hostnames that must go down with it, copied
# from the proven desktop blocker (see electron/hosts-blocker.cjs).
EXTRA_HOSTS = {
    "youtube.com": ["googlevideo.com", "ytimg.com", "youtu.be", "youtube-nocookie.com", "ggpht.com"],
    "tiktok.com": ["tiktokcdn.com", "tiktokv.com", "tiktokcdn-us.com"],
    "twitter.com": ["twimg.com"],
    "x.com": ["twimg.com"],
    "instagram.com": ["cdninstagram.com"],
    "facebook.com": ["fbcdn.net"],
    "reddit.com": ["redditmedia.com", "redd.it", "redditstatic.com"],
    "twitch.tv": ["ttvnw.net", "jtvnw.net"],
    "netflix.com": ["nflxvideo.net"],
    "snapchat.com": ["snapcdn.com", "sc-cdn.net"],
}

_NO_WINDOW = 0x08000000  # CREATE_NO_WINDOW 窶・no console flash from reg/ipconfig
_DOH_POLICY_KEYS = [
    r"HKLM\SOFTWARE\Policies\Google\Chrome",
    r"HKLM\SOFTWARE\Policies\Microsoft\Edge",
    r"HKLM\SOFTWARE\Policies\BraveSoftware\Brave",
]

_refresh_lock = threading.Lock()
_WS_LOCK = threading.Lock()
_FOCUS_WS: dict[int, set] = {}  # user_id -> set of open focus WebSockets
_NOTIFY_WS: set = set()  # every open /ws/notifications socket
_ADMIN_WS: dict = {}  # /ws/admin socket -> admin_id (presence + chat roster)
_MAIN_LOOP: asyncio.AbstractEventLoop | None = None

# Which hostnames currently point at the intercept IP (mirrors the hosts
# section). Rebound atomically after every successful/unchanged apply so the
# HTTP/HTTPS interceptor threads never see a half-updated set.
_ACTIVE_DOMAINS: set[str] = set()

# CDN extras reported under the base domain the admin actually blocked
# (googlevideo.com attempts show up as youtube.com).
_EXTRA_TO_BASE: dict[str, str] = {
    extra: base for base, extras in EXTRA_HOSTS.items() for extra in extras
}

_ATTEMPTS_LOCK = threading.Lock()
_ATTEMPTS: deque[dict] = deque(maxlen=50)  # recent blocked_attempt events

# Legacy one-time arm set 窶・kept so older policy-PUT callers don't crash.
# Notifications no longer depend on arming: every attempt on an actively
# blocked host is recorded and pushed (see record_attempt).
_ALERT_LOCK = threading.Lock()
_ARMED_ALERTS: set[str] = set()

_ORIGIN_LOCK = threading.Lock()
_CLIENT_ORIGIN = "127.0.0.1:8421"  # replaced by the next WS Host header

_INTERCEPTORS_STARTED = False


def _hosts_path() -> Path:
    override = os.environ.get("STUBILLY_HOSTS_PATH")
    if override:
        return Path(override)
    if sys.platform == "win32":
        root = os.environ.get("SystemRoot", r"C:\Windows")
        return Path(root) / "System32" / "drivers" / "etc" / "hosts"
    return Path("/etc/hosts")


def _using_test_override() -> bool:
    return bool(os.environ.get("STUBILLY_HOSTS_PATH"))


def _normalize_domain(raw) -> str:
    """Whatever shape an admin typed ('https://www.facebook.com/x', 'FACEBOOK.COM ',
    'facebook.com:8080', 'facebook.com ') -> one canonical bare hostname."""
    value = str(raw or "").strip().lower()
    if not value:
        return ""
    if value.startswith("http://"):
        value = value[7:]
    elif value.startswith("https://"):
        value = value[8:]
    cut = [i for i in (value.find("/"), value.find("?"), value.find("#")) if i >= 0]
    if cut:
        value = value[: min(cut)]
    if ":" in value:
        value = value.split(":", 1)[0]
    if value.startswith("www."):
        value = value[4:]
    value = value.strip(".")
    if not value or " " in value or not all(c.isalnum() or c in ".-" for c in value):
        return ""  # junk/phrases never reach the hosts file
    # The study app's own domains (stubilly, stubilly.tail....ts.net) must
    # never enter the hosts file - blocking them would kill the session and
    # fire a blocked-alert on every Stubilly request.
    if value == "stubilly" or value.split(".")[0] == "stubilly":
        return ""
    return value


def _strip_block(content: str) -> str:
    # end is searched FROM start: the suffixed marker of another deployment
    # ("...-END-LC") contains this block's END as a prefix, so a from-zero
    # find could land in the other block and mangle the file.
    start = content.find(BLOCK_START)
    end = content.find(BLOCK_END, start) if start != -1 else -1
    if start == -1 or end == -1:
        return content
    return content[:start] + content[end + len(BLOCK_END):]


def _current_section(content: str) -> str:
    start = content.find(BLOCK_START)
    end = content.find(BLOCK_END, start) if start != -1 else -1
    if start == -1 or end == -1:
        return ""
    return content[start + len(BLOCK_START):end]


def _intercept_ip() -> str:
    """Loopback address the hosts file points blocked domains at, and the
    address the HTTP/HTTPS interceptors bind. Defaults to 127.0.0.2 so a
    local Laragon/Apache on 127.0.0.1:80 never steals the traffic."""
    return os.environ.get("STUBILLY_INTERCEPT_IP") or "127.0.0.2"


def build_block_section(hostnames) -> str:
    """Intercept-IP lines for each hostname plus its www. twin (hosts matches
    exact names only 窶・facebook.com does NOT cover www.facebook.com)."""
    ip = _intercept_ip()
    lines = []
    seen = set()
    for raw in hostnames:
        base = _normalize_domain(raw)
        if not base:
            continue
        for host in (base, f"www.{base}"):
            if host in seen:
                continue
            seen.add(host)
            lines.append(f"{ip} {host}")
    return "\n".join(lines)


def detach_grace_sec() -> float:
    """Seconds a session keeps the block after its last focus socket drops
    (and after start, before the first one attaches). Covers page reloads,
    network blips, and the start->socket gap; once it elapses with nobody
    attached the scheduled refresh lifts the block so a stale session row
    can never keep the machine blocked."""
    raw = os.environ.get("STUBILLY_BLOCK_DETACH_GRACE_SEC")
    if raw is None or raw == "":
        return 120.0
    try:
        value = float(raw)
    except ValueError:
        return 120.0
    return max(0.0, value)


def effective_hosts(db) -> list[str]:
    """Per-user netting: each student's blocked_sites minus their OWN
    allowed_sites, then unioned across students. One student's allow must
    never cancel another student's block 窶・the hosts file is machine-wide,
    so a global subtraction would let any single allow silently unblock
    everyone.

    Active ONLY while a session is LIVE: an open row (ended_at IS NULL)
    whose runtime has an attached focus WebSocket, or that is within the
    detach grace window (just started, or reconnecting after a reload).
    End session empties it immediately; a session nobody drives empties it
    once the grace elapses. Also emptied while any live session is on a
    break."""
    open_ids = [
        sid
        for (sid,) in db.query(models.StudySession.id)
        .filter(models.StudySession.ended_at.is_(None))
        .all()
    ]
    if not open_ids:
        return []

    now = time.time()
    grace = detach_grace_sec()
    live_rts = []
    for sid in open_ids:
        rt = state_machine.active_sessions.get(sid)
        if rt is None:
            continue  # nobody driving this session (stale row / fresh boot)
        if rt.open_connections > 0:
            live_rts.append(rt)
            continue
        last_live = rt.detached_at if rt.detached_at is not None else rt.created_at
        if now - last_live <= grace:
            live_rts.append(rt)
    if not live_rts:
        return []

    if any(rt.on_break for rt in live_rts):
        return []

    out: list[str] = []
    seen: set[str] = set()

    def add(host: str) -> None:
        host = _normalize_domain(host)
        if not host or host in seen:
            return
        seen.add(host)
        out.append(host)

    for user in db.query(models.User).all():
        blocked_u: set[str] = set()
        allowed_u: set[str] = set()
        for raw in schemas.parse_stored_list(user.blocked_sites):
            domain = _normalize_domain(raw)
            if domain:
                blocked_u.add(domain)
        for raw in schemas.parse_stored_list(user.allowed_sites):
            domain = _normalize_domain(raw)
            if domain:
                allowed_u.add(domain)
        for base in sorted(blocked_u - allowed_u):
            add(base)
            for extra in EXTRA_HOSTS.get(base, []):
                if _normalize_domain(extra) in allowed_u:
                    continue  # this same student's CDN-level exemption
                add(extra)
    return out


def _sync_active_domains(section: str) -> None:
    """Rebind _ACTIVE_DOMAINS from a hosts-block section (full replace, so
    interceptor threads never observe a partially updated set)."""
    global _ACTIVE_DOMAINS
    domains: set[str] = set()
    for line in section.splitlines():
        parts = line.split()
        if len(parts) >= 2 and not parts[0].startswith("#"):
            domains.add(parts[1].strip().lower())
    _ACTIVE_DOMAINS = domains


def apply_hosts(hostnames, effects: bool = True) -> dict:
    """Rewrite only our marker-delimited section of the hosts file. A no-op
    (no read-modify-write, no DNS flush) when the file already matches."""
    path = _hosts_path()
    try:
        content = path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""
    except OSError as exc:
        return {"ok": False, "error": f"Cannot read hosts file {path}: {exc}"}

    section = build_block_section(hostnames)
    current = " ".join(_current_section(content).split())
    desired = " ".join(section.split())
    if current == desired:
        _sync_active_domains(_current_section(content))
        # Even when the hosts text is unchanged, re-assert DNS-flush /
        # Secure-DNS-off while blocking is active 窶・a browser or policy
        # refresh can turn DoH back on and silently bypass the hosts file.
        if not _using_test_override() and hostnames and effects:
            _post_write_effects(blocking=True)
        return {"ok": True, "unchanged": True, "domains": len(hostnames)}

    base = _strip_block(content)
    if section:
        next_content = f"{base.rstrip()}\n\n{BLOCK_START}\n{section}\n{BLOCK_END}\n"
    else:
        next_content = base.rstrip("\n")
        if next_content and not next_content.endswith("\n"):
            next_content += "\n"

    try:
        if _using_test_override():
            path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(next_content, encoding="utf-8")
    except PermissionError:
        _sync_active_domains(_current_section(content))
        return {
            "ok": False,
            "error": (
                f"Cannot write {path} 窶・editing the hosts file needs administrator "
                "rights. Run run-web.bat as administrator (it self-elevates)."
            ),
        }
    except OSError as exc:
        _sync_active_domains(_current_section(content))
        return {"ok": False, "error": f"Cannot write hosts file {path}: {exc}"}

    _sync_active_domains(section)
    if not _using_test_override() and effects:
        _post_write_effects(blocking=bool(hostnames))
    return {"ok": True, "domains": len(hostnames)}


def _post_write_effects(blocking: bool) -> None:
    """Best-effort Windows reinforcement, mirrored from the desktop blocker:
    flush the DNS resolver cache so the change lands immediately, and turn
    Chrome/Edge/Brave's Secure-DNS off while blocking is active (it would
    otherwise resolve straight past the hosts file) 窶・restored to each
    browser's real default when blocking lifts."""
    if sys.platform != "win32":
        return
    try:
        subprocess.run(["ipconfig", "/flushdns"], capture_output=True, timeout=10, creationflags=_NO_WINDOW)
    except Exception:
        pass  # hosts itself already changed; a stale cache just expires
    # A second deployment (STUBILLY_DOH_SKIP=1) leaves the Secure-DNS registry
    # to the primary instance: both servers writing this toggle would let one
    # instance's "restore to automatic" silently bypass the other's active block.
    if os.environ.get("STUBILLY_DOH_SKIP"):
        return
    value = "off" if blocking else "automatic"
    for key in _DOH_POLICY_KEYS:
        try:
            subprocess.run(
                ["reg", "add", key, "/v", "DnsOverHttpsMode", "/t", "REG_SZ", "/d", value, "/f"],
                capture_output=True,
                timeout=10,
                creationflags=_NO_WINDOW,
            )
        except Exception:
            pass  # non-admin dev runs may not hold the key 窶・hosts still blocks


def refresh_enforcement(effects: bool = True) -> dict:
    """Recompute the effective block set from the DB (only while a session
    is LIVE ? attached socket or inside the detach grace; empty when none,
    so end session fully lifts blocking and stale rows never hold it) + live
    break state and push it to the hosts file. Never raises: returns
    {"ok", "error"?}.

    effects=False skips the Windows reinforcement step (ipconfig /flushdns
    plus turning Secure-DNS back off). That step spawns a process per call, so
    the login path passes effects=False: when a whole class signs in at once
    every login would otherwise queue behind a flushdns. Nothing can have
    re-enabled DoH in the microseconds since the session start that already
    ran it, so the hosts section itself is all that login needs to assert."""
    with _refresh_lock:
        try:
            db = next(get_db())
            try:
                hosts = effective_hosts(db)
            finally:
                db.close()
            result = apply_hosts(hosts, effects=effects)
        except Exception as exc:
            logger.exception("hosts enforcement refresh failed")
            return {"ok": False, "error": str(exc)}
        if not result.get("ok"):
            logger.warning("hosts enforcement failed: %s", result.get("error"))
        return result


def clear_enforcement() -> dict:
    """Drop the hosts block section entirely (sites become accessible).
    Used on app shutdown so removing/stopping the web base never leaves
    the machine half-blocked. Never raises."""
    with _refresh_lock:
        try:
            return apply_hosts([])
        except Exception as exc:
            logger.exception("hosts enforcement clear failed")
            return {"ok": False, "error": str(exc)}


# ---------------------------------------------------------------------------
# Real-time push: admin saves a policy -> the student's open session hears
# about it immediately (the 5s /policy/current poll is only the fallback).
# ---------------------------------------------------------------------------

def set_main_loop(loop: asyncio.AbstractEventLoop) -> None:
    global _MAIN_LOOP
    _MAIN_LOOP = loop


# Guardian site-presence recorder (installed by main.py): async fn(site)
# scheduled on the main loop for every interceptor hit, so a blocked-site
# visit shows up in the parent dashboard's "currently on" feed too.
_SITE_VISIT_RECORDER = None


def set_site_visit_recorder(fn) -> None:
    global _SITE_VISIT_RECORDER
    _SITE_VISIT_RECORDER = fn


# Machine-student attribution (installed by main.py): fn(site) -> user_id.
# Every blocked_attempt is stamped with WHO caused it, and delivery (live
# push + replay) is scoped to that student's own tabs 窶・a sibling's hit,
# a parent's dashboard, or another account on the same machine must never
# ring someone else's alarm.
_USER_ATTRIBUTOR = None


def set_user_attribution(fn) -> None:
    global _USER_ATTRIBUTOR
    _USER_ATTRIBUTOR = fn


def active_focus_user_ids() -> list:
    """User ids with an open focus socket (i.e. a live session right now)."""
    with _WS_LOCK:
        return list(_FOCUS_WS.keys())


def register_focus_ws(user_id: int, websocket) -> None:
    with _WS_LOCK:
        _FOCUS_WS.setdefault(user_id, set()).add(websocket)


def unregister_focus_ws(user_id: int, websocket) -> None:
    with _WS_LOCK:
        sockets = _FOCUS_WS.get(user_id)
        if not sockets:
            return
        sockets.discard(websocket)
        if not sockets:
            _FOCUS_WS.pop(user_id, None)


def broadcast_policy_refresh(user_id: int) -> None:
    """Fire-and-forget: schedule the send on the server's main event loop.
    Safe to call from sync endpoints (admin threadpool) and from threads.

    Delivers {"type": "policy_refresh"} on BOTH realtime channels a student
    can be listening on, so an allow-list (or block-list) change applies
    immediately instead of waiting out the 5s /policy/current poll:
      - the live session's focus sockets (useFocusSocket handler), and
      - the account's open /ws/notifications tabs (BlockedNotifier), which on
        the current build reacts to the frame by re-fetching the policy.
    This is what makes an ALLOWED-site save feel as fast as the blocked-site
    interceptor alarm — the blocked site alarms from the OS side no matter
    what, while the allowed list's student-visible effects used to depend on
    the next poll."""
    loop = _MAIN_LOOP
    if loop is None or not loop.is_running():
        return
    with _WS_LOCK:
        focus_targets = list(_FOCUS_WS.get(user_id, ()))
        notify_targets = list(_NOTIFY_WS)
    if not focus_targets and not notify_targets:
        return

    async def _send() -> None:
        for ws in focus_targets:
            try:
                await ws.send_json({"type": "policy_refresh"})
            except Exception:
                pass  # socket already gone 窶・the poll covers it
        for ws in notify_targets:
            # Scoped delivery: only the student's OWN tabs re-fetch (a shared
            # machine never re-applies another student's policy).
            if getattr(ws, "_stubilly_user_id", None) != user_id:
                continue
            try:
                await ws.send_json({"type": "policy_refresh"})
            except Exception:
                pass

    asyncio.run_coroutine_threadsafe(_send(), loop)


def register_admin_ws(websocket, admin_id: int | None = None) -> None:
    with _WS_LOCK:
        _ADMIN_WS[websocket] = admin_id


def unregister_admin_ws(websocket) -> None:
    left: int | None = None
    with _WS_LOCK:
        admin_id = _ADMIN_WS.pop(websocket, None)
        if admin_id is not None and admin_id not in _ADMIN_WS.values():
            left = admin_id
    if left is not None:
        # Outside the lock: broadcast_admin_presence takes it too.
        broadcast_admin_presence({
            "type": "admin_presence",
            "admin_id": left,
            "online": False,
        })


def admin_online_ids() -> list[int]:
    """Admin ids with at least one open /ws/admin socket (chat roster)."""
    with _WS_LOCK:
        return sorted({a for a in _ADMIN_WS.values() if a is not None})


def broadcast_admin_presence(payload: dict) -> None:
    """Push a presence/status frame to every open Admin Hub socket.
    Safe from sync endpoints and background threads."""
    loop = _MAIN_LOOP
    if loop is None or not loop.is_running():
        return
    with _WS_LOCK:
        targets = list(_ADMIN_WS)
    if not targets:
        return

    async def _send() -> None:
        for ws in targets:
            try:
                await ws.send_json(payload)
            except Exception:
                pass

    asyncio.run_coroutine_threadsafe(_send(), loop)


# ---------------------------------------------------------------------------
# Blocked-site attempts: the interceptors record every hit, push it to any
# open /ws/notifications socket, and keep a short replay buffer for tabs that
# connect a moment later.
# ---------------------------------------------------------------------------

def set_client_origin(host: str | None) -> None:
    """Remember the Host header a Stubilly tab used so the HTTP interceptor
    can 302 back to the same origin (works for LAN IPs and custom ports)."""
    global _CLIENT_ORIGIN
    if not host:
        return
    value = str(host).strip().lower()
    if not value or not re.fullmatch(r"[a-z0-9.\-\[\]:]+", value):
        return
    with _ORIGIN_LOCK:
        _CLIENT_ORIGIN = value


def _client_origin() -> str:
    with _ORIGIN_LOCK:
        return _CLIENT_ORIGIN


def register_notify_ws(websocket, user_id=None) -> None:
    # Stamp the socket with its authenticated owner 窶・the fan-out below
    # only delivers frames whose attributed user matches.
    try:
        websocket._stubilly_user_id = int(user_id) if user_id else None
    except Exception:
        pass
    with _WS_LOCK:
        _NOTIFY_WS.add(websocket)


def unregister_notify_ws(websocket) -> None:
    with _WS_LOCK:
        _NOTIFY_WS.discard(websocket)


def notify_user_blocked(user_id, label: str, reason: str = "") -> None:
    """Push a smart-intervention frame to the student's own /ws/notifications
    tabs: 'the blocker closed <label> because it kept interrupting'. Same
    scoped fan-out as record_attempt (only that user's tabs), and never
    raises: this runs from the window-monitor thread, not the event loop."""
    if not user_id or not label:
        return
    # Never alert on the study app itself - a stubilly-labelled "blocked"
    # frame would fire while the student is already in Stubilly studying.
    if "stubilly" in str(label).strip().lower():
        return
    entry = {
        "type": "intervention",
        "label": str(label)[:160],
        "reason": str(reason)[:200],
        "at": time.time(),
        "user_id": int(user_id),
    }
    loop = _MAIN_LOOP
    if loop is None or not loop.is_running():
        return
    with _WS_LOCK:
        targets = list(_NOTIFY_WS)
    if not targets:
        return

    async def _send() -> None:
        for ws in targets:
            if getattr(ws, "_stubilly_user_id", None) != entry.get("user_id"):
                continue
            try:
                await ws.send_json(entry)
            except Exception:
                pass

    try:
        asyncio.run_coroutine_threadsafe(_send(), loop)
    except Exception:
        pass


def push_focus_frame(user_id: int, frame: dict) -> None:
    """Fire-and-forget: deliver one frame to the student's live focus
    sockets AND their own /ws/notifications tabs. Used by server-driven
    events (break start/end, game warn/close) that originate outside the
    student's own WS send loop."""
    loop = _MAIN_LOOP
    if loop is None or not loop.is_running() or not frame:
        return
    with _WS_LOCK:
        focus_targets = list(_FOCUS_WS.get(user_id, ()))
        notify_targets = list(_NOTIFY_WS)
    if not focus_targets and not notify_targets:
        return

    async def _send() -> None:
        for ws in focus_targets:
            try:
                await ws.send_json(frame)
            except Exception:
                pass
        for ws in notify_targets:
            if getattr(ws, "_stubilly_user_id", None) != user_id:
                continue
            try:
                await ws.send_json(frame)
            except Exception:
                pass

    asyncio.run_coroutine_threadsafe(_send(), loop)


def recent_attempts() -> list[dict]:
    with _ATTEMPTS_LOCK:
        return list(_ATTEMPTS)


def arm_alerts(sites) -> None:
    """Legacy one-time arm bookkeeping (kept for compatibility). Notifications
    no longer gate on arming 窶・see record_attempt."""
    with _ALERT_LOCK:
        for raw in sites:
            base = _normalize_domain(raw)
            if base:
                _ARMED_ALERTS.add(base)


def disarm_alerts(sites) -> None:
    """Drop arming when an admin unblocks a site or moves it to allowed."""
    with _ALERT_LOCK:
        for raw in sites:
            base = _normalize_domain(raw)
            if base:
                _ARMED_ALERTS.discard(base)
                for extra in EXTRA_HOSTS.get(base, ()):
                    _ARMED_ALERTS.discard(_normalize_domain(extra))


def clear_alerts() -> None:
    with _ALERT_LOCK:
        _ARMED_ALERTS.clear()


def prune_alerts(keep: set[str]) -> None:
    """Drop any armed site that is no longer effectively blocked by any
    user (unblocked, allowed, or netted away). Cross-user safe: one
    student's allow never disarms another student's still-active block."""
    keep_norm = {_normalize_domain(x) for x in keep}
    keep_norm.discard("")
    with _ALERT_LOCK:
        for site in list(_ARMED_ALERTS):
            if site not in keep_norm:
                _ARMED_ALERTS.discard(site)


def _pop_armed_alert(site: str) -> bool:
    """Legacy one-time arm pop 窶・no longer used by record_attempt."""
    base = _EXTRA_TO_BASE.get(site, site)
    with _ALERT_LOCK:
        if base in _ARMED_ALERTS:
            _ARMED_ALERTS.discard(base)
            return True
        return False


def _blocked_site_for_host(host_header: str) -> str:
    """Reportable base domain if this Host/SNI is currently intercepted."""
    host = str(host_header or "").strip().lower()
    if not host:
        return ""
    if host.startswith("["):  # [::1]:port form
        end = host.find("]")
        host = host[1:end] if end != -1 else host
    elif ":" in host:
        host = host.split(":", 1)[0]
    if not host:
        return ""
    norm = _normalize_domain(host)
    if not norm:
        return ""
    active = _ACTIVE_DOMAINS
    if host in active or norm in active or f"www.{norm}" in active:
        return _EXTRA_TO_BASE.get(norm, norm)
    return ""


def record_attempt(site: str) -> bool:
    """Record a blocked_attempt and fan it out to the attributed student's
    open /ws/notifications tabs. Called for every interceptor hit on an
    actively blocked host (not only the first hit after an admin save).
    Returns True so the HTTP path always includes ?site= on the 302 back
    to Stubilly."""
    site = _normalize_domain(site)
    if not site:
        return False
    base = _EXTRA_TO_BASE.get(site, site)
    user_id = None
    attrib = _USER_ATTRIBUTOR
    if attrib is not None:
        try:
            user_id = attrib(base)
        except Exception:
            user_id = None
    entry: dict = {"type": "blocked_attempt", "site": base, "at": time.time()}
    if user_id:
        entry["user_id"] = int(user_id)
    with _ATTEMPTS_LOCK:
        _ATTEMPTS.append(entry)
    loop = _MAIN_LOOP
    if loop is None or not loop.is_running():
        return True
    # Feed the guardian site-presence tracker: this machine's student just
    # tried this site, which in browser mode is the only browsing signal
    # the server can see (schedule 窶・record_attempt runs on a listener
    # thread, never on the event loop itself).
    rec = _SITE_VISIT_RECORDER
    if rec is not None:
        try:
            asyncio.run_coroutine_threadsafe(rec(base), loop)
        except Exception:
            pass
    with _WS_LOCK:
        targets = list(_NOTIFY_WS)
    if not targets:
        return True

    async def _send() -> None:
        for ws in targets:
            # Scoped delivery: only tabs of the attributed student alarm.
            if getattr(ws, "_stubilly_user_id", None) != entry.get("user_id"):
                continue
            try:
                await ws.send_json(entry)
            except Exception:
                pass

    asyncio.run_coroutine_threadsafe(_send(), loop)
    return True


def _parse_sni_name(server_name_ext: bytes) -> str:
    if len(server_name_ext) < 5:
        return ""
    pos = 2  # ServerNameList length
    name_type = server_name_ext[pos]
    pos += 1
    if name_type != 0:
        return ""
    name_len = int.from_bytes(server_name_ext[pos:pos + 2], "big")
    pos += 2
    if pos + name_len > len(server_name_ext):
        return ""
    return server_name_ext[pos:pos + name_len].decode("ascii", errors="ignore").lower()


def _parse_tls_sni(data: bytes) -> str:
    """Hostname from a TLS ClientHello SNI extension (0x0000), or ''."""
    try:
        if len(data) < 5 or data[0] != 0x16:
            return ""
        rec_len = int.from_bytes(data[3:5], "big")
        hs = data[5:5 + rec_len]
        if len(hs) < 4 or hs[0] != 0x01:
            return ""
        hs_len = int.from_bytes(hs[1:4], "big")
        body = hs[4:4 + hs_len]
        if len(body) < 34:
            return ""
        pos = 34  # client_version(2) + random(32)
        if pos >= len(body):
            return ""
        pos += 1 + body[pos]  # session_id
        if pos + 2 > len(body):
            return ""
        pos += 2 + int.from_bytes(body[pos:pos + 2], "big")  # cipher_suites
        if pos >= len(body):
            return ""
        pos += 1 + body[pos]  # compression_methods
        if pos + 2 > len(body):
            return ""
        ext_total = int.from_bytes(body[pos:pos + 2], "big")
        pos += 2
        end = min(pos + ext_total, len(body))
        while pos + 4 <= end:
            etype = int.from_bytes(body[pos:pos + 2], "big")
            elen = int.from_bytes(body[pos + 2:pos + 4], "big")
            pos += 4
            if pos + elen > end:
                break
            edata = body[pos:pos + elen]
            pos += elen
            if etype == 0x0000:
                return _parse_sni_name(edata)
    except Exception:
        return ""
    return ""


class _BlockedHTTPRequestHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _handle(self) -> None:
        site = _blocked_site_for_host(self.headers.get("Host", ""))
        if site:
            # Always transport back to Stubilly WITH ?site= so the tab that
            # lands on /blocked can show the blocked-site alarm (client
            # dedups the HTTP+WS double delivery of the same attempt).
            record_attempt(site)
            origin = _client_origin()
            location = f"http://{origin}/blocked?site={site}"
            self.send_response(302)
            self.send_header("Location", location)
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "close")
            self.end_headers()
        else:
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "close")
            self.end_headers()

    do_GET = _handle
    do_POST = _handle
    do_HEAD = _handle
    do_PUT = _handle
    do_DELETE = _handle
    do_OPTIONS = _handle
    do_PATCH = _handle

    def log_message(self, fmt: str, *args) -> None:
        logger.debug("intercept-http " + fmt, *args)


def _http_interceptor(ip: str, port: int) -> None:
    try:
        srv = ThreadingHTTPServer((ip, port), _BlockedHTTPRequestHandler)
    except OSError as exc:
        logger.warning("HTTP interceptor not started on %s:%s: %s", ip, port, exc)
        return
    logger.info("HTTP interceptor listening on %s:%s", ip, port)
    try:
        srv.serve_forever()
    except Exception:
        logger.exception("HTTP interceptor stopped")


def _https_handle(conn: socket.socket) -> None:
    try:
        conn.settimeout(3.0)
        try:
            data = conn.recv(8192)
        except OSError:
            data = b""
        sni = _parse_tls_sni(data)
        if sni:
            site = _blocked_site_for_host(sni)
            if site:
                record_attempt(site)
    finally:
        try:
            conn.close()
        except OSError:
            pass


def _https_interceptor(ip: str, port: int) -> None:
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        srv.bind((ip, port))
    except OSError as exc:
        logger.warning("HTTPS interceptor not started on %s:%s: %s", ip, port, exc)
        srv.close()
        return
    srv.listen(32)
    logger.info("HTTPS interceptor listening on %s:%s", ip, port)
    while True:
        try:
            conn, _addr = srv.accept()
        except OSError:
            break
        threading.Thread(target=_https_handle, args=(conn,), daemon=True).start()


def start_interceptors() -> None:
    """Bind the loopback HTTP/HTTPS listeners that see hosts-blocked traffic.
    Idempotent; bind failures degrade to hosts-only (logged warning)."""
    global _INTERCEPTORS_STARTED
    if _INTERCEPTORS_STARTED:
        return
    _INTERCEPTORS_STARTED = True
    if os.environ.get("STUBILLY_INTERCEPT_DISABLE"):
        logger.info("site interceptors disabled via STUBILLY_INTERCEPT_DISABLE")
        return
    ip = _intercept_ip()
    http_port = int(os.environ.get("STUBILLY_INTERCEPT_HTTP_PORT") or "80")
    https_port = int(os.environ.get("STUBILLY_INTERCEPT_HTTPS_PORT") or "443")
    threading.Thread(
        target=_http_interceptor, args=(ip, http_port),
        daemon=True, name="stubilly-http-intercept",
    ).start()
    threading.Thread(
        target=_https_interceptor, args=(ip, https_port),
        daemon=True, name="stubilly-https-intercept",
    ).start()
