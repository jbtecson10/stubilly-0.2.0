import { useEffect, useRef, useState } from "react";
import { FaceLandmarker, FilesetResolver } from "@mediapipe/tasks-vision";

// NOTE on offline installs: by default this fetches from a CDN on first run
// and caches. For a fully offline packaged app, run
// `node scripts/download-models.mjs` once — it saves the wasm + model files
// into public/models/, which Vite then bundles into dist/. This hook checks
// for those local files first and only falls back to the CDN if they're
// not present (e.g. you haven't run the download script yet).
//
// Paths are built from import.meta.env.BASE_URL (not a hardcoded "/...")
// so they still resolve once packaged: Electron loads index.html via
// file://, where a literal "/models/..." would resolve against the OS
// filesystem root instead of the app's dist folder.
const LOCAL_WASM_URL = `${import.meta.env.BASE_URL}models/wasm`;
const LOCAL_MODEL_URL = `${import.meta.env.BASE_URL}models/face_landmarker.task`;
const CDN_WASM_URL = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const CDN_MODEL_URL =
  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

async function resolveModelSources() {
  try {
    const res = await fetch(LOCAL_MODEL_URL, { method: "HEAD" });
    // A plain res.ok isn't enough: Vite's dev server (and some static
    // hosts) serve index.html as a catch-all "200 OK" fallback for any
    // path that doesn't match a real file, which would otherwise trick
    // this into thinking a local model exists when public/models/ is
    // actually empty. A real .task file is never served as text/html.
    const contentType = res.headers.get("content-type") || "";
    if (res.ok && !contentType.includes("text/html")) {
      return { wasmUrl: LOCAL_WASM_URL, modelUrl: LOCAL_MODEL_URL };
    }
  } catch {
    // local files not bundled — fall through to CDN
  }
  return { wasmUrl: CDN_WASM_URL, modelUrl: CDN_MODEL_URL };
}

// Eye Aspect Ratio-ish signal derived from blendshapes: eyeBlinkLeft/Right
// scores go toward 1.0 as the eye closes. We average both eyes.
function eyeClosureScore(blendshapes) {
  if (!blendshapes?.length) return 0;
  const categories = blendshapes[0].categories;
  const left = categories.find((c) => c.categoryName === "eyeBlinkLeft")?.score ?? 0;
  const right = categories.find((c) => c.categoryName === "eyeBlinkRight")?.score ?? 0;
  return (left + right) / 2;
}

// Head yaw/pitch in degrees, derived from the facial transformation matrix.
function headPoseFromMatrix(matrix) {
  if (!matrix) return { yaw: 0, pitch: 0 };
  const m = matrix.data;
  // Standard rotation-matrix-to-euler extraction (matrix is column-major 4x4).
  const yaw = Math.atan2(-m[8], Math.sqrt(m[9] * m[9] + m[10] * m[10])) * (180 / Math.PI);
  const pitch = Math.atan2(m[9], m[10]) * (180 / Math.PI);
  return { yaw, pitch };
}

async function createLandmarker(filesetResolver, modelUrl, delegate) {
  return FaceLandmarker.createFromOptions(filesetResolver, {
    baseOptions: { modelAssetPath: modelUrl, delegate },
    outputFaceBlendshapes: true,
    outputFacialTransformationMatrixes: true,
    runningMode: "VIDEO",
    numFaces: 1,
  });
}

const EYE_CLOSED_THRESHOLD = 0.6; // blendshape score above this = eye considered closed
const HEAD_TURNED_THRESHOLD_DEG = 25; // yaw beyond this = "looking away"
const SLEEP_CONSEC_FRAMES = 15; // ~5 sec at ~3fps sampling, tune to your sample rate
// Accuracy guard: a stray glance (page refresh, the cat, a sideways look for
// half a second) is exactly ONE tick above the yaw threshold. Requiring TWO
// consecutive yaw'd ticks before committing to "distracted" kills the
// gibberish on/off-on/off flapping while still flipping within ~1.4s of a
// REAL head-turn away. This is the "precise" half of the realtime ask.
const DISTRACTED_CONSEC_TICKS = 2;
// Gaze proxy bands (coarser than the distraction threshold — analytics only).
const GAZE_TURN_THRESHOLD_DEG = 15;
const GAZE_DOWN_THRESHOLD_DEG = 25;
const GAZE_UP_THRESHOLD_DEG = 20;

/**
 * Runs FaceLandmarker on a <video> element on a fixed interval and classifies
 * focus state every tick. Returns the latest classification plus a
 * `startDetection`/`stopDetection` pair to control the loop.
 *
 * Classification logic (kept simple & explainable for a research writeup):
 *   - no face detected for a while       -> "absent"
 *   - eyes closed for many consec. ticks -> "sleeping"
 *   - head turned away from screen       -> "distracted"
 *   - otherwise                          -> "focused"
 */
export function useFocusDetector(videoRef, { onTick, intervalMs = 700 } = {}) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);
  const landmarkerRef = useRef(null);
  const intervalRef = useRef(null);
  const closedStreakRef = useRef(0);
  const absentStreakRef = useRef(0);
  const distractedStreakRef = useRef(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { wasmUrl, modelUrl } = await resolveModelSources();
        const filesetResolver = await FilesetResolver.forVisionTasks(wasmUrl);

        let landmarker;
        try {
          // GPU delegate is faster, but its WebGL context can fail to
          // initialize on machines with hardware acceleration disabled or
          // flaky GPU drivers (common in Electron on some Windows/Linux
          // setups) — that failure often surfaces with no useful message,
          // which is why this used to just say "Failed to load vision
          // model" with no detail. Fall back to CPU rather than give up.
          landmarker = await createLandmarker(filesetResolver, modelUrl, "GPU");
        } catch (gpuErr) {
          console.warn("Face landmarker GPU delegate failed, retrying on CPU:", gpuErr);
          landmarker = await createLandmarker(filesetResolver, modelUrl, "CPU");
        }

        if (!cancelled) {
          landmarkerRef.current = landmarker;
          setReady(true);
        }
      } catch (e) {
        console.error("Vision model failed to load:", e);
        if (!cancelled) {
          setError(e?.message || e?.toString?.() || "Failed to load vision model — check your internet connection");
        }
      }
    })();
    return () => {
      cancelled = true;
      landmarkerRef.current?.close();
    };
  }, []);

  function startDetection() {
    if (!ready || !videoRef.current || intervalRef.current) return;
    intervalRef.current = setInterval(() => {
      const video = videoRef.current;
      const landmarker = landmarkerRef.current;
      if (!video || !landmarker || video.readyState < 2) return;

      const result = landmarker.detectForVideo(video, performance.now());

      if (!result.faceLandmarks?.length) {
        absentStreakRef.current += 1;
        closedStreakRef.current = 0;
        const state = absentStreakRef.current >= 3 ? "absent" : "distracted";
        onTick?.({ state, confidence: 0.5, face_detected: false });
        return;
      }
      absentStreakRef.current = 0;

      const closure = eyeClosureScore(result.faceBlendshapes);
      const { yaw, pitch } = headPoseFromMatrix(result.facialTransformationMatrixes?.[0]);

      if (closure > EYE_CLOSED_THRESHOLD) {
        closedStreakRef.current += 1;
      } else {
        closedStreakRef.current = 0;
      }

      let state = "focused";
      let confidence = 1 - closure;

      if (Math.abs(yaw) > HEAD_TURNED_THRESHOLD_DEG) {
        distractedStreakRef.current += 1;
      } else {
        distractedStreakRef.current = 0;
      }

      if (closedStreakRef.current >= SLEEP_CONSEC_FRAMES) {
        state = "sleeping";
        confidence = closure;
      } else if (distractedStreakRef.current >= DISTRACTED_CONSEC_TICKS) {
        state = "distracted";
        confidence = Math.min(1, Math.abs(yaw) / 90);
      }

      // Coarse gaze proxy from head pose (stored on every tick so the
      // analytics view can ask "when do they look away" without re-running
      // the vision model over raw matrices).
      const gaze_direction =
        Math.abs(yaw) > GAZE_TURN_THRESHOLD_DEG
          ? yaw > 0
            ? "right"
            : "left"
          : pitch > GAZE_DOWN_THRESHOLD_DEG
            ? "down"
            : pitch < -GAZE_UP_THRESHOLD_DEG
              ? "up"
              : "center";

      onTick?.({
        state,
        confidence: Number(confidence.toFixed(2)),
        eye_aspect_ratio: Number((1 - closure).toFixed(3)),
        head_pose_yaw: Number(yaw.toFixed(1)),
        head_pose_pitch: Number(pitch.toFixed(1)),
        face_detected: true,
        gaze_direction,
      });
    }, intervalMs);
  }

  function stopDetection() {
    clearInterval(intervalRef.current);
    intervalRef.current = null;
    closedStreakRef.current = 0;
    absentStreakRef.current = 0;
    distractedStreakRef.current = 0;
  }

  return { ready, error, startDetection, stopDetection };
}
