import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Drives a work/break Pomodoro cycle on top of an already-running session.
 *
 * - Counts down `workMinutes`, then auto-switches to a break (if breaks remain).
 * - Counts down `breakMinutes`, then auto-switches back to work.
 * - `maxBreaks === null` means unlimited breaks; once breaksTaken hits
 *   maxBreaks, work intervals just restart instead of offering a break.
 * - Pure client-side timer — no backend persistence, since it only shapes
 *   the UI of an existing session.
 */
export function usePomodoro({ workMinutes, breakMinutes, maxBreaks, onPhaseChange }) {
  const [phase, setPhase] = useState("work"); // "work" | "break"
  const [remaining, setRemaining] = useState(workMinutes * 60);
  const [breaksTaken, setBreaksTaken] = useState(0);
  const [running, setRunning] = useState(true);

  const phaseRef = useRef(phase);
  const breaksTakenRef = useRef(breaksTaken);
  phaseRef.current = phase;
  breaksTakenRef.current = breaksTaken;

  const breaksExhausted = maxBreaks !== null && breaksTaken >= maxBreaks;
  const breaksLeft = maxBreaks === null ? null : Math.max(maxBreaks - breaksTaken, 0);

  const switchPhase = useCallback(
    (next) => {
      setPhase(next);
      setRemaining((next === "work" ? workMinutes : breakMinutes) * 60);
      if (next === "break") setBreaksTaken((n) => n + 1);
      onPhaseChange?.(next);
    },
    [workMinutes, breakMinutes, onPhaseChange]
  );

  // Tick once per second. Boundary transitions are decided in a separate
  // effect below (watching `remaining` hit 0), so each tick is exactly one
  // state update — no nested setState calls.
  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => {
      setRemaining((r) => (r > 0 ? r - 1 : r));
    }, 1000);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => {
    if (remaining !== 0) return;
    if (phaseRef.current === "work") {
      const canBreak = maxBreaks === null || breaksTakenRef.current < maxBreaks;
      switchPhase(canBreak ? "break" : "work");
    } else {
      switchPhase("work");
    }
  }, [remaining, maxBreaks, switchPhase]);

  const takeBreakNow = useCallback(() => {
    if (phaseRef.current === "work" && !breaksExhausted) switchPhase("break");
  }, [breaksExhausted, switchPhase]);

  const endBreakNow = useCallback(() => {
    if (phaseRef.current === "break") switchPhase("work");
  }, [switchPhase]);

  // Restart a fresh cycle — used when a brand-new session begins so a
  // reused config (e.g. default 25/5/4) doesn't silently no-op.
  const resetCycle = useCallback(() => {
    setPhase("work");
    setRemaining(workMinutes * 60);
    setBreaksTaken(0);
    setRunning(true);
  }, [workMinutes]);

  return {
    phase,
    remaining,
    breaksTaken,
    breaksLeft,
    breaksExhausted,
    running,
    setRunning,
    takeBreakNow,
    endBreakNow,
    resetCycle,
  };
}
