import { ShieldBan } from "lucide-react";

// Unlike BlockingBadge (the student's own editable list), this one has no
// settings gear — the hard-block list (Steam, Facebook, Instagram,
// Twitter/X, Snapchat, WhatsApp, Telegram) is fixed policy, not
// something to edit mid-session. Shown whenever it's active, independent of
// whether the student also turned on their own custom blocklist.
export default function HardBlockBadge({ active }) {
  if (!active) return null;

  return (
    <div
      className="app-monitor-pill app-monitor-pill-blocking"
      title="Steam, Facebook, Instagram, Twitter/X, Snapchat, WhatsApp, and Telegram are blocked system-wide for this session — this list isn't editable. (Messenger is left accessible.)"
    >
      <ShieldBan size={14} />
      <span className="app-monitor-label">Steam/social blocked</span>
    </div>
  );
}
