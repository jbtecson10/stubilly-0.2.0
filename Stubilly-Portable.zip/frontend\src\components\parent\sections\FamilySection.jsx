import { ShieldCheck, ShieldOff } from "lucide-react";
import { AddStudentBox } from "../shared.jsx";

/**
 * Family section: add/link student forms plus the linked-students list
 * with the monitoring-consent toggle (same handlers as the Overview
 * cards — consent also stays on each card there).
 */
export default function FamilySection({
  students,
  setConsent,
  showAdd,
  setShowAdd,
  addMode,
  setAddMode,
  addError,
  setAddError,
  linkMsg,
  setLinkMsg,
  form,
  setForm,
  createStudent,
  adding,
  linkIdent,
  setLinkIdent,
  linkStudent,
  linking,
}) {
  return (
    <>
      <h1 className="setup-title">Family</h1>
      <p className="setup-subtitle">
        Add your child's account or link one they already have.
      </p>
      <p className="parent-instruction">
        Monitoring only works after you grant consent — use the button on each
        student below to turn it on or off.
      </p>

      <AddStudentBox
        showAdd={showAdd}
        setShowAdd={setShowAdd}
        addMode={addMode}
        setAddMode={setAddMode}
        addError={addError}
        setAddError={setAddError}
        linkMsg={linkMsg}
        setLinkMsg={setLinkMsg}
        form={form}
        setForm={setForm}
        createStudent={createStudent}
        adding={adding}
        linkIdent={linkIdent}
        setLinkIdent={setLinkIdent}
        linkStudent={linkStudent}
        linking={linking}
      />

      <h2 className="parent-section-title">Linked students</h2>
      {students.length === 0 ? (
        <p className="setup-notice">
          No students linked yet — use Add student above to create your child's
          account, or link one they already have.
        </p>
      ) : (
        <div className="parent-students">
          {students.map((s) => (
            <div key={s.id} className="parent-student">
              <div className="parent-student-head">
                <span className="parent-student-name">
                  {s.full_name || s.serial_number}
                  {s.is_minor && <><span className="parent-tag-sep"> </span><em className="parent-minor-tag">minor</em></>}
                </span>
                <span className={`parent-status parent-status-${s.status}`}>
                  {s.status.replace(/_/g, " ")}
                </span>
              </div>
              <div className="parent-student-consent">
                <span
                  className={`parent-consent parent-consent-${
                    s.consent_granted ? "granted" : "pending"
                  }`}
                >
                  Monitoring:{" "}
                  {s.consent_granted ? "consent granted" : "consent not granted"}
                </span>
                <button
                  type="button"
                  className="btn-secondary parent-consent-btn"
                  onClick={() => setConsent(s, !s.consent_granted)}
                >
                  {s.consent_granted ? (
                    <ShieldOff size={15} aria-hidden="true" />
                  ) : (
                    <ShieldCheck size={15} aria-hidden="true" />
                  )}
                  {s.consent_granted ? "Withdraw consent" : "Grant consent"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}
