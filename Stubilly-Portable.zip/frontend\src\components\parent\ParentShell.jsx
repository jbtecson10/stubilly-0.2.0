import { useEffect, useRef, useState } from "react";
import {
  BellRing,
  ChevronRight,
  Gauge,
  History,
  LogOut,
  Moon,
  Settings,
  SlidersHorizontal,
  Sun,
  Users,
} from "lucide-react";

const SECTIONS = [
  { id: "overview", label: "Overview", icon: Gauge },
  { id: "alerts", label: "Alerts", icon: BellRing },
  { id: "history", label: "History", icon: History },
  { id: "controls", label: "Controls", icon: SlidersHorizontal },
  { id: "family", label: "Family", icon: Users },
  { id: "settings", label: "Settings", icon: Settings },
];

const LIVE_TEXT = {
  live: "Live",
  reconnecting: "Reconnecting",
  connecting: "Connecting",
};

// First letters of the guardian's name for the avatar chip ("Ana Parent" -> "AP").
function initialsOf(name) {
  const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "G";
  return parts
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join("");
}

/**
 * Parent dashboard shell: left-rail section navigation, an ACCOUNT card
 * pinned at the bottom (same reveal pattern as StudentNav — click opens a
 * Sign out menu), a slim header (Live badge + theme toggle) and the
 * scrolling section outlet. All data lives in ParentDashboard — this is
 * pure layout.
 */
export default function ParentShell({
  user,
  onLogout,
  section,
  setSection,
  unread,
  wsState,
  theme,
  toggleTheme,
  children,
}) {
  const [accountOpen, setAccountOpen] = useState(false);
  const accountRef = useRef(null);

  const name = user?.full_name || user?.email || user?.serial_number || "Guardian";
  const email = user?.email || "";

  // Close the account menu on outside click / Escape (keyboard-operable).
  useEffect(() => {
    if (!accountOpen) return undefined;
    const onPointerDown = (e) => {
      if (accountRef.current && !accountRef.current.contains(e.target)) {
        setAccountOpen(false);
      }
    };
    const onKeyDown = (e) => {
      if (e.key === "Escape") setAccountOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [accountOpen]);

  const go = (id) => {
    setAccountOpen(false);
    setSection(id);
  };

  return (
    <div className="parent-layout">
      <nav className="prail" aria-label="Parent sections">
        <span className="prail-brand">
          <strong>Stubilly</strong>
          <small>Guardian</small>
        </span>
        <ul className="prail-list">
          {SECTIONS.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  type="button"
                  className="prail-item"
                  data-tutorial={`pnav-${item.id}`}
                  aria-current={section === item.id ? "page" : undefined}
                  aria-label={
                    item.id === "alerts" && unread > 0
                      ? `${item.label}, ${unread} unread`
                      : item.label
                  }
                  title={item.label}
                  onClick={() => go(item.id)}
                >
                  <Icon size={17} className="prail-item-icon" aria-hidden="true" />
                  {/* Label lives in its own span so the phone media query
                      can hide it (icon-only rail) while aria-label keeps the
                      button named for screen readers — same pattern as the
                      student .snav-item-label. */}
                  <span className="prail-item-label">{item.label}</span>
                  {item.id === "alerts" && unread > 0 && (
                    <span className="prail-badge">{unread}</span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>

        {/* Account card pinned at the bottom — click reveals Sign out. */}
        <div className="prail-account-wrap" ref={accountRef}>
          {accountOpen && (
            <div className="prail-account-menu" role="menu">
              <span className="prail-account-menu-head">
                <strong>{name}</strong>
                {email && <small>{email}</small>}
              </span>
              <button
                type="button"
                className="prail-account-menu-item"
                role="menuitem"
                onClick={() => {
                  setAccountOpen(false);
                  onLogout?.();
                }}
              >
                <LogOut size={15} aria-hidden="true" />
                Sign out
              </button>
              <span className="prail-account-menu-note">
                Signs you out of the guardian view on this device.
              </span>
            </div>
          )}
          <button
            type="button"
            className="prail-account"
            onClick={() => setAccountOpen((o) => !o)}
            aria-expanded={accountOpen}
            aria-haspopup="menu"
            title={name}
          >
            <span className="prail-account-avatar" aria-hidden="true">
              {initialsOf(name)}
            </span>
            <span className="prail-account-text">
              <strong>{name}</strong>
              <em>Guardian</em>
            </span>
            <ChevronRight size={16} className="prail-account-chevron" aria-hidden="true" />
          </button>
        </div>
      </nav>
      <div className="prail-main">
        <header className="prail-header">
          <div className="prail-tools">
            <span className={`prail-live prail-live-${wsState}`} aria-live="polite">
              <span className="prail-live-dot" aria-hidden="true" />
              {LIVE_TEXT[wsState] || LIVE_TEXT.connecting}
            </span>
            <button
              type="button"
              className="btn-small prail-theme"
              onClick={toggleTheme}
              aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
            >
              {theme === "dark" ? (
                <Sun size={15} aria-hidden="true" />
              ) : (
                <Moon size={15} aria-hidden="true" />
              )}
              {theme === "dark" ? "Light" : "Dark"}
            </button>
          </div>
        </header>
        <main className="parent-content">
          <div className="setup-card parent-card">{children}</div>
        </main>
      </div>
    </div>
  );
}
