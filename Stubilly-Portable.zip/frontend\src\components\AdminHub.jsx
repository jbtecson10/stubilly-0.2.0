import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Search,
  Users,
  CalendarClock,
  X,
  UserPlus,
  UserRound,
  LogOut,
  ShieldCheck,
  Key,
  Eye,
  EyeOff,
  Shield,
  Bell,
  ChevronRight,
  ChevronDown,
  Copy,
  Check,
  CheckCheck,
  ListChecks,
  GraduationCap,
  Flame,
  Clock,
  Sparkles,
  Link2,
  RefreshCw,
  ExternalLink,
  Activity,
  AlertCircle,
  Sliders,
  MessageCircle,
  Trash2,
  Pin,
  Star,
  GripVertical,
  Sun,
  Moon,
} from "lucide-react";
import { api, getWsUrl, recheckBaseUrls } from "../api/client";
import SmartOps from "./SmartOps";
import useAdminTheme from "../hooks/useAdminTheme";

// Naive UTC timestamps parsed cleanly without timezone shift
function parseNaiveUtc(iso) {
  if (!iso) return null;
  let s = String(iso);
  if (
    /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(s) &&
    !/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)
  ) {
    s = s.replace(" ", "T") + "Z";
  }
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

function fmt(iso) {
  const d = parseNaiveUtc(iso);
  return d ? d.toLocaleString() : "—";
}

function fmtTime(iso) {
  const d = parseNaiveUtc(iso);
  if (!d) return "—";
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

// Message text with any link turned into a real, clickable link plus a small
// domain chip, so a shared file/site can be opened straight from the chat
// instead of being read out character by character. Nothing is fetched from
// the link - only the visible text comes from the message.
const CHAT_URL_RE = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;

function linkDomain(url) {
  try {
    return new URL(url.startsWith("http") ? url : `https://${url}`).hostname.replace(/^www\./, "");
  } catch {
    return url;
  }
}

// Oldest-first chat arrays from different pages are merged by id (later
// pages overlap by a message or two at the seam, so never concatenate).
function mergeChatMessages(...lists) {
  const byId = new Map();
  for (const list of lists) {
    for (const m of list) byId.set(m.id, m);
  }
  return [...byId.values()].sort((a, b) => a.id - b.id);
}

function renderChatText(body) {
  const text = String(body || "");
  const out = [];
  let last = 0;
  let match;
  CHAT_URL_RE.lastIndex = 0;
  while ((match = CHAT_URL_RE.exec(text)) !== null) {
    if (match.index > last) out.push(text.slice(last, match.index));
    const raw = match[0];
    const href = raw.startsWith("http") ? raw : `https://${raw}`;
    out.push(
      <span className="admin-chat-link-wrap" key={`${match.index}-${raw}`}>
        <a href={href} target="_blank" rel="noreferrer noopener">
          {raw}
        </a>
        <span className="admin-chat-link-domain">{linkDomain(raw)}</span>
      </span>
    );
    last = match.index + raw.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out.length ? out : text;
}

function dayLabel(iso) {
  const d = parseNaiveUtc(iso);
  if (!d) return "";
  const midnight = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((midnight(new Date()) - midnight(d)) / 86400000);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

// Day label plus the concrete date, for section headers where "Today" alone
// would hide when something actually happened.
function dayLabelFull(iso) {
  const d = parseNaiveUtc(iso);
  if (!d) return "Earlier";
  const short = dayLabel(iso);
  const date = d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: d.getFullYear() === new Date().getFullYear() ? undefined : "numeric",
  });
  if (short === "Today" || short === "Yesterday") return `${short} · ${date}`;
  return short;
}

// What each account-lifecycle notification is about, so a long feed can be
// scanned instead of read. Unknown kinds still render - they just stay generic.
const NOTIF_KINDS = {
  account_created: { label: "New account", tone: "add" },
  account_created_by_guardian: { label: "Guardian added", tone: "add" },
  account_created_by_admin: { label: "Admin added", tone: "add" },
  account_removed: { label: "Removed", tone: "remove" },
  password_reset_remote: { label: "Security", tone: "warn" },
  student_linked: { label: "Linked", tone: "link" },
  user_signed_in: { label: "Signed in", tone: "link" },
  user_signed_out: { label: "Signed out", tone: "info" },
  user_session_started: { label: "Session start", tone: "add" },
  user_session_finished: { label: "Session end", tone: "info" },
  // --- "Request an account" loop ---
  account_request: { label: "Account request", tone: "add" },
  account_request_approved: { label: "Request approved", tone: "add" },
  account_request_denied: { label: "Request denied", tone: "remove" },
  // --- smart intervention approval gate ---
  block_proposal: { label: "Block proposal", tone: "warn" },
  block_auto: { label: "Auto-block", tone: "remove" },
  block_decision: { label: "Block decision", tone: "info" },
  intervention_settings: { label: "Intervention setting", tone: "info" },
};

function notifKind(kind) {
  return NOTIF_KINDS[kind] || { label: "Update", tone: "info" };
}

// The "monitor what everyone is doing" filters. Activity = who is coming and
// going, Sessions = who is actually studying, Accounts = roster changes,
// Security = recovery attempts. "All" plus the unread toggle cover the rest.
const NOTIF_FILTERS = [
  { id: "all", label: "Everything", kinds: null },
  {
    id: "activity",
    label: "Sign in / out",
    kinds: ["user_signed_in", "user_signed_out"],
  },
  {
    id: "sessions",
    label: "Sessions",
    kinds: ["user_session_started", "user_session_finished"],
  },
  {
    id: "accounts",
    label: "Accounts",
    kinds: [
      "account_created",
      "account_created_by_guardian",
      "account_created_by_admin",
      "account_removed",
      "student_linked",
    ],
  },
  { id: "security", label: "Security", kinds: ["password_reset_remote"] },
  {
    id: "requests",
    label: "Requests",
    kinds: ["account_request", "account_request_approved", "account_request_denied"],
  },
  {
    id: "interventions",
    label: "Interventions",
    kinds: ["block_proposal", "block_auto", "block_decision", "intervention_settings"],
  },
];

// Who an entry is about: the name travels in the payload for live presence
// events and is already part of the message for the rest, so a search for a
// name finds every kind of activity for that person - including a removed
// account, whose row no longer exists to be clicked.
function notifSearchText(n) {
  const p = n.payload || {};
  return [
    n.message || "",
    p.full_name || "",
    p.name || "",
    p.serial_number || "",
    p.email || "",
    p.current_task || "",
    notifKind(n.kind).label,
  ]
    .join(" ")
    .toLowerCase();
}

// Newest-first feed -> one bucket per calendar day, order preserved, so the
// panel reads like a diary of the day instead of one endless list.
function groupNotifsByDay(list) {
  const out = [];
  let current = null;
  for (const n of list) {
    const label = dayLabelFull(n.created_at);
    if (!current || current.label !== label) {
      current = { label, items: [], unread: 0 };
      out.push(current);
    }
    current.items.push(n);
    if (!n.read_at) current.unread += 1;
  }
  return out;
}

function fmtDuration(sec) {
  if (!sec && sec !== 0) return "—";
  const m = Math.floor(sec / 60);
  const h = Math.floor(m / 60);
  if (h) return `${h}h ${m % 60}m`;
  return `${m}m`;
}

function fmtMinutes(min) {
  const totalM = Math.round(min || 0);
  if (totalM < 60) return `${totalM}m`;
  const h = Math.floor(totalM / 60);
  const r = totalM % 60;
  return r ? `${h}h ${r}m` : `${h}h`;
}

function sessionFocusPct(s) {
  const focused = s.total_focused_seconds || 0;
  const distracted = s.total_distracted_seconds || 0;
  const total = focused + distracted;
  if (!total) return null;
  return Math.round((100 * focused) / total);
}

function sortSessions(list) {
  return [...list].sort((a, b) => {
    if (!a.ended_at && b.ended_at) return -1;
    if (a.ended_at && !b.ended_at) return 1;
    return String(b.started_at || "").localeCompare(String(a.started_at || ""));
  });
}

function groupByDay(list) {
  const out = [];
  let last = null;
  for (const s of list) {
    const key = dayLabel(s.started_at) || "Earlier";
    if (key !== last) {
      out.push({ day: key, key: `d-${key}-${out.length}` });
      last = key;
    }
    out.push({ s, key: `s-${s.id}` });
  }
  return out;
}

const STATUS_STYLE = {
  offline: { text: "Offline", css: "is-offline" },
  signed_in: { text: "Online", css: "is-online" },
  studying: { text: "Studying", css: "is-studying" },
  focusing: { text: "Focusing", css: "is-focusing" },
  off_task: { text: "Off task", css: "is-offtask" },
};

// --- Active-first ordering -------------------------------------------------
// Anyone live floats to the top of their section (realtime over /ws/admin),
// so guardians and students who are active are always visible without a
// manual search.
const ACTIVITY_RANK = { focusing: 5, studying: 4, off_task: 3, signed_in: 2, offline: 1 };

function rankOf(u) {
  const st = u?.status || (u?.online ? "signed_in" : "offline");
  return ACTIVITY_RANK[st] || 1;
}

function statusStyleOf(u) {
  const st = u?.status || (u?.online ? "signed_in" : "offline");
  return STATUS_STYLE[st] || STATUS_STYLE.offline;
}

// Stable sort: ties keep their original order so the 4s fallback poll never
// shuffles same-rank rows around under the admin's cursor.
function sortByActivity(list, rankFn) {
  return list
    .map((item, idx) => ({ item, idx, rank: rankFn(item) }))
    .sort((a, b) => b.rank - a.rank || a.idx - b.idx)
    .map((x) => x.item);
}

// --- Soft, friendly WebAudio chimes ---------------------------------------
// No audio assets: two sine notes with a fast attack and a long gentle
// decay. The context is created lazily and everything is wrapped so a
// browser-blocked autoplay policy can never throw into React.
let _audioCtx = null;
function audioCtx() {
  try {
    if (!_audioCtx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return null;
      _audioCtx = new Ctx();
    }
    if (_audioCtx.state === "suspended") _audioCtx.resume().catch(() => {});
    return _audioCtx;
  } catch {
    return null;
  }
}

function playNotes(notes) {
  const ctx = audioCtx();
  if (!ctx) return;
  try {
    const now = ctx.currentTime;
    for (const { f, at, dur, gain } of notes) {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = f;
      g.gain.setValueAtTime(0.0001, now + at);
      g.gain.exponentialRampToValueAtTime(gain, now + at + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, now + at + dur);
      osc.connect(g).connect(ctx.destination);
      osc.start(now + at);
      osc.stop(now + at + dur + 0.05);
    }
  } catch {
    /* audio unavailable — silence is fine */
  }
}

// Someone became active: gentle two-note upward chime (wind-chime soft).
function playActiveChime() {
  playNotes([
    { f: 659.25, at: 0, dur: 0.5, gain: 0.055 },
    { f: 987.77, at: 0.14, dur: 0.7, gain: 0.05 },
  ]);
}

// New admin chat message: one soft bell note a fourth up, distinct from the
// presence chime so admins can tell them apart by ear.
function playChatTone() {
  playNotes([{ f: 783.99, at: 0, dur: 0.55, gain: 0.05 }]);
}

const PROGRESS_RANGES = [
  { label: "7 days", value: "week" },
  { label: "30 days", value: "month" },
  { label: "Year", value: "year" },
  { label: "All time", value: "all" },
];

function ChipList({ title, entries, onChange, placeholder }) {
  const [draft, setDraft] = useState("");
  function handleAdd(e) {
    e.preventDefault();
    const v = draft.trim();
    if (!v) return;
    if (!entries.some((x) => x.toLowerCase() === v.toLowerCase())) {
      onChange([...entries, v]);
    }
    setDraft("");
  }
  return (
    <div className="admin-chip-block">
      <div className="admin-chip-head">{title}</div>
      <ul className="admin-chip-list">
        {entries.length === 0 && <li className="admin-chip-empty">No rules configured</li>}
        {entries.map((entry) => (
          <li key={entry} className="admin-chip">
            <span>{entry}</span>
            <button
              type="button"
              className="btn-icon"
              onClick={() => onChange(entries.filter((x) => x.toLowerCase() !== entry.toLowerCase()))}
              aria-label={`Remove ${entry}`}
            >
              <X size={12} />
            </button>
          </li>
        ))}
      </ul>
      <form className="admin-chip-add" onSubmit={handleAdd}>
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={placeholder}
        />
        <button type="submit" className="btn-text" disabled={!draft.trim()}>
          Add
        </button>
      </form>
    </div>
  );
}

export default function AdminHub({ adminToken, admin, onLock, onClose }) {
  // Navigation tabs: "users" (Accounts & Families), "sessions" (Itemized Sessions Hub), "admins" (System Admins)
  const [tab, setTab] = useState("users");
  const [peopleFilter, setPeopleFilter] = useState("all"); // "all" | "parents" | "students"
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [selected, setSelected] = useState(null); // UserDetailOut
  const [draftBlocked, setDraftBlocked] = useState([]);
  const [draftAllowed, setDraftAllowed] = useState([]);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState(null);
  const [userSessions, setUserSessions] = useState([]);
  const [progress, setProgress] = useState(null);
  const [progressRange, setProgressRange] = useState("week");
  const [progressLoading, setProgressLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  // Admins state
  const [admins, setAdmins] = useState([]);
  const [creatingAdmin, setCreatingAdmin] = useState(false);
  const [newAdminName, setNewAdminName] = useState("");
  const [newAdminUsername, setNewAdminUsername] = useState("");
  const [newAdminPassword, setNewAdminPassword] = useState("");
  const [createAdminBusy, setCreateAdminBusy] = useState(false);
  const [myPassword, setMyPassword] = useState(admin?.password || "");
  const [passwordDraft, setPasswordDraft] = useState("");
  const [resetUserId, setResetUserId] = useState(null);
  const [resetDraft, setResetDraft] = useState("");
  const [resetBusy, setResetBusy] = useState(false);
  const [sessionExpired, setSessionExpired] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);

  // Sign out: revoke this admin token server-side, then hand control back to
  // App (which clears the adminSession and returns to the sign-in card).
  async function handleAdminSignOut() {
    try {
      await api.adminLogout(adminToken);
    } catch {
      // Best-effort — even if the revoke fails, drop the local session.
    }
    onLock?.();
  }

  // Scoped password visibility toggles
  const [showUserPw, setShowUserPw] = useState(false);
  const [showMyPw, setShowMyPw] = useState(false);
  const [revealedAdminPws, setRevealedAdminPws] = useState({});

  // Notifications feed
  const [notifs, setNotifs] = useState([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifUnread, setNotifUnread] = useState(0);
  // "all" | "unread" - lets a busy admin triage without scrolling the whole feed
  const [notifFilter, setNotifFilter] = useState("all");
  // Which Smart Ops sub-section is active (controlled so notification clicks
  // can jump straight to e.g. "accounts").
  const [smartOpsSection, setSmartOpsSection] = useState("overview");
  // Which slice of the day-to-day activity to show (NOTIF_FILTERS): everything,
  // who is signing in and out, who is in a study session, roster changes or
  // security attempts.
  const [notifKindFilter, setNotifKindFilter] = useState("all");
  // Free-text search over the name/message of every entry, so "who was in my
  // class today" is one box rather than a scroll.
  const [notifQuery, setNotifQuery] = useState("");
  // Oldest-first re-orders the whole feed (and the day buckets with it) for
  // reading a single day's story from the morning forward.
  const [notifOldestFirst, setNotifOldestFirst] = useState(false);
  // Select-then-delete: checkboxes replace click-to-open so an admin can drop
  // a handful of entries in one pass (Clear all takes the whole feed).
  const [notifSelectMode, setNotifSelectMode] = useState(false);
  const [notifSelected, setNotifSelected] = useState([]);
  // Two-step arm for Clear all - first click flips to "Sure?", second runs.
  const [notifClearArmed, setNotifClearArmed] = useState(false);
  const [notifBusy, setNotifBusy] = useState(false);
  // Highest notification id at the moment the panel was opened; anything newer
  // is a live arrival and gets the "new" highlight.
  // Smart ops tab: closed sign-up requests + block-proposal tickets + AUTO.
  const [acctRequests, setAcctRequests] = useState([]);
  const [acctReqStatus, setAcctReqStatus] = useState("pending");
  const [blockTickets, setBlockTickets] = useState([]);
  const [autoBlock, setAutoBlock] = useState(false);
  const [opsError, setOpsError] = useState(null);
  const [opsLoading, setOpsLoading] = useState(false);

  const notifSeenRef = useRef(0);

  // Admin-to-admin chat (Telegram-style room over /ws/admin)
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMsgs, setChatMsgs] = useState([]);
  const [chatDraft, setChatDraft] = useState(
    () => (typeof window !== "undefined" && window.localStorage?.getItem("stubilly_admin_chat_draft")) || ""
  );
  const [chatUnread, setChatUnread] = useState(0);
  const [chatStuck, setChatStuck] = useState(true); // user is parked at the bottom
  const [chatNewBelow, setChatNewBelow] = useState(0); // unseen msgs below the fold
  const [chatUnreadFrom, setChatUnreadFrom] = useState(null); // id to draw the "new" line above
  const [onlineAdmins, setOnlineAdmins] = useState(() => new Set());
  // --- Telegram-style chat actions (all additive) --------------------------
  // The message being quoted back (Reply), the message being retyped (Edit),
  // the picture/voice note waiting to be sent, and the recorder state.
  const [chatReply, setChatReply] = useState(null);
  const [chatEditId, setChatEditId] = useState(null);
  const [chatEditText, setChatEditText] = useState(
    () => (typeof window !== "undefined" && window.localStorage?.getItem("stubilly_admin_chat_edit")) || ""
  );
  const [chatAttach, setChatAttach] = useState(null); // uploaded, not sent yet
  const [chatSending, setChatSending] = useState(false);
  const [chatRecording, setChatRecording] = useState(false);
  const [chatRecSecs, setChatRecSecs] = useState(0);
  const [chatError, setChatError] = useState("");
  // token -> object URL for each attachment, fetched with the admin token
  const [chatMedia, setChatMedia] = useState({});
  const chatMediaFailedRef = useRef(new Set());
  const chatFileRef = useRef(null);
  const chatRecRef = useRef(null);
  const chatRecTimerRef = useRef(null);
  const chatOpenRef = useRef(false);
  const chatListRef = useRef(null);
  // Message id -> rendered bubble element, so a quoted reply (or an entry in
  // the Organized panel) can scroll the original message into view.
  const chatMsgElsRef = useRef(new Map());
  const chatFlashRef = useRef(null);
  // A reply-jump whose target bubble is not mounted yet (a fresh live message,
  // or a row still committing after a re-key). The bubble's OWN ref callback
  // fires the jump the instant it attaches, so a new-message jump never
  // depends on a fragile polling window.
  const pendingJumpRef = useRef(null);
  // Token for the post-jump settle pass: every new jump invalidates the
  // previous one so an old timer can never scroll the reader later.
  const jumpSettleRef = useRef(0);
  // Hold timer for the stick-to-bottom guard: released ~700ms after the last
  // jump attempt (see armJumpGuard), long past any smooth scroll, so the
  // bottom effect can never cancel a jump mid-flight.
  const jumpGuardTimerRef = useRef(0);
  // Every object URL we have handed a bubble, mirrored outside React state so
  // it can be revoked once, on unmount, without tearing down live images when
  // a new attachment arrives (see the cleanup effect below).
  const chatMediaRef = useRef({});
  // Telegram-style "Organized" panel (Media / Voice / Links) + which tab.
  const [chatOrganized, setChatOrganized] = useState(false);
  const [chatOrgTab, setChatOrgTab] = useState("media");
  const chatSeenRef = useRef(
    Number(
      (typeof window !== "undefined" && window.localStorage?.getItem("stubilly_admin_chat_seen")) || 0
    )
  );
  // Autosave the draft/edit text across closes and reloads (the "save all
  // drafts" ask) — read back on mount (see the useState initializers above),
  // written to localStorage on every change, cleared on send/cancel.
  useEffect(() => {
    try {
      window.localStorage.setItem("stubilly_admin_chat_draft", chatDraft);
    } catch {
      /* storage blocked — draft just won't survive a reload */
    }
  }, [chatDraft]);
  useEffect(() => {
    try {
      window.localStorage.setItem("stubilly_admin_chat_edit", chatEditText);
    } catch {
      /* storage blocked */
    }
  }, [chatEditText]);
  // Flexible chat window: size is user-resizable (drag the corner grip) and
  // remembered in localStorage so every open uses the admin's preferred room.
  const [chatSize, setChatSize] = useState(() => {
    const bigDefault = () => ({
      w: 470,
      h: Math.max(480, Math.min(640, Math.round((window.innerHeight || 900) * 0.82))),
    });
    try {
      const raw = window.localStorage?.getItem("stubilly_admin_chat_size");
      if (raw) {
        const p = JSON.parse(raw);
        if (Number(p?.w) > 0 && Number(p?.h) > 0) {
          const w = Number(p.w);
          const h = Number(p.h);
          // Older builds shipped a cramped 370x480 room. A stored size that
          // small was never hand-resized, so grow it once instead of leaving
          // every existing admin in the narrow window.
          if (w <= 400 && h <= 540) return bigDefault();
          return { w, h };
        }
      }
    } catch {
      /* corrupt/blocked storage — default size */
    }
    return bigDefault();
  });
  const chatSizeRef = useRef(chatSize);
  useEffect(() => {
    chatSizeRef.current = chatSize;
    try {
      window.localStorage.setItem("stubilly_admin_chat_size", JSON.stringify(chatSize));
    } catch {
      /* storage blocked */
    }
  }, [chatSize]);
  const chatResizeRef = useRef(null); // {x, y, w, h} snapshot at drag start
  const chatResizeStart = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    const s = chatSizeRef.current;
    chatResizeRef.current = { x: e.clientX, y: e.clientY, w: s.w, h: s.h };
    const maxH = Math.max(240, Math.floor((window.innerHeight || 800) * 0.9));
    const move = (ev) => {
      const start = chatResizeRef.current;
      if (!start) return;
      const next = {
        w: Math.min(840, Math.max(300, start.w + (ev.clientX - start.x))),
        h: Math.min(maxH, Math.max(240, start.h + (ev.clientY - start.y))),
      };
      setChatSize(next);
    };
    const up = () => {
      chatResizeRef.current = null;
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }, []);
  // Older-history paging (scroll-up loading + long-distance reply jumps).
  const [chatLoadingOlder, setChatLoadingOlder] = useState(false);
  const chatLoadingOlderRef = useRef(false);
  const [chatSearching, setChatSearching] = useState(false);
  const chatSearchingRef = useRef(false);
  const adminIdRef = useRef(admin?.id ?? null);
  // Presence-change baselines for the "someone became active" chime + popup
  const presenceRef = useRef(null);
  const chimeCooldownRef = useRef({});
  // Latest known status per user — the offline grace timer re-checks this so a
  // student who reconnects during the grace window never gets a "signed out"
  // popup for a refresh.
  const presenceNowRef = useRef(new Map());
  const leaveTimersRef = useRef({});
  // Users whose departure the server confirmed as a REAL sign-out (they called
  // /auth/logout). Their popup is announced at once; everybody else waits out
  // the short grace window in case the tab is merely quiet.
  const explicitLeavesRef = useRef(new Set());
  // Admin names for the "an admin joined/left the hub" popups.
  const adminsRef = useRef([]);
  useEffect(() => {
    adminsRef.current = admins;
  }, [admins]);
  // One-shot popups: "X is now active" / "X started a session" (auto-dismiss)
  const [activeToasts, setActiveToasts] = useState([]);

  function pushActiveToast(text, tone = "active") {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    // Keep a short stack (4) so a burst of simultaneous joins is all visible
    // at once instead of one popup replacing the next.
    setActiveToasts((prev) => [...prev.slice(-3), { id, text, tone }]);
    setTimeout(() => {
      setActiveToasts((prev) => prev.filter((t) => t.id !== id));
    }, tone === "leave" ? 6000 : 5000);
  }

  // Staggered toast pump: when several people join in the same presence tick
  // (or a student AND a parent sign in together) every one of them gets its
  // own popup, released ~350ms apart so they stay readable and never overlap.
  const toastQueueRef = useRef([]);
  const toastTimerRef = useRef(null);
  const enqueueToast = useCallback((text, tone = "active") => {
    toastQueueRef.current.push({ text, tone });
    if (toastTimerRef.current) return;
    const pump = () => {
      const item = toastQueueRef.current.shift();
      if (!item) {
        toastTimerRef.current = null;
        return;
      }
      pushActiveToast(item.text, item.tone);
      toastTimerRef.current = setTimeout(pump, 350);
    };
    toastTimerRef.current = setTimeout(pump, 0);
  }, []);

  useEffect(
    () => () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      Object.values(leaveTimersRef.current).forEach((t) => clearTimeout(t));
    },
    []
  );

  // Organization & Session reveal state
  const [collapsedParents, setCollapsedParents] = useState({});
  const [activeSessionUserId, setActiveSessionUserId] = useState(null);
  const [sessSearchQuery, setSessSearchQuery] = useState("");
  const [sessFilter, setSessFilter] = useState("all"); // "all" | "live" | "active"
  const [detailTab, setDetailTab] = useState("overview"); // "overview" | "sessions" | "policy" | "progress" | "logins"
  const [relinkingUserId, setRelinkingUserId] = useState(null);
  const [selectedParentLink, setSelectedParentLink] = useState("");

  // Account creation modal/form
  const EMPTY_ACCOUNT = {
    full_name: "",
    email: "",
    password: "",
    role: "student",
    date_of_birth: "",
    parent_id: "",
  };
  const [showCreate, setShowCreate] = useState(false);
  const createFormRef = useRef(null);
  const { theme: adminTheme, toggleTheme: toggleAdminTheme } = useAdminTheme();
  const [creating, setCreating] = useState(false);
  const [newAcct, setNewAcct] = useState(EMPTY_ACCOUNT);

  // Smart open: when New Account is clicked, slide the form into view and
  // put the cursor straight into the first field so an admin can type.
  // The pane keeps its own scrollbar, so a second pass after layout settles
  // guarantees the Save button is on screen too.
  useEffect(() => {
    if (!showCreate) return;
    const reveal = () => {
      createFormRef.current?.scrollIntoView({ block: "end" });
      createFormRef.current?.querySelector('button[type="submit"]')?.scrollIntoView({ block: "nearest" });
    };
    const id = requestAnimationFrame(() => {
      reveal();
      createFormRef.current?.querySelector("input")?.focus({ preventScroll: true });
    });
    const settle = setTimeout(reveal, 150);
    return () => {
      cancelAnimationFrame(id);
      clearTimeout(settle);
    };
  }, [showCreate]);

  // Incoming chat frame: dedupe by id, badge + soft tone when the panel is
  // closed, and never mark our own messages unread.
  const appendChatMessage = useCallback((m) => {
    if (!m || typeof m.id !== "number") return;
    setChatMsgs((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
    const mine = m.admin_id != null && m.admin_id === adminIdRef.current;
    if (m.id > chatSeenRef.current) {
      if (mine) {
        chatSeenRef.current = m.id;
        try {
          window.localStorage.setItem("stubilly_admin_chat_seen", String(m.id));
        } catch {
          /* storage blocked — badge still works for this session */
        }
      } else if (!chatOpenRef.current) {
        setChatUnread((u) => u + 1);
        playChatTone();
      }
    }
  }, []);

  // Keep the identity ref fresh without tearing down the socket.
  useEffect(() => {
    adminIdRef.current = admin?.id ?? null;
  }, [admin?.id]);

  // An edit arrives as the whole message again, so replace by id instead of
  // appending (which would leave the old text in the bubble).
  const patchChatMessage = useCallback((m) => {
    if (!m || typeof m.id !== "number") return;
    setChatMsgs((prev) => {
      const i = prev.findIndex((x) => x.id === m.id);
      if (i === -1) return [...prev, m];
      const next = prev.slice();
      next[i] = m;
      return next;
    });
  }, []);

  // A delete arrives as just the id: the server keeps a tombstone so every hub
  // removes the same bubble.
  const dropChatMessage = useCallback((id) => {
    if (typeof id !== "number") return;
    setChatMsgs((prev) =>
      prev.map((x) =>
        x.id === id ? { ...x, deleted_at: x.deleted_at || new Date().toISOString(), body: "" } : x
      )
    );
  }, []);

  // Attachments are admin-only, so pull each one once with the admin token and
  // hand the bubble an object URL.
  // A token whose file is gone (deleted message, or a file the janitor already
  // reaped) is remembered as "failed" so the effect never asks for it again -
  // otherwise every new message would re-trigger a 404 for it forever.
  useEffect(() => {
    const wanted = chatMsgs
      .filter((m) => !m.deleted_at)
      .map((m) => m.attachment_token)
      .filter((t) => t && !chatMedia[t] && !chatMediaFailedRef.current.has(t));
    if (!wanted.length || !adminToken) return;
    let cancelled = false;
    (async () => {
      for (const token of wanted) {
        try {
          const blob = await api.adminChatMediaBlob(adminToken, token);
          if (cancelled) return;
          const url = URL.createObjectURL(blob);
          chatMediaRef.current[token] = url;
          setChatMedia((prev) => (prev[token] ? prev : { ...prev, [token]: url }));
        } catch {
          chatMediaFailedRef.current.add(token);
          /* a deleted attachment simply stays unviewable */
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [chatMsgs, adminToken, chatMedia]);

  // Free the object URLs when the hub goes away (sign-out / reload), so a long
  // admin session is not holding every picture and voice note in memory. This
  // must NOT depend on `chatMedia`: revoking on every change tore down the URLs
  // of already-rendered pictures the moment the next attachment arrived.
  useEffect(() => {
    return () => {
      Object.values(chatMediaRef.current).forEach((u) => {
        try {
          URL.revokeObjectURL(u);
        } catch {
          /* already gone */
        }
      });
      chatMediaRef.current = {};
    };
  }, []);

  // Realtime presence over /ws/admin
  const applyPresence = useCallback((msg) => {
    if (!msg || typeof msg.user_id !== "number") return;
    const patch = {
      online: Boolean(msg.online),
      status: msg.status || "offline",
      current_task: msg.current_task ?? null,
    };
    // A sign-out the student/parent actually performed is pushed by the server
    // the moment /auth/logout revokes the token (msg.explicit_leave). Remember
    // it here so the popup below is instant instead of waiting out the grace
    // window that only exists for tabs that merely went quiet.
    if (msg.explicit_leave && !msg.online) {
      explicitLeavesRef.current.add(msg.user_id);
    }
    setUsers((prev) =>
      prev.map((u) => (u.id === msg.user_id ? { ...u, ...patch } : u))
    );
    setSelected((prev) => {
      if (!prev?.user || prev.user.id !== msg.user_id) return prev;
      return { ...prev, user: { ...prev.user, ...patch } };
    });
  }, []);

  useEffect(() => {
    if (sessionExpired || !adminToken) return undefined;
    let active = true;
    let ws = null;
    let attempt = 0;
    let reconnectTimer = null;

    async function connect() {
      if (!active) return;
      try {
        const url = await getWsUrl(`/ws/admin?token=${encodeURIComponent(adminToken)}`);
        if (!active) return;
        ws = new WebSocket(url);
      } catch {
        scheduleReconnect();
        return;
      }
      ws.onopen = () => {
        if (active) attempt = 0;
      };
      ws.onmessage = (evt) => {
        if (!active) return;
        try {
          const msg = JSON.parse(evt.data);
          if (msg?.type === "presence") applyPresence(msg);
          else if (msg?.type === "chat_message" && msg.message) appendChatMessage(msg.message);
          else if (msg?.type === "chat_message_updated" && msg.message)
            patchChatMessage(msg.message);
          else if (msg?.type === "chat_message_deleted") dropChatMessage(msg.message_id);
          else if (msg?.type === "admin_presence" && typeof msg.admin_id === "number") {
            setOnlineAdmins((prev) => {
              const next = new Set(prev);
              if (msg.online) next.add(msg.admin_id);
              else next.delete(msg.admin_id);
              return next;
            });
            // Administrators are part of the same room: joining/leaving the hub
            // is announced too (skipped for THIS admin — the server echoes our
            // own socket open back to us). Simultaneous admin joins each get
            // their own popup via the same staggered queue as the students,
            // and no chime (hub staff arriving must not chime the room).
            if (msg.admin_id !== adminIdRef.current) {
              const who =
                adminsRef.current.find((a) => a.id === msg.admin_id)?.name ||
                adminsRef.current.find((a) => a.id === msg.admin_id)?.username ||
                `Admin ${msg.admin_id}`;
              enqueueToast(msg.online ? `${who} joined the hub` : `${who} left the hub`, "admin");
            }
            // Another admin just came/goes — refresh the roster so accounts
            // created after our mount still show up by name (quiet poll).
            api.adminAdmins(adminToken)
              .then(setAdmins)
              .catch((e) => {
                if (e?.status === 401) setSessionExpired(true);
              });
          } else if (msg?.type === "admin_roster" && Array.isArray(msg.online_admin_ids)) {
            setOnlineAdmins(new Set(msg.online_admin_ids));
            api.adminAdmins(adminToken)
              .then(setAdmins)
              .catch((e) => {
                if (e?.status === 401) setSessionExpired(true);
              });
          } else if (msg?.type === "notification" && msg.notification) {
            setNotifs((prev) =>
              prev.some((x) => x.id === msg.notification.id)
                ? prev
                : [msg.notification, ...prev]
            );
            setNotifUnread((u) => u + 1);
          }
        } catch {
          // ignore malformed frame
        }
      };
      ws.onclose = (evt) => {
        if (!active) return;
        if (evt?.code === 4401) {
          setSessionExpired(true);
          return;
        }
        scheduleReconnect();
      };
      ws.onerror = () => ws?.close();
    }

    function scheduleReconnect() {
      const delay = Math.min(800 * 2 ** attempt, 10000);
      attempt += 1;
      reconnectTimer = setTimeout(() => {
        recheckBaseUrls();
        connect();
      }, delay);
    }

    connect();
    return () => {
      active = false;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      ws?.close();
    };
  }, [
    adminToken,
    sessionExpired,
    applyPresence,
    appendChatMessage,
    patchChatMessage,
    dropChatMessage,
    enqueueToast,
  ]);

  // One gentle chime + one popup when someone flips offline -> active, or
  // when an already-signed-in user starts a session (WS realtime + the 4s
  // poll drive the same state). A 45s per-user cooldown plus a single
  // note/popup per update keeps the room quiet instead of a chord every
  // poll tick — each activation shows its popup exactly once.
  useEffect(() => {
    const sessionStates = new Set(["studying", "focusing", "off_task"]);
    const next = new Map();
    for (const u of users)
      next.set(u.id, {
        status: u.status || (u.online ? "signed_in" : "offline"),
        label: u.full_name || u.serial_number || `User ${u.id}`,
        role: u.role,
      });
    presenceNowRef.current = next;
    const prev = presenceRef.current;
    if (prev) {
      const now = Date.now();
      // Every transition in this tick is collected — simultaneous joins (a
      // student AND a parent signing in together, or a whole class at once)
      // each get their own popup instead of only the first one.
      const batch = [];
      for (const [id, cur] of next) {
        const before = prev.get(id);
        const prevStatus = before ? before.status : "offline";
        const cameActive = prevStatus === "offline" && cur.status !== "offline";
        const startedSession =
          !sessionStates.has(prevStatus) && sessionStates.has(cur.status);
        const wentOffline = prevStatus !== "offline" && cur.status === "offline";
        // Session finished but they are still signed in (back to signed_in) —
        // announced separately. If they also went offline in the same tick the
        // sign-out grace popup covers it, so no double notification here.
        const leftSession =
          sessionStates.has(prevStatus) &&
          !sessionStates.has(cur.status) &&
          cur.status !== "offline";
        const who = before?.label || cur.label;
        if (cameActive || startedSession || leftSession) {
          // Activation, session-start and session-end carry separate 45s
          // cooldowns so a quick login -> session start -> finish shows all
          // three popups, once each.
          const key = cameActive ? String(id) : startedSession ? `s${id}` : `f${id}`;
          const last = chimeCooldownRef.current[key] || 0;
          if (now - last >= 45000) {
            chimeCooldownRef.current[key] = now;
            // A stale token that comes back ALREADY inside a session is
            // reported as the session start (the more precise fact) rather
            // than a bare "is now active" — otherwise the session-start
            // notification would be swallowed on that transition.
            batch.push({
              text: startedSession
                ? `${cur.label} started a session`
                : cameActive
                  ? `${cur.label} is now active`
                  : `${who} finished their session`,
              tone: leftSession && !startedSession ? "leave" : "active",
            });
          }
        }
        if (cameActive && leaveTimersRef.current[id]) {
          // They came back inside the signed-out grace window — stand down.
          clearTimeout(leaveTimersRef.current[id]);
          delete leaveTimersRef.current[id];
        }
        if (wentOffline) {
          if (explicitLeavesRef.current.delete(id)) {
            // They really signed out (/auth/logout revoked the token, and the
            // server pushed this exact frame): say so now, no waiting.
            if (leaveTimersRef.current[id]) {
              clearTimeout(leaveTimersRef.current[id]);
              delete leaveTimersRef.current[id];
            }
            enqueueToast(`${who} signed out`, "leave");
          } else if (!leaveTimersRef.current[id]) {
            // Only a tab that went QUIET gets the grace window — a refresh, a
            // reconnect or a backgrounded tab must not be announced as a
            // sign-out while it is still there.
            leaveTimersRef.current[id] = setTimeout(() => {
              delete leaveTimersRef.current[id];
              const still = presenceNowRef.current.get(id);
              if (still && still.status === "offline") {
                enqueueToast(`${who} signed out`, "leave");
              }
            }, 8000);
          }
        }
      }
      if (batch.length > 0) {
        // ONE chime for the batch, then each popup released 350ms apart. A big
        // burst is summarised so the room never floods.
        playActiveChime();
        if (batch.length > 4) {
          enqueueToast(batch[0].text, batch[0].tone);
          for (const item of batch.slice(1, 4)) enqueueToast(item.text, item.tone);
          enqueueToast(`+${batch.length - 4} more updates`, "batch");
        } else {
          for (const item of batch) enqueueToast(item.text, item.tone);
        }
      }
    }
    presenceRef.current = next;
  }, [users, enqueueToast]);

  function handleAdminError(e, quiet) {
    if (e?.status === 401) setSessionExpired(true);
    else if (!quiet) setNotice(e?.message || "Something went wrong.");
  }

  const loadUsers = useCallback(
    async (q, quiet) => {
      if (!quiet) setLoading(true);
      try {
        const list = q?.trim()
          ? await api.adminSearchUsers(adminToken, q.trim())
          : await api.adminUsers(adminToken);
        setUsers(list);
      } catch (e) {
        if (e?.status === 401) setSessionExpired(true);
        else if (!quiet) handleAdminError(e);
      } finally {
        if (!quiet) setLoading(false);
      }
    },
    [adminToken]
  );

  const loadNotifs = useCallback(async () => {
    try {
      const list = await api.adminNotifications(adminToken);
      setNotifs(list);
      setNotifUnread(list.filter((n) => !n.read_at).length);
    } catch (e) {
      if (e?.status === 401) setSessionExpired(true);
    }
  }, [adminToken]);

  useEffect(() => {
    if (adminToken && !sessionExpired) loadNotifs();
  }, [adminToken, sessionExpired, loadNotifs]);

  // --- Smart ops tab: account requests + block-proposal tickets + AUTO ---
  const loadOps = useCallback(
    async (opts = {}) => {
      if (!adminToken || sessionExpired) return;
      if (!opts.quiet) setOpsLoading(true);
      try {
        const [reqs, tickets, settings] = await Promise.all([
          api.adminAccountRequests(adminToken, opts.reqStatus || acctReqStatus),
          api.adminBlockTickets(adminToken, "open"),
          api.adminInterventionSettings(adminToken),
        ]);
        setAcctRequests(Array.isArray(reqs) ? reqs : []);
        setBlockTickets(Array.isArray(tickets) ? tickets : []);
        setAutoBlock(Boolean(settings.auto_block));
        setOpsError(null);
      } catch (e) {
        if (e?.status === 401) setSessionExpired(true);
        else setOpsError(e?.message || "Couldn't load operations data.");
      } finally {
        if (!opts.quiet) setOpsLoading(false);
      }
    },
    [adminToken, sessionExpired, acctReqStatus]
  );

  async function decideAccountRequest(id, action) {
    try {
      if (action === "approve") await api.approveAccountRequest(adminToken, id);
      else await api.denyAccountRequest(adminToken, id);
      await loadOps({ quiet: true });
    } catch (e) {
      handleAdminError(e);
    }
  }

  async function decideTicket(id, action) {
    try {
      await api.adminDecideBlockTicket(adminToken, id, action);
      await loadOps({ quiet: true });
    } catch (e) {
      handleAdminError(e);
    }
  }

  async function updateAutoBlock(next) {
    const prev = autoBlock;
    setAutoBlock(next); // optimistic — the switch should feel instant
    try {
      await api.adminUpdateInterventionSettings(adminToken, next);
    } catch (e) {
      setAutoBlock(prev);
      handleAdminError(e);
    }
  }

  // Day buckets for the bell. Memoised so a presence frame arriving every 1.5s
  // never re-sorts the notification feed. The pipeline is: unread toggle ->
  // kind slice -> name/message search -> day order -> optional oldest-first.
  const notifGroups = useMemo(() => {
    let src = notifFilter === "unread" ? notifs.filter((n) => !n.read_at) : notifs;
    const slice = NOTIF_FILTERS.find((f) => f.id === notifKindFilter);
    if (slice?.kinds) src = src.filter((n) => slice.kinds.includes(n.kind));
    const q = notifQuery.trim().toLowerCase();
    if (q) src = src.filter((n) => notifSearchText(n).includes(q));
    // Sorting on the id is stable and cheap; created_at can tie when a burst
    // lands inside the same second.
    src = [...src].sort((a, b) => (notifOldestFirst ? a.id - b.id : b.id - a.id));
    return groupNotifsByDay(src);
  }, [notifs, notifFilter, notifKindFilter, notifQuery, notifOldestFirst]);

  const notifTotalShown = useMemo(
    () => notifGroups.reduce((sum, g) => sum + g.items.length, 0),
    [notifGroups]
  );

  // Chat view-model: a day divider whenever the date changes, the sender name
  // only when it changes (or after a long pause), and a marker for where the
  // admin last left off. Consecutive messages from one person therefore read as
  // one block instead of a stack of repeated names.
  const chatView = useMemo(() => {
    const rows = [];
    let lastDay = null;
    let lastSender = null;
    let lastAt = 0;
    for (const m of chatMsgs) {
      const mine = m.admin_id != null && m.admin_id === admin?.id;
      const day = dayLabelFull(m.created_at);
      const newDay = day !== lastDay;
      const d = parseNaiveUtc(m.created_at);
      const at = d ? d.getTime() : 0;
      const sameSender =
        !newDay &&
        lastSender === (m.sender_name ?? "") &&
        !mine &&
        at - lastAt < 5 * 60 * 1000;
      const isUnreadStart =
        chatUnreadFrom != null && m.id > chatUnreadFrom && !rows.some((r) => r.unreadStart);
      rows.push({
        m,
        mine,
        showDay: newDay,
        day,
        showSender: !mine && !sameSender,
        unreadStart: isUnreadStart,
      });
      lastDay = day;
      lastSender = m.sender_name ?? "";
      lastAt = at;
    }
    return rows;
  }, [chatMsgs, admin?.id, chatUnreadFrom]);

  // Telegram-style Organized panel: every picture, voice note and link in the
  // room, newest first, each carrying its sender + time so anything can be
  // traced back to who sent it. Clicking an item jumps to the message in chat.
  const chatOrganizedData = useMemo(() => {
    const media = [];
    const audio = [];
    const links = [];
    const pinned = [];
    const important = [];
    for (const m of chatMsgs) {
      if (m.deleted_at) continue;
      const ctx = {
        id: m.id,
        sender: m.sender_name || "Admin",
        at: m.created_at,
        mine: m.admin_id != null && m.admin_id === admin?.id,
        body: m.body || "",
        token: m.attachment_token,
        name: m.attachment_name,
        seconds: m.attachment_seconds,
      };
      if (m.pinned) pinned.push({ ...ctx, body: m.body || "" });
      if (m.important_label) important.push({ ...ctx, label: m.important_label });
      if (m.attachment_kind === "image" && m.attachment_token) media.push(ctx);
      if (m.attachment_kind === "audio" && m.attachment_token) audio.push(ctx);
      CHAT_URL_RE.lastIndex = 0;
      let mm;
      const text = String(m.body || "");
      while ((mm = CHAT_URL_RE.exec(text)) !== null) {
        const raw = mm[0];
        const href = raw.startsWith("http") ? raw : `https://${raw}`;
        links.push({ ...ctx, url: href, domain: linkDomain(raw), raw });
      }
    }
    const byNewest = (a, b) => (String(b.at || "").localeCompare(String(a.at || "")) || b.id - a.id);
    media.sort(byNewest);
    audio.sort(byNewest);
    links.sort(byNewest);
    // Pinned reads like an anchor list: oldest pinned first (the message that
    // was pinned first stays on top), Important newest-first like the media tabs.
    pinned.sort((a, b) => a.id - b.id);
    important.sort(byNewest);
    return { media, audio, links, pinned, important };
  }, [chatMsgs, admin?.id]);

  // One-line preview of the message a reply points at. The server only sends
  // text back when there is some; a deleted original, a voice note or a photo
  // all come through empty, so name what is actually there instead of
  // claiming the reply is broken.
  const chatReplySnippet = (m) => {
    if (m.reply_to_body) return m.reply_to_body;
    const target = chatMsgs.find((x) => x.id === m.reply_to_id);
    if (!target) return "Original message unavailable";
    if (target.deleted_at) return "Original message deleted";
    if (target.attachment_kind === "audio") return "Voice note";
    if (target.attachment_kind === "image") return "Photo";
    if (target.pinned) return "Pinned message";
    return "Original message";
  };

  // Chat history replay — live frames arrive over /ws/admin after this.
  useEffect(() => {
    if (!adminToken || sessionExpired) return undefined;
    let alive = true;
    (async () => {
      try {
        const rows = await api.adminChatMessages(adminToken);
        if (!alive) return;
        setChatMsgs(rows);
        setChatUnread(
          rows.filter((m) => m.id > chatSeenRef.current && m.admin_id !== adminIdRef.current)
            .length
        );
      } catch (e) {
        if (e?.status === 401 && alive) setSessionExpired(true);
      }
    })();
    return () => {
      alive = false;
    };
  }, [adminToken, sessionExpired]);

  // Keep the newest message in view while the panel is open.
  // Smart follow: only stick to the bottom when the admin is ALREADY reading
  // the newest messages. Someone scrolling back through history keeps their
  // place, and gets a "jump to latest" pill instead of being yanked away on
  // every incoming frame.
  const jumpToLatest = useCallback(() => {
    const el = chatListRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    setChatStuck(true);
    setChatNewBelow(0);
  }, []);

  // Keep stick-to-bottom off for the whole jump. The list counts "at bottom"
  // with 80px of slack, so the first moments of a smooth scroll away from the
  // bottom still read as "at bottom" — without this guard the stick effect
  // re-runs and yanks scrollTop straight back, which is exactly the jump that
  // flashed but never moved.
  const armJumpGuard = useCallback((targetId, delay = 700) => {
    pendingJumpRef.current = targetId;
    if (jumpGuardTimerRef.current) window.clearTimeout(jumpGuardTimerRef.current);
    jumpGuardTimerRef.current = window.setTimeout(() => {
      jumpGuardTimerRef.current = 0;
      if (pendingJumpRef.current === targetId) pendingJumpRef.current = null;
      // Re-sync "stuck" with where the reader actually landed.
      const el = chatListRef.current;
      if (el) setChatStuck(el.scrollHeight - el.scrollTop - el.clientHeight < 80);
    }, delay);
  }, []);

  // Telegram-style "tap the reply to read the original": scroll the quoted
  // message (or any message id) into view and flash it so the reader can find
  // the context behind a reply. Also used by the Organized panel.
  // If the target is NOT the loaded window (older than the newest 200), page
  // through history until it is found — the jump now works for ANY message the
  // room has ever sent, not just the ones cached on open.
  const scrollAndFlashMessage = useCallback((el) => {
    if (!el) return;
    // Arm (or re-arm) the stick guard FIRST: setChatStuck(false) below starts a
    // render, and the guard must already be up before scroll events land.
    armJumpGuard(pendingJumpRef.current ?? -1);
    setChatStuck(false);
    const container = chatListRef.current;
    const beforeTop = container ? container.scrollTop : 0;
    try {
      el.scrollIntoView({ block: "center", behavior: "smooth" });
    } catch {
      /* very old engines — the manual fallback below still centers it */
    }
    // A smooth scroll may silently no-op when the row was just re-keyed or the
    // container was empty. Detect that and center it by hand so the jump is
    // never lost — the exact failure a fresh live message used to hit.
    if (container) {
      requestAnimationFrame(() => {
        const moved = Math.abs(container.scrollTop - beforeTop) > 1;
        const rect = el.getBoundingClientRect();
        const cRect = container.getBoundingClientRect();
        const offscreen = rect.bottom < cRect.top || rect.top > cRect.bottom;
        if (!moved && offscreen) {
          const delta = rect.top - cRect.top;
          container.scrollTop += delta - (container.clientHeight - el.offsetHeight) / 2;
        }
      });
    }
    el.classList.add("is-flashing");
    chatFlashRef.current = el;
    window.setTimeout(() => {
      if (chatFlashRef.current === el) {
        el.classList.remove("is-flashing");
        chatFlashRef.current = null;
      }
    }, 2400);
  }, [armJumpGuard]);

  const loadOlderChatPage = useCallback(
    async (olderThanId) => {
      if (chatLoadingOlderRef.current) return null;
      chatLoadingOlderRef.current = true;
      setChatLoadingOlder(true);
      try {
        const page = await api.adminChatMessages(adminToken, { limit: 200, before_id: olderThanId });
        if (Array.isArray(page) && page.length) {
          setChatMsgs((prev) => mergeChatMessages(page, prev));
        }
        return page;
      } catch (e) {
        if (e?.status === 401) setSessionExpired(true);
        return null;
      } finally {
        chatLoadingOlderRef.current = false;
        setChatLoadingOlder(false);
      }
    },
    [adminToken]
  );

  const jumpToChatMessage = useCallback(
    async (targetId) => {
      if (targetId == null) return;
      setChatOrganized(false);
      setChatOpen(true);
      chatOpenRef.current = true;
      if (chatFlashRef.current) {
        chatFlashRef.current.classList.remove("is-flashing");
        chatFlashRef.current = null;
      }
      const el = chatMsgElsRef.current.get(targetId);
      if (el) {
        armJumpGuard(targetId);
        scrollAndFlashMessage(el);
        // The panel can still reshape right after this click — the Organised
        // drawer closing, the roster collapsing. Re-check once it has settled
        // and only then correct a jump that got pushed out of view.
        const token = ++jumpSettleRef.current;
        setTimeout(() => {
          if (token !== jumpSettleRef.current) return;
          const again = chatMsgElsRef.current.get(targetId);
          const list = chatListRef.current;
          if (!again || !list) return;
          const row = again.getBoundingClientRect();
          const box = list.getBoundingClientRect();
          if (row.bottom < box.top + 8 || row.top > box.bottom - 8) {
            scrollAndFlashMessage(again);
          }
        }, 320);
        return;
      }
      const startId = chatMsgs.length > 0 ? chatMsgs[0].id : Number.MAX_SAFE_INTEGER;
      const newestId = chatMsgs.length > 0 ? chatMsgs[chatMsgs.length - 1].id : 0;
      if (targetId >= startId && targetId <= newestId) {
        // We HOLD this message but its bubble has not attached yet — the exact
        // fresh-live-message case. Arm the pending jump; the row's ref callback
        // fires it the moment it mounts. No polling window to miss.
        armJumpGuard(targetId, 5000);
        return;
      }
      if (targetId >= startId) {
        // Not among the ids we hold: newer than the newest (never delivered) or
        // missing from the window — nothing older to page through either way.
        setChatError("That message is not in the loaded history.");
        return;
      }
      // Deep-dive: fetch older pages until the target id appears (or history
      // runs out). Each page is 200 — a very old reply resolves in a few hops.
      if (chatSearchingRef.current) return;
      chatSearchingRef.current = true;
      setChatSearching(true);
      armJumpGuard(targetId, 5000); // stays armed until the merged page mounts it
      try {
        let oldestId = startId;
        let hops = 0;
        while (oldestId > targetId) {
          const page = await loadOlderChatPage(oldestId);
          if (!page || page.length === 0) break;
          oldestId = page[0].id;
          hops += 1;
          if (page.some((p) => p.id === targetId) || page.length < 200) break;
          if (hops > 20) break; // safety valve — never hang on a huge room
        }
      } finally {
        chatSearchingRef.current = false;
        setChatSearching(false);
      }
      // The ref callback usually fired during the merge render. Give it one
      // frame, then fall back to an explicit lookup before declaring a miss.
      await new Promise((r) => requestAnimationFrame(() => r()));
      const found = chatMsgElsRef.current.get(targetId);
      if (found) {
        armJumpGuard(targetId);
        scrollAndFlashMessage(found);
        return;
      }
      await new Promise((r) => setTimeout(r, 180));
      if (chatMsgElsRef.current.get(targetId)) return; // callback handled it
      pendingJumpRef.current = null;
      setChatError("Couldn't locate that message — it may have been deleted.");
    },
    [chatMsgs, scrollAndFlashMessage, loadOlderChatPage, armJumpGuard]
  );

  useEffect(() => {
    if (!chatOpen) return;
    if (pendingJumpRef.current != null) {
      // A reply-jump is in flight — never yank the reader back to the bottom.
      setChatNewBelow(0);
      return;
    }
    const el = chatListRef.current;
    if (!el) return;
    if (chatStuck) {
      el.scrollTop = el.scrollHeight;
      setChatNewBelow(0);
    } else if (chatMsgs.length) {
      setChatNewBelow((n) => n + 1);
    }
  }, [chatMsgs, chatOpen, chatStuck]);

  const onChatScroll = useCallback(() => {
    const el = chatListRef.current;
    if (!el) return;
    // 80px of slack so a slightly-off scroll still counts as "at the bottom".
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    // While a jump is animating, readings inside the 80px bottom slack are
    // stale: never flip stick back on (the bottom effect would cancel the
    // scroll) — armJumpGuard settles both values once the reader lands.
    if (pendingJumpRef.current == null) {
      setChatStuck(atBottom);
      if (atBottom) setChatNewBelow(0);
    }
    // Scroll-up loading (Messenger-style): near the top of the loaded window,
    // pull the next older page IF one more may exist. Preserve the reader's
    // place: they asked for older text, not to be yanked down.
    if (el.scrollTop < 40 && chatMsgs.length > 0 && chatMsgs[0].id > 1) {
      const preserve = { height: el.scrollHeight, top: el.scrollTop };
      const load = async () => {
        const page = await loadOlderChatPage(chatMsgs[0].id);
        if (page && page.length && chatListRef.current) {
          const l = chatListRef.current;
          l.scrollTop = l.scrollHeight - preserve.height + preserve.top;
        }
      };
      load().catch(() => {});
    }
  }, [chatMsgs, loadOlderChatPage]);

  function toggleChat() {
    const next = !chatOpen;
    setChatOpen(next);
    chatOpenRef.current = next;
    if (next) {
      setNotifOpen(false);
      // Draw the "new messages" divider above the first unseen one, then clear
      // the badge exactly as before.
      const maxId = chatMsgs.reduce((m, x) => Math.max(m, x.id), chatSeenRef.current);
      // Only mark a divider when there is history ABOVE it - on a first-ever
      // open "everything is new" would just be noise.
      const hadUnseen =
        chatSeenRef.current > 0 && chatMsgs.some((x) => x.id > chatSeenRef.current);
      setChatUnreadFrom(hadUnseen ? chatSeenRef.current : null);
      setChatUnread(0);
      setChatStuck(true);
      setChatNewBelow(0);
      chatSeenRef.current = maxId;
      try {
        window.localStorage.setItem("stubilly_admin_chat_seen", String(maxId));
      } catch {
        /* storage blocked — session badge still works */
      }
    }
  }

  async function sendChat(e) {
    e.preventDefault();
    const body = chatDraft.trim();
    // A picture or voice note can be sent on its own, so an empty draft is
    // only a no-op when there is nothing attached either.
    if (!body && !chatAttach) return;
    setChatSending(true);
    setChatError("");
    try {
      const m = await api.adminSendChat(adminToken, body, {
        reply_to_id: chatReply?.id ?? undefined,
        attachment_token: chatAttach?.token ?? undefined,
      });
      setChatDraft("");
      setChatReply(null);
      setChatAttach(null);
      appendChatMessage(m);
    } catch (err) {
      setChatError(err?.message || "Could not send that message.");
      handleAdminError(err);
    } finally {
      setChatSending(false);
    }
  }

  // --- Reply / Edit / Delete ------------------------------------------------
  function startReply(m) {
    if (m.deleted_at) return;
    setChatEditId(null);
    setChatReply(m);
    // Keep the current draft — an admin mid-sentence who taps Reply shouldn't
    // lose their autosaved text (the reply just carries it when sent).
    setChatError("");
  }
  function cancelReply() {
    setChatReply(null);
  }
  function startEdit(m) {
    setChatReply(null);
    setChatEditId(m.id);
    setChatEditText(m.body || "");
    setChatError("");
  }
  function cancelEdit() {
    setChatEditId(null);
    setChatEditText("");
  }
  async function saveEdit() {
    const body = chatEditText.trim();
    if (!body || chatEditId == null) return;
    setChatSending(true);
    try {
      const m = await api.adminEditChat(adminToken, chatEditId, body);
      patchChatMessage(m);
      setChatEditId(null);
      setChatEditText("");
    } catch (err) {
      setChatError(err?.message || "Could not edit that message.");
      handleAdminError(err);
    } finally {
      setChatSending(false);
    }
  }
  async function removeChat(m) {
    setChatSending(true);
    try {
      await api.adminDeleteChat(adminToken, m.id);
      dropChatMessage(m.id);
      // A reply pointing at it loses its quote, exactly like Telegram.
      if (chatReply?.id === m.id) setChatReply(null);
      if (chatEditId === m.id) setChatEditId(null);
    } catch (err) {
      setChatError(err?.message || "Could not delete that message.");
      handleAdminError(err);
    } finally {
      setChatSending(false);
    }
  }

  // Pin / IMPORTANT — any admin may flag any message. Persisted server-side
  // and broadcast as "chat_message_updated" (NO "edited" marker), so one hub
  // pinning a message is instantly visible to every other hub in the room.
  async function toggleChatPin(m) {
    setChatSending(true);
    setChatError("");
    try {
      const updated = await api.adminSetChatFlags(adminToken, m.id, { pinned: !m.pinned });
      patchChatMessage(updated);
    } catch (err) {
      setChatError(err?.message || "Could not update that pin.");
      handleAdminError(err);
    } finally {
      setChatSending(false);
    }
  }
  async function toggleChatImportant(m) {
    setChatSending(true);
    setChatError("");
    try {
      const updated = await api.adminSetChatFlags(adminToken, m.id, {
        important_label: m.important_label ? null : "Important",
      });
      patchChatMessage(updated);
    } catch (err) {
      setChatError(err?.message || "Could not update that label.");
      handleAdminError(err);
    } finally {
      setChatSending(false);
    }
  }

  // --- Attach a picture -----------------------------------------------------
  async function pickChatFile(e) {
    const file = e.target.files?.[0];
    e.target.value = ""; // let the same file be picked twice
    if (!file) return;
    setChatError("");
    setChatSending(true);
    try {
      const meta = await api.adminUploadChatMedia(adminToken, file, null);
      setChatAttach(meta);
    } catch (err) {
      setChatError(err?.message || "That file could not be attached.");
      handleAdminError(err);
    } finally {
      setChatSending(false);
    }
  }

  // --- Record a voice note --------------------------------------------------
  async function toggleChatRecording() {
    if (chatRecording) {
      chatRecRef.current?.stop();
      return;
    }
    setChatError("");
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setChatError("This browser cannot record audio here - try Chrome or Edge.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // webm/opus plays inline in Chrome/Edge; mp4 is the Safari fallback.
      const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find(
        (t) => MediaRecorder.isTypeSupported?.(t)
      );
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      const chunks = [];
      const startedAt = Date.now();
      rec.ondataavailable = (ev) => ev.data?.size && chunks.push(ev.data);
      rec.onstop = async () => {
        clearInterval(chatRecTimerRef.current);
        stream.getTracks().forEach((t) => t.stop());
        setChatRecording(false);
        const seconds = Math.max(0.5, (Date.now() - startedAt) / 1000);
        try {
          const type = rec.mimeType || mime || "audio/webm";
          const file = new File(chunks, `voice-${Date.now()}.${type.includes("mp4") ? "m4a" : "webm"}`, {
            type,
          });
          if (!file.size) {
            setChatError("That recording was empty - try again.");
            return;
          }
          const meta = await api.adminUploadChatMedia(adminToken, file, seconds);
          setChatAttach(meta);
        } catch (err) {
          setChatError(err?.message || "That voice note could not be attached.");
        }
      };
      rec.start();
      chatRecRef.current = rec;
      setChatRecording(true);
      setChatRecSecs(0);
      chatRecTimerRef.current = setInterval(
        () => setChatRecSecs((s) => s + 1),
        1000
      );
    } catch {
      setChatError("Microphone permission was declined - allow it to send a voice note.");
    }
  }

  async function openNotif(n) {
    if (!n.read_at) {
      setNotifs((prev) =>
        prev.map((x) => (x.id === n.id ? { ...x, read_at: new Date().toISOString() } : x))
      );
      setNotifUnread((u) => Math.max(0, u - 1));
      try {
        await api.adminReadNotification(adminToken, n.id);
      } catch {
        // best effort
      }
    }
    const uid = n.payload?.user_id;
    // Account requests jump to Smart Ops > Accounts (the approval queue),
    // regardless of whether a user_id exists yet.
    if (n.kind === "account_request") {
      setNotifOpen(false);
      setTab("ops");
      setSmartOpsSection("accounts");
      return;
    }
    // Entries with no account behind them (system notes) only mark
    // themselves read - clicking must not eject the admin from the bell.
    if (!uid) return;
    setNotifOpen(false);
    // Session start/end jumps to the Sessions Hub opened on that person, so
    // "they started math" lands on their session list, not the account page.
    if (n.kind === "user_session_started" || n.kind === "user_session_finished") {
      setTab("sessions");
      await revealPersonSessions(uid);
      return;
    }
    setTab("users");
    // The account may have been deleted since the event fired. Verify before
    // navigating so a dangling notification never leaves a 404 banner up;
    // a stale notice is dropped instead of clicked.
    try {
      await api.adminGetUser(adminToken, uid);
      await openUser(uid);
    } catch (e) {
      const is404 = e?.status === 404;
      if (is404) {
        setNotifs((prev) => prev.filter((x) => x.id !== n.id));
        setNotifUnread((u) => Math.max(0, u - 1));
        try {
          await api.adminDeleteNotification(adminToken, n.id);
        } catch {
          /* best effort */
        }
        setNotice("This account was deleted — notification removed.");
        setTimeout(() => setNotice(null), 4000);
        return;
      }
      handleAdminError(e);
    }
  }

  async function readAllNotifs() {
    setNotifs((prev) =>
      prev.map((x) => ({ ...x, read_at: x.read_at || new Date().toISOString() }))
    );
    setNotifUnread(0);
    try {
      await api.adminReadAllNotifications(adminToken);
    } catch {
      // best effort
    }
  }

  // Closing the panel always drops select mode and the Clear all arm, so a
  // later visit starts from plain browsing.
  function closeNotifPanel() {
    setNotifOpen(false);
    setNotifSelectMode(false);
    setNotifSelected([]);
    setNotifClearArmed(false);
  }

  function toggleNotifSelect(n) {
    setNotifSelected((prev) =>
      prev.includes(n.id) ? prev.filter((x) => x !== n.id) : [...prev, n.id]
    );
  }

  function exitNotifSelect() {
    setNotifSelectMode(false);
    setNotifSelected([]);
  }

  async function deleteSelectedNotifs() {
    if (notifSelected.length === 0 || notifBusy) return;
    setNotifBusy(true);
    const ids = [...notifSelected];
    const removedUnread = notifs.filter((x) => ids.includes(x.id) && !x.read_at).length;
    // Optimistic: the entries leave the bell now; the server records a
    // per-admin dismissal so nobody else's feed changes.
    setNotifs((prev) => prev.filter((x) => !ids.includes(x.id)));
    setNotifUnread((u) => Math.max(0, u - removedUnread));
    exitNotifSelect();
    try {
      await api.adminDismissNotifications(adminToken, ids);
    } catch (e) {
      loadNotifs(); // rollback to server truth
      if (e?.status === 401) setSessionExpired(true);
    } finally {
      setNotifBusy(false);
    }
  }

  async function clearAllNotifs() {
    if (notifBusy) return;
    if (!notifClearArmed) {
      setNotifClearArmed(true);
      setTimeout(() => setNotifClearArmed(false), 3000);
      return;
    }
    setNotifClearArmed(false);
    setNotifBusy(true);
    setNotifs([]);
    setNotifUnread(0);
    exitNotifSelect();
    try {
      await api.adminClearNotifications(adminToken);
    } catch (e) {
      loadNotifs(); // rollback to server truth
      if (e?.status === 401) setSessionExpired(true);
    } finally {
      setNotifBusy(false);
    }
  }

  async function createAccount(e) {
    e.preventDefault();
    if (creating) return;
    const payload = {
      full_name: newAcct.full_name.trim(),
      email: newAcct.email.trim(),
      password: newAcct.password,
      role: newAcct.role,
      ...(newAcct.date_of_birth ? { date_of_birth: newAcct.date_of_birth } : {}),
      ...(newAcct.role === "student" && newAcct.parent_id
        ? { parent_id: Number(newAcct.parent_id) }
        : {}),
    };
    if (!payload.email || !payload.password) {
      setNotice("Email and password are required.");
      return;
    }
    if (payload.password.length < 8) {
      setNotice("Password must be at least 8 characters.");
      return;
    }
    setCreating(true);
    try {
      const u = await api.adminCreateUser(adminToken, payload);
      setNotice(`Account created: ${u.full_name || u.email || u.serial_number}`);
      setNewAcct(EMPTY_ACCOUNT);
      setShowCreate(false);
      await loadUsers(query, true);
    } catch (err) {
      handleAdminError(err);
    } finally {
      setCreating(false);
      setTimeout(() => setNotice(null), 4000);
    }
  }

  const loadSessions = useCallback(
    async (quiet) => {
      if (!quiet) setLoading(true);
      try {
        const rows = await api.adminSessions(adminToken);
        setSessions(rows);
      } catch (e) {
        if (e?.status === 401) setSessionExpired(true);
        else if (!quiet) handleAdminError(e);
      } finally {
        if (!quiet) setLoading(false);
      }
    },
    [adminToken]
  );

  const loadProgress = useCallback(
    async (range, userId) => {
      if (!userId) return;
      setProgressLoading(true);
      try {
        setProgress(await api.adminAnalyticsOverview(adminToken, userId, range));
      } catch (e) {
        handleAdminError(e);
      } finally {
        setProgressLoading(false);
      }
    },
    [adminToken]
  );

  const loadDetailData = useCallback(
    async (userId, { sessionsOnly = false } = {}) => {
      if (!userId) return;
      if (!sessionsOnly) {
        try {
          const detail = await api.adminGetUser(adminToken, userId);
          setSelected((prev) => {
            if (!prev?.user || prev.user.id !== userId) return prev;
            return {
              ...detail,
              user: { ...detail.user, ...prev.user, ...detail.user },
            };
          });
        } catch (e) {
          handleAdminError(e, true);
        }
      }
      try {
        const rows = await api.adminGetUserSessions(adminToken, userId);
        setUserSessions(rows);
      } catch (e) {
        handleAdminError(e, true);
      }
    },
    [adminToken]
  );

  const loadAdmins = useCallback(
    async (quiet) => {
      try {
        setAdmins(await api.adminAdmins(adminToken));
      } catch (e) {
        if (e?.status === 401) setSessionExpired(true);
        else if (!quiet) handleAdminError(e);
      }
    },
    [adminToken]
  );

  useEffect(() => {
    loadSessions();
  }, [loadSessions]);

  useEffect(() => {
    if (adminToken && !sessionExpired) loadAdmins(true);
  }, [adminToken, sessionExpired, loadAdmins]);

  useEffect(() => {
    if (tab === "admins") loadAdmins();
  }, [loadAdmins, tab]);

  useEffect(() => {
    if (tab === "ops") loadOps();
  }, [loadOps, tab]);

  // Periodic poll fallback for presence
  useEffect(() => {
    if (sessionExpired) return undefined;
    const id = setInterval(() => {
      loadUsers(query, true);
      loadSessions(true);
      if (tab === "admins") loadAdmins(true);
      if (tab === "ops") loadOps({ quiet: true });
      if (selected?.user && (detailTab === "sessions" || tab === "sessions")) {
        loadDetailData(selected.user.id, { sessionsOnly: true });
      }
    }, 4000);
    return () => clearInterval(id);
  }, [
    loadUsers,
    loadSessions,
    loadAdmins,
    loadOps,
    loadDetailData,
    query,
    selected?.user?.id,
    tab,
    detailTab,
    sessionExpired,
  ]);

  useEffect(() => {
    if (selected?.user && progressRange) {
      loadProgress(progressRange, selected.user.id);
    }
  }, [progressRange, loadProgress, selected?.user?.id]);

  // Debounced search
  useEffect(() => {
    const delay = query.trim() ? 220 : 0;
    const id = setTimeout(() => loadUsers(query, true), delay);
    return () => clearTimeout(id);
  }, [query, loadUsers]);

  async function openUser(userId, opts = {}) {
    setTab("users");
    setDetailTab(opts.detailTab || "overview");
    setShowUserPw(false);
    const listed = users.find((u) => u.id === userId);
    if (listed?.parent_id) {
      setCollapsedParents((p) => ({ ...p, [listed.parent_id]: false }));
    }
    try {
      const detail = await api.adminGetUser(adminToken, userId);
      setSelected(detail);
      setDraftBlocked(detail.user.blocked_sites || []);
      setDraftAllowed(detail.user.allowed_sites || []);
      setSelectedParentLink(detail.user.parent_id ? String(detail.user.parent_id) : "");
      if (detail.user.parent_id) {
        setCollapsedParents((p) => ({ ...p, [detail.user.parent_id]: false }));
      }
    } catch (e) {
      handleAdminError(e);
    }
    try {
      const rows = await api.adminGetUserSessions(adminToken, userId);
      setUserSessions(rows);
    } catch (e) {
      handleAdminError(e);
    }
    try {
      setProgress(await api.adminAnalyticsOverview(adminToken, userId, progressRange));
    } catch (e) {
      handleAdminError(e);
    }
  }

  async function revealPersonSessions(userId) {
    setActiveSessionUserId(userId);
    try {
      const rows = await api.adminGetUserSessions(adminToken, userId);
      setUserSessions(rows);
    } catch (e) {
      handleAdminError(e, true);
    }
  }

  async function savePolicy() {
    if (!selected) return;
    try {
      await api.adminUpdatePolicy(adminToken, selected.user.id, draftBlocked, draftAllowed);
      setNotice("Policy saved — active live on student machine.");
      await openUser(selected.user.id, { detailTab: "policy" });
      loadUsers(query, true);
    } catch (e) {
      handleAdminError(e);
    } finally {
      setTimeout(() => setNotice(null), 4000);
    }
  }

  async function handleLinkGuardian(studentId, parentId) {
    try {
      await api.adminUpdateUser(adminToken, studentId, {
        parent_id: parentId ? Number(parentId) : null,
      });
      setNotice("Guardian relationship updated.");
      setRelinkingUserId(null);
      await loadUsers(query, true);
      if (selected?.user?.id === studentId) {
        await openUser(studentId);
      }
    } catch (e) {
      handleAdminError(e);
    } finally {
      setTimeout(() => setNotice(null), 4000);
    }
  }

  async function handleSetConsent(studentId, granted) {
    try {
      await api.adminSetConsent(adminToken, studentId, granted);
      setNotice(granted ? "Monitoring consent granted." : "Monitoring consent revoked.");
      // Show the new state at once, then re-read the account. Gating the refresh
      // on the `selected` render closure could skip it and leave the card
      // showing the previous consent state (the account really had changed).
      setSelected((prev) =>
        prev?.user?.id === studentId
          ? {
              ...prev,
              user: { ...prev.user, consent_granted: granted, consent_at: new Date().toISOString() },
            }
          : prev
      );
      await openUser(studentId);
      await loadUsers(query, true);
    } catch (e) {
      handleAdminError(e);
    } finally {
      setTimeout(() => setNotice(null), 4000);
    }
  }

  function closeDetail() {
    setSelected(null);
    setDraftBlocked([]);
    setDraftAllowed([]);
    setUserSessions([]);
    setProgress(null);
    setDetailTab("overview");
    setShowUserPw(false);
  }

  async function createAdminAccount(e) {
    e.preventDefault();
    if (!newAdminName.trim() || !newAdminUsername.trim() || !newAdminPassword || createAdminBusy) return;
    setCreateAdminBusy(true);
    try {
      await api.adminCreateAdmin(adminToken, {
        name: newAdminName.trim(),
        username: newAdminUsername.trim(),
        password: newAdminPassword,
      });
      setNewAdminName("");
      setNewAdminUsername("");
      setNewAdminPassword("");
      setCreatingAdmin(false);
      setNotice(`Admin account "${newAdminName.trim()}" created.`);
      await loadAdmins();
    } catch (err) {
      handleAdminError(err);
    } finally {
      setCreateAdminBusy(false);
      setTimeout(() => setNotice(null), 4000);
    }
  }

  async function deleteAdminAccount(id) {
    if (!window.confirm("Delete this administrator account?")) return;
    try {
      await api.adminDeleteAdmin(adminToken, id);
      setNotice("Administrator removed.");
      await loadAdmins();
    } catch (err) {
      handleAdminError(err);
    } finally {
      setTimeout(() => setNotice(null), 4000);
    }
  }

  async function changeMyPassword(e) {
    e.preventDefault();
    if (!passwordDraft || passwordDraft.length < 4) return;
    try {
      const res = await api.adminChangeAdminPassword(adminToken, passwordDraft);
      setMyPassword(res.password);
      setPasswordDraft("");
      setNotice("Admin password updated.");
    } catch (err) {
      handleAdminError(err);
    } finally {
      setTimeout(() => setNotice(null), 4000);
    }
  }

  async function resetStudentPassword(userId) {
    if (!resetDraft || resetDraft.length < 4) return;
    setResetBusy(true);
    try {
      await api.adminSetUserPassword(adminToken, userId, resetDraft);
      setNotice("Password updated successfully.");
      setResetUserId(null);
      setResetDraft("");
      await loadUsers(query, true);
      if (selected?.user?.id === userId) await openUser(userId);
    } catch (err) {
      handleAdminError(err);
    } finally {
      setResetBusy(false);
      setTimeout(() => setNotice(null), 4000);
    }
  }

  async function removeUserAccount(user) {
    const label = user.email || user.full_name || user.serial_number;
    const roleWord = user.role === "parent" ? "guardian" : "student";
    if (
      !window.confirm(
        `Remove this ${roleWord} account (${label})? This permanently deletes the account and its study data.`,
      )
    ) {
      return;
    }
    try {
      await api.adminDeleteUser(adminToken, user.id);
      setNotice(`Account removed: ${label}`);
      closeDetail();
      await loadUsers(query, true);
    } catch (err) {
      handleAdminError(err);
    } finally {
      setTimeout(() => setNotice(null), 4000);
    }
  }

  function handleCopy(text) {
    if (!text) return;
    navigator.clipboard?.writeText(text);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  }

  // --- Data organization: Households & Students ---
  const query_ = query.trim().toLowerCase();
  const parentAccounts = useMemo(() => users.filter((u) => u.role === "parent"), [users]);
  const parentIdSet = useMemo(() => new Set(parentAccounts.map((u) => u.id)), [parentAccounts]);
  const isStudent = (u) => (u.role || "student") === "student";

  // Per-user session metrics computed from all sessions feed
  const userSessionMetrics = useMemo(() => {
    const counts = {};
    const focuses = {};
    const lastDates = {};
    const lives = {};

    for (const s of sessions) {
      if (s.user_id == null) continue;
      counts[s.user_id] = (counts[s.user_id] || 0) + 1;
      if (s.ended_at) {
        focuses[s.user_id] = (focuses[s.user_id] || 0) + (s.total_focused_seconds || 0);
      } else {
        lives[s.user_id] = true;
      }
      if (!lastDates[s.user_id] || String(s.started_at) > String(lastDates[s.user_id])) {
        lastDates[s.user_id] = s.started_at;
      }
    }
    return { counts, focuses, lastDates, lives };
  }, [sessions]);

  // Grouped students under parents
  const kidsByParent = useMemo(() => {
    const map = {};
    for (const u of users) {
      if (isStudent(u) && u.parent_id && parentIdSet.has(u.parent_id)) {
        if (!map[u.parent_id]) map[u.parent_id] = [];
        map[u.parent_id].push(u);
      }
    }
    return map;
  }, [users, parentIdSet]);

  // Unlinked students (either no parent_id or parent account doesn't exist)
  const unlinkedStudents = useMemo(() => {
    return users.filter((u) => isStudent(u) && (!u.parent_id || !parentIdSet.has(u.parent_id)));
  }, [users, parentIdSet]);

  // Filtered lists based on query & peopleFilter
  const matchesSearch = (u) => {
    if (!query_) return true;
    return [u.full_name, u.serial_number, u.email]
      .filter(Boolean)
      .some((v) => String(v).toLowerCase().includes(query_));
  };

  const filteredParents = useMemo(() => {
    if (peopleFilter === "students") return [];
    return parentAccounts.filter((p) => {
      if (!query_) return true;
      if (matchesSearch(p)) return true;
      const kids = kidsByParent[p.id] || [];
      return kids.some(matchesSearch);
    });
  }, [parentAccounts, peopleFilter, query_, kidsByParent]);

  const filteredUnlinked = useMemo(() => {
    if (peopleFilter === "parents") return [];
    return unlinkedStudents.filter(matchesSearch);
  }, [unlinkedStudents, peopleFilter, query_]);

  // Active-first ordering, realtime: a household bubbles to the top when its
  // guardian OR any linked student is active; unlinked students sort the
  // same way. Kids inside each household reorder too.
  const rankedKidsByParent = useMemo(() => {
    const map = {};
    for (const [pid, kids] of Object.entries(kidsByParent)) {
      map[pid] = sortByActivity(kids, rankOf);
    }
    return map;
  }, [kidsByParent]);

  const sortedParents = useMemo(() => {
    const rows = filteredParents.map((p, idx) => {
      const kids = rankedKidsByParent[p.id] || [];
      const kidRank = kids.length ? Math.max(...kids.map(rankOf)) : 1;
      return { p, idx, rank: Math.max(rankOf(p), kidRank) };
    });
    rows.sort((a, b) => b.rank - a.rank || a.idx - b.idx);
    return rows.map((x) => x.p);
  }, [filteredParents, rankedKidsByParent]);

  const sortedUnlinked = useMemo(
    () => sortByActivity(filteredUnlinked, rankOf),
    [filteredUnlinked]
  );

  // Sessions Tab: all people with sessions, with REAL detection - "live" and
  // "active" are decided by the live presence flag (u.online, pushed over
  // /ws/admin from the token TTL, not from a session row). An open session left
  // behind by a crashed app can no longer keep claiming the student is here.
  const sessionsPeople = useMemo(() => {
    const sq = sessSearchQuery.trim().toLowerCase();
    return users.map((u) => {
      const count = userSessionMetrics.counts[u.id] || 0;
      const focus = userSessionMetrics.focuses[u.id] || 0;
      const last = userSessionMetrics.lastDates[u.id] || null;
      const online = Boolean(u.online);
      // A session counts as live only while its student is still connected:
      // open row + detected online, not merely an unclosed row.
      const isLive = online && Boolean(userSessionMetrics.lives[u.id]);
      const parentName = u.parent_id
        ? users.find((p) => p.id === u.parent_id)?.full_name || null
        : null;
      return {
        ...u,
        sessionCount: count,
        totalFocusSeconds: focus,
        lastActive: last,
        isLive,
        parentName,
      };
    }).filter((p) => {
      if (!sq) return true;
      return [p.full_name, p.serial_number, p.email, p.parentName]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(sq));
    });
  }, [users, userSessionMetrics, sessSearchQuery]);

  const peopleWithSessions = useMemo(() => {
    let list = sessionsPeople;
    if (sessFilter === "live") list = list.filter((p) => p.isLive);
    else if (sessFilter === "active") list = list.filter((p) => p.online);
    return [...list].sort((a, b) => {
      if (a.isLive && !b.isLive) return -1;
      if (!a.isLive && b.isLive) return 1;
      if (a.online && !b.online) return -1;
      if (!a.online && b.online) return 1;
      return (b.sessionCount || 0) - (a.sessionCount || 0);
    });
  }, [sessionsPeople, sessFilter]);

  // Selected person in sessions tab
  const activeSessPerson = useMemo(() => {
    if (!activeSessionUserId) return peopleWithSessions[0] || null;
    return peopleWithSessions.find((p) => p.id === activeSessionUserId) || null;
  }, [activeSessionUserId, peopleWithSessions]);

  // Active person's sessions list for the Sessions tab
  const activePersonSessions = useMemo(() => {
    if (!activeSessPerson) return [];
    return sortSessions(sessions.filter((s) => s.user_id === activeSessPerson.id));
  }, [sessions, activeSessPerson]);

  const activeUser = users.find((u) => u.id === selected?.user?.id);

  if (sessionExpired) {
    return (
      <div
        className={`admin-hub-overlay${adminTheme === "dark" ? " admin-theme-dark" : ""}`}
      >
        <div className="admin-hub">
          <header className="admin-hub-head">
            <div className="admin-hub-title-block">
              <h1 className="admin-hub-title">Stubilly Admin Hub</h1>
              <span className="admin-hub-badge is-expired">Signed out</span>
            </div>
            <div className="admin-hub-actions">
              <button className="btn-icon" onClick={onClose} title="Close hub">
                <X size={16} />
              </button>
            </div>
          </header>
          <main className="admin-hub-body">
            <div className="admin-expired-card">
              <AlertCircle size={28} className="admin-warn-icon" />
              <h3>Admin Session Expired</h3>
              <p>The backend server was restarted or your token expired.</p>
              <button className="btn-primary" onClick={onLock}>
                Sign in again
              </button>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    // NOTE: clicking the dark margin around the dashboard must NOT close the
    // hub (it used to bounce the admin back to the sign-in page — including
    // clicks after F11 fullscreen). Only the explicit X button closes it.
    <div
      className={`admin-hub-overlay${adminTheme === "dark" ? " admin-theme-dark" : ""}`}
    >
      <div className="admin-hub">
        {/* Hub Header */}
        <header className="admin-hub-head">
          <div className="admin-hub-title-block">
            <ShieldCheck size={18} className="admin-hub-shield" />
              <h1 className="admin-hub-title">Stubilly Admin Hub</h1>
              <span className="admin-hub-badge">
                {admin?.name || "Administrator"}
              </span>
            </div>

          {/* Clean Navigation Tabs */}
          <div className="admin-hub-tabs" role="tablist">
            <button
              className={`admin-hub-tab${tab === "users" ? " is-active" : ""}`}
              onClick={() => setTab("users")}
            >
              <Users size={14} /> Accounts & Families
            </button>
            <button
              className={`admin-hub-tab${tab === "sessions" ? " is-active" : ""}`}
              onClick={() => {
                setTab("sessions");
                if (selected?.user) {
                  setActiveSessionUserId(selected.user.id);
                } else if (!activeSessionUserId && peopleWithSessions.length > 0) {
                  setActiveSessionUserId(peopleWithSessions[0].id);
                }
              }}
            >
              <CalendarClock size={14} /> Sessions Hub
            </button>
            <button
              className={`admin-hub-tab${tab === "admins" ? " is-active" : ""}`}
              onClick={() => setTab("admins")}
            >
              <Shield size={14} /> Administrators
            </button>
            <button
              className={`admin-hub-tab${tab === "ops" ? " is-active" : ""}`}
              onClick={() => setTab("ops")}
            >
              <Sliders size={14} /> Smart Ops
            </button>
          </div>

          {/* Action Buttons: Theme, Chat, Notifications, Lock, Close */}
          <div className="admin-hub-actions">
            <button
              className="btn-icon"
              title={adminTheme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
              onClick={toggleAdminTheme}
            >
              {adminTheme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
            </button>
            <div className="admin-notif-wrap admin-chat-wrap">
              <button
                className={`btn-icon${chatUnread > 0 ? " has-unread" : ""}`}
                title="Admin chat"
                onClick={toggleChat}
              >
                <MessageCircle size={15} />
                {chatUnread > 0 && <span className="admin-notif-badge">{chatUnread}</span>}
              </button>

              {chatOpen && (
                <>
                  <div
                    className="admin-notif-backdrop"
                    onClick={() => {
                      setChatOpen(false);
                      chatOpenRef.current = false;
                    }}
                  />
                  <div className="admin-chat-panel" style={{ width: chatSize.w, height: chatSize.h }}>
                    <div className="admin-notif-head">
                      <span>Admin Chat</span>
                      <span className="admin-chat-head-actions">
                        <button
                          type="button"
                          className={`admin-chat-organized-btn${chatOrganized ? " is-active" : ""}`}
                          title={`Organize: ${chatOrganizedData.pinned.length} pinned, ${chatOrganizedData.important.length} important, ${chatOrganizedData.links.length} link${
                            chatOrganizedData.links.length === 1 ? "" : "s"
                          }, ${chatOrganizedData.media.length} photo${
                            chatOrganizedData.media.length === 1 ? "" : "s"
                          }, ${chatOrganizedData.audio.length} voice note${
                            chatOrganizedData.audio.length === 1 ? "" : "s"
                          }`}
                          onClick={() => {
                            if (!chatOrganized) setChatOrgTab("pinned");
                            setChatOrganized((v) => !v);
                          }}
                        >
                          Organized
                        </button>
                        <span className="admin-chat-online-count">
                          {onlineAdmins.size} online
                        </span>
                      </span>
                    </div>

                    <div className="admin-chat-roster">
                      {admins.length === 0 && (
                        <span className="admin-chip-empty">Loading admins…</span>
                      )}
                      {admins.map((a) => {
                        const isOn = onlineAdmins.has(a.id);
                        const isMe = a.id === admin?.id;
                        return (
                          <span
                            key={a.id}
                            className={`admin-chat-admin${isOn ? " is-online" : ""}`}
                          >
                            <span className="admin-chat-admin-dot" />
                            {a.name || a.username}
                            {isMe ? " (you)" : ""}
                          </span>
                        );
                      })}
                    </div>

                    {chatOrganized && (
                      <div className="admin-chat-organized">
                        <div className="admin-chat-org-head">
                          <span className="admin-chat-org-title">Shared in this room</span>
                          <span className="admin-chat-org-counts">
                            {chatOrganizedData.media.length} {chatOrganizedData.media.length === 1 ? "photo" : "photos"}{" · "}
                            {chatOrganizedData.audio.length} {chatOrganizedData.audio.length === 1 ? "voice note" : "voice notes"}{" · "}
                            {chatOrganizedData.links.length} {chatOrganizedData.links.length === 1 ? "link" : "links"}
                          </span>
                        </div>
                        <div className="admin-chat-org-tabs">
                          {[
                            { id: "pinned", label: `Pinned ${chatOrganizedData.pinned.length}` },
                            { id: "important", label: `Important ${chatOrganizedData.important.length}` },
                            { id: "media", label: `Photos ${chatOrganizedData.media.length}` },
                            { id: "voice", label: `Voice ${chatOrganizedData.audio.length}` },
                            { id: "links", label: `Links ${chatOrganizedData.links.length}` },
                          ].map((t) => (
                            <button
                              type="button"
                              key={t.id}
                              className={`admin-chat-org-tab${chatOrgTab === t.id ? " is-active" : ""}`}
                              onClick={() => setChatOrgTab(t.id)}
                            >
                              {t.label}
                            </button>
                          ))}
                        </div>
                        <div className="admin-chat-org-list">
                          {chatOrgTab === "links" && chatOrganizedData.links.length === 0 && (
                            <div className="admin-chip-empty">No shared links yet.</div>
                          )}
                          {chatOrgTab === "media" && chatOrganizedData.media.length === 0 && (
                            <div className="admin-chip-empty">No shared pictures yet.</div>
                          )}
                          {chatOrgTab === "voice" && chatOrganizedData.audio.length === 0 && (
                            <div className="admin-chip-empty">No voice notes yet.</div>
                          )}
                          {chatOrgTab === "pinned" && chatOrganizedData.pinned.length === 0 && (
                            <div className="admin-chip-empty">
                              Nothing pinned yet — hover a message and press Pin.
                            </div>
                          )}
                          {chatOrgTab === "important" && chatOrganizedData.important.length === 0 && (
                            <div className="admin-chip-empty">
                              Nothing marked IMPORTANT yet.
                            </div>
                          )}
                          {chatOrgTab === "pinned" &&
                            chatOrganizedData.pinned.map((it) => (
                              <button
                                type="button"
                                key={`pinned-${it.id}`}
                                className="admin-chat-org-item"
                                onClick={() => jumpToChatMessage(it.id)}
                                title="Open in chat"
                              >
                                <span className="admin-chat-org-meta">
                                  <span className="admin-chat-org-sender">
                                    <Pin size={11} /> {it.sender}
                                  </span>
                                  <span className="admin-chat-org-text">
                                    {it.body || "attachment"}
                                  </span>
                                  <span className="admin-chat-org-when">
                                    {dayLabelFull(it.at)} · {fmtTime(it.at)}
                                  </span>
                                </span>
                              </button>
                            ))}
                          {chatOrgTab === "important" &&
                            chatOrganizedData.important.map((it) => (
                              <button
                                type="button"
                                key={`important-${it.id}`}
                                className="admin-chat-org-item"
                                onClick={() => jumpToChatMessage(it.id)}
                                title="Open in chat"
                              >
                                <span className="admin-chat-org-meta">
                                  <span className="admin-chat-org-sender">
                                    <Star size={11} /> {it.label} · {it.sender}
                                  </span>
                                  <span className="admin-chat-org-text">
                                    {it.body || "attachment"}
                                  </span>
                                  <span className="admin-chat-org-when">
                                    {dayLabelFull(it.at)} · {fmtTime(it.at)}
                                  </span>
                                </span>
                              </button>
                            ))}
                          {chatOrgTab === "media" &&
                            chatOrganizedData.media.map((it) => {
                              const url = chatMedia[it.token];
                              return (
                                <button
                                  type="button"
                                  key={`media-${it.id}`}
                                  className="admin-chat-org-item"
                                  onClick={() => jumpToChatMessage(it.id)}
                                  title="Open in chat"
                                >
                                  {url ? (
                                    <img
                                      src={url}
                                      alt={it.name || "shared picture"}
                                      className="admin-chat-org-thumb"
                                    />
                                  ) : (
                                    <span className="admin-chat-org-thumb admin-chat-org-wait">
                                      …
                                    </span>
                                  )}
                                  <span className="admin-chat-org-meta">
                                    <span className="admin-chat-org-sender">{it.sender}</span>
                                    <span className="admin-chat-org-when">{dayLabelFull(it.at)} · {fmtTime(it.at)}</span>
                                  </span>
                                </button>
                              );
                            })}
                          {chatOrgTab === "voice" &&
                            chatOrganizedData.audio.map((it) => {
                              const url = chatMedia[it.token];
                              return (
                                <button
                                  type="button"
                                  key={`voice-${it.id}`}
                                  className="admin-chat-org-item"
                                  onClick={() => jumpToChatMessage(it.id)}
                                  title="Open in chat"
                                >
                                  {url ? (
                                    <audio
                                      controls
                                      preload="metadata"
                                      src={url}
                                      className="admin-chat-org-audio"
                                      onClick={(e) => e.stopPropagation()}
                                    />
                                  ) : (
                                    <span className="admin-chat-org-thumb admin-chat-org-wait">…</span>
                                  )}
                                  <span className="admin-chat-org-meta">
                                    <span className="admin-chat-org-sender">
                                      {it.sender}
                                      {it.seconds ? ` · ${Math.round(it.seconds)}s` : ""}
                                    </span>
                                    <span className="admin-chat-org-when">{dayLabelFull(it.at)} · {fmtTime(it.at)}</span>
                                  </span>
                                </button>
                              );
                            })}
                          {chatOrgTab === "links" &&
                            chatOrganizedData.links.map((it) => (
                              <button
                                type="button"
                                key={`link-${it.id}-${it.url}`}
                                className="admin-chat-org-item admin-chat-org-link"
                                onClick={() => jumpToChatMessage(it.id)}
                                title="Open in chat"
                              >
                                <span className="admin-chat-org-meta">
                                  <span className="admin-chat-org-sender">{it.sender}</span>
                                  <span className="admin-chat-org-url">
                                    <span className="admin-chat-link-domain">{it.domain}</span>
                                    <span className="admin-chat-org-wrap">{it.raw}</span>
                                  </span>
                                  <span className="admin-chat-org-when">{dayLabelFull(it.at)} · {fmtTime(it.at)}</span>
                                </span>
                              </button>
                            ))}
                        </div>
                      </div>
                    )}

                    <div
                      className="admin-chat-list"
                      ref={chatListRef}
                      onScroll={onChatScroll}
                    >
                      {chatSearching && (
                        <div className="admin-chat-locator">Searching for earlier message…</div>
                      )}
                      {chatLoadingOlder && (
                        <div className="admin-chat-locator">Loading earlier messages…</div>
                      )}
                      {chatMsgs.length === 0 && (
                        <div className="admin-chip-empty admin-chat-empty">
                          No messages yet — say hi to the team.
                        </div>
                      )}
                      {chatView.map((row) => {
                        const m = row.m;
                        const url = m.attachment_token ? chatMedia[m.attachment_token] : null;
                        const mine = row.mine;
                        return (
                          <Fragment key={m.id}>
                            {row.showDay && (
                              <div className="admin-chat-day">
                                <span>{row.day}</span>
                              </div>
                            )}
                            {row.unreadStart && (
                              <div className="admin-chat-newline">
                                <span>New messages</span>
                              </div>
                            )}
                            <div
                              className={`admin-chat-msg${mine ? " is-mine" : ""}${
                                row.showSender ? " is-first" : ""
                              }${m.deleted_at ? " is-deleted" : ""}`}
                              data-msg-id={m.id}
                              ref={(node) => {
                                if (node) {
                                  chatMsgElsRef.current.set(m.id, node);
                                  // The moment the awaited bubble attaches,
                                  // complete the pending reply-jump. Deferred
                                  // a frame so layout (and scrollIntoView) is
                                  // ready. This is what makes a jump to a brand
                                  // new live message land reliably.
                                  if (pendingJumpRef.current === m.id) {
                                    requestAnimationFrame(() =>
                                      scrollAndFlashMessage(node)
                                    );
                                  }
                                } else {
                                  chatMsgElsRef.current.delete(m.id);
                                }
                              }}
                            >
                              {!mine && (
                                <span className="admin-chat-avatar" aria-hidden="true">
                                  {row.showSender
                                    ? (m.sender_name || "?")
                                        .trim()
                                        .split(/\s+/)
                                        .slice(0, 2)
                                        .map((p) => p[0])
                                        .join("")
                                        .toUpperCase()
                                    : ""}
                                </span>
                              )}
                              <div className="admin-chat-col">
                                {!mine && row.showSender && (
                                  <span className="admin-chat-sender">{m.sender_name}</span>
                                )}
                                <div
                                  className="admin-chat-bubble"
                                  onDoubleClick={() => startReply(m)}
                                >
                                {m.reply_to_id != null && (
                                  <button
                                    type="button"
                                    className="admin-chat-quote"
                                    title="Read the original message"
                                    onClick={() => jumpToChatMessage(m.reply_to_id)}
                                  >
                                    <span className="admin-chat-quote-name">
                                      {m.reply_to_name || "Message"}
                                    </span>
                                    <span className="admin-chat-quote-body">
                                      {chatReplySnippet(m)}
                                    </span>
                                    <span className="admin-chat-quote-go">› View original</span>
                                  </button>
                                )}
                                {m.attachment_kind === "image" && (
                                  <div className="admin-chat-photo">
                                    {url ? (
                                      <a href={url} target="_blank" rel="noreferrer">
                                        <img src={url} alt={m.attachment_name || "shared picture"} />
                                      </a>
                                    ) : (
                                      <span className="admin-chat-media-wait">Loading picture…</span>
                                    )}
                                  </div>
                                )}
                                {m.attachment_kind === "audio" && (
                                  <div className="admin-chat-audio">
                                    {url ? (
                                      <audio controls preload="metadata" src={url} />
                                    ) : (
                                      <span className="admin-chat-media-wait">Loading voice note…</span>
                                    )}
                                    {m.attachment_seconds ? (
                                      <span className="admin-chat-audio-len">
                                        {Math.round(m.attachment_seconds)}s voice note
                                      </span>
                                    ) : null}
                                  </div>
                                )}
                                {m.deleted_at ? (
                                  <em className="admin-chat-tombstone">message deleted</em>
                                ) : (
                                  <>
                                    <span className="admin-chat-text">{renderChatText(m.body)}</span>
                                    {m.edited_at && <span className="admin-chat-edited">edited</span>}
                                  </>
                                )}
                                {(m.pinned || m.important_label) && (
                                  <span className="admin-chat-flags">
                                    {m.pinned && (
                                      <span className="admin-chat-flag is-pinned">
                                        <Pin size={9} /> Pinned
                                      </span>
                                    )}
                                    {m.important_label && (
                                      <span className="admin-chat-flag is-important">
                                        <Star size={9} /> {m.important_label}
                                      </span>
                                    )}
                                  </span>
                                )}
                                <span className="admin-chat-time">{fmtTime(m.created_at)}</span>
                              </div>
                              {!m.deleted_at && (
                                <div className="admin-chat-tools">
                                  <button
                                    type="button"
                                    title="Reply to this message"
                                    onClick={() => startReply(m)}
                                  >
                                    Reply
                                  </button>
                                  {mine && (
                                    <>
                                      <button type="button" title="Edit your message" onClick={() => startEdit(m)}>
                                        Edit
                                      </button>
                                      <button
                                        type="button"
                                        className="is-danger"
                                        title="Delete your message"
                                        onClick={() => removeChat(m)}
                                      >
                                        Delete
                                      </button>
                                    </>
                                  )}
                                  <button
                                    type="button"
                                    className={m.pinned ? "is-pinned" : ""}
                                    title={m.pinned ? "Unpin this message" : "Pin this message to the top"}
                                    onClick={() => toggleChatPin(m)}
                                  >
                                    {m.pinned ? "Unpin" : "Pin"}
                                  </button>
                                  <button
                                    type="button"
                                    className={m.important_label ? "is-important" : ""}
                                    title={
                                      m.important_label
                                        ? "Remove the IMPORTANT label"
                                        : "Mark this message as IMPORTANT"
                                    }
                                    onClick={() => toggleChatImportant(m)}
                                  >
                                    {m.important_label ? "Unmark" : "Important"}
                                  </button>
                                </div>
                              )}
                              </div>
                            </div>
                          </Fragment>
                        );
                      })}
                    </div>

                    {chatNewBelow > 0 && (
                      <button
                        type="button"
                        className="admin-chat-jump"
                        onClick={jumpToLatest}
                      >
                        {chatNewBelow} new {chatNewBelow === 1 ? "message" : "messages"} · jump to
                        latest
                      </button>
                    )}

                    {chatEditId != null && (
                      <div className="admin-chat-mode">
                        <span className="admin-chat-mode-label">Editing your message</span>
                        <button type="button" onClick={cancelEdit}>
                          Cancel
                        </button>
                      </div>
                    )}
                    {chatEditId != null ? (
                      <form
                        className="admin-chat-input"
                        onSubmit={(e) => {
                          e.preventDefault();
                          saveEdit();
                        }}
                      >
                        <input
                          value={chatEditText}
                          onChange={(e) => setChatEditText(e.target.value)}
                          placeholder="Change your message…"
                          maxLength={2000}
                          autoFocus
                        />
                        <button type="submit" className="btn-primary" disabled={!chatEditText.trim() || chatSending}>
                          Save
                        </button>
                      </form>
                    ) : (
                      <>
                        {chatReply && (
                          <div className="admin-chat-mode is-reply">
                            <button
                              type="button"
                              className="admin-chat-mode-jump"
                              title="Jump to the message being replied to"
                              onClick={() => jumpToChatMessage(chatReply.id)}
                            >
                              <span className="admin-chat-mode-label">
                                Replying to {chatReply.sender_name}:{" "}
                                {chatReply.body?.slice(0, 60) || "attachment"}
                              </span>
                              <span className="admin-chat-mode-go">View original ›</span>
                            </button>
                            <button type="button" onClick={cancelReply}>
                              Cancel
                            </button>
                          </div>
                        )}
                        {chatAttach && (
                          <div className="admin-chat-attach">
                            {chatAttach.kind === "image" ? (
                              <span>📷 {chatAttach.name}</span>
                            ) : (
                              <span>🎤 Voice note ({Math.round(chatAttach.seconds || 0)}s)</span>
                            )}
                            <button type="button" onClick={() => setChatAttach(null)}>
                              Remove
                            </button>
                          </div>
                        )}
                        {chatError && <div className="admin-chat-error">{chatError}</div>}
                        <form className="admin-chat-input" onSubmit={sendChat}>
                          <input
                            value={chatDraft}
                            onChange={(e) => setChatDraft(e.target.value)}
                            placeholder="Message the admins…"
                            maxLength={2000}
                          />
                          <input
                            ref={chatFileRef}
                            type="file"
                            accept="image/png,image/jpeg,image/gif,image/webp"
                            onChange={pickChatFile}
                            className="admin-chat-file"
                          />
                          <button
                            type="button"
                            className="admin-chat-icon"
                            title="Send a picture"
                            onClick={() => chatFileRef.current?.click()}
                          >
                            🖼
                          </button>
                          <button
                            type="button"
                            className={`admin-chat-icon${chatRecording ? " is-recording" : ""}`}
                            title={chatRecording ? "Stop recording" : "Record a voice note"}
                            onClick={toggleChatRecording}
                          >
                            {chatRecording ? `⏹ ${chatRecSecs}s` : "🎤"}
                          </button>
                          <button
                            type="submit"
                            className="btn-primary admin-chat-send"
                            disabled={(!chatDraft.trim() && !chatAttach) || chatSending}
                          >
                            Send
                          </button>
                        </form>
                      </>
                    )}
                    <div
                      className="admin-chat-resize"
                      title="Drag to resize the chat window"
                      onPointerDown={chatResizeStart}
                    >
                      <GripVertical size={12} />
                    </div>
                  </div>
                </>
              )}
            </div>

            <div className="admin-notif-wrap">
              <button
                className={`btn-icon${notifUnread > 0 ? " has-unread" : ""}`}
                title="Account notifications"
                onClick={() => {
                  setChatOpen(false);
                  chatOpenRef.current = false;
                  if (!notifOpen) {
                    // Opening the panel snapshots what is already there, so only
                    // notifications that arrive while it is open light up as new.
                    notifSeenRef.current = notifs.reduce((m, x) => Math.max(m, x.id), 0);
                    setNotifOpen(true);
                  } else {
                    closeNotifPanel();
                  }
                }}
              >
                <Bell size={15} />
                {notifUnread > 0 && (
                  <span className="admin-notif-badge">{notifUnread}</span>
                )}
              </button>

              {notifOpen && (
                <>
                  <div
                    className="admin-notif-backdrop"
                    onClick={closeNotifPanel}
                  />
                  <div className="admin-notif-panel">
                    <div className="admin-notif-head">
                      <span className="admin-notif-title">
                        Notifications
                        {notifUnread > 0 && (
                          <span className="admin-notif-unread-pill">
                            {notifUnread} unread
                          </span>
                        )}
                      </span>
                    </div>

                    {notifs.length > 0 &&
                      (notifSelectMode ? (
                        <div className="admin-notif-actions is-select">
                          <span className="admin-notif-selcount">
                            {notifSelected.length} selected
                          </span>
                          <span className="admin-notif-actions-right">
                            <button
                              className="admin-notif-btn is-danger"
                              onClick={deleteSelectedNotifs}
                              disabled={notifSelected.length === 0 || notifBusy}
                            >
                              <Trash2 size={13} />
                              Delete{notifSelected.length > 0 ? ` (${notifSelected.length})` : ""}
                            </button>
                            <button
                              className="admin-notif-btn"
                              onClick={exitNotifSelect}
                              disabled={notifBusy}
                            >
                              <X size={13} />
                              Cancel
                            </button>
                          </span>
                        </div>
                      ) : (
                        <div className="admin-notif-actions">
                          <button
                            className="admin-notif-btn"
                            onClick={readAllNotifs}
                            title="Mark everything in the bell as read"
                          >
                            <CheckCheck size={13} />
                            Mark all read
                          </button>
                          <button
                            className="admin-notif-btn"
                            onClick={() => {
                              setNotifClearArmed(false);
                              setNotifSelectMode(true);
                            }}
                            title="Pick specific entries to delete"
                          >
                            <ListChecks size={13} />
                            Select
                          </button>
                          <button
                            className={`admin-notif-btn is-danger${
                              notifClearArmed ? " is-armed" : ""
                            }`}
                            onClick={clearAllNotifs}
                            disabled={notifBusy}
                            title="Remove every notification from YOUR bell"
                          >
                            <Trash2 size={13} />
                            {notifClearArmed ? "Sure? Clear" : "Clear all"}
                          </button>
                        </div>
                      ))}

                    {notifs.length > 0 && (
                      <div className="admin-notif-filters">
                        <button
                          type="button"
                          className={`admin-chip-toggle${notifFilter === "all" ? " is-on" : ""}`}
                          onClick={() => setNotifFilter("all")}
                        >
                          All {notifs.length}
                        </button>
                        <button
                          type="button"
                          className={`admin-chip-toggle${notifFilter === "unread" ? " is-on" : ""}`}
                          onClick={() => setNotifFilter("unread")}
                          disabled={notifUnread === 0}
                        >
                          Unread {notifUnread}
                        </button>
                        <button
                          type="button"
                          className={`admin-chip-toggle admin-chip-sort${notifOldestFirst ? " is-on" : ""}`}
                          onClick={() => setNotifOldestFirst((v) => !v)}
                          title={
                            notifOldestFirst
                              ? "Showing oldest first - click for newest first"
                              : "Showing newest first - click to read a day from the start"
                          }
                        >
                          {notifOldestFirst ? "Oldest first" : "Newest first"}
                        </button>
                      </div>
                    )}

                    {notifs.length > 0 && (
                      <div className="admin-notif-search">
                        <Search size={13} />
                        <input
                          className="admin-notif-search-input"
                          type="search"
                          value={notifQuery}
                          placeholder="Search activity by name, task or word"
                          onChange={(e) => setNotifQuery(e.target.value)}
                          aria-label="Search notifications"
                        />
                        {notifQuery && (
                          <button
                            type="button"
                            className="btn-text"
                            onClick={() => setNotifQuery("")}
                          >
                            Clear
                          </button>
                        )}
                      </div>
                    )}

                    {notifs.length > 0 && (
                      <div className="admin-notif-kinds">
                        {NOTIF_FILTERS.map((f) => {
                          const n = f.kinds
                            ? notifs.filter((x) => f.kinds.includes(x.kind)).length
                            : notifs.length;
                          return (
                            <button
                              key={f.id}
                              type="button"
                              className={`admin-chip-toggle${
                                notifKindFilter === f.id ? " is-on" : ""
                              }`}
                              onClick={() => setNotifKindFilter(f.id)}
                              disabled={n === 0 && f.id !== "all"}
                            >
                              {f.label} {n}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    <ul className="admin-notif-list">
                      {notifGroups.length === 0 && (
                        <li className="admin-chip-empty">
                          {notifQuery
                            ? `Nothing matches “${notifQuery}”`
                            : notifFilter === "unread"
                              ? "Nothing unread — all caught up."
                              : "No notifications yet"}
                        </li>
                      )}
                      {notifGroups.map((group) => (
                        <li key={group.label} className="admin-notif-group">
                          <div className="admin-notif-day">
                            <span>{group.label}</span>
                            <span className="admin-notif-day-count">
                              {group.unread > 0 ? `${group.unread} new · ` : ""}
                              {group.items.length}
                            </span>
                          </div>
                          <ul className="admin-notif-items">
                            {group.items.map((n) => {
                              const k = notifKind(n.kind);
                              const selected = notifSelected.includes(n.id);
                              return (
                                <li
                                  key={n.id}
                                  className={`admin-notif-item${n.read_at ? "" : " is-unread"}${
                                    n.id > notifSeenRef.current ? " is-live" : ""
                                  }${notifSelectMode ? " is-selecting" : ""}${
                                    selected ? " is-selected" : ""
                                  }`}
                                  onClick={() =>
                                    notifSelectMode ? toggleNotifSelect(n) : openNotif(n)
                                  }
                                >
                                  {notifSelectMode && (
                                    <span className="admin-notif-check">
                                      {selected && <Check size={11} />}
                                    </span>
                                  )}
                                  <span className={`admin-notif-kind is-${k.tone}`}>
                                    {k.label}
                                  </span>
                                  <span className="admin-notif-msg">{n.message}</span>
                                  {n.payload?.full_name &&
                                    !n.message.includes(n.payload.full_name) && (
                                      <span className="admin-notif-who">{n.payload.full_name}</span>
                                    )}
                                  <span className="admin-notif-time">
                                    {fmtTime(n.created_at)}
                                  </span>
                                </li>
                              );
                            })}
                          </ul>
                        </li>
                      ))}
                    </ul>
                    {notifTotalShown > 40 && (
                      <div className="admin-notif-foot">
                        Showing the {notifTotalShown} most recent updates.
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>

            <div className="admin-hub-account-wrap">
              {accountMenuOpen && (
                <>
                  <div
                    className="admin-notif-backdrop"
                    onClick={() => setAccountMenuOpen(false)}
                  />
                  <div className="admin-hub-account-menu" role="menu">
                    <button
                      type="button"
                      className="admin-hub-account-menu-item"
                      role="menuitem"
                      onClick={() => {
                        setAccountMenuOpen(false);
                        handleAdminSignOut();
                      }}
                    >
                      <LogOut size={15} />
                      <span>Sign out</span>
                    </button>
                    <span className="admin-hub-account-menu-note">
                      Ends your session on the server.
                    </span>
                  </div>
                </>
              )}
              <button
                type="button"
                className="admin-hub-account"
                onClick={() => setAccountMenuOpen((o) => !o)}
                aria-expanded={accountMenuOpen}
                aria-haspopup="menu"
                title={admin?.name || "Administrator"}
              >
                <span className="admin-hub-account-avatar" aria-hidden="true">
                  <UserRound size={18} />
                </span>
                <span className="admin-hub-account-text">
                  <small>Account</small>
                  <strong>{admin?.name || "Administrator"}</strong>
                  <em>Managed Access</em>
                </span>
              </button>
            </div>
            <button className="btn-icon" onClick={onClose} title="Close hub">
              <X size={16} />
            </button>
          </div>
        </header>

        {activeToasts.length > 0 && (
          <div className="admin-active-toasts" aria-live="polite">
            {activeToasts.map((t) => (
              <div key={t.id} className={`admin-active-toast is-${t.tone || "active"}`}>
                <Activity size={14} />
                <span>{t.text}</span>
              </div>
            ))}
          </div>
        )}

        {notice && <div className="admin-hub-notice">{notice}</div>}

        <main className="admin-hub-body">
          {/* ================================================================ */}
          {/* TAB 1: ACCOUNTS & FAMILIES (Itemized Guardians & Students)       */}
          {/* ================================================================ */}
          {tab === "users" && (
            <div className="admin-workspace">
              {/* Left Pane: Master List of Guardians & Students */}
              <div className={`admin-workspace-list${showCreate ? " is-creating" : ""}`}>
                {/* Search & Actions Bar */}
                <div className="admin-search-row">
                  <Search size={14} className="admin-search-icon" />
                  <input
                    className="admin-search-input"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search by student, guardian, or serial…"
                  />
                  {loading && <span className="admin-search-spinner">…</span>}
                  <button
                    className="btn-icon"
                    title="Refresh list"
                    onClick={() => loadUsers(query)}
                  >
                    <RefreshCw size={12} />
                  </button>
                </div>

                {/* Filter & Add Account Header */}
                <div className="admin-filter-bar">
                  <div className="admin-pill-group">
                    <button
                      className={`admin-pill-btn${peopleFilter === "all" ? " is-active" : ""}`}
                      onClick={() => setPeopleFilter("all")}
                    >
                      All ({users.length})
                    </button>
                    <button
                      className={`admin-pill-btn${peopleFilter === "parents" ? " is-active" : ""}`}
                      onClick={() => setPeopleFilter("parents")}
                    >
                      Guardians ({parentAccounts.length})
                    </button>
                    <button
                      className={`admin-pill-btn${peopleFilter === "students" ? " is-active" : ""}`}
                      onClick={() => setPeopleFilter("students")}
                    >
                      Students ({users.length - parentAccounts.length})
                    </button>
                  </div>

                  <button
                    className="btn-primary admin-create-btn"
                    onClick={() => setShowCreate((s) => !s)}
                  >
                    <UserPlus size={13} /> {showCreate ? "Cancel" : "New Account"}
                  </button>
                </div>

                {/* Create Account card: expands inline right under the
                    New Account button (same place as before). On small
                    windows the workspace stack scrolls instead of crushing
                    the card and the student list. */}
                {showCreate && (
                  <form
                    ref={createFormRef}
                    className="admin-create-form"
                    onSubmit={createAccount}
                  >
                    <div className="admin-create-header">
                      <h4>Create New Account</h4>
                      <p>Guardian or student · takes one minute.</p>
                    </div>

                    <div className="admin-create-grid">
                      <label className="admin-field">
                        <span>Full Name</span>
                        <input
                          value={newAcct.full_name}
                          onChange={(e) => setNewAcct({ ...newAcct, full_name: e.target.value })}
                          placeholder="e.g. Maria Santos"
                          required
                        />
                      </label>

                      <label className="admin-field">
                        <span>Email</span>
                        <input
                          type="email"
                          value={newAcct.email}
                          onChange={(e) => setNewAcct({ ...newAcct, email: e.target.value })}
                          placeholder="name@example.com"
                          required
                        />
                        <span className="admin-field-hint">This email is the sign-in serial number.</span>
                      </label>

                      <label className="admin-field">
                        <span>Password</span>
                        <input
                          type="text"
                          value={newAcct.password}
                          onChange={(e) => setNewAcct({ ...newAcct, password: e.target.value })}
                          placeholder="At least 8 characters"
                          minLength={8}
                          required
                        />
                        <span className="admin-field-hint">Minimum 8 characters — used to sign in.</span>
                      </label>

                      <label className="admin-field">
                        <span>Role</span>
                        <select
                          value={newAcct.role}
                          onChange={(e) =>
                            setNewAcct({ ...newAcct, role: e.target.value, parent_id: "" })
                          }
                        >
                          <option value="student">Student</option>
                          <option value="parent">Parent / Guardian</option>
                        </select>
                        <span className="admin-field-hint">Students can be linked to a guardian below.</span>
                      </label>

                      <label className="admin-field">
                        <span>Date of Birth (optional)</span>
                        <input
                          type="date"
                          value={newAcct.date_of_birth}
                          onChange={(e) => setNewAcct({ ...newAcct, date_of_birth: e.target.value })}
                          max={new Date().toISOString().slice(0, 10)}
                        />
                      </label>

                      {newAcct.role === "student" && (
                        <label className="admin-field">
                          <span>Link to Guardian</span>
                          <select
                            value={newAcct.parent_id}
                            onChange={(e) => setNewAcct({ ...newAcct, parent_id: e.target.value })}
                          >
                            <option value="">None (Independent student)</option>
                            {parentAccounts.map((p) => (
                              <option key={p.id} value={p.id}>
                                {p.full_name || p.email} ({p.serial_number})
                              </option>
                            ))}
                          </select>
                          <span className="admin-field-hint">
                            Student study data appears on the guardian's dashboard.
                          </span>
                        </label>
                      )}
                    </div>

                    <div className="admin-create-actions">
                      <button type="submit" className="btn-primary" disabled={creating}>
                        {creating ? "Creating…" : "Save Account"}
                      </button>
                      <button
                        type="button"
                        className="btn-text"
                        onClick={() => setShowCreate(false)}
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}

                {/* People List: Organized by Parents & Nested Students */}
                <div className="admin-people-scroll">
                  {/* Section 1: Parents / Guardians with nested students */}
                  {sortedParents.length > 0 && (
                    <div className="admin-section-block">
                      <div className="admin-group-title">
                        <span>Guardians & Families</span>
                        <span className="admin-badge-count">{sortedParents.length}</span>
                      </div>

                      {sortedParents.map((parent) => {
                        const kids = rankedKidsByParent[parent.id] || [];
                        // An active household (guardian or any student live)
                        // stays expanded so the active person is visible.
                        const householdActive =
                          rankOf(parent) > 1 || kids.some((k) => rankOf(k) > 1);
                        const isCollapsed =
                          Boolean(collapsedParents[parent.id]) && !householdActive;
                        const isParentSelected = activeUser?.id === parent.id;
                        const parentStatus = statusStyleOf(parent);

                        return (
                          <div
                            key={parent.id}
                            className={`admin-household-card${isParentSelected ? " is-selected" : ""}`}
                          >
                            {/* Guardian Header Row */}
                            <div
                              className="admin-guardian-row"
                              onClick={() => openUser(parent.id)}
                            >
                              <button
                                type="button"
                                className="admin-chevron-btn"
                                title={isCollapsed ? "Expand students" : "Collapse students"}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setCollapsedParents((prev) => ({
                                    ...prev,
                                    [parent.id]: !prev[parent.id],
                                  }));
                                }}
                              >
                                {isCollapsed ? <ChevronRight size={13} /> : <ChevronDown size={13} />}
                              </button>

                              <span
                                className={`admin-presence-dot${parent.online ? " is-online" : ""}`}
                                title={parentStatus.text}
                              />

                              <div className="admin-person-info">
                                <div className="admin-name-line">
                                  <span className="admin-name">{parent.full_name || parent.email}</span>
                                  <span className="admin-role-tag is-guardian">Guardian</span>
                                </div>
                                <span className="admin-subtext">{parent.serial_number}</span>
                              </div>

                              {parent.online && (
                                <span className={`admin-status-pill ${parentStatus.css}`}>
                                  {parentStatus.text}
                                </span>
                              )}

                              <div className="admin-family-count">
                                {kids.length} {kids.length === 1 ? "student" : "students"}
                              </div>
                            </div>

                            {/* Itemized Nested Students */}
                            {!isCollapsed && (
                              <div className="admin-nested-kids">
                                {kids.length === 0 && (
                                  <div className="admin-empty-kids">
                                    No students linked to this guardian yet.
                                  </div>
                                )}
                                {kids.map((kid) => {
                                  const isKidSelected = activeUser?.id === kid.id;
                                  const kidStatus = STATUS_STYLE[kid.status] || (kid.online ? STATUS_STYLE.signed_in : STATUS_STYLE.offline);
                                  const sCount = userSessionMetrics.counts[kid.id] || 0;
                                  const isLive = Boolean(userSessionMetrics.lives[kid.id] && kid.online);

                                  return (
                                    <div
                                      key={kid.id}
                                      className={`admin-student-item${isKidSelected ? " is-selected" : ""}`}
                                      onClick={() => openUser(kid.id)}
                                    >
                                      <GraduationCap size={13} className="admin-kid-icon" />
                                      <span
                                        className={`admin-presence-dot ${kidStatus.css}`}
                                        title={kidStatus.text}
                                      />
                                      <div className="admin-person-info">
                                        <div className="admin-name-line">
                                          <span className="admin-kid-name">{kid.full_name || kid.serial_number}</span>
                                          {kid.is_minor && <span className="admin-minor-tag">minor</span>}
                                          {isLive && <span className="admin-live-pulse">live</span>}
                                        </div>
                                        <span className="admin-subtext">{kid.serial_number}</span>
                                      </div>

                                      <div className="admin-kid-stats">
                                        <span className={`admin-status-pill ${kidStatus.css}`}>
                                          {kidStatus.text}
                                        </span>
                                        <span className="admin-session-badge">
                                          {sCount} {sCount === 1 ? "sess" : "sess"}
                                        </span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Section 2: Independent / Unlinked Students */}
                  {sortedUnlinked.length > 0 && (
                    <div className="admin-section-block">
                      <div className="admin-group-title">
                        <span>Independent / Unlinked Students</span>
                        <span className="admin-badge-count">{sortedUnlinked.length}</span>
                      </div>

                      {sortedUnlinked.map((student) => {
                        const isStudentSelected = activeUser?.id === student.id;
                        const stStatus = STATUS_STYLE[student.status] || (student.online ? STATUS_STYLE.signed_in : STATUS_STYLE.offline);
                        const sCount = userSessionMetrics.counts[student.id] || 0;
                        const isLive = Boolean(userSessionMetrics.lives[student.id] && student.online);

                        return (
                          <div
                            key={student.id}
                            className={`admin-student-item is-standalone${isStudentSelected ? " is-selected" : ""}`}
                            onClick={() => openUser(student.id)}
                          >
                            <GraduationCap size={14} className="admin-kid-icon" />
                            <span
                              className={`admin-presence-dot ${stStatus.css}`}
                              title={stStatus.text}
                            />
                            <div className="admin-person-info">
                              <div className="admin-name-line">
                                <span className="admin-kid-name">{student.full_name || student.serial_number}</span>
                                {student.is_minor && <span className="admin-minor-tag">minor</span>}
                                {isLive && <span className="admin-live-pulse">live</span>}
                              </div>
                              <span className="admin-subtext">{student.serial_number}</span>
                            </div>

                            <div className="admin-kid-stats">
                              <span className={`admin-status-pill ${stStatus.css}`}>
                                {stStatus.text}
                              </span>
                              <span className="admin-session-badge">
                                {sCount} {sCount === 1 ? "session" : "sessions"}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Empty State */}
                  {sortedParents.length === 0 && sortedUnlinked.length === 0 && (
                    <div className="admin-empty-state">
                      <Users size={24} />
                      <p>No accounts match your filter or search.</p>
                      <button className="btn-text" onClick={() => { setQuery(""); setPeopleFilter("all"); }}>
                        Reset filters
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Right Pane: READY TO ASSIST & Student Process Cockpit */}
              <div className="admin-workspace-detail">
                {selected ? (
                  <div className="admin-detail-panel">
                    {/* User Profile Header */}
                    <div className="admin-user-header">
                      <div className="admin-user-identity">
                        <div className="admin-avatar">
                          {selected.user.role === "parent" ? (
                            <Users size={20} />
                          ) : (
                            <GraduationCap size={20} />
                          )}
                        </div>
                        <div>
                          <div className="admin-header-title">
                            <h2>{selected.user.full_name || selected.user.serial_number}</h2>
                            <span className={`admin-status-pill ${(STATUS_STYLE[selected.user.status] || STATUS_STYLE.offline).css}`}>
                              {(STATUS_STYLE[selected.user.status] || STATUS_STYLE.offline).text}
                            </span>
                          </div>
                          <p className="admin-meta-text">
                            Serial <strong>{selected.user.serial_number}</strong> ·{" "}
                            {selected.user.email ? `${selected.user.email} · ` : ""}
                            {selected.user.role === "parent" ? "Guardian" : "Student"}
                            {selected.user.is_minor && " · Minor (under 18)"}
                          </p>
                        </div>
                      </div>

                      <div className="admin-header-actions">
                        <button
                          type="button"
                          className="admin-remove-btn"
                          title={`Remove ${selected.user.role === "parent" ? "guardian" : "student"} account`}
                          onClick={() => removeUserAccount(selected.user)}
                        >
                          <Trash2 size={13} /> Remove
                        </button>
                        <button
                          type="button"
                          className="btn-icon admin-close-detail"
                          title="Close profile"
                          onClick={closeDetail}
                        >
                          <X size={16} />
                        </button>
                      </div>
                    </div>

                    {/* LIVE ASSIST BANNER: Active Session Alert */}
                    {selected.active_session_count > 0 && selected.user.online && (
                      <div className="admin-live-assist-banner">
                        <span className="admin-pulse-dot" />
                        <div className="admin-live-assist-info">
                          <strong>Active Session in Progress</strong>
                          <p>
                            {selected.user.current_task || "Working on a declared session."}
                          </p>
                        </div>
                        <button
                          type="button"
                          className="btn-text"
                          onClick={() => setDetailTab("sessions")}
                        >
                          View Live Session →
                        </button>
                      </div>
                    )}

                    {/* Navigation Tabs for Selected User */}
                    <div className="admin-detail-tabs" role="tablist">
                      <button
                        className={`admin-detail-tab${detailTab === "overview" ? " is-active" : ""}`}
                        onClick={() => setDetailTab("overview")}
                      >
                        <Sparkles size={13} /> Process & Assist
                      </button>
                      <button
                        className={`admin-detail-tab${detailTab === "sessions" ? " is-active" : ""}`}
                        onClick={() => setDetailTab("sessions")}
                      >
                        <Clock size={13} /> Itemized Sessions ({userSessions.length})
                      </button>
                      <button
                        className={`admin-detail-tab${detailTab === "policy" ? " is-active" : ""}`}
                        onClick={() => setDetailTab("policy")}
                      >
                        <Sliders size={13} /> Website & App Policy
                      </button>
                      <button
                        className={`admin-detail-tab${detailTab === "logins" ? " is-active" : ""}`}
                        onClick={() => setDetailTab("logins")}
                      >
                        <Activity size={13} /> Logins ({selected.login_history?.length || 0})
                      </button>
                    </div>

                    {/* -------------------------------------------------------- */}
                    {/* SUBTAB 1: PROCESS & READY TO ASSIST OVERVIEW             */}
                    {/* -------------------------------------------------------- */}
                    {detailTab === "overview" && (
                      <div className="admin-tab-body">
                        {/* Time Range Filter Bar */}
                        <div className="admin-process-range-bar">
                          <div className="admin-pill-group">
                            {PROGRESS_RANGES.map((r) => (
                              <button
                                key={r.value}
                                type="button"
                                className={`admin-pill-btn${progressRange === r.value ? " is-active" : ""}`}
                                onClick={() => setProgressRange(r.value)}
                              >
                                {r.label}
                              </button>
                            ))}
                          </div>
                          {progressLoading && (
                            <span className="admin-search-spinner">Updating metrics…</span>
                          )}
                        </div>

                        {/* Process Metrics Cards */}
                        <div className="admin-metric-grid">
                          <div className="admin-metric-card">
                            <span className="admin-metric-label">Focus Rate</span>
                            <span className="admin-metric-val is-focused">
                              {progress ? `${Math.round(progress.avg_focus_pct || 0)}%` : "—"}
                            </span>
                            <span className="admin-metric-sub">
                              {progress ? fmtMinutes(progress.total_focused_minutes) : "0m"} focused
                            </span>
                          </div>

                          <div className="admin-metric-card">
                            <span className="admin-metric-label">Off-Task & Distracted</span>
                            <span className="admin-metric-val is-distracted">
                              {progress ? fmtMinutes(progress.total_distracted_minutes) : "—"}
                            </span>
                            <span className="admin-metric-sub">
                              {progress ? `${fmtMinutes(progress.total_sleeping_minutes)} closed eyes` : "0m"}
                            </span>
                          </div>

                          <div className="admin-metric-card">
                            <span className="admin-metric-label">Nudges & Interventions</span>
                            <span className="admin-metric-val is-nudges">
                              {progress ? progress.total_interventions || 0 : "0"}
                            </span>
                            <span className="admin-metric-sub">gentle reminders</span>
                          </div>

                          <div className="admin-metric-card">
                            <span className="admin-metric-label">Study Streak</span>
                            <div className="admin-streak-badge">
                              <Flame size={14} />
                              <span>{progress?.current_streak_days || 0} days</span>
                            </div>
                            <span className="admin-metric-sub">
                              {selected.session_count} total sessions
                            </span>
                          </div>
                        </div>

                        {/* ASSIST SECTION 1: Credentials & Access */}
                        <div className="admin-assist-card">
                          <div className="admin-card-head">
                            <Key size={14} />
                            <h4>Student Credentials & Access</h4>
                          </div>

                          <div className="admin-cred-actions">
                            <div className="admin-cred-display">
                              <span className="admin-field-label">Password:</span>
                              <code>
                                {selected.user.password
                                  ? showUserPw
                                    ? selected.user.password
                                    : "••••••••"
                                  : "No password stored"}
                              </code>

                              {selected.user.password && (
                                <>
                                  <button
                                    type="button"
                                    className="btn-icon"
                                    title={showUserPw ? "Hide" : "Reveal password"}
                                    onClick={() => setShowUserPw((v) => !v)}
                                  >
                                    {showUserPw ? <EyeOff size={13} /> : <Eye size={13} />}
                                  </button>
                                  <button
                                    type="button"
                                    className="btn-text"
                                    onClick={() => handleCopy(selected.user.password)}
                                  >
                                    {copiedKey ? <Check size={12} /> : <Copy size={12} />}
                                    {copiedKey ? "Copied" : "Copy"}
                                  </button>
                                </>
                              )}
                            </div>

                            {/* Reset Password Form */}
                            {resetUserId === selected.user.id ? (
                              <form
                                className="admin-inline-form"
                                onSubmit={(e) => {
                                  e.preventDefault();
                                  resetStudentPassword(selected.user.id);
                                }}
                              >
                                <input
                                  type="password"
                                  className="admin-inline-input"
                                  value={resetDraft}
                                  onChange={(e) => setResetDraft(e.target.value)}
                                  placeholder="New password (min 4 chars)"
                                  autoFocus
                                />
                                <button
                                  type="submit"
                                  className="btn-primary btn-sm"
                                  disabled={resetBusy || resetDraft.length < 4}
                                >
                                  {resetBusy ? "Saving…" : "Save Password"}
                                </button>
                                <button
                                  type="button"
                                  className="btn-text"
                                  onClick={() => {
                                    setResetUserId(null);
                                    setResetDraft("");
                                  }}
                                >
                                  Cancel
                                </button>
                              </form>
                            ) : (
                              <button
                                type="button"
                                className="btn-secondary btn-sm"
                                onClick={() => {
                                  setResetUserId(selected.user.id);
                                  setResetDraft("");
                                }}
                              >
                                <Key size={12} /> Reset Password
                              </button>
                            )}
                          </div>
                        </div>

                        {/* ASSIST SECTION 2: Household & Guardian Linking */}
                        <div className="admin-assist-card">
                          <div className="admin-card-head">
                            <Link2 size={14} />
                            <h4>Household & Guardian Connection</h4>
                          </div>

                          {selected.user.role === "student" ? (
                            <div className="admin-guardian-link-row">
                              <span className="admin-field-label">Assigned Guardian:</span>
                              {relinkingUserId === selected.user.id ? (
                                <div className="admin-inline-form">
                                  <select
                                    className="admin-inline-select"
                                    value={selectedParentLink}
                                    onChange={(e) => setSelectedParentLink(e.target.value)}
                                  >
                                    <option value="">None (Unlinked / Independent)</option>
                                    {parentAccounts.map((p) => (
                                      <option key={p.id} value={p.id}>
                                        {p.full_name || p.email} ({p.serial_number})
                                      </option>
                                    ))}
                                  </select>
                                  <button
                                    type="button"
                                    className="btn-primary btn-sm"
                                    onClick={() => handleLinkGuardian(selected.user.id, selectedParentLink)}
                                  >
                                    Save Link
                                  </button>
                                  <button
                                    type="button"
                                    className="btn-text"
                                    onClick={() => setRelinkingUserId(null)}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              ) : (
                                <div className="admin-guardian-current">
                                  {selected.user.parent_id ? (
                                    <>
                                      {(() => {
                                        const p = users.find((x) => x.id === selected.user.parent_id);
                                        return (
                                          <button
                                            type="button"
                                            className="admin-household-chip"
                                            onClick={() => openUser(selected.user.parent_id)}
                                          >
                                            <Users size={12} />
                                            <span>{p ? p.full_name || p.email : `#${selected.user.parent_id}`}</span>
                                            <ExternalLink size={10} />
                                          </button>
                                        );
                                      })()}
                                      <button
                                        type="button"
                                        className="btn-text"
                                        onClick={() => {
                                          setRelinkingUserId(selected.user.id);
                                          setSelectedParentLink(String(selected.user.parent_id || ""));
                                        }}
                                      >
                                        Change Guardian
                                      </button>
                                    </>
                                  ) : (
                                    <>
                                      <span className="admin-unlinked-tag">No guardian linked</span>
                                      <button
                                        type="button"
                                        className="btn-secondary btn-sm"
                                        onClick={() => {
                                          setRelinkingUserId(selected.user.id);
                                          setSelectedParentLink("");
                                        }}
                                      >
                                        <Link2 size={12} /> Assign Guardian
                                      </button>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>
                          ) : (
                            /* Parent view: show all linked students */
                            <div className="admin-parent-kids-section">
                              <span className="admin-field-label">Linked Students ({ (kidsByParent[selected.user.id] || []).length }):</span>
                              <div className="admin-household-kids-list">
                                {(kidsByParent[selected.user.id] || []).map((k) => (
                                  <button
                                    key={k.id}
                                    type="button"
                                    className="admin-household-chip"
                                    onClick={() => openUser(k.id)}
                                  >
                                    <GraduationCap size={12} />
                                    <span>{k.full_name || k.serial_number}</span>
                                    <span className={`admin-presence-dot${k.online ? " is-online" : ""}`} />
                                  </button>
                                ))}
                                {(kidsByParent[selected.user.id] || []).length === 0 && (
                                  <span className="admin-chip-empty">No students assigned to this guardian yet.</span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* ASSIST SECTION 3: Monitoring Consent (admin can approve
                            independent minors who have no guardian to grant it) */}
                        {selected.user.role === "student" && (
                          <div className="admin-assist-card">
                            <div className="admin-card-head">
                              <Shield size={14} />
                              <h4>Monitoring Consent</h4>
                            </div>
                            <div className="admin-consent-row">
                              {selected.user.is_minor ? (
                                selected.user.consent_granted ? (
                                  <>
                                    <span className="admin-consent-pill is-granted">consent granted</span>
                                    <span className="admin-consent-meta">
                                      {fmt(selected.user.consent_at)}
                                      {selected.user.consent_scope ? ` · ${selected.user.consent_scope}` : ""}
                                    </span>
                                    <button
                                      type="button"
                                      className="btn-secondary btn-sm"
                                      onClick={() => handleSetConsent(selected.user.id, false)}
                                    >
                                      Revoke Consent
                                    </button>
                                  </>
                                ) : (
                                  <>
                                    <span className="admin-consent-pill is-pending">consent not granted</span>
                                    {!selected.user.parent_id && (
                                      <span className="admin-consent-meta">
                                        Independent account — no guardian to approve. Grant here to unlock.
                                      </span>
                                    )}
                                    <button
                                      type="button"
                                      className="btn-primary btn-sm"
                                      onClick={() => handleSetConsent(selected.user.id, true)}
                                    >
                                      <Check size={12} /> Grant Consent
                                    </button>
                                  </>
                                )
                              ) : (
                                <span className="admin-consent-meta">
                                  18+ account — monitoring consent not required.
                                </span>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Recent Process Preview */}
                        <div className="admin-assist-card">
                          <div className="admin-card-head">
                            <Clock size={14} />
                            <h4>Latest Study Activity</h4>
                            <button
                              type="button"
                              className="btn-text admin-card-action"
                              onClick={() => setDetailTab("sessions")}
                            >
                              See all {userSessions.length} sessions →
                            </button>
                          </div>

                          <div className="admin-recent-sessions">
                            {userSessions.slice(0, 3).map((s) => (
                              <div key={s.id} className="admin-mini-session-row">
                                <div className="admin-session-title-line">
                                  <span className="admin-task-name">{s.task_description || "Untitled Session"}</span>
                                  {s.subject && <span className="admin-subject-pill">{s.subject}</span>}
                                  {!s.ended_at && <span className="admin-live-pulse">live</span>}
                                </div>
                                <div className="admin-session-details">
                                  <span>{dayLabel(s.started_at)} {fmtTime(s.started_at)}</span>
                                  <span>·</span>
                                  <span>{s.ended_at ? `${fmtDuration(s.total_focused_seconds)} focused` : "In progress"}</span>
                                  {sessionFocusPct(s) != null && (
                                    <>
                                      <span>·</span>
                                      <span className="admin-focus-stat">{sessionFocusPct(s)}% focus</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            ))}
                            {userSessions.length === 0 && (
                              <p className="admin-chip-empty">No sessions recorded yet for this student.</p>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* -------------------------------------------------------- */}
                    {/* SUBTAB 2: ITEMIZED SESSIONS LIST                         */}
                    {/* -------------------------------------------------------- */}
                    {detailTab === "sessions" && (
                      <div className="admin-tab-body">
                        <div className="admin-sessions-header">
                          <h3>Itemized Study Sessions ({userSessions.length})</h3>
                          <p>Chronological history organized day-by-day.</p>
                        </div>

                        <div className="admin-itemized-timeline">
                          {userSessions.length === 0 && (
                            <p className="admin-chip-empty">No sessions recorded yet.</p>
                          )}
                          {groupByDay(userSessions).map((it) =>
                            it.s ? (
                              <div
                                key={it.key}
                                className={`admin-session-card${!it.s.ended_at ? " is-live" : ""}`}
                              >
                                <div className="admin-session-card-main">
                                  <div className="admin-session-card-title">
                                    <span className="admin-task-bold">
                                      {it.s.task_description || "Untitled study session"}
                                    </span>
                                    {it.s.subject && (
                                      <span className="admin-subject-pill">{it.s.subject}</span>
                                    )}
                                    {!it.s.ended_at && (
                                      <span className="admin-live-pulse">IN PROGRESS</span>
                                    )}
                                  </div>

                                  <div className="admin-session-time-row">
                                    <Clock size={12} />
                                    <span>
                                      {fmt(it.s.started_at)}
                                      {it.s.ended_at ? ` → ${fmtTime(it.s.ended_at)}` : " (ongoing)"}
                                    </span>
                                  </div>
                                </div>

                                <div className="admin-session-stats-group">
                                  {it.s.ended_at ? (
                                    <>
                                      {sessionFocusPct(it.s) != null && (
                                        <div className="admin-stat-box is-focus">
                                          <strong>{sessionFocusPct(it.s)}%</strong>
                                          <span>focus</span>
                                        </div>
                                      )}
                                      <div className="admin-stat-box">
                                        <strong>{fmtDuration(it.s.total_focused_seconds)}</strong>
                                        <span>focused</span>
                                      </div>
                                      <div className="admin-stat-box">
                                        <strong>{fmtDuration(it.s.total_distracted_seconds)}</strong>
                                        <span>off-task</span>
                                      </div>
                                      <div className="admin-stat-box">
                                        <strong>{it.s.intervention_count || 0}</strong>
                                        <span>nudges</span>
                                      </div>
                                    </>
                                  ) : (
                                    <div className="admin-live-badge">Studying right now</div>
                                  )}
                                </div>
                              </div>
                            ) : (
                              <div key={it.key} className="admin-day-divider">
                                <span>{it.day}</span>
                              </div>
                            )
                          )}
                        </div>
                      </div>
                    )}

                    {/* -------------------------------------------------------- */}
                    {/* SUBTAB 3: POLICY (BLOCKED / ALLOWED SITES)               */}
                    {/* -------------------------------------------------------- */}
                    {detailTab === "policy" && (
                      <div className="admin-tab-body">
                        <div className="admin-sessions-header">
                          <h3>App & Website Monitoring Policy</h3>
                          <p>Configure which websites and applications this student is restricted from during study sessions.</p>
                        </div>

                        <div className="admin-policy-grid">
                          <ChipList
                            title="Blocked Websites & Applications"
                            entries={draftBlocked}
                            onChange={setDraftBlocked}
                            placeholder="e.g. youtube.com, discord, netflix"
                          />
                          <ChipList
                            title="Allowed Websites & Applications"
                            entries={draftAllowed}
                            onChange={setDraftAllowed}
                            placeholder="e.g. docs.google.com, wikipedia.org"
                          />
                        </div>

                        <div className="admin-policy-actions">
                          <button type="button" className="btn-primary" onClick={savePolicy}>
                            Save Policy Changes
                          </button>
                        </div>
                      </div>
                    )}

                    {/* -------------------------------------------------------- */}
                    {/* SUBTAB 4: LOGIN HISTORY                                  */}
                    {/* -------------------------------------------------------- */}
                    {detailTab === "logins" && (
                      <div className="admin-tab-body">
                        <div className="admin-sessions-header">
                          <h3>Device Sign-in History</h3>
                          <p>Record of sign-ins and active sessions for this account.</p>
                        </div>

                        <div className="admin-login-list">
                          {(selected.login_history || []).length === 0 && (
                            <p className="admin-chip-empty">No login records available.</p>
                          )}
                          {(selected.login_history || []).map((ev) => (
                            <div key={ev.id} className="admin-login-row">
                              <div>
                                <span className="admin-login-device">{ev.device || "Desktop App"}</span>
                                <span className="admin-login-time">{fmt(ev.login_at)}</span>
                              </div>
                              <span className={ev.logout_at ? "admin-logged-out" : "admin-logged-in"}>
                                {ev.logout_at ? `Signed out ${fmt(ev.logout_at)}` : "Currently signed in"}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  /* Clean Minimal Empty Selection State */
                  <div className="admin-empty-assist-screen">
                    <div className="admin-empty-icon-ring">
                      <GraduationCap size={32} />
                    </div>
                    <h3>Ready to Assist Students</h3>
                    <p>
                      Select any student or guardian on the left to track their focus process,
                      manage passwords, review study timelines, or adjust app blocking policies.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* TAB 2: SESSIONS HUB (Organized Person-by-Person Reveal)           */}
          {/* ================================================================ */}
          {tab === "sessions" && (
            <div className="admin-sess-layout">
              {/* Left Column: People Selector */}
              <div className="admin-sess-sidebar">
                <div className="admin-search-row">
                  <Search size={14} className="admin-search-icon" />
                  <input
                    className="admin-search-input"
                    value={sessSearchQuery}
                    onChange={(e) => setSessSearchQuery(e.target.value)}
                    placeholder="Search people with sessions…"
                  />
                  {sessSearchQuery && (
                    <button className="btn-icon" onClick={() => setSessSearchQuery("")}>
                      <X size={12} />
                    </button>
                  )}
                </div>

                <div className="admin-sess-filters">
                  <button
                    className={`admin-pill-btn${sessFilter === "all" ? " is-active" : ""}`}
                    onClick={() => setSessFilter("all")}
                  >
                    All ({sessionsPeople.length})
                  </button>
                  <button
                    className={`admin-pill-btn${sessFilter === "live" ? " is-active" : ""}`}
                    onClick={() => setSessFilter("live")}
                  >
                    Live Now ({sessionsPeople.filter((p) => p.isLive).length})
                  </button>
                  <button
                    className={`admin-pill-btn${sessFilter === "active" ? " is-active" : ""}`}
                    onClick={() => setSessFilter("active")}
                  >
                    Active ({sessionsPeople.filter((p) => p.online).length})
                  </button>
                </div>

                <div className="admin-sess-people-list">
                  {peopleWithSessions.length === 0 && (
                    <p className="admin-chip-empty">No accounts match this search.</p>
                  )}
                  {peopleWithSessions.map((p) => {
                    const isSelected = activeSessPerson?.id === p.id;
                    return (
                      <div
                        key={p.id}
                        className={`admin-sess-person-card${isSelected ? " is-selected" : ""}`}
                        onClick={() => revealPersonSessions(p.id)}
                      >
                        <div className="admin-sess-person-top">
                          <span
                            className={`admin-presence-dot${p.online ? " is-online" : ""}`}
                            title={p.online ? "Online" : "Offline"}
                          />
                          <span className="admin-sess-person-name">
                            {p.full_name || p.serial_number}
                          </span>
                          {p.isLive && <span className="admin-live-pulse">live</span>}
                        </div>

                        <div className="admin-sess-person-meta">
                          <span>{p.sessionCount} {p.sessionCount === 1 ? "session" : "sessions"}</span>
                          <span>·</span>
                          <span>{fmtDuration(p.totalFocusSeconds)} total focus</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Right Column: ONLY this Person's Itemized Sessions */}
              <div className="admin-sess-content">
                {activeSessPerson ? (
                  <div className="admin-person-sessions-container">
                    {/* Person Sessions Banner */}
                    <div className="admin-sess-banner">
                      <div className="admin-sess-banner-left">
                        <div className="admin-avatar">
                          <GraduationCap size={18} />
                        </div>
                        <div>
                          <h2>{activeSessPerson.full_name || activeSessPerson.serial_number}</h2>
                          <p>
                            Serial <strong>{activeSessPerson.serial_number}</strong> ·{" "}
                            {activeSessPerson.sessionCount} recorded sessions ·{" "}
                            {fmtDuration(activeSessPerson.totalFocusSeconds)} total focused
                          </p>
                        </div>
                      </div>

                      <button
                        type="button"
                        className="btn-secondary btn-sm"
                        onClick={() => openUser(activeSessPerson.id)}
                      >
                        <ExternalLink size={12} /> Open Student Assist Profile
                      </button>
                    </div>

                    {/* Timeline of ONLY This Person's Sessions */}
                    <div className="admin-itemized-timeline">
                      {activePersonSessions.length === 0 && (
                        <div className="admin-empty-state">
                          <CalendarClock size={24} />
                          <p>No study sessions recorded yet for {activeSessPerson.full_name || activeSessPerson.serial_number}.</p>
                        </div>
                      )}

                      {groupByDay(activePersonSessions).map((it) =>
                        it.s ? (
                          <div
                            key={it.key}
                            className={`admin-session-card${!it.s.ended_at ? " is-live" : ""}`}
                          >
                            <div className="admin-session-card-main">
                              <div className="admin-session-card-title">
                                <span className="admin-task-bold">
                                  {it.s.task_description || "Untitled study session"}
                                </span>
                                {it.s.subject && (
                                  <span className="admin-subject-pill">{it.s.subject}</span>
                                )}
                                {!it.s.ended_at && (
                                  <span className="admin-live-pulse">IN PROGRESS</span>
                                )}
                              </div>

                              <div className="admin-session-time-row">
                                <Clock size={12} />
                                <span>
                                  {fmt(it.s.started_at)}
                                  {it.s.ended_at ? ` → ${fmtTime(it.s.ended_at)}` : " (ongoing)"}
                                </span>
                              </div>
                            </div>

                            <div className="admin-session-stats-group">
                              {it.s.ended_at ? (
                                <>
                                  {sessionFocusPct(it.s) != null && (
                                    <div className="admin-stat-box is-focus">
                                      <strong>{sessionFocusPct(it.s)}%</strong>
                                      <span>focus</span>
                                    </div>
                                  )}
                                  <div className="admin-stat-box">
                                    <strong>{fmtDuration(it.s.total_focused_seconds)}</strong>
                                    <span>focused</span>
                                  </div>
                                  <div className="admin-stat-box">
                                    <strong>{fmtDuration(it.s.total_distracted_seconds)}</strong>
                                    <span>off-task</span>
                                  </div>
                                  <div className="admin-stat-box">
                                    <strong>{it.s.intervention_count || 0}</strong>
                                    <span>nudges</span>
                                  </div>
                                </>
                              ) : (
                                <div className="admin-live-badge">Studying right now</div>
                              )}
                            </div>
                          </div>
                        ) : (
                          <div key={it.key} className="admin-day-divider">
                            <span>{it.day}</span>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="admin-empty-assist-screen">
                    <CalendarClock size={32} />
                    <h3>Itemized Sessions Hub</h3>
                    <p>Select a person on the left to reveal and inspect only their study sessions.</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* TAB 3: ADMINISTRATORS (System Admin Credentials)                 */}
          {/* ================================================================ */}
          {tab === "admins" && (
            <div className="admin-subpage">
              <div className="admin-page-header">
                <div>
                  <h2>Administrator Accounts</h2>
                  <p>Manage system operators who have access to this central hub.</p>
                </div>
                <button
                  type="button"
                  className="btn-primary"
                  onClick={() => setCreatingAdmin((v) => !v)}
                >
                  <UserPlus size={14} /> {creatingAdmin ? "Cancel" : "Add Administrator"}
                </button>
              </div>

              {/* Self Password Change Card */}
              <div className="admin-assist-card">
                <div className="admin-card-head">
                  <Key size={14} />
                  <h4>My Admin Password</h4>
                </div>
                <form className="admin-inline-form" onSubmit={changeMyPassword}>
                  <input
                    type="password"
                    className="admin-inline-input"
                    value={passwordDraft}
                    onChange={(e) => setPasswordDraft(e.target.value)}
                    placeholder="New password (min 4 chars)"
                  />
                  <button
                    type="submit"
                    className="btn-primary btn-sm"
                    disabled={passwordDraft.length < 4}
                  >
                    Change Password
                  </button>
                  <span className="admin-cred-display">
                    <code>
                      {showMyPw ? myPassword : "••••••••"}
                    </code>
                    <button
                      type="button"
                      className="btn-icon"
                      title={showMyPw ? "Hide" : "Reveal"}
                      onClick={() => setShowMyPw((v) => !v)}
                    >
                      {showMyPw ? <EyeOff size={13} /> : <Eye size={13} />}
                    </button>
                  </span>
                </form>
              </div>

              {/* Create Admin Form */}
              {creatingAdmin && (
                <form className="admin-create-form" onSubmit={createAdminAccount}>
                  <div className="admin-create-header">
                    <h4>Add New Administrator</h4>
                  </div>
                  <div className="admin-create-grid">
                    <label className="admin-field">
                      <span>Admin Name</span>
                      <input
                        value={newAdminName}
                        onChange={(e) => setNewAdminName(e.target.value)}
                        placeholder="e.g. Principal Santos"
                        required
                        autoFocus
                      />
                    </label>
                    <label className="admin-field">
                      <span>Username</span>
                      <input
                        value={newAdminUsername}
                        onChange={(e) => setNewAdminUsername(e.target.value)}
                        placeholder="e.g. santos"
                        required
                      />
                    </label>
                    <label className="admin-field">
                      <span>Password</span>
                      <input
                        type="password"
                        value={newAdminPassword}
                        onChange={(e) => setNewAdminPassword(e.target.value)}
                        placeholder="Min 4 characters"
                        required
                      />
                    </label>
                  </div>
                  <div className="admin-create-actions">
                    <button
                      type="submit"
                      className="btn-primary"
                      disabled={
                        createAdminBusy ||
                        !newAdminName.trim() ||
                        !newAdminUsername.trim() ||
                        newAdminPassword.length < 4
                      }
                    >
                      {createAdminBusy ? "Saving…" : "Create Administrator"}
                    </button>
                    <button
                      type="button"
                      className="btn-text"
                      onClick={() => setCreatingAdmin(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              {/* Admins Table */}
              <div className="admin-table-container">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Administrator</th>
                      <th>Username</th>
                      <th>Password</th>
                      <th>Created</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {admins.map((a) => {
                      const isRevealed = Boolean(revealedAdminPws[a.id]);
                      return (
                        <tr key={a.id}>
                          <td>
                            <div className="admin-name-line">
                              <Shield size={13} />
                              <strong>{a.name}</strong>
                              {a.id === admin?.id && <span className="admin-pill-tag">You</span>}
                            </div>
                          </td>
                          <td><code>{a.username}</code></td>
                          <td>
                            {a.password ? (
                              <div className="admin-cred-display">
                                <code>{isRevealed ? a.password : "••••••••"}</code>
                                <button
                                  type="button"
                                  className="btn-icon"
                                  title={isRevealed ? "Hide" : "Reveal"}
                                  onClick={() =>
                                    setRevealedAdminPws((prev) => ({
                                      ...prev,
                                      [a.id]: !prev[a.id],
                                    }))
                                  }
                                >
                                  {isRevealed ? <EyeOff size={12} /> : <Eye size={12} />}
                                </button>
                                <button
                                  type="button"
                                  className="btn-icon"
                                  title="Copy password"
                                  onClick={() => handleCopy(a.password)}
                                >
                                  <Copy size={12} />
                                </button>
                              </div>
                            ) : (
                              <span className="admin-subtext">—</span>
                            )}
                          </td>
                          <td>{fmt(a.created_at)}</td>
                          <td>
                            {a.id !== admin?.id ? (
                              <button
                                type="button"
                                className="btn-text btn-danger"
                                onClick={() => deleteAdminAccount(a.id)}
                              >
                                Delete
                              </button>
                            ) : (
                              <span className="admin-subtext">Active session</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {tab === "ops" && (
            <SmartOps
              adminToken={adminToken}
              acctRequests={acctRequests}
              acctReqStatus={acctReqStatus}
              setAcctReqStatus={setAcctReqStatus}
              blockTickets={blockTickets}
              autoBlock={autoBlock}
              updateAutoBlock={updateAutoBlock}
              decideAccountRequest={decideAccountRequest}
              decideTicket={decideTicket}
              refresh={() => loadOps()}
              opsError={opsError}
              opsLoading={opsLoading}
              fmt={fmt}
              sessions={sessions}
              section={smartOpsSection}
              onSectionChange={setSmartOpsSection}
            />
          )}
        </main>
      </div>
    </div>
  );
}
