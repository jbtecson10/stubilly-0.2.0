import { useEffect, useState } from "react";
import { api } from "../api/client";

const MIN_PASSWORD = 8;

// Mirror of the server's minor check (under 18 today) — used only to show
// the consent heads-up at signup; the server remains the authority.
function isLikelyMinor(dob) {
  if (!dob) return false;
  const b = new Date(dob);
  if (Number.isNaN(b.getTime())) return false;
  const now = new Date();
  let age = now.getFullYear() - b.getFullYear();
  const beforeBirthday =
    now.getMonth() < b.getMonth() ||
    (now.getMonth() === b.getMonth() && now.getDate() < b.getDate());
  if (beforeBirthday) age -= 1;
  return age < 18;
}

function isBrowserSignIn() {
  return typeof window !== "undefined" && (window.location?.origin || "").startsWith("http");
}

// --- line icons (match the reference sign-in card) ------------------------
const svg = {
  width: 18,
  height: 18,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

function IconMail() {
  return (
    <svg {...svg}>
      <rect x="3" y="5" width="18" height="14" rx="2.5" />
      <path d="m3.5 7.5 8.5 5.5 8.5-5.5" />
    </svg>
  );
}

function IconLock() {
  return (
    <svg {...svg}>
      <rect x="5" y="11" width="14" height="9" rx="2" />
      <path d="M8 11V8a4 4 0 0 1 8 0v3" />
    </svg>
  );
}

function IconUser() {
  return (
    <svg {...svg}>
      <circle cx="12" cy="8" r="4" />
      <path d="M4.5 20a7.5 7.5 0 0 1 15 0" />
    </svg>
  );
}

function IconEye() {
  return (
    <svg {...svg}>
      <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z" />
      <circle cx="12" cy="12" r="2.6" />
    </svg>
  );
}

function IconEyeOff() {
  return (
    <svg {...svg}>
      <path d="M4 5l16 14" />
      <path d="M9.6 6.4A9.9 9.9 0 0 1 12 6c6.5 0 10 6 10 6a17 17 0 0 1-3.2 3.7" />
      <path d="M6.4 8.3A16.6 16.6 0 0 0 2 12s3.5 6 10 6a9.7 9.7 0 0 0 3.7-.7" />
      <path d="M10.2 10.3a2.6 2.6 0 0 0 3.5 3.6" />
    </svg>
  );
}

// Icon-prefixed input, optionally with a password show/hide eye.
function AuthInput({
  icon,
  value,
  onChange,
  placeholder,
  type = "text",
  toggle = false,
  autoFocus = false,
  autoComplete,
}) {
  const [show, setShow] = useState(false);
  return (
    <div className="auth-input">
      <span className="auth-input-icon" aria-hidden="true">
        {icon}
      </span>
      <input
        type={toggle ? (show ? "text" : "password") : type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        aria-label={placeholder}
        autoFocus={autoFocus}
        autoComplete={autoComplete}
      />
      {toggle && (
        <button
          type="button"
          className="auth-eye"
          aria-label={show ? "Hide password" : "Show password"}
          onClick={() => setShow((s) => !s)}
        >
          {show ? <IconEyeOff /> : <IconEye />}
        </button>
      )}
    </div>
  );
}

// The unified account door, styled after the reference sign-in card:
//   - centered "Stubilly" title + per-view subtitle
//   - sign-in: email/ID-or-username + password (eye toggle), blue Sign In
//     button, centered "Forgot password?" / "Sign up" links. The same field
//     accepts a student's email/serial OR an administrator's username — the
//     backend tries the student table first, then the administrator table —
//     so admins no longer need a separate login link or secret shortcut.
//   - create: self-service registration (admins no longer build student
//     accounts), same styling, with a "Sign in" link to switch back
//   - forgot / reset: the password-recovery flow inside the same card
// Every fresh install lands here too (`firstRun`), with Create selected, so
// the very first account ever still bootstraps the deployment.
export default function AuthScreen({ onLogin, onAdminLogin, backendLabel, firstRun }) {
  const [tab, setTab] = useState(firstRun ? "create" : "signin");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [notice, setNotice] = useState(null);

  // Sign-in
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");

  // Registration
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  // Age (framework input): self-registration is18+ only — under-18 students
  // are created by their guardian or the administrator, never on this form.
  // DOB is required; the server re-checks it (this is just the friendly gate).
  const [regDob, setRegDob] = useState("");

  // "Request an account" — closed sign-up: the form becomes a proposal to
  // the admin (their bell rings), and we poll our own email for the answer.
  const [reqName, setReqName] = useState("");
  const [reqEmail, setReqEmail] = useState("");
  const [reqRole, setReqRole] = useState("student");
  const [reqPassword, setReqPassword] = useState("");
  const [reqConfirm, setReqConfirm] = useState("");
  const [reqMessage, setReqMessage] = useState("");
  const [reqSubmitted, setReqSubmitted] = useState(false);
  const [reqStatus, setReqStatus] = useState(null); // none|pending|approved|denied

  // Password recovery ("forgot password") — three tiny steps in one card.
  const [recoveryView, setRecoveryView] = useState("none"); // none | forgot | reset
  const [recoveryEmail, setRecoveryEmail] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [recoveryNew, setRecoveryNew] = useState("");
  const [recoverySent, setRecoverySent] = useState(false);

  // Social sign-in availability
  const [socialProviders, setSocialProviders] = useState([]);
  useEffect(() => {
    if (!isBrowserSignIn()) return;
    let cancelled = false;
    api
      .socialProviders()
      .then((s) => !cancelled && setSocialProviders(s.providers || []))
      .catch(() => {
        // Non-fatal: just hide the social buttons.
      });
    return () => {
      cancelled = true;
    };
  }, []);

  async function handleSignIn(e) {
    e.preventDefault();
    if (!identifier.trim() || !password || busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await api.login(identifier.trim(), password, navigator.userAgent.slice(0, 120));
      if (res.admin_token) {
        onAdminLogin?.(res.admin_token, res.admin);
        return;
      }
      onLogin(res.token, res.user);
    } catch (err) {
      setError(err.message || "Couldn't sign in — is the server reachable?");
    } finally {
      setBusy(false);
    }
  }

  async function handleCreate(e) {
    e.preventDefault();
    if (!regName.trim() || !regEmail.trim() || !regPassword || !regDob || busy) return;
    setError(null);
    if (regPassword.length < MIN_PASSWORD) {
      setError(`Password must be at least ${MIN_PASSWORD} characters`);
      return;
    }
    if (regPassword !== regConfirm) {
      setError("Passwords don't match");
      return;
    }
    if (!regDob) {
      setError("Date of birth is required — sign-up is for ages 18 and over");
      return;
    }
    if (isLikelyMinor(regDob)) {
      setError(
        "Sign-up is for students 18 or older — a parent or the administrator must create your account"
      );
      return;
    }
    setBusy(true);
    try {
      // Self-service registration: the backend auto-generates a serial/ID
      // number from the email, so students never need one to sign up.
      // Student-only role + a verified 18+ date of birth (the guardian and
      // administrator flows live behind their own logins).
      await api.registerUser({
        email: regEmail.trim(),
        full_name: regName.trim(),
        password: regPassword,
        role: "student",
        date_of_birth: regDob,
      });
      const res = await api.login(regEmail.trim(), regPassword, navigator.userAgent.slice(0, 120));
      onLogin(res.token, res.user);
    } catch (err) {
      setError(err.message || "Couldn't create your account.");
    } finally {
      setBusy(false);
    }
  }

  // Poll the requester's own status while their request is open — the
  // unauthenticated endpoint answers by email (none | pending | approved |
  // denied), so "your account was approved" shows up without a reload.
  useEffect(() => {
    if (!reqSubmitted || !reqEmail) return undefined;
    let cancelled = false;
    const check = () => {
      api
        .accountRequestStatus(reqEmail)
        .then((s) => {
          if (!cancelled) setReqStatus(s);
        })
        .catch(() => {
          // Transient network error: keep the last known status.
        });
    };
    check();
    const id = setInterval(check, 5000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [reqSubmitted, reqEmail]);

  async function handleSubmitRequest(e) {
    e.preventDefault();
    if (!reqName.trim() || !reqEmail.trim() || !reqPassword || busy) return;
    setError(null);
    if (reqPassword.length < MIN_PASSWORD) {
      setError(`Password must be at least ${MIN_PASSWORD} characters`);
      return;
    }
    if (reqPassword !== reqConfirm) {
      setError("Passwords don't match");
      return;
    }
    setBusy(true);
    try {
      await api.requestAccount({
        full_name: reqName.trim(),
        email: reqEmail.trim(),
        role: reqRole,
        password: reqPassword,
        message: reqMessage.trim(),
      });
      setReqSubmitted(true);
      setReqStatus({ status: "pending", email: reqEmail.trim() });
    } catch (err) {
      setError(err.message || "Couldn't send your request.");
    } finally {
      setBusy(false);
    }
  }

  async function handleRequestCode(e) {
    e.preventDefault();
    if (!recoveryEmail.trim() || busy) return;
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      // Stubilly has no mail server, so the code comes straight back to the
      // person at this screen (and is also logged server-side).
      const res = await api.forgotPassword(recoveryEmail.trim());
      setRecoverySent(true);
      setNotice(
        res.reset_code
          ? "Your recovery code is below — I've entered it for you, just set a new password."
          : "If an account exists with that email, a recovery code was issued."
      );
      if (res.reset_code) {
        setRecoveryCode(res.reset_code);
        setRecoveryView("reset");
      }
    } catch (err) {
      setError(err.message || "Couldn't request a recovery code.");
    } finally {
      setBusy(false);
    }
  }

  async function handleResetPassword(e) {
    e.preventDefault();
    if (!recoveryCode.trim() || !recoveryNew || busy) return;
    setError(null);
    if (recoveryNew.length < MIN_PASSWORD) {
      setError(`New password must be at least ${MIN_PASSWORD} characters`);
      return;
    }
    setBusy(true);
    try {
      await api.resetPassword(recoveryEmail.trim(), recoveryCode.trim(), recoveryNew);
      const ok = "Password reset — sign in with your new password.";
      closeRecovery(ok, recoveryEmail.trim());
    } catch (err) {
      setError(err.message || "Couldn't reset your password.");
    } finally {
      setBusy(false);
    }
  }

  function closeRecovery(goToSignIn, prefillEmail) {
    setRecoveryView("none");
    setRecoveryCode("");
    setRecoveryNew("");
    setRecoverySent(false);
    setNotice(goToSignIn || null);
    if (prefillEmail) setIdentifier(prefillEmail);
    if (goToSignIn) setTab("signin");
  }

  async function handleSocial(provider) {
    try {
      window.location.href = await api.socialLoginUrl(provider);
    } catch (err) {
      setError(`Couldn't start ${provider} sign-in: ${err.message}`);
    }
  }

  function switchTo(nextTab) {
    setTab(nextTab);
    setRecoveryView("none");
    setError(null);
    setNotice(null);
  }

  const socialOk = isBrowserSignIn() && socialProviders.length > 0;
  const signInView = tab === "signin" && recoveryView === "none";

  // Centered subtitle under the centered "Stubilly" title, per view.
  let subtitle;
  if (recoveryView === "forgot") {
    subtitle = "Enter the email on your account to receive a recovery code.";
  } else if (recoveryView === "reset") {
    subtitle = (
      <>
        Set a new password for <strong>{recoveryEmail.trim() || "your account"}</strong>.
      </>
    );
  } else if (firstRun) {
    subtitle = "Create the very first account to unlock your study space — you can sign in with it right away.";
  } else if (tab === "create") {
    subtitle = "Create an account to continue studying.";
  } else if (tab === "request") {
    subtitle = reqSubmitted
      ? "Your request is with the administrator."
      : "Sign-up is closed — ask the administrator for an account.";
  } else {
    subtitle = "Sign in to continue studying.";
  }

  return (
    <div className="setup-screen">
      <div className="setup-card login-card">
        <header className="auth-brand">
          <span className="setup-lamp" aria-hidden="true" />
          <span className="auth-eyebrow">Study space</span>
        </header>
        <h1 className="auth-title">Stubilly</h1>
        <p className="auth-subtitle">
          {subtitle}
          {backendLabel ? ` Connected to ${backendLabel}.` : ""}
        </p>

        {tab === "signin" ? (
          signInView ? (
            <form onSubmit={handleSignIn} className="login-form">
              <AuthInput
                icon={<IconMail />}
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="Email or ID number"
                autoFocus
                autoComplete="username"
              />
              <AuthInput
                icon={<IconLock />}
                toggle
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                autoComplete="current-password"
              />
              {error && <p className="login-error">{error}</p>}
              {notice && <p className="login-success">{notice}</p>}
              <button
                type="submit"
                className="auth-submit"
                disabled={!identifier.trim() || !password || busy}
              >
                <IconLock />
                {busy ? "Signing in…" : "Sign In"}
              </button>
              {socialOk && (
                <div className="auth-social">
                  <div className="auth-or">
                    <span>or</span>
                  </div>
                  {socialProviders.includes("google") && (
                    <button
                      type="button"
                      className="auth-social-btn"
                      onClick={() => handleSocial("google")}
                    >
                      Continue with Google
                    </button>
                  )}
                  {socialProviders.includes("github") && (
                    <button
                      type="button"
                      className="auth-social-btn"
                      onClick={() => handleSocial("github")}
                    >
                      Continue with GitHub
                    </button>
                  )}
                </div>
              )}
              <button
                type="button"
                className="auth-link"
                onClick={() => {
                  setRecoveryView("forgot");
                  setError(null);
                  setNotice(null);
                }}
              >
                Forgot password?
              </button>
              <button type="button" className="auth-link" onClick={() => switchTo("request")}>
                Don't have an account? Request one
              </button>
            </form>
          ) : recoveryView === "forgot" ? (
            <form onSubmit={handleRequestCode} className="login-form">
              <AuthInput
                icon={<IconMail />}
                type="email"
                value={recoveryEmail}
                onChange={(e) => setRecoveryEmail(e.target.value)}
                placeholder="Email address"
                autoFocus
                autoComplete="email"
              />
              {error && <p className="login-error">{error}</p>}
              {notice && recoverySent && <p className="login-success">{notice}</p>}
              <button
                type="submit"
                className="auth-submit"
                disabled={!recoveryEmail.trim() || busy}
              >
                <IconLock />
                {busy ? "Requesting code…" : "Request Recovery Code"}
              </button>
              <button type="button" className="auth-link" onClick={() => closeRecovery()}>
                Back to sign in
              </button>
            </form>
          ) : (
            <form onSubmit={handleResetPassword} className="login-form">
              <AuthInput
                icon={<IconMail />}
                value={recoveryCode}
                onChange={(e) => setRecoveryCode(e.target.value)}
                placeholder="Recovery code"
                autoFocus
              />
              <AuthInput
                icon={<IconLock />}
                toggle
                value={recoveryNew}
                onChange={(e) => setRecoveryNew(e.target.value)}
                placeholder={`New password (at least ${MIN_PASSWORD} characters)`}
                autoComplete="new-password"
              />
              {error && <p className="login-error">{error}</p>}
              {notice && <p className="login-success">{notice}</p>}
              <button
                type="submit"
                className="auth-submit"
                disabled={!recoveryCode.trim() || !recoveryNew || busy}
              >
                <IconLock />
                {busy ? "Resetting…" : "Reset Password"}
              </button>
              <button type="button" className="auth-link" onClick={() => closeRecovery()}>
                Back to sign in
              </button>
            </form>
          )
        ) : tab === "request" ? (
          reqSubmitted ? (
            <div className="login-form request-status">
              <p className="auth-hint">
                We emailed the administrator your request for <strong>{reqEmail}</strong>.
              </p>
              {reqStatus?.status === "pending" && (
                <p className="login-success">
                  Still pending — this page checks every few seconds.
                </p>
              )}
              {reqStatus?.status === "approved" && (
                <p className="login-success">
                  Approved — your chosen password is active. Sign in below.
                </p>
              )}
              {reqStatus?.status === "denied" && (
                <p className="login-error">
                  The administrator declined this request. You can ask again or contact them.
                </p>
              )}
              <button
                type="button"
                className="auth-submit"
                onClick={() => {
                  setReqSubmitted(false);
                  setReqStatus(null);
                  setReqPassword("");
                  setReqConfirm("");
                  setTab("signin");
                  setRecoveryView("none");
                  setIdentifier(reqEmail);
                  setError(null);
                  setNotice(
                    reqStatus?.status === "approved"
                      ? "Your account is ready — sign in with your chosen password."
                      : null
                  );
                }}
              >
                <IconLock />
                {reqStatus?.status === "approved" ? "Go to sign in" : "Back to sign in"}
              </button>
              <button
                type="button"
                className="auth-link"
                onClick={() => {
                  setReqSubmitted(false);
                  setReqStatus(null);
                  setTab("signin");
                }}
              >
                Use a different email
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmitRequest} className="login-form">
              <AuthInput
                icon={<IconUser />}
                value={reqName}
                onChange={(e) => setReqName(e.target.value)}
                placeholder="Full name"
                autoFocus
                autoComplete="name"
              />
              <AuthInput
                icon={<IconMail />}
                type="email"
                value={reqEmail}
                onChange={(e) => setReqEmail(e.target.value)}
                placeholder="Email address"
                autoComplete="email"
              />
              <AuthInput
                icon={<IconLock />}
                toggle
                value={reqPassword}
                onChange={(e) => setReqPassword(e.target.value)}
                placeholder={`Password (at least ${MIN_PASSWORD} characters)`}
                autoComplete="new-password"
              />
              <AuthInput
                icon={<IconLock />}
                toggle
                value={reqConfirm}
                onChange={(e) => setReqConfirm(e.target.value)}
                placeholder="Confirm password"
                autoComplete="new-password"
              />
              <div className="auth-role-row">
                <label className="auth-role-field">
                  <span>Account type</span>
                  <select value={reqRole} onChange={(e) => setReqRole(e.target.value)}>
                    <option value="student">Student</option>
                    <option value="parent">Parent / guardian</option>
                  </select>
                </label>
              </div>
              <textarea
                className="auth-role-field request-message"
                value={reqMessage}
                onChange={(e) => setReqMessage(e.target.value)}
                placeholder="Message for the administrator (optional) — who are you, why do you need access?"
                rows={3}
                maxLength={500}
              />
              <p className="auth-hint">
                The administrator reviews every request. You'll see your status here, and you'll
                sign in with the password you chose above.
              </p>
              {error && <p className="login-error">{error}</p>}
              <button
                type="submit"
                className="auth-submit"
                disabled={!reqName.trim() || !reqEmail.trim() || !reqPassword || busy}
              >
                <IconMail />
                {busy ? "Sending request…" : "Request an account"}
              </button>
              <button type="button" className="auth-link" onClick={() => switchTo("signin")}>
                Back to sign in
              </button>
            </form>
          )
        ) : (
          <form onSubmit={handleCreate} className="login-form">
            <AuthInput
              icon={<IconUser />}
              value={regName}
              onChange={(e) => setRegName(e.target.value)}
              placeholder="Full name"
              autoFocus
              autoComplete="name"
            />
            <AuthInput
              icon={<IconMail />}
              type="email"
              value={regEmail}
              onChange={(e) => setRegEmail(e.target.value)}
              placeholder="Email address"
              autoComplete="email"
            />
            <AuthInput
              icon={<IconLock />}
              toggle
              value={regPassword}
              onChange={(e) => setRegPassword(e.target.value)}
              placeholder="Password"
              autoComplete="new-password"
            />
            <AuthInput
              icon={<IconLock />}
              toggle
              value={regConfirm}
              onChange={(e) => setRegConfirm(e.target.value)}
              placeholder="Confirm password"
              autoComplete="new-password"
            />
            <div className="auth-role-row">
              <label className="auth-role-field">
                <span>Date of birth (18 or older)</span>
                <input
                  type="date"
                  value={regDob}
                  onChange={(e) => setRegDob(e.target.value)}
                  max={new Date().toISOString().slice(0, 10)}
                />
              </label>
            </div>
            <p className="auth-hint">
              Under 18? Ask your parent or the administrator to create your account for you.
            </p>
            {error && <p className="login-error">{error}</p>}
            {notice && <p className="login-success">{notice}</p>}
            <button
              type="submit"
              className="auth-submit"
              disabled={!regName.trim() || !regEmail.trim() || !regPassword || !regDob || busy}
            >
              <IconLock />
              {busy ? "Creating account…" : "Create Account"}
            </button>
            <p className="auth-hint">
              Your serial / ID number is generated automatically — you'll see it on the home screen.
            </p>
            <button type="button" className="auth-link" onClick={() => switchTo("signin")}>
              Already have an account? Sign in
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
