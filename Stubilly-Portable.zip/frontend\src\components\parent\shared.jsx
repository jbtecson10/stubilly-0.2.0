/**
 * Shared pure helpers + presentational pieces for the parent/guardian
 * dashboard. These were lifted verbatim out of ParentDashboard.jsx so the
 * data-owning component stays focused on state, cadences and handlers.
 */

import { UserPlus } from "lucide-react";

export const KIND_LABELS = {
  student_linked: "New student account",
  focus_started: "Started focusing",
  focus_ended: "Session ended",
  site_visit: "Now on",
  app_visit: "Now using",
  screen_limit: "Screen limit",
  off_task: "Off task",
  paralysis: "Looks stuck",
  session_report: "Session report",
  distraction_spike: "Distraction spike",
  absent: "Away",
  sleeping: "Dozing off",
  // Smart intervention — the guardian's approval feed matches the admin gate.
  block_suggested: "Block suggested",
  blocked: "Blocked",
  account_removed: "Account removed",
};

// --- Clock accuracy -------------------------------------------------------
// Server timestamps are naive UTC; naive strings parsed by `new Date()`
// would be read as LOCAL time (the exact cause of a "8h ago" on every
// fresh alert in UTC+8). Every relative label therefore parses through
// parseServerTime() AND runs against a skew-corrected clock: the server's
// own time (from /meta/time) minus this device's clock. Result is exact
// "12s / 3m / 2h ago" even when this PC's clock is wrong, the page has
// been open offline for hours, or the tab is in the background.
let serverSkew = 0;

// The dashboard's clock-sync effect writes the skew here after each
// /meta/time probe; everything that renders relative labels reads it.
export function setServerSkew(skew) {
  serverSkew = skew;
}

export function serverNow() {
  return Date.now() + serverSkew;
}

export function timeAgo(iso) {
  if (!iso) return "";
  const then = parseServerTime(iso);
  if (!then) return "";
  const secs = Math.floor(Math.max(0, (serverNow() - then.getTime()) / 1000));
  if (secs < 10) return "just now";
  if (secs < 60) return `${secs}s ago`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

// Feed day-group heading for the alert timeline: "Today" / "Yesterday" /
// "Mon, Sep 28" — computed against the skew-corrected clock like timeAgo.
export function dayLabel(iso) {
  const d = parseServerTime(iso);
  if (!d) return "";
  const midnight = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((midnight(new Date(serverNow())) - midnight(d)) / 86400000);
  if (diff <= 0) return "Today";
  if (diff === 1) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
}

// Time-on-site figure: "45s", "3m", "12m 40s".
export function fmtDur(seconds) {
  const s = Math.max(0, Math.round(seconds || 0));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return rem === 0 ? `${m}m` : `${m}m ${rem}s`;
}

// "409 Conflict: {"detail":"..."}" -> "..."
export function detailOf(err) {
  const m = /:\s*(\{.*)$/s.exec(err?.message || "");
  if (m) {
    try {
      const parsed = JSON.parse(m[1]);
      if (parsed?.detail) return String(parsed.detail);
    } catch {
      /* not JSON — fall through */
    }
  }
  return err?.message || "Something went wrong";
}

// Server timestamps are naive UTC ("2026-09-30 07:34:27"); parse them as
// UTC so history entries display the right LOCAL clock time.
export function parseServerTime(iso) {
  if (!iso) return null;
  let s = String(iso);
  if (
    /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}/.test(s) &&
    !/[zZ]|[+-]\d{2}:?\d{2}$/.test(s)
  ) {
    s = s.replace(" ", "T") + "Z";
  }
  const d = new Date(s);
  return Number.isNaN(d) ? null : d;
}

export function fmtDateTime(iso) {
  const d = parseServerTime(iso);
  if (!d) return "";
  return d.toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/**
 * One session as the guardian sees it — used by both history tabs
 * (per-session list and the by-day rollup): time, task, focus, screen
 * time, the sites/app opened during it and the micro-task list.
 */
export function HistSession({ sess }) {
  return (
    <div className={`parent-hist-item${sess.is_active ? " is-live" : ""}`}>
      <div className="parent-hist-head">
        <strong>{sess.task_description || "Study session"}</strong>
        <span className="parent-hist-when">
          {fmtDateTime(sess.started_at)}
          {sess.is_active ? " · in progress" : ""}
        </span>
      </div>
      <div className="parent-hist-meta">
        <span>{fmtDur(sess.duration_seconds)}</span>
        {sess.focus_pct != null && <span>{sess.focus_pct}% focused</span>}
        <span>screen {fmtDur(sess.screen_seconds)}</span>
        <span>off task {sess.off_task_minutes} min</span>
      </div>
      {(sess.top_sites?.length || 0) > 0 && (
        <div className="parent-hist-chips">
          {sess.top_sites.slice(0, 6).map((t) => (
            <span className="parent-chip" key={t.site}>
              {t.site} · {fmtDur(t.seconds)}
            </span>
          ))}
        </div>
      )}
      {(sess.top_apps?.length || 0) > 0 && (
        <div className="parent-hist-chips">
          {sess.top_apps.slice(0, 5).map((t) => (
            <span className="parent-chip parent-chip-app" key={t.app}>
              {t.app} · {fmtDur(t.seconds)}
            </span>
          ))}
        </div>
      )}
      {(sess.recent_windows?.length || 0) > 0 && (
        <div className="parent-hist-chips">
          {sess.recent_windows.slice(0, 4).map((w) => (
            <span className="parent-chip parent-chip-window" key={w.title} title={w.title}>
              {(w.title || w.app).length > 40
                ? `${(w.title || w.app).slice(0, 40)}…`
                : w.title || w.app}{" "}
              · {fmtDur(w.seconds)}
            </span>
          ))}
        </div>
      )}
      {(sess.tasks?.length || 0) > 0 && (
        <ol className="parent-hist-tasks">
          {sess.tasks.slice(0, 8).map((t, i) => (
            <li key={i} className={t.completed ? "is-done" : ""}>
              {t.description}
              {t.estimated_minutes ? ` (${t.estimated_minutes}m)` : ""}
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

export function fmtEventTime(iso) {
  const d = parseServerTime(iso);
  if (!d) return "";
  return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

/**
 * One day of guardian-visible activity: the windows that were in front
 * (title + seconds) and the click/view breadcrumb timeline. Window
 * titles and element labels only — never page content or typed values.
 */
export function ActivityTimeline({ data }) {
  const events = data.events || [];
  const windows = data.top_windows || [];
  return (
    <div className="parent-hist-day">
      <div className="parent-hist-meta">
        <span>
          Screen time <strong>{fmtDur(data.screen_seconds)}</strong>
        </span>
        <span>{events.length} interaction(s)</span>
      </div>
      {windows.length > 0 && (
        <div className="parent-site-top">
          <span className="parent-site-top-label">Windows that day</span>
          {windows.slice(0, 8).map((w) => (
            <div className="parent-site-row" key={w.title}>
              <span className="parent-site-name" title={w.title}>
                {w.title}
              </span>
              <span className="parent-site-track">
                <span
                  className="parent-site-fill parent-window-fill"
                  style={{
                    width: `${Math.max(
                      6,
                      Math.round((w.seconds / (windows[0]?.seconds || 1)) * 100)
                    )}%`,
                  }}
                />
              </span>
              <span className="parent-site-time">{fmtDur(w.seconds)}</span>
            </div>
          ))}
        </div>
      )}
      {events.length === 0 ? (
        <p className="parent-history-empty">
          No clicks recorded this day{data.date ? ` (${data.date})` : ""} — try
          another date.
        </p>
      ) : (
        <ul className="parent-activity-list">
          {events.map((ev, i) => (
            <li key={`${ev.at}-${i}`} className={`parent-activity-item parent-activity-${ev.kind}`}>
              <span className="parent-activity-time">{fmtEventTime(ev.at)}</span>
              <span className="parent-activity-kind">
                {ev.kind === "view" ? "viewed" : "clicked"}
              </span>
              <span className="parent-activity-label">{ev.label}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/**
 * The Add-student box (create a new account vs link an existing one).
 * Shared by the Overview and the Family section — same handlers either
 * way, owned by ParentDashboard.
 */
export function AddStudentBox({
  showAdd,
  setShowAdd,
  addMode,
  setAddMode,
  addError,
  setAddError,
  linkMsg,
  setLinkMsg,
  form,
  setForm,
  createStudent,
  adding,
  linkIdent,
  setLinkIdent,
  linkStudent,
  linking,
}) {
  return (
    <>
      <div className="parent-add-toggle">
        <button
          type="button"
          className="btn-primary"
          onClick={() => {
            setShowAdd((v) => !v);
            setAddError(null);
            setLinkMsg(null);
          }}
        >
          <UserPlus size={16} aria-hidden="true" />
          {showAdd ? "Cancel" : "Add student"}
        </button>
      </div>

      {showAdd && (
        <div className="parent-add-box">
          <div className="parent-add-tabs">
            <button
              type="button"
              className={`parent-add-tab${addMode === "create" ? " is-active" : ""}`}
              onClick={() => {
                setAddMode("create");
                setAddError(null);
                setLinkMsg(null);
              }}
            >
              Create account
            </button>
            <button
              type="button"
              className={`parent-add-tab${addMode === "link" ? " is-active" : ""}`}
              onClick={() => {
                setAddMode("link");
                setAddError(null);
                setLinkMsg(null);
              }}
            >
              Link existing
            </button>
          </div>

          {addMode === "create" ? (
            <form className="parent-add" onSubmit={createStudent}>
              <div className="parent-add-row">
                <label className="parent-add-field">
                  Full name
                  <input
                    value={form.full_name}
                    onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                    placeholder="e.g. Juan Dela Cruz"
                    required
                  />
                </label>
                <label className="parent-add-field">
                  Email
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="student@school.edu"
                    required
                  />
                </label>
                <label className="parent-add-field">
                  Password
                  <input
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="At least 4 characters"
                    minLength={4}
                    required
                  />
                </label>
                <label className="parent-add-field">
                  Date of birth (optional)
                  <input
                    type="date"
                    value={form.date_of_birth}
                    onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })}
                  />
                </label>
              </div>
              <div className="parent-add-actions">
                <button type="submit" className="btn-primary" disabled={adding}>
                  {adding ? "Creating…" : "Create account"}
                </button>
                <span className="parent-add-hint">
                  The account is linked to you — you grant monitoring consent next.
                </span>
              </div>
              {addError && <p className="parent-add-error">{addError}</p>}
            </form>
          ) : (
            <form className="parent-add" onSubmit={linkStudent}>
              <div className="parent-add-row">
                <label className="parent-add-field">
                  Student email or ID
                  <input
                    value={linkIdent}
                    onChange={(e) => setLinkIdent(e.target.value)}
                    placeholder="student@school.edu or 2024-0099"
                    required
                  />
                </label>
              </div>
              <div className="parent-add-actions">
                <button type="submit" className="btn-primary" disabled={linking}>
                  {linking ? "Linking…" : "Link student"}
                </button>
                <span className="parent-add-hint">
                  Already has an account — even if they're studying right now? Attach
                  it here; no password needed.
                </span>
              </div>
              {linkMsg && (
                <p className={linkMsg.ok ? "parent-add-ok" : "parent-add-error"}>
                  {linkMsg.text}
                </p>
              )}
            </form>
          )}
        </div>
      )}
    </>
  );
}
