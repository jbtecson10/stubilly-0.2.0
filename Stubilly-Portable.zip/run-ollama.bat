@echo off
rem ============================================================
rem  Stubilly — Ollama mode  (port 8422)
rem  Requires: Ollama running locally (ollama serve) and
rem  setup.bat already completed.
rem ============================================================
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Setup not completed. Run setup.bat first.
    pause
    exit /b 1
)

rem Load .env into the environment (skip blank lines and comments)
for /f "usebackq eol=# tokens=1,* delims==" %%a in (".env") do if not "%%a"=="" set "%%a=%%b"

rem Pin this instance's identity
set STUBILLY_HOST=127.0.0.1
set STUBILLY_PORT=8422
set STUBILLY_LLM_BACKEND=ollama

echo.
echo === Stubilly (Ollama) starting on http://localhost:8422 ===
echo Keep this window open. Press Ctrl+C to stop.
echo.
call ".venv\Scripts\activate.bat"
cd backend
python -m uvicorn main:app --host %STUBILLY_HOST% --port %STUBILLY_PORT%
pause
