function formatDuration(totalSeconds) {
  const m = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const s = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function PomodoroBar({ pomodoro }) {
  const { phase, remaining, breaksLeft, breaksExhausted, takeBreakNow, endBreakNow } = pomodoro;

  const nearingEnd = phase === "work" && remaining <= 60;

  return (
    <div className={`pomodoro-bar pomodoro-bar-${phase}`}>
      <span className={`pomodoro-pill pomodoro-pill-${phase}`}>
        {phase === "work" ? "Focus" : "Break"}
      </span>
      <span className={`pomodoro-countdown${nearingEnd ? " pomodoro-countdown-warn" : ""}`}>
        {formatDuration(remaining)}
      </span>

      {phase === "work" && (
        <button
          className="btn-text pomodoro-action"
          onClick={takeBreakNow}
          disabled={breaksExhausted}
          title={breaksExhausted ? "No breaks left this session" : "Take a break now"}
        >
          {breaksExhausted ? "No breaks left" : "Take a break"}
        </button>
      )}
      {phase === "break" && (
        <button className="btn-text pomodoro-action" onClick={endBreakNow}>
          End break early
        </button>
      )}

      {breaksLeft !== null && (
        <span className="pomodoro-breaks-left">
          {breaksLeft} break{breaksLeft === 1 ? "" : "s"} left
        </span>
      )}
    </div>
  );
}
