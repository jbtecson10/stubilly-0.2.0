"""Deep URL/domain relevance intel: when the foreground window shows a
domain the local classifier is unsure about, fetch the domain's actual
page content and score it against the session task — so a YouTube lecture
on the assignment, or a Wikipedia page on the topic, is recognised as
task-relevant even when the window title alone says "video".

Design constraints (deliberate):
  - Only the DOMAIN root is fetched (window_probe extracts hostnames from
    titles, not full URLs). One GET per domain, 3s timeout, 200KB cap.
  - YOUTUBE EXCEPTION: youtube.com roots are JS apps whose HTML carries no
    topic text, so for YouTube hosts the fetch instead runs a YouTube
    RESULTS SEARCH for the session task and scores the actual video
    titles that come back — "are there on-topic videos for this task?"
    One GET, same timeout/cap, cached per task (30 min).
  - When a non-YouTube domain root fetches fine but scores 0, a best-effort
    search-index fallback (DuckDuckGo HTML, then Bing HTML) asks whether
    ANY page under that domain is about the task before calling it
    irrelevant. Both backends are flaky against bots by design — failure
    just keeps the honest root score.
  - Results are cached per domain (TTL 30 min, negative cache 5 min) so
    the 2.5s window monitor never hammers the network — one fetch per
    domain per half hour, ever.
  - Scoring reuses intervention.task_keywords (same /3 saturation as
    task_relevance). No JS rendering, no headless browser.
  - Failure is cached briefly (negative cache) so a dead domain is not
    retried every tick. Never raises; callers see None (unknown).
  - No API keys — the pages themselves are the source of truth. This runs
    on the student's own machine, same trust boundary as the window probe.
  - Known caveat (accepted): a YouTube results search for the task will
    usually surface titles containing the task keywords (query echo), so
    YouTube leans toward "guide" whenever any on-topic videos exist —
    that is the intended product behaviour (study-first, block the rest)."""
from __future__ import annotations

import json
import logging
import re
import threading
import time
from typing import Optional
from urllib.parse import quote_plus

import httpx

import intervention

logger = logging.getLogger("stubilly.url_intel")

TTL_POSITIVE_SEC = 1800.0   # 30 min: domains rarely change topic
TTL_NEGATIVE_SEC = 300.0    # 5 min: retry failed fetches
FETCH_TIMEOUT = 3.0
MAX_BYTES = 200_000
MAX_BYTES_YT = 1_500_000    # YouTube results pages are ~1.4MB; the first
                            # videoRenderer entries can sit past 200KB.
MAX_CACHE = 300
_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) StubillyFocus/1.0"
# Search endpoints (DuckDuckGo) reject non-browser UAs with 403.
_SEARCH_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.9",
}
_HOST_RE = re.compile(r"^[a-z0-9.-]+\.[a-z]{2,}$")

YOUTUBE_HOSTS = frozenset({
    "youtube.com", "www.youtube.com", "m.youtube.com",
    "youtu.be", "www.youtu.be",
    "youtube-nocookie.com", "www.youtube-nocookie.com",
})
# ytInitialData: each video hit is a "videoRenderer" object whose first
# title run is the video name. Non-greedy across the small header gap.
_YT_TITLE_RE = re.compile(
    r'"videoRenderer".{0,800}?"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"',
    re.S,
)
# Description text under each hit (detailedMetadataSnippets or the older
# snippetText) - the task keyword often lives HERE, not in the title.
_YT_SNIPPET_BLOCK_RE = re.compile(
    r'(?:detailedMetadataSnippets|snippetText)":\{"runs":\[(.*?)\]\}',
    re.S,
)
_YT_RUN_TEXT_RE = re.compile(r'\{"text":"((?:[^"\\]|\\.)*)"')

_lock = threading.Lock()
_cache: dict[str, dict] = {}          # domain -> {score, at, expires, snippet}
_yt_cache: dict[str, dict] = {}       # normalized task -> {score, at, expires, ok}
_inflight: set[str] = set()


def _extract_text(html: bytes) -> str:
    """Visible-ish text from a page: <title> + meta description + first
    body text. lxml if available, stdlib regex fallback otherwise."""
    try:
        from lxml import html as lhtml
        doc = lhtml.fromstring(html)
        parts = []
        title = doc.xpath("//title/text()")
        if title:
            parts.append(str(title[0]))
        for meta in doc.xpath('//meta[@name="description"]/@content'):
            parts.append(str(meta))
        # Drop script/style subtrees, then pull text.
        for bad in doc.xpath("//script|//style"):
            bad.drop_tree()
        body = " ".join(doc.xpath("//body//text()"))
        parts.append(body)
        return " ".join(parts)[:2000]
    except Exception:
        try:
            text = html.decode("utf-8", errors="ignore")
            text = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", text, flags=re.S | re.I)
            text = re.sub(r"<[^>]+>", " ", text)
            return re.sub(r"\s+", " ", text)[:2000]
        except Exception:
            return ""


def _score_against_task(content: str, task: Optional[str]) -> tuple[float, list]:
    keys = intervention.task_keywords(task)
    if not keys or not content:
        return 0.0, []
    low = content.lower()
    matched = sorted(k for k in keys if k in low)
    return min(1.0, len(matched) / 3.0), matched


def _extract_youtube_titles(html: bytes) -> list[str]:
    """Video titles out of a YouTube results page's embedded JSON.
    Best-effort regex on ytInitialData; returns up to 20 titles."""
    try:
        text = html.decode("utf-8", errors="ignore")
    except Exception:
        return []
    out: list[str] = []
    for m in _YT_TITLE_RE.finditer(text):
        raw = m.group(1)
        try:
            title = json.loads(f'"{raw}"')
        except Exception:
            title = raw.replace("\\u0026", "&").replace("\\n", " ")
        title = title.strip()
        if len(title) >= 4:
            out.append(title)
        if len(out) >= 20:
            break
    return out


def _extract_youtube_snippets(html: bytes) -> list[str]:
    """Description runs out of a YouTube results page - up to 40 pieces.
    Best-effort regex on ytInitialData; never raises."""
    try:
        text = html.decode("utf-8", errors="ignore")
    except Exception:
        return []
    out: list[str] = []
    for block in _YT_SNIPPET_BLOCK_RE.finditer(text):
        for m in _YT_RUN_TEXT_RE.finditer(block.group(1)):
            raw = m.group(1)
            try:
                piece = json.loads(f'"{raw}"')
            except Exception:
                piece = raw.replace("\\u0026", "&").replace("\\n", " ")
            piece = piece.strip()
            if len(piece) >= 4:
                out.append(piece)
            if len(out) >= 40:
                return out
    return out


def fetch_youtube_search(task: Optional[str]) -> Optional[float]:
    """Search YouTube for the session task and score the video titles that
    come back — the 'is there on-topic content for this task?' signal for
    CONDITIONAL_ALLOWLIST hosts. Cached per normalized task (30 min).
    Returns the score, or None on failure. Never raises."""
    key = re.sub(r"\s+", " ", (task or "").strip().lower())[:120]
    if not key:
        return None
    now = time.time()
    with _lock:
        hit = _yt_cache.get(key)
        if hit and hit.get("expires", 0) > now:
            return float(hit.get("score") or 0.0) if hit.get("ok") else None
    score: Optional[float] = None
    try:
        with httpx.Client(
            timeout=FETCH_TIMEOUT, follow_redirects=True, headers={"User-Agent": _UA}
        ) as client:
            resp = client.get(
                "https://www.youtube.com/results",
                params={"search_query": task},
            )
            titles = _extract_youtube_titles(resp.content[:MAX_BYTES_YT])
            snippets = _extract_youtube_snippets(resp.content[:MAX_BYTES_YT])
            blob = " . ".join(titles + snippets)
            if blob.strip():
                score, _m = _score_against_task(blob, task)
            else:
                # Page fetched but no parseable titles = found nothing, not
                # a network failure (0.0 is a real answer: no videos matched).
                score = 0.0
    except Exception as e:
        logger.debug(f"url_intel youtube search failed: {e}")
        score = None
    now = time.time()
    ttl = TTL_POSITIVE_SEC if score is not None else TTL_NEGATIVE_SEC
    with _lock:
        if len(_yt_cache) >= MAX_CACHE:
            oldest = sorted(_yt_cache.items(), key=lambda kv: kv[1].get("at", 0))
            for k, _ in oldest[: MAX_CACHE // 10]:
                _yt_cache.pop(k, None)
        _yt_cache[key] = {
            "score": float(score) if score is not None else 0.0,
            "at": now,
            "expires": now + ttl,
            "ok": score is not None,
        }
    return score


def _search_score(domain: str, task: str) -> Optional[float]:
    """Best-effort 'is ANY page under this domain about the task?' via
    HTML search-result pages. DuckDuckGo first, then Bing (DDG serves
    bot-challenge pages after a few queries; Bing tolerates more).
    Scored on result titles/snippets. Returns the first positive score,
    0.0 if both backends answered with nothing, None if both failed.
    Needs browser-like headers — both engines 403 non-browser UAs."""
    query = {"q": f"site:{domain} {task}"}
    for url in (
        "https://html.duckduckgo.com/html/",
        "https://www.bing.com/search",
    ):
        try:
            with httpx.Client(
                timeout=FETCH_TIMEOUT, follow_redirects=True, headers=_SEARCH_HEADERS
            ) as client:
                resp = client.get(url, params=query)
                if resp.status_code != 200:
                    continue
                text = _extract_text(resp.content[:MAX_BYTES])
                score, _m = _score_against_task(text, task)
                if score > 0:
                    return float(score)
        except Exception as e:
            logger.debug(f"url_intel search fallback failed at {url} for {domain}: {e}")
    return None


def _store_domain(domain: str, score: Optional[float]) -> None:
    now = time.time()
    ttl = TTL_POSITIVE_SEC if score is not None else TTL_NEGATIVE_SEC
    with _lock:
        if len(_cache) >= MAX_CACHE:
            # Evict oldest by timestamp.
            oldest = sorted(_cache.items(), key=lambda kv: kv[1].get("at", 0))
            for k, _ in oldest[: MAX_CACHE // 10]:
                _cache.pop(k, None)
        _cache[domain] = {
            "score": float(score) if score is not None else 0.0,
            "at": now,
            "expires": now + ttl,
            "ok": score is not None,
        }


def fetch_and_score(domain: str, task: Optional[str]) -> Optional[float]:
    """Synchronous fetch+score for one domain. Stores in the cache.
    YouTube hosts -> results-page video titles; other hosts -> domain
    root text, with a DuckDuckGo site: fallback when the root itself says
    nothing. Returns the score, or None on failure (also cached as 0.0
    briefly). Never raises."""
    domain = (domain or "").strip().lower().split(":")[0].strip(".")
    if not domain or not _HOST_RE.match(domain):
        return None
    if "stubilly" in domain:
        return None
    if domain in YOUTUBE_HOSTS:
        score = fetch_youtube_search(task) if task else None
        _store_domain(domain, score)
        return score
    score: Optional[float] = None
    try:
        with httpx.Client(
            timeout=FETCH_TIMEOUT, follow_redirects=True, headers={"User-Agent": _UA}
        ) as client:
            resp = client.get(f"https://{domain}")
            content = _extract_text(resp.content[:MAX_BYTES])
            score, _matched = _score_against_task(content, task)
    except Exception as e:
        logger.debug(f"url_intel fetch failed for {domain}: {e}")
        score = None
    # Root fetched fine but topic-free? Ask the search indexes whether any
    # page under this domain is about the task before calling it dead.
    if score == 0.0 and task:
        found = _search_score(domain, str(task))
        if found is not None and found > 0:
            score = found
    _store_domain(domain, score)
    return score


def ensure_fetched(domain: str, task: Optional[str]) -> None:
    """Fire-and-forget background fetch if this domain is not cached and
    not already in flight. Called from the window monitor on uncertain
    windows. Never raises."""
    domain = (domain or "").strip().lower().split(":")[0].strip(".")
    if not domain or not task or not _HOST_RE.match(domain):
        return
    if "stubilly" in domain:
        return
    now = time.time()
    with _lock:
        hit = _cache.get(domain)
        if hit and hit.get("expires", 0) > now:
            return
        if domain in _inflight:
            return
        _inflight.add(domain)
    threading.Thread(
        target=_run_fetch, args=(domain, task), daemon=True
    ).start()


def _run_fetch(domain: str, task: Optional[str]) -> None:
    try:
        fetch_and_score(domain, task)
    except Exception:
        logger.exception("url_intel worker failed")
    finally:
        with _lock:
            _inflight.discard(domain)


def latest_score(domain: str) -> Optional[float]:
    """Cached score for this domain, or None if never fetched / expired /
    fetch failed. The monitor floors task-relevance with this."""
    domain = (domain or "").strip().lower().split(":")[0].strip(".")
    if not domain:
        return None
    with _lock:
        hit = _cache.get(domain)
        if not hit or hit.get("expires", 0) <= time.time() or not hit.get("ok"):
            return None
        return float(hit.get("score") or 0.0)


def cache_summary() -> dict:
    """Diagnostics view: domains cached, in flight, how many scored >0."""
    with _lock:
        scored = sum(1 for h in _cache.values() if (h.get("score") or 0) > 0)
        yt_scored = sum(1 for h in _yt_cache.values() if h.get("ok") and (h.get("score") or 0) > 0)
        return {
            "cached": len(_cache),
            "inflight": len(_inflight),
            "relevant": scored,
            "yt_cached": len(_yt_cache),
            "yt_relevant": yt_scored,
        }
