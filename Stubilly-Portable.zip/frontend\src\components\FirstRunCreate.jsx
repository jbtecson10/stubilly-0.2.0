import { useState } from "react";
import { api } from "../api/client";

// First-account landing page. Shown when the server is reachable but has no
// accounts yet — every fresh install now lands here instead of being dumped
// straight into the home screen. Registration is intentionally open for the
// very first account (bootstrap); afterwards the normal sign-in takes over.
export default function FirstRunCreate({ onReady }) {
  const [serial, setSerial] = useState("");
  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!serial.trim() || !password) return;
    setBusy(true);
    setError(null);
    try {
      const device = navigator.userAgent.slice(0, 120);
      await api.registerUser({ serial_number: serial.trim(), full_name: fullName.trim(), password });
      const res = await api.login(serial.trim(), password, device);
      onReady(res.token, res.user);
    } catch (err) {
      setError(err.message || "Couldn't create your account.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="setup-screen">
      <div className="setup-card login-card">
        <h1 className="setup-title">Set up Stubilly</h1>
        <p className="setup-subtitle">
          This machine has no account yet — create the first one to unlock the sign-in page.
        </p>
        <form onSubmit={handleSubmit} className="login-form">
          <label className="setup-field">
            <span>Serial / ID number</span>
            <input
              className="setup-custom-input login-input"
              type="text"
              value={serial}
              onChange={(e) => setSerial(e.target.value)}
              placeholder="e.g. 2024-0021"
              autoFocus
            />
          </label>
          <label className="setup-field">
            <span>Full name</span>
            <input
              className="setup-custom-input login-input"
              type="text"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="Your name"
            />
          </label>
          <label className="setup-field">
            <span>Password</span>
            <input
              className="setup-custom-input login-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="At least 4 characters"
            />
          </label>
          {error && <p className="login-error">{error}</p>}
          <div className="setup-actions">
            <button type="submit" className="btn-primary" disabled={!serial.trim() || !password || busy}>
              {busy ? "Creating…" : "Create account & continue"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}