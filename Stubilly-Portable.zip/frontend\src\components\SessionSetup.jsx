import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, Lock, Moon, ShieldCheck, Sun } from "lucide-react";
import OllamaStatusBanner from "./OllamaStatusBanner";
import CompanionPicker from "./CompanionPicker";
import StudentNav from "./StudentNav";
import SessionHistoryPage from "./SessionHistory";
import AnalyticsPage from "./AnalyticsDashboard";
import FocusGuardsPage from "./FocusGuardsPage";
import CompanionsPage from "./CompanionsPage";
import HelpPage from "./HelpPage";
import StudentPage from "./StudentPage";
import SettingsModal from "./SettingsModal";
import useTheme from "../hooks/useTheme";

const BREAK_LIMIT_OPTIONS = [
  { label: "2 breaks", value: 2 },
  { label: "4 breaks", value: 4 },
  { label: "6 breaks", value: 6 },
  { label: "Unlimited", value: null },
];

const FOCUS_PRESETS = [20, 25, 30, 45, 60];
const BREAK_PRESETS = [5, 10, 15, 20, 25, 30];

// Built-in subject choices. Custom subjects the student adds in Settings are
// appended after these (see SUBJECT_OTHER_VALUE / the select below).
const SUBJECT_PRESETS = [
  "Mathematics",
  "Science",
  "Physics",
  "Chemistry",
  "Biology",
  "Computer Science",
  "Engineering",
  "English",
  "History",
  "Geography",
  "Economics",
  "Business",
  "Psychology",
  "Philosophy",
  "Law",
  "Medicine",
  "Art & Design",
  "Music",
  "Thesis / Research",
];
const SUBJECT_OTHER_VALUE = "__other__";

// Example tasks that type themselves into the empty task field as a friendly
// prompt. Rotates only while the box is empty (see useTypewriter below).
const TASK_TYPING_EXAMPLES = [
  "Finish the lit review section of my thesis",
  "Revise for tomorrow's calculus midterm",
  "Read chapters 4–5 and take notes",
  "Draft the intro paragraph of my essay",
];

// One-tap task starters shown as chips under the field.
const TASK_CHIPS = [
  "Study for an exam",
  "Finish an assignment",
  "Read & take notes",
  "Practice problems",
  "Write an essay",
];

// Types a rotating set of example strings into `target` (the placeholder),
// pausing whenever the field has real content or the user prefers reduced
// motion. Returns the current placeholder text to render.
function useTypewriter(examples, active) {
  const [text, setText] = useState("");
  const idxRef = useRef(0);
  const charRef = useRef(0);
  const deletingRef = useRef(false);

  useEffect(() => {
    const reduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;
    if (!active || reduced) {
      setText("");
      return undefined;
    }

    let timer;
    const tick = () => {
      const full = examples[idxRef.current % examples.length];
      if (!deletingRef.current) {
        charRef.current += 1;
        setText(full.slice(0, charRef.current));
        if (charRef.current >= full.length) {
          deletingRef.current = true;
          timer = setTimeout(tick, 1600); // hold the finished line
          return;
        }
        timer = setTimeout(tick, 42 + Math.random() * 40);
      } else {
        charRef.current -= 1;
        setText(full.slice(0, Math.max(0, charRef.current)));
        if (charRef.current <= 0) {
          deletingRef.current = false;
          idxRef.current += 1;
          timer = setTimeout(tick, 320);
          return;
        }
        timer = setTimeout(tick, 22);
      }
    };
    timer = setTimeout(tick, 500);
    return () => clearTimeout(timer);
  }, [examples, active]);

  return text;
}

function minutesLabel(mins) {
  if (mins >= 60 && mins % 60 === 0) return `${mins / 60} hr`;
  if (mins >= 60) {
    const h = Math.floor(mins / 60);
    const r = mins % 60;
    return r ? `${h} hr ${r} min` : `${h} hr`;
  }
  return `${mins} min`;
}

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export default function SessionSetup({ onStart, starting, ollamaOnline, managed, user, policy, onLogout, onStudyAgain, onContinue, onResumeInProgress, settings, onSettingsSaved }) {
  const { theme, toggleTheme } = useTheme();
  const [task, setTask] = useState("");
  // Declared academic task (INPUT layer of the framework): subject,
  // deadline and priority feed the AI's breakdown and the progress views.
  // `subjectChoice` is what the <select> holds — a preset label, a saved
  // custom label, SUBJECT_OTHER_VALUE for free-text, or "" for none.
  const [subjectChoice, setSubjectChoice] = useState("");
  const [subjectOther, setSubjectOther] = useState("");
  const [deadline, setDeadline] = useState("");
  const [priority, setPriority] = useState("");
  // Which main view the content column shows. "study" is the setup form;
  // the rest are full pages rendered beside it (the form stays mounted so
  // its state survives navigation).
  const [view, setView] = useState("study");
  const [workMinutes, setWorkMinutes] = useState(25);
  const [workCustom, setWorkCustom] = useState(false);
  const [customWork, setCustomWork] = useState("");
  const [breakMinutes, setBreakMinutes] = useState(5);
  const [breakCustom, setBreakCustom] = useState(false);
  const [customBreak, setCustomBreak] = useState("");
  const [maxBreaks, setMaxBreaks] = useState(4);
  const [strictBlocking, setStrictBlocking] = useState(null); // null = auto-decided
  const [blockThroughBreaks, setBlockThroughBreaks] = useState(false);
  const [autoBlock, setAutoBlock] = useState(true);
  const [liveKill, setLiveKill] = useState(false);
  const [companionId, setCompanionId] = useState("fokus");
  const [showDisclaimer, setShowDisclaimer] = useState(false);
  // Progressive disclosure: the four blocking toggles are opt-in detail, not
  // something a student needs to read before starting. Collapsed by default.
  const [showGuards, setShowGuards] = useState(false);

  // Merge built-in presets with any custom subjects the student saved in
  // Settings (synced from the server), de-duplicated case-insensitively.
  const subjectOptions = useMemo(() => {
    const seen = new Set();
    const out = [];
    for (const label of [...SUBJECT_PRESETS, ...(settings?.custom_subjects || [])]) {
      const clean = String(label || "").trim();
      const key = clean.toLowerCase();
      if (!clean || seen.has(key)) continue;
      seen.add(key);
      out.push(clean);
    }
    return out;
  }, [settings?.custom_subjects]);

  // Typewriter runs only while the task box is empty — the moment the student
  // types, it stops and the real placeholder takes over.
  const typedPlaceholder = useTypewriter(TASK_TYPING_EXAMPLES, task.trim() === "");
  const taskPlaceholder =
    task.trim() === ""
      ? typedPlaceholder || "What are we working on today?"
      : "";

  // Greeting name: first word of the display name, or a friendly fallback.
  const displayName = user?.full_name || user?.email || "";
  const firstName = displayName.split(/[\s@]/)[0] || "friend";

  // Resolve the effective subject string that rides along in taskMeta.
  const subject =
    subjectChoice === SUBJECT_OTHER_VALUE
      ? subjectOther.trim()
      : subjectChoice.trim();

  const finalWork = workCustom ? Math.max(1, parseInt(customWork, 10) || 0) : workMinutes;
  const finalBreak = breakCustom ? Math.max(1, parseInt(customBreak, 10) || 0) : breakMinutes;

  // Managed mode (admin hub): the admin owns the block/allow lists, so the
  // site-blocking features (and their toggles) are fixed on/off by policy
  // instead of being student choices. Focus/break lengths stay free.
  const strictBlockingEffective = managed ? true : Boolean(strictBlocking);

  function pickWork(value) {
    if (value === "custom") {
      setWorkCustom(true);
      if (!customWork.trim()) setCustomWork(String(workMinutes));
    } else {
      setWorkCustom(false);
      setWorkMinutes(Number(value));
    }
  }

  function pickBreak(value) {
    if (value === "custom") {
      setBreakCustom(true);
      if (!customBreak.trim()) setCustomBreak(String(breakMinutes));
    } else {
      setBreakCustom(false);
      setBreakMinutes(Number(value));
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (task.trim()) setShowDisclaimer(true);
  }

  function handleConfirmStart() {
    setShowDisclaimer(false);
    onStart(task.trim(), {
      workMinutes: finalWork,
      breakMinutes: finalBreak,
      maxBreaks,
      // Managed: blocking is ALWAYS on, and the student's auto-block /
      // live-shutdown extras are locked off (the admin list is the source
      // of truth — the student can't include a site the admin blocked).
      strictBlocking: strictBlockingEffective,
      blockThroughBreaks: strictBlockingEffective && !managed && blockThroughBreaks,
      autoBlock: strictBlockingEffective && !managed && autoBlock,
      liveKill: strictBlockingEffective && !managed && liveKill,
      // Declared academic task (INPUT) — rides along with the run config so
      // App.handleStart's existing signature stays unchanged.
      taskMeta: {
        subject: subject.trim() || null,
        deadline: deadline ? new Date(deadline).toISOString() : null,
        priority: priority || null,
        companionId,
      },
    });
  }

  // Guard toggles exposed on the Focus guards page, bound to the same state
  // the Study setup form uses so edits here carry into the next session.
  const guards = { strictBlocking, blockThroughBreaks, autoBlock, liveKill };
  const setGuard = (key, val) => {
    if (key === "strictBlocking") setStrictBlocking(val);
    else if (key === "blockThroughBreaks") setBlockThroughBreaks(val);
    else if (key === "autoBlock") setAutoBlock(val);
    else if (key === "liveKill") setLiveKill(val);
  };

  return (
    <div className={`setup-screen ${theme === "light" ? "theme-light" : ""}`}>
      <StudentNav
        view={view}
        onNavigate={setView}
        user={user}
        managed={managed}
        onLogout={onLogout}
      />
      <div className="setup-main">
        <div className={`setup-pane${view !== "study" ? " is-hidden" : ""}`}>
      <div className="setup-card">
        <header className="setup-masthead">
          <span className="setup-lamp" aria-hidden="true" />
          <span className="setup-wordmark">Stubilly</span>
          <button
            type="button"
            className="theme-toggle"
            onClick={toggleTheme}
            aria-label={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
            title={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
          >
            {theme === "light" ? <Moon size={16} /> : <Sun size={16} />}
          </button>
        </header>
        <div className="setup-banner">
          <span className="setup-banner-badge">Study session</span>
          <h1 className="setup-title">{greeting()}, {firstName}.</h1>
          <p className="setup-subtitle">
            Tell me the task, and I'll break it into a few small steps and keep you company while you work.
          </p>
        </div>
        <form onSubmit={handleSubmit}>
          <section className="setup-section" aria-labelledby="setup-sec-task">
            <h2 className="setup-section-title" id="setup-sec-task">Your task</h2>
            <textarea
              className="setup-textarea"
              data-tutorial="task"
              placeholder={taskPlaceholder}
              value={task}
              onChange={(e) => setTask(e.target.value)}
              rows={3}
              autoFocus
            />
            <div className="setup-chips" role="group" aria-label="Suggested tasks">
              {TASK_CHIPS.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  className="setup-chip"
                  onClick={() => setTask(chip)}
                >
                  {chip}
                </button>
              ))}
            </div>
            <div className="setup-taskmeta" aria-label="Task details">
              <label className="setup-field setup-taskmeta-subject">
                <span>Subject</span>
                <select
                  className="setup-custom-input"
                  value={subjectChoice}
                  onChange={(e) => setSubjectChoice(e.target.value)}
                >
                  <option value="">Not set</option>
                  {subjectOptions.map((label) => (
                    <option key={label} value={label}>{label}</option>
                  ))}
                  <option value={SUBJECT_OTHER_VALUE}>Other…</option>
                </select>
              </label>
              {subjectChoice === SUBJECT_OTHER_VALUE && (
                <label className="setup-field setup-taskmeta-subject-other">
                  <span>Subject name</span>
                  <input
                    type="text"
                    className="setup-custom-input"
                    placeholder="e.g. Thesis, Math 101"
                    value={subjectOther}
                    onChange={(e) => setSubjectOther(e.target.value)}
                    maxLength={80}
                  />
                </label>
              )}
              <label className="setup-field">
                <span>Due</span>
                <input
                  type="datetime-local"
                  className="setup-custom-input"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                />
              </label>
              <label className="setup-field">
                <span>Priority</span>
                <select value={priority} onChange={(e) => setPriority(e.target.value)}>
                  <option value="">Not set</option>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                </select>
              </label>
            </div>
          </section>

          <section className="setup-section" aria-labelledby="setup-sec-companion" data-tutorial="companion">
            <h2 className="setup-section-title" id="setup-sec-companion">Study buddy</h2>
            <CompanionPicker value={companionId} onChange={setCompanionId} />
          </section>

          <section className="setup-section" aria-labelledby="setup-sec-rhythm">
            <h2 className="setup-section-title" id="setup-sec-rhythm">Session rhythm</h2>
            <div className="setup-pomodoro">
              <label className="setup-field">
                <span>Focus block</span>
                <div className="setup-custom-row">
                  <select
                    value={workCustom ? "custom" : workMinutes}
                    onChange={(e) => pickWork(e.target.value)}
                  >
                    {FOCUS_PRESETS.map((m) => (
                      <option key={m} value={m}>{m} min</option>
                    ))}
                    <option value="custom">Custom…</option>
                  </select>
                  {workCustom && (
                    <input
                      className="setup-custom-input"
                      type="number"
                      min="1"
                      max="960"
                      placeholder="e.g. 90"
                      value={customWork}
                      onChange={(e) => setCustomWork(e.target.value)}
                      aria-label="Custom focus block length in minutes"
                    />
                  )}
                </div>
              </label>
              <label className="setup-field">
                <span>Break</span>
                <div className="setup-custom-row">
                  <select
                    value={breakCustom ? "custom" : breakMinutes}
                    onChange={(e) => pickBreak(e.target.value)}
                  >
                    {BREAK_PRESETS.map((m) => (
                      <option key={m} value={m}>{m} min</option>
                    ))}
                    <option value="custom">Custom…</option>
                  </select>
                  {breakCustom && (
                    <input
                      className="setup-custom-input"
                      type="number"
                      min="1"
                      max="240"
                      placeholder="e.g. 20"
                      value={customBreak}
                      onChange={(e) => setCustomBreak(e.target.value)}
                      aria-label="Custom break length in minutes"
                    />
                  )}
                </div>
              </label>
              <label className="setup-field">
                <span>Break limit</span>
                <select
                  value={maxBreaks === null ? "unlimited" : maxBreaks}
                  onChange={(e) =>
                    setMaxBreaks(e.target.value === "unlimited" ? null : Number(e.target.value))
                  }
                >
                  {BREAK_LIMIT_OPTIONS.map((opt) => (
                    <option key={opt.label} value={opt.value === null ? "unlimited" : opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            {(workCustom || breakCustom) && (
              <p className="setup-field-hint">
                {minutesLabel(finalWork)} focus · {minutesLabel(finalBreak)} break
              </p>
            )}
          </section>

          <section className="setup-section setup-section-guards">
            <button
              type="button"
              className={`setup-guards-toggle${showGuards ? " is-open" : ""}`}
              onClick={() => setShowGuards((v) => !v)}
              aria-expanded={showGuards}
              aria-controls="setup-guards-panel"
            >
              <span className="setup-guards-heading">
                <span className="setup-section-title setup-guards-title">Focus guards</span>
                <span className="setup-guards-summary">
                  {managed
                    ? "Managed by your administrator"
                    : strictBlockingEffective
                      ? "On — distracting sites blocked"
                      : "Off — browse freely"}
                </span>
              </span>
              <ChevronDown size={16} className="setup-guards-chevron" aria-hidden="true" />
            </button>
            <div
              id="setup-guards-panel"
              className={`setup-guards-panel${showGuards ? " is-open" : ""}`}
              hidden={!showGuards}
            >
              <div className="setup-features">
                {managed ? (
                  <div className="setup-managed-banner">
                    <span className="setup-managed-shield" aria-hidden="true">
                      <ShieldCheck size={22} />
                    </span>
                    <div className="setup-managed-copy">
                      <span className="setup-managed-banner-title">
                        Site blocking is managed by your administrator
                      </span>
                      <span className="setup-managed-banner-note">
                        The center's guardrails for this session are enforced automatically —
                        live, even while you work — and can't be changed here. Speak to an
                        administrator for any changes.
                      </span>
                    </div>
                    {(policy?.blocked_sites?.length > 0 || policy?.allowed_sites?.length > 0) && (
                      <div className="setup-managed-chips">
                        {policy.blocked_sites.length > 0 && (
                          <span className="setup-managed-chip setup-managed-chip-blocked">
                            <Lock size={11} /> {policy.blocked_sites.length} blocked
                          </span>
                        )}
                        {policy.allowed_sites.length > 0 && (
                          <span className="setup-managed-chip setup-managed-chip-allowed">
                            <ShieldCheck size={11} /> {policy.allowed_sites.length} allowed
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <label className={`setup-feature${strictBlocking ? " is-on" : ""}`}>
                      <input
                        type="checkbox"
                        // null = auto-decided (not yet loaded) — treat as off so
                        // React never sees a null→bool flip that warns/unmounts.
                        checked={Boolean(strictBlocking)}
                        onChange={(e) => setStrictBlocking(e.target.checked)}
                      />
                      <span className="setup-feature-title">Strict site blocking</span>
                      <span className="setup-feature-note">
                        System-wide redirect of your blocklist in every browser while you focus; lifts
                        automatically on breaks. Asks once for your OS admin permission.
                      </span>
                    </label>

                    {[
                      {
                        checked: blockThroughBreaks,
                        set: setBlockThroughBreaks,
                        title: "Block through breaks",
                        note: "Extends the blocklist into break time, so blocked sites stay unreachable for the whole session.",
                      },
                      {
                        checked: autoBlock,
                        set: setAutoBlock,
                        title: "Auto-block off-task sites",
                        note: "Detects off-task domains in real time, adds them to your blocklist instantly, and force-closes their windows. Resets at session end. Browser tabs only.",
                      },
                      {
                        checked: liveKill,
                        set: setLiveKill,
                        title: "Live shutdown (2-minute rule)",
                        note: "Force-closes any off-task app after 2 continuous minutes. Unsaved work in that app can be lost; terminals are never closed.",
                      },
                    ].map((opt) => (
                      <label
                        key={opt.title}
                        className={`setup-feature${strictBlocking ? "" : " is-disabled"}`}
                      >
                        <input
                          type="checkbox"
                          checked={opt.checked}
                          disabled={!strictBlocking}
                          onChange={(e) => opt.set(e.target.checked)}
                        />
                        <span className="setup-feature-title">{opt.title}</span>
                        <span className="setup-feature-note">{opt.note}</span>
                      </label>
                    ))}
                  </>
                )}
              </div>
            </div>
          </section>

          <div className="setup-actions" data-tutorial="start">
            <button type="submit" className="btn-primary" disabled={!task.trim() || starting}>
              {starting ? "Getting set up…" : "Start session"}
            </button>
          </div>
        </form>
        <OllamaStatusBanner />
        {!ollamaOnline && (
          <p className="setup-notice">
            Ollama isn't running locally — I'll still track focus, but task breakdowns and nudges
            will be generic until it's up.
          </p>
        )}
        </div>
        </div>
        {view === "history" && (
          <StudentPage
            title="History"
            subtitle="Every session you've run, with its task, times and outcome."
            onBack={() => setView("study")}
            wide
          >
            <div className="spage-embed">
              <SessionHistoryPage
                onClose={() => setView("study")}
                onStudyAgain={onStudyAgain}
                onContinue={onContinue}
                onResumeInProgress={onResumeInProgress}
              />
            </div>
          </StudentPage>
        )}
        {view === "progress" && (
          <StudentPage
            title="Progress"
            subtitle="Your focus analytics — streaks, totals and trends over time."
            onBack={() => setView("study")}
            wide
          >
            <div className="spage-embed">
              <AnalyticsPage onClose={() => setView("study")} />
            </div>
          </StudentPage>
        )}
        {view === "guards" && (
          <FocusGuardsPage onBack={() => setView("study")} guards={guards} setGuard={setGuard} />
        )}
        {view === "companions" && (
          <CompanionsPage onBack={() => setView("study")} value={companionId} onChange={setCompanionId} />
        )}
        {view === "help" && <HelpPage onBack={() => setView("study")} />}
        {view === "settings" && (
          <StudentPage
            title="Settings"
            subtitle="Check-in cadence, nudge tone, subjects, voice and webcam."
            onBack={() => setView("study")}
          >
            <div className="spage-embed spage-embed--settings">
              <SettingsModal
                settings={settings}
                onClose={() => setView("study")}
                onSaved={(u) => {
                  onSettingsSaved?.(u);
                  setView("study");
                }}
              />
            </div>
          </StudentPage>
        )}
      </div>
      {showDisclaimer && (
        <div className="disclaimer-overlay">
          <div className="disclaimer-card">
            <h2 className="disclaimer-title">Before You Begin</h2>
            <p className="disclaimer-text">
              By starting this session, you acknowledge and consent to the following:
            </p>
            <ul className="disclaimer-list">
              <li>
                <strong>Webcam Access:</strong> Stubilly will activate your webcam to monitor focus and attention during the session. Video is processed locally and is never recorded or transmitted.
              </li>
              <li>
                <strong>App & Window Monitoring:</strong> The system will track your active window and applications to detect when you move off-task. This includes reading the names of open programs and browser tabs.
              </li>
              <li>
                <strong>Site Blocking (if enabled):</strong> Blocked websites are redirected through your system's hosts file, which blocks them in every browser and app on this computer. This requires administrator privileges, stays in effect until an administrator removes them, and is temporarily lifted during break time.
              </li>
              <li>
                <strong>Live Shutdown (if enabled):</strong> Off-task applications may be force-closed after prolonged distraction. Unsaved work in those applications may be lost.
              </li>
              <li>
                <strong>AI Companion:</strong> Your task description, chat messages, and session notes are processed by a local AI model to provide study support. No data leaves your machine.
              </li>
            </ul>
            <p className="disclaimer-text disclaimer-notice">
              All monitoring data is stored locally on your device and is never uploaded to any external server. You may end the session at any time.
            </p>
            <div className="disclaimer-actions">
              <button className="btn-primary" onClick={handleConfirmStart}>
                I understand, start session
              </button>
              <button className="btn-text" onClick={() => setShowDisclaimer(false)}>
                Go back
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}