import { useState } from "react";
import { X, Plus } from "lucide-react";
import { api } from "../api/client";

const INTERVAL_OPTIONS = [
  { label: "Off", value: 0 },
  { label: "Every minute", value: 60 },
  { label: "Every 5 minutes", value: 300 },
  { label: "Every 10 minutes", value: 600 },
  { label: "Every 15 minutes", value: 900 },
  { label: "Every 30 minutes", value: 1800 },
];

// Matches the server-side cap (admin.CUSTOM_SUBJECT_MAX_COUNT / _MAX_LEN).
const SUBJECT_MAX = 12;
const SUBJECT_LEN = 80;

/**
 * Student preferences — the INPUT-settings layer of the framework:
 * adaptive check-in cadence, intervention tone, spoken delivery, webcam.
 * Saves to PUT /me/settings and reports the result back to App so the live
 * session (and its check-in scheduler) picks the change up immediately.
 */
export default function SettingsModal({ settings, onClose, onSaved }) {
  const [interval, setInterval] = useState(settings?.check_in_interval_sec ?? 300);
  const [tone, setTone] = useState(settings?.tone ?? "gentle");
  const [voice, setVoice] = useState(Boolean(settings?.voice_mode));
  const [webcam, setWebcam] = useState(settings?.webcam_enabled !== false);
  const [adaptiveCheckIn, setAdaptiveCheckIn] = useState(Boolean(settings?.adaptive_check_in));
  const [subjects, setSubjects] = useState(
    () => (settings?.custom_subjects || []).map((s) => String(s))
  );
  const [newSubject, setNewSubject] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  function addSubject() {
    const label = newSubject.trim();
    if (!label) return;
    setSubjects((prev) => {
      if (prev.length >= SUBJECT_MAX) return prev;
      if (prev.some((s) => s.toLowerCase() === label.toLowerCase())) return prev;
      return [...prev, label.slice(0, SUBJECT_LEN)];
    });
    setNewSubject("");
  }

  function removeSubject(label) {
    setSubjects((prev) => prev.filter((s) => s !== label));
  }

  async function save() {
    setSaving(true);
    setError(null);
    try {
      const updated = await api.updateSettings({
        check_in_interval_sec: Number(interval),
        tone,
        voice_mode: voice,
        webcam_enabled: webcam,
        adaptive_check_in: adaptiveCheckIn,
        custom_subjects: subjects,
      });
      onSaved?.(updated);
      onClose();
    } catch (e) {
      setError(`Couldn't save settings (${e.message})`);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="disclaimer-overlay" role="dialog" aria-modal="true" aria-label="Settings">
      <div className="disclaimer-card settings-card">
        <h2 className="disclaimer-title">Settings</h2>

        <label className="settings-field">
          <span className="settings-label">Progress check-ins</span>
          <select
            value={interval}
            onChange={(e) => setInterval(Number(e.target.value))}
          >
            {INTERVAL_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
          <span className="settings-hint">
            A periodic "how's it going?" while you focus — your cadence, your call.
          </span>
        </label>

        <div className="settings-field">
          <span className="settings-label">Your subjects</span>
          <span className="settings-hint">
            Add the subjects you study so they show up in the session setup dropdown.
          </span>
          {subjects.length > 0 && (
            <ul className="settings-subjects">
              {subjects.map((s) => (
                <li key={s} className="settings-subject-chip">
                  <span>{s}</span>
                  <button
                    type="button"
                    className="settings-subject-x"
                    aria-label={`Remove ${s}`}
                    onClick={() => removeSubject(s)}
                  >
                    <X size={12} />
                  </button>
                </li>
              ))}
            </ul>
          )}
          <div className="settings-subject-add">
            <input
              type="text"
              placeholder="e.g. Organic Chemistry"
              value={newSubject}
              maxLength={SUBJECT_LEN}
              onChange={(e) => setNewSubject(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  addSubject();
                }
              }}
            />
            <button
              type="button"
              className="btn-secondary settings-subject-add-btn"
              onClick={addSubject}
              disabled={!newSubject.trim() || subjects.length >= SUBJECT_MAX}
            >
              <Plus size={14} /> Add
            </button>
          </div>
          {subjects.length >= SUBJECT_MAX && (
            <span className="settings-hint">Reached the {SUBJECT_MAX}-subject limit.</span>
          )}
        </div>

        <fieldset className="settings-field">
          <legend className="settings-label">Nudge tone</legend>
          <label className="settings-option">
            <input
              type="radio"
              name="tone"
              checked={tone === "gentle"}
              onChange={() => setTone("gentle")}
            />
            Gentle — supportive wording
          </label>
          <label className="settings-option">
            <input
              type="radio"
              name="tone"
              checked={tone === "firm"}
              onChange={() => setTone("firm")}
            />
            Firm — straight to the point
          </label>
        </fieldset>

        <label className="settings-option settings-toggle">
          <input
            type="checkbox"
            checked={voice}
            onChange={(e) => setVoice(e.target.checked)}
          />
          Speak interventions aloud
          <span className="settings-hint">Use your browser's built-in voice — nothing is recorded.</span>
        </label>

        <label className="settings-option settings-toggle">
          <input
            type="checkbox"
            checked={adaptiveCheckIn}
            onChange={(e) => setAdaptiveCheckIn(e.target.checked)}
          />
          Adaptive check-in wording
          <span className="settings-hint">
            Lets the AI write each progress check-in to match your task and how you're
            doing — the same adaptive cadence, with a personal touch.
          </span>
        </label>

        <label className="settings-option settings-toggle">
          <input
            type="checkbox"
            checked={webcam}
            onChange={(e) => setWebcam(e.target.checked)}
          />
          Use webcam for focus detection
          <span className="settings-hint">Turn off to run a session without camera monitoring.</span>
        </label>

        {error && <p className="settings-error">{error}</p>}

        <div className="disclaimer-actions">
          <button className="btn-primary" onClick={save} disabled={saving}>
            {saving ? "Saving…" : "Save settings"}
          </button>
          <button className="btn-text" onClick={onClose}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
