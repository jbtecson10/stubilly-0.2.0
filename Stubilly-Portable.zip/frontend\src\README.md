# frontend/src/ — React renderer (the UI + on-device detection)

Everything the student sees and every hook that powers a feature.

| Path | Purpose |
|---|---|
| `main.jsx` | React bootstrap (just renders `<App />`). |
| `App.jsx` | **The whole app in one component** — session phases, blocking toggles, auto-block, live-kill, chat, login/admin gate, all orchestration. |
| `api/client.js` | REST + WebSocket helpers with smart server resolution and localhost fallback. |
| `hooks/` | Feature logic (see its README). |
| `components/` | UI panels (see its README). |
| `App.css` / `index.css` | Styling (dark theme lives in `App.css`). |
| `public/` | Static assets (icons, bundled MediaPipe models). |

**App flow (phases):** `setup` → `active` → `summary`, with an optional
`login` screen when the admin hub manages the machine (`App.jsx:32-33`, gate
at `App.jsx:55-100`).

Start reading: **`App.jsx`**.