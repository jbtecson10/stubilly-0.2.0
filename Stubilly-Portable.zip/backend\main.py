"""
Stubilly backend  EFastAPI app.

Run locally:
    pip install -r requirements.txt
    uvicorn main:app --reload --port 8420

Endpoints:
    POST /sessions/start            -> create a session + Ollama task breakdown
    POST /sessions/{id}/end         -> close a session, compute summary stats
    GET  /sessions                  -> list past sessions (for a history view)
    GET  /sessions/{id}             -> one session + its tasks
    GET  /sessions/{id}/events      -> raw focus_event dataset for that session
    GET  /sessions/{id}/stats       -> aggregated stats for that session
    GET  /health                    -> {"ollama": true/false}
    WS   /ws/{session_id}           -> live focus_event stream in, live state/intervention out
    GET  /analytics/overview        -> aggregated productivity stats for the dashboard

    GET  /sessions/{id}/chat        -> companion chat history
    GET  /sessions/{id}/notes       -> auto-captured study notes
    WS   /ws/{session_id}/chat      -> body-doubling companion chat (streamed replies)
"""
import asyncio
import base64
import json
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone, timedelta, date
from collections import defaultdict, deque
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

load_dotenv()  # picks up GEMINI_API_KEY / GROK_API_KEY from backend/.env if present

import httpx
from fastapi import FastAPI, Depends, WebSocket, WebSocketDisconnect, HTTPException, Header, UploadFile, File, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
from sqlalchemy.orm import selectinload
from sqlalchemy.exc import IntegrityError

import models
import schemas
import llm_backend as ollama_client
import companion_llm
import companions
import google_link
import intervention
import learning
import state_machine
import migrate
import site_blocking
import window_probe
import screen_probe
import url_intel
import ml_model
import auth as auth_service
import admin as admin_router
from database import engine, get_db, Base

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("stubilly")

Base.metadata.create_all(bind=engine)
migrate.run_migrations()  # adds columns missing from older-created DBs

app = FastAPI(title="Stubilly API")


@app.on_event("startup")
async def _startup_prewarm_ai():
    # Load the companion model into memory the moment the server starts (not
    # awaited, never raises), so the first chat/checklist call of the day
    # answers fast instead of paying the cold-load penalty.
    asyncio.create_task(ollama_client.warm_model())
    # Remember the event loop so admin policy saves can push policy_refresh
    # to open focus sockets, then apply hosts-file blocking for any session
    # still open (cleared when none is  Esee effective_hosts).
    site_blocking.set_main_loop(asyncio.get_running_loop())
    try:
        result = await asyncio.to_thread(site_blocking.refresh_enforcement)
        if not result.get("ok"):
            logger.warning("site blocking at startup: %s", result.get("error"))
    except Exception:
        logger.exception("site blocking startup refresh failed")
    # Loopback HTTP/HTTPS listeners for hosts-blocked traffic (attempt
    # recording + HTTP 302 back to /blocked). After refresh so the active
    # domain set is already populated; never fatal.
    try:
        site_blocking.start_interceptors()
    except Exception:
        logger.exception("site interceptors startup failed")
    # Realtime presence for the Admin Hub: sweep who is online / what they're
    # doing and push diffs over /ws/admin so the hub never needs a manual
    # refresh. The hub's 4s poll remains only as a fallback.
    asyncio.create_task(_presence_sweeper())
    # Durable activity trail for the same diffs (who signed in / out, who went
    # into or out of a session). Kept in its own task so writing those rows can
    # never delay a live presence popup.
    asyncio.create_task(_presence_activity_flusher())
    # Foreground-window sampler: while a session is open, record the window
    # in front (title + seconds) for the guardian's activity view and push
    # window_status diffs to the linked parent's dashboard socket.
    asyncio.create_task(_window_monitor_task())
    # Background game scan: Steam/standalone games get a fair warning,
    # then a WM_CLOSE while the session is live (breaks lift it; End
    # Session stops it with everything else).
    asyncio.create_task(_game_scan_task())


@app.on_event("shutdown")
async def _shutdown_clear_hosts():
    # Removing/stopping the web base must free every blocked site  Enever
    # leave the machine with a stale hosts block after the app is gone.
    try:
        result = await asyncio.to_thread(site_blocking.clear_enforcement)
        if not result.get("ok"):
            logger.warning("site blocking clear on shutdown: %s", result.get("error"))
        else:
            logger.info("site blocking hosts section cleared on shutdown")
    except Exception:
        logger.exception("site blocking shutdown clear failed")

# Electron/React dev server origins + the public funnel origin. The old
# wildcard "*" combined with allow_credentials=True let ANY website drive
# this API from a victim's browser (classic CORS misconfiguration)  Eevery
# other host must now go same-origin (the page is served by this backend)
# or match the explicit list/regex below.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "app://."],
    allow_origin_regex=r"^(https://stubilly\.tail9266d1\.ts\.net|app://\.|http://(localhost|127\.0\.0\.1)(:\d+)?)$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(admin_router.router)


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health():
    # Bounded: a wedged/slow Ollama must never be able to hold the event
    # loop (one such freeze once took the whole server down  Eevery request
    # timed out with "Failed to fetch" while this probe waited).
    try:
        ollama_ok = await asyncio.wait_for(ollama_client.check_ollama_health(), 4.5)
    except Exception:
        ollama_ok = False
    # Naive-UTC server clock (same convention as every stored timestamp):
    # dashboards diff it against their own clock to render "2m ago" with
    # ZERO skew even when the guardian's PC clock is wrong.
    return {"status": "ok", "ollama": ollama_ok,
            "llm_backend": ollama_client.BACKEND_NAME,
            "server_time": datetime.utcnow().isoformat()}


@app.get("/meta/time")
async def meta_time():
    # Tiny clock-sync endpoint (no Ollama probe): dashboards diff this
    # against their own clock so every "2m ago" renders with zero skew,
    # even when the guardian's device clock is wrong or the page has been
    # open offline for hours.
    return {"server_time": datetime.utcnow().isoformat()}


@app.get("/meta/version")
async def meta_version():
    # Version + capability advertisement. Designed to be purely additive, so
    # OLD clients ignore it and NEW clients can use it to detect server-side
    # feature additions without a full client update  Ethe connection between
    # server and devices never breaks across upgrades.
    return {
        "name": "stubilly",
        "version": "0.1.0",
        "api": 1,
        "features": [
            "managed-users",
            "admin-hub",
            "companion-chat",
            "focus-sessions",
            "policies",
            "realtime-ws",
            "self-registration",
            "password-recovery",
            "social-login",
            "blocked-site-alerts",
            "session-quiz",
            "academic-progress",
        ],
    }


# ---------------------------------------------------------------------------
# Sessions
# ---------------------------------------------------------------------------

# How long POST /sessions/start will wait for the AI task breakdown before the
# student starts on a stand-in step. A warm single-user breakdown takes ~1.5s,
# so this is generous for one student (they always get their real plan
# immediately) and short enough that a full class pressing Start together is not
# queued behind the slowest request. Whatever has not arrived yet is written in
# the background, in place, without the student doing anything.
_MICROTASK_WAIT_SEC = float(os.environ.get("STUBILLY_MICROTASK_WAIT_SEC", "6"))


async def _generate_microtasks_guarded(task_description: str):
    """Break a task down, or return None so the caller can degrade.

    Never raises: this runs in the background for the "plan still being
    written" path, where an exception must simply leave the stand-in step in
    place rather than tear the session down.
    """
    try:
        return await ollama_client.generate_microtasks(task_description)
    except Exception as e:  # pragma: no cover - defensive
        logger.warning(f"Microtask generation failed; using generic step: {e}")
        return None


def _schedule_plan_upgrade(ai_task, session_id: int):
    """Write the real breakdown into a session that started on a stand-in step.

    The placeholder row is EDITED into the first real step instead of being
    deleted and re-created, so any id the runtime, the UI or the student
    already saw keeps pointing at the same row.
    """

    async def _upgrade():
        try:
            microtasks = await ai_task
            if not microtasks:
                return
            db = next(get_db())
            try:
                session = db.get(models.StudySession, session_id)
                if session is None or session.ended_at is not None:
                    return
                rows = (db.query(models.MicroTask)
                        .filter(models.MicroTask.session_id == session_id)
                        .order_by(models.MicroTask.order_index).all())
                # Only while the stand-in step is still the whole plan - never
                # trample on tasks the student has since edited or completed.
                if len(rows) != 1 or not rows[0].is_placeholder or rows[0].completed:
                    return
                first, *rest = microtasks
                rows[0].description = first["description"]
                rows[0].estimated_minutes = first.get("estimated_minutes")
                rows[0].order_index = 0
                rows[0].is_placeholder = 0
                for i, t in enumerate(rest, start=1):
                    db.add(models.MicroTask(
                        session_id=session_id,
                        description=t["description"],
                        estimated_minutes=t.get("estimated_minutes"),
                        order_index=i,
                    ))
                db.commit()
            finally:
                db.close()
        except Exception:  # pragma: no cover - defensive
            logger.exception("background task-plan upgrade failed")

    asyncio.create_task(_upgrade())


@app.post("/sessions/start", response_model=schemas.SessionOut)
async def start_session(
    req: schemas.SessionStartRequest,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    # Attribute the session to the logged-in account when there is one
    # (managed mode). Legacy single-user runs carry NULL and behave exactly
    # as before.
    user_id = auth_service.get_user_from_token(admin_router.bearer_token(authorization))

    # --- Age/consent gate (conceptual framework, process step 2) ---
    # A minor whose guardian has not granted monitoring consent cannot start a
    # webcam/attention session. Logged-in adults are always allowed; the
    # legacy no-login mode is untouched.
    if user_id is not None:
        account = db.query(models.User).filter(models.User.id == user_id).first()
        if account is not None:
            # Role boundary: guardian accounts read focus reports, they never
            # run a monitored session of their own.
            if (account.role or "student") == "parent":
                raise HTTPException(
                    403, "Parent/guardian accounts don't run focus sessions"
                )
            if not admin_router.consent_allows_monitoring(account):
                raise HTTPException(
                    403,
                    "Monitoring consent has not been granted for this account. "
                    "Ask your parent/guardian to approve it first.",
                )

    # Parental controls gate (Family-Link style): a guardian's pause, an
    # active downtime window or an already-spent daily screen budget
    # refuse a NEW session with the reason, before anything is created.
    if user_id is not None:
        block_reason = await asyncio.to_thread(_parental_block_reason, db, user_id)
        if block_reason:
            raise HTTPException(403, block_reason)

    # Close THIS student's open session(s) left behind by an abrupt app close
    # (or by starting a new one while another of theirs is still running)  E    # never another account's running session. Legacy (no accounts) keeps the
    # old sweep of NULL-owner rows.
    open_q = db.query(models.StudySession).filter(models.StudySession.ended_at.is_(None))
    if user_id is not None:
        open_q = open_q.filter(models.StudySession.user_id == user_id)
    else:
        open_q = open_q.filter(models.StudySession.user_id.is_(None))
    for open_session in open_q.all():
        # Hosts refresh is off-loop so a slow hosts write can't stall the API.
        await asyncio.to_thread(_finalize_session, db, open_session, False)

    priority = (req.priority or "").strip().lower() or None
    if priority is not None and priority not in ("low", "medium", "high"):
        priority = None  # tolerate junk from older clients instead of 500ing
    session = models.StudySession(
        task_description=req.task_description,
        user_id=user_id,
        # Declared academic task (INPUT)  Esubject / deadline / priority.
        subject=(req.subject or "").strip() or None,
        deadline=_naive_utc(req.deadline),
        priority=priority,
        # Chosen companion  Evalidated against the registry; unknown ids
        # fall back to the default companion rather than 500ing.
        companion_id=companions.get_companion(req.companion_id).id,
    )
    db.add(session)
    db.commit()
    db.refresh(session)

    # Resume-with-saved-steps: reuse the task breakdown (with its completion
    # flags) from an earlier session so the user continues their saved process
    # rather than getting a fresh one. Falls back gracefully (to Ollama) if
    # the referenced session doesn't exist.
    source_tasks = []
    if req.microtasks_from_session_id is not None:
        # Ownership check: a student must not copy another account's task
        # breakdown (same rule as every other session read).
        try:
            _get_owned_session(db, authorization, req.microtasks_from_session_id)
        except HTTPException:
            raise HTTPException(404, "Source session not found")
        source_tasks = (
            db.query(models.MicroTask)
            .filter(models.MicroTask.session_id == req.microtasks_from_session_id)
            .order_by(models.MicroTask.order_index)
            .all()
        )

    if source_tasks:
        ai_task = None
        placeholder = False
        for t in source_tasks:
            db.add(models.MicroTask(
                session_id=session.id,
                description=t.description,
                estimated_minutes=t.estimated_minutes,
                completed=t.completed,
                order_index=t.order_index,
            ))
    else:
        # Ask Ollama to break the task down; falls back gracefully if Ollama is down.
        #
        # A whole class can press Start in the same second, and a small local
        # model answers one request at a time, so simply awaiting the breakdown
        # left the LAST student staring at a spinner for 20+ seconds. The
        # generation now gets a bounded head start instead of an open-ended wait:
        # whoever wins gets their real plan at once, and everyone else starts
        # immediately on a usable stand-in step which the SAME background task
        # rewrites in place a moment later (never generated twice).
        ai_task = asyncio.ensure_future(_generate_microtasks_guarded(req.task_description))
        try:
            microtasks = await asyncio.wait_for(asyncio.shield(ai_task),
                                                 timeout=_MICROTASK_WAIT_SEC)
            placeholder = False
        except asyncio.TimeoutError:
            microtasks = [{"description": req.task_description, "estimated_minutes": 25}]
            placeholder = True
        except Exception as e:
            logger.warning(f"Microtask generation failed; using generic step: {e}")
            microtasks = [{"description": req.task_description, "estimated_minutes": 25}]
            placeholder = False
        for i, t in enumerate(microtasks):
            db.add(models.MicroTask(
                session_id=session.id,
                description=t["description"],
                estimated_minutes=t.get("estimated_minutes"),
                order_index=i,
                is_placeholder=1 if placeholder else 0,
            ))
    db.commit()
    db.refresh(session)
    if ai_task is not None and placeholder:
        # The plan is still being written; the student's screen already has a
        # task to work on and will pick up the real breakdown when it lands.
        _schedule_plan_upgrade(ai_task, session.id)

    # Warm the chat model in the background so the first chat reply doesn't
    # pay the cold-load penalty  Edeliberately not awaited. The microtask
    # call right above already loaded it; this covers the case where setup
    # took long enough for Ollama to have unloaded it again.
    asyncio.create_task(ollama_client.warm_model())

    state_machine.get_or_create_runtime(session.id)
    # Re-assert hosts from the stored admin policy  Epressing Start makes
    # this session live immediately (the focus socket attaches a beat later
    # and the detach grace covers that gap). With none open, any leftover
    # block is cleared so login alone never re-arms sites after End session.
    # If no socket ever attaches (abandoned/API start), the scheduled detach
    # refresh lifts the block once the grace elapses  Ea stale row must
    # never keep the machine blocked.
    try:
        enforcement = await asyncio.to_thread(site_blocking.refresh_enforcement)
        if not enforcement.get("ok"):
            logger.warning("site blocking at session start: %s", enforcement.get("error"))
    except Exception:
        logger.exception("site blocking refresh at session start failed")
    _schedule_detach_refresh(session.id)
    return session


def _schedule_detach_refresh(session_id: int) -> None:
    """Re-derive hosts enforcement once the detach grace elapses: if nobody
    attached to this session in the meantime the block lifts (stale rows
    stop blocking the machine); if a socket came back the refresh finds the
    session live again and keeps the block. Scheduled when a session starts
    (socket not attached yet) and when its last focus socket drops."""
    grace = site_blocking.detach_grace_sec()

    async def _later() -> None:
        await asyncio.sleep(grace)
        rt = state_machine.active_sessions.get(session_id)
        if rt is not None and rt.open_connections > 0:
            return  # reconnected  Estill live, nothing to lift
        try:
            await asyncio.to_thread(site_blocking.refresh_enforcement)
        except Exception:
            logger.exception("site blocking refresh after detach grace failed")

    try:
        asyncio.get_running_loop().create_task(_later())
    except RuntimeError:
        pass  # no running loop  Estartup/login refreshes cover this path


def _naive_utc(dt):
    """SQLite stores DateTime columns without tz info, so rows read back as
    naive UTC. Normalize any boundary datetime to the same shape before
    arithmetic  Ecomparing aware and naive datetimes raises in Python 3."""
    if dt is None:
        return None
    if dt.tzinfo is not None:
        return dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


_STATES = ("focused", "distracted", "sleeping", "absent")


def _iter_state_segments(events, end_time, max_gap_sec=120.0):
    """
    Yield (segment_start, segment_end, state) for every stretch of a session's
    focus readings, applying the gap-cap rule the dashboard has always used: a
    gap between two readings much longer than the ~1-2 s webcam cadence means
    the loop itself was paused (lid closed, machine asleep, app idle), so only
    the first `max_gap_sec` seconds count as the observed state and everything
    after that gap counts as "absent". This is the shared generator behind both
    the per-state totals (`_compute_state_durations`) and the per-calendar-day
    split (`_state_seconds_by_day`), so the two can never disagree.

    The final segment runs from the last reading up to `end_time` (the session's
    ended_at, or "now" for a session still in progress).
    """
    end_time = _naive_utc(end_time)
    if not events:
        return
    for prev, cur in zip(events, events[1:]):
        delta = (cur.timestamp - prev.timestamp).total_seconds()
        if delta <= 0:
            continue
        if prev.state in _STATES:
            counted = min(delta, max_gap_sec)
            seg_end = prev.timestamp + timedelta(seconds=counted)
            yield (prev.timestamp, seg_end, prev.state)
            leftover = delta - counted
            if leftover > 0:
                yield (seg_end, cur.timestamp, "absent")
    last = events[-1]
    tail = (end_time - last.timestamp).total_seconds()
    if tail > 0 and last.state in _STATES:
        counted = min(tail, max_gap_sec)
        seg_end = last.timestamp + timedelta(seconds=counted)
        yield (last.timestamp, seg_end, last.state)
        leftover = tail - counted
        if leftover > 0:
            yield (seg_end, end_time, "absent")


def _compute_state_durations(events, end_time, max_gap_sec=120.0):
    """
    Exact per-state seconds from consecutive FocusEvent timestamps, including
    the final segment from the last event up to `end_time` (session ended_at,
    or "now" for a running session). This is the single source of truth used
    by end-session persistence, the per-session stats endpoint, and the
    analytics dashboard  Eso none of them can ever disagree.
    """
    time_in = {"focused": 0.0, "distracted": 0.0, "sleeping": 0.0, "absent": 0.0}
    for _start, _end, state in _iter_state_segments(events, end_time, max_gap_sec):
        time_in[state] += (_end - _start).total_seconds()
    return time_in


def _next_local_midnight(day: date):
    """Instant (as naive UTC) of the first local-midnight boundary after `day`
     Ei.e. the midnight that ends it. Segment timestamps are naive UTC, so the
    boundary is converted into the same space for comparison."""
    nxt_local = datetime.combine(day + timedelta(days=1), datetime.min.time(), tzinfo=_LOCAL_TZ)
    return nxt_local.astimezone(timezone.utc).replace(tzinfo=None)


def _state_seconds_by_day(events, end_time, max_gap_sec=120.0):
    """Per-calendar-day (local) per-state seconds for ONE session. Each state
    segment is walked across local-midnight boundaries so time is billed to the
    day it was actually spent  Enever wholly to the day the session started. A
    session running 11 PM E AM puts its first hour on yesterday and its last    hour on today."""
    by_day: dict[date, dict] = defaultdict(
        lambda: {"focused": 0.0, "distracted": 0.0, "sleeping": 0.0, "absent": 0.0}
    )
    for start, end, state in _iter_state_segments(events, end_time, max_gap_sec):
        cursor = start
        while cursor < end:
            day = _to_local_day(cursor)
            boundary = _next_local_midnight(day)
            seg_end = min(end, boundary)
            by_day[day][state] += (seg_end - cursor).total_seconds()
            cursor = seg_end
    return by_day


def _compute_duration_stats(events, end_time):
    """Backwards-compatible wrapper: (focused, distracted_or_absent, sleeping)."""
    t = _compute_state_durations(events, end_time)
    return t["focused"], t["distracted"] + t["absent"], t["sleeping"]


def _finalize_session(
    db: Session,
    session: models.StudySession,
    refresh_hosts: bool = True,
) -> models.StudySession:
    """Cleanly close a session: recompute exact durations from its raw focus
    events, persist the totals, and tear down its runtime + chat context.
    Used by the normal end endpoint AND to sweep up sessions abandoned by an
    app crash or by starting a new session over an old one.

    `refresh_hosts=False` lets async callers skip the blocking hosts rewrite
    here and await `refresh_enforcement` themselves via `asyncio.to_thread`
    (so the event loop never stalls on DNS-flush / hosts I/O)."""
    # Idempotent: a double-click / reconnect retry must not re-bill time.
    if session.ended_at is not None:
        state_machine.end_runtime(session.id)
        _chat_context.pop(session.id, None)
        _rule_check_state.pop(session.id, None)
        if refresh_hosts:
            enforcement = site_blocking.refresh_enforcement()
            if not enforcement.get("ok"):
                logger.warning("site blocking after finalize: %s", enforcement.get("error"))
        return session

    events = (
        db.query(models.FocusEvent)
        .filter(models.FocusEvent.session_id == session.id)
        .order_by(models.FocusEvent.timestamp)
        .all()
    )
    now = datetime.now(timezone.utc)
    focused_sec, distracted_sec, sleeping_sec = _compute_duration_stats(events, now)

    session.ended_at = now
    session.total_focused_seconds = focused_sec
    # Sleeping is tracked separately in the raw stats but, historically,
    # lumped into "distracted" for the stored totals the summary screen shows.
    session.total_distracted_seconds = distracted_sec + sleeping_sec
    session.intervention_count = db.query(models.Intervention).filter(
        models.Intervention.session_id == session.id
    ).count()
    db.commit()
    db.refresh(session)

    # Parent output: end-of-run focus report (numbers only, never chat).
    if session.user_id is not None:
        tracked = focused_sec + distracted_sec + sleeping_sec
        focus_pct = round(100.0 * focused_sec / tracked, 1) if tracked > 0 else 0.0
        _emit_parent_alert(
            db, session.user_id, "session_report",
            f"Session ended: {focus_pct}% focused over "
            f"{(session.total_distracted_seconds or 0.0) / 60.0:.0f} min off task.",
            {
                "session_id": session.id,
                "focus_pct": focus_pct,
                "focused_minutes": round(focused_sec / 60.0, 1),
                "off_task_minutes": round((session.total_distracted_seconds or 0.0) / 60.0, 1),
                "paralysis_count": session.paralysis_count or 0,
                "check_in_count": session.check_in_count or 0,
                "intervention_count": session.intervention_count or 0,
                "task": (session.task_description or "")[:200],
                "subject": session.subject,
                "priority": session.priority,
            },
            session_id=session.id,
        )

    state_machine.end_runtime(session.id)
    _chat_context.pop(session.id, None)
    _rule_check_state.pop(session.id, None)
    if refresh_hosts:
        # Recompute from policy: with no open session left the hosts block
        # is cleared entirely (sites accessible again after End session).
        enforcement = site_blocking.refresh_enforcement()
        if not enforcement.get("ok"):
            logger.warning("site blocking after finalize: %s", enforcement.get("error"))

    # Fold this finished session into the account's companion learning
    # profile so personalisation travels with the login. Never let a profile
    # failure break session teardown.
    if session.user_id is not None:
        try:
            summary = learning.summarize_session(db, session.id)
            if summary:
                profile = learning.merge_profile(
                    learning.load_profile(db, session.user_id), summary
                )
                # Online drift model: one SGD step per finished session, then
                # refresh the unsupervised usage clusters over recent history.
                profile = learning.train_model(profile, summary)
                profile = learning.cluster_history(profile)
                learning.save_profile(db, session.user_id, profile)
        except Exception:
            logger.warning(
                "companion learning update failed for session %s",
                session.id,
                exc_info=True,
            )
    return session


def _resync_session_totals() -> None:
    """Recompute the denormalized totals of already-completed sessions from
    their raw focus events (honoring the gap cap), so past sessions recorded
    by older builds  Ewhich could bill days of abandoned idle time as focus  E    show honest numbers in the history list and summary screens."""
    db = next(get_db())
    try:
        sessions = (
            db.query(models.StudySession)
            .filter(models.StudySession.ended_at.isnot(None))
            .all()
        )
        for session in sessions:
            events = (
                db.query(models.FocusEvent)
                .filter(models.FocusEvent.session_id == session.id)
                .order_by(models.FocusEvent.timestamp)
                .all()
            )
            focused_sec, distracted_sec, sleeping_sec = _compute_duration_stats(
                events, _naive_utc(session.ended_at) or datetime.now(timezone.utc)
            )
            session.total_focused_seconds = round(focused_sec, 2)
            session.total_distracted_seconds = round(distracted_sec + sleeping_sec, 2)
        db.commit()
    finally:
        db.close()


_resync_session_totals()


# Which presence transitions are worth keeping as a durable entry in the
# Admin Hub bell, so an administrator can read back WHO signed in, who
# signed out, who went into a session and who came out of one - for
# students and guardians alike - instead of only seeing them flash past as a
# realtime popup. (Removed accounts keep their own `account_removed` entry,
# which is written by the delete handler because the account is already gone
# by the time the sweeper notices.)
_PRESENCE_ACTIVITY = {
    "signed_in": "Signed in",
    "signed_out": "Signed out",
    "session_started": "Session started",
    "session_finished": "Session finished",
}

# Transitions are QUEUED, never written from the sweeper itself. The sweeper is
# the latency-critical path (it drives the admin's live presence view for
# everyone at once), and a database write per transition there made offline
# announcements late enough to be missed when several people signed in and out
# at the same time. The flusher below drains this queue instead, so the write
# happens off the hot path and the popup still goes out immediately.
_PRESENCE_ACTIVITY_QUEUE: deque = deque(maxlen=500)


def _queue_presence_activity(user_id: int, previous, current) -> None:
    _PRESENCE_ACTIVITY_QUEUE.append((user_id, previous, current))


def _record_presence_activity(db, user, previous, current) -> None:
    """Write bell entries for one observed presence transition.

    `previous`/`current` are the sweeper's (online, status, task) keys. A
    `previous` of None means the account was not in the diff cache at all -
    i.e. it was created after boot and has just signed in - so it is treated
    as "was offline". The startup baseline never reaches this function
    (the sweeper skips it on its first pass), so a server restart cannot
    fabricate a sign-in for everybody."""
    try:
        name = (user.full_name or user.serial_number or f"User {user.id}").strip()
        role = (user.role or "student").strip()
        # First sighting of an account (created after boot) = it just signed in.
        was_online, was_status, _ = previous if previous is not None else (False, "offline", None)
        is_online, is_status, task = current
        payload = {
            "user_id": user.id,
            "full_name": name,
            "role": role,
            "status": is_status,
            "current_task": task,
        }
        events: list[tuple[str, str]] = []
        if not was_online and is_online:
            events.append(("signed_in", f"{name} signed in"))
        elif was_online and not is_online:
            events.append(("signed_out", f"{name} signed out (left)"))
        if is_online and is_status == "studying" and was_status != "studying":
            label = task or "a study session"
            events.append(("session_started", f"{name} started a session: {label}"))
        elif is_online and was_status == "studying" and is_status != "studying":
            events.append(("session_finished", f"{name} finished their session"))
        for kind, message in events:
            admin_router._notify_admin_event(db, f"user_{kind}", message, payload)
    except Exception:
        # The activity log is a convenience: never let it stop presence.
        logger.exception("presence activity record failed for user %s", getattr(user, "id", "?"))


async def _presence_activity_flusher(interval: float = 2.0) -> None:
    """Drain the presence-activity queue into the bell, off the sweeper's
    hot path. One account at a time, each in its own row (a batch could be
    several hundred on a busy day); the account is re-read here so a user
    deleted in the meantime is skipped - the delete handler already wrote its
    own `account_removed` entry. Best effort by design: a failed write is
    logged and dropped rather than retried forever, and never propagates."""
    while True:
        await asyncio.sleep(interval)
        try:
            while _PRESENCE_ACTIVITY_QUEUE:
                user_id, previous, current = _PRESENCE_ACTIVITY_QUEUE.popleft()
                db = None
                try:
                    db = next(get_db())
                    user = db.query(models.User).filter(models.User.id == user_id).first()
                    if user is None:
                        continue
                    _record_presence_activity(db, user, previous, current)
                finally:
                    if db is not None:
                        try:
                            db.close()
                        except Exception:
                            pass
        except Exception:
            logger.exception("presence activity flush failed")
            await asyncio.sleep(2.0)


async def _presence_sweeper(interval: float = 1.5) -> None:
    """Diff every student's online/status every `interval` seconds and push
    changes to open Admin Hub sockets ({"type":"presence", ...}). Started
    from the startup hook; never raises  Ea bad tick is logged and the loop
    continues. The hub's 4s HTTP poll is only the fallback when this task
    (or the WS) is unavailable."""
    last: dict[int, tuple[bool, str, Optional[str]]] = {}
    while True:
        await asyncio.sleep(interval)
        try:
            db = next(get_db())
            try:
                seen_ids: set[int] = set()
                # The very first sweep after boot is the baseline: it seeds the
                # diff cache without announcing anybody, so a server restart does
                # not stamp a fake "signed in" row for everyone already in the
                # app. Every sweep after that is a real diff - including the first
                # sighting of an account created after boot (a previous value of
                # None then means "this account just signed in", not "startup").
                seeding = not last
                for user in db.query(models.User).all():
                    seen_ids.add(user.id)
                    try:
                        status, task = admin_router._user_status(db, user)
                    except Exception:
                        # One bad user/status read must not stop the sweeper.
                        logger.exception("presence status failed for user %s", user.id)
                        continue
                    online = status != "offline"
                    key = (online, status, task)
                    previous = last.get(user.id)
                    if previous == key:
                        continue
                    last[user.id] = key
                    if not seeding:
                        _queue_presence_activity(user.id, previous, key)
                    site_blocking.broadcast_admin_presence({
                        "type": "presence",
                        "user_id": user.id,
                        "online": online,
                        "status": status,
                        "current_task": task,
                    })
                    # Guardian mirror: the same status change lands on the
                    # linked parent's dashboard socket, so "signed in /
                    # offline / off task" updates without waiting for the
                    # dashboard's HTTP poll.
                    if user.parent_id is not None:
                        _push_parent_sockets(user.parent_id, {
                            "type": "presence",
                            "student_id": user.id,
                            "online": online,
                            "status": status,
                            "current_task": task,
                        })
                    if not online:
                        # A student who just closes the tab (or whose token
                        # expires) never calls /auth/logout, so their row in
                        # the admin's login history stayed "still signed in"
                        # forever. Close it at the same moment the hub sees
                        # them go offline. The online badge itself is computed
                        # from the token registry (_user_status), so this never
                        # affects presence  Eonly the history gets truthful.
                        try:
                            admin_router._close_open_logins(db, user.id)
                        except Exception:
                            logger.exception(
                                "closing stale login events failed for user %s", user.id
                            )
                # Forget accounts that no longer exist. SQLite reuses row ids
                # after a delete, so a fresh account landing on a removed id
                # must not inherit that account's presence history (which would
                # hide its first sign-in from the hub).
                for gone in [i for i in last if i not in seen_ids]:
                    last.pop(gone, None)
            finally:
                db.close()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("presence sweeper tick failed")


# In-memory foreground-window snapshot per user  Ethe "did the window
# change" memory that decides window_status pushes (window_visits rows
# are the durable copy; this never leaves the process).
_USER_WINDOWS: dict[int, dict] = {}


def _credit_window_visit(
    db: Session,
    user_id: int,
    session_id: Optional[int],
    app: str,
    title: str,
    now: datetime,
    day: str,
) -> None:
    """Upsert one foreground-window observation. Rows are session-scoped
    (user+session+app+title), so each history entry lists exactly the
    windows that were in front during THAT session; the local `day`
    column still feeds the by-day rollup. The first sighting opens the
    row at 0s; every later sighting credits the elapsed gap (capped at
    30s so a stalled loop or laptop resume can't dump a huge jump into
    the day's numbers). Insert runs in a savepoint so a concurrent
    writer can never lose the tick  Eon a unique clash we fall through
    to the update path."""
    q = db.query(models.WindowVisit).filter(
        models.WindowVisit.user_id == user_id,
        models.WindowVisit.day == day,
        models.WindowVisit.app == app,
        models.WindowVisit.title == title,
    )
    if session_id is None:
        q = q.filter(models.WindowVisit.session_id.is_(None))
    else:
        q = q.filter(models.WindowVisit.session_id == session_id)
    row = q.first()
    if row is None:
        row = models.WindowVisit(
            user_id=user_id,
            session_id=session_id,
            app=app,
            title=title,
            day=day,
            first_seen=now,
            last_seen=now,
            seconds=0.0,
        )
        try:
            with db.begin_nested():
                db.add(row)
                db.flush()
            return
        except IntegrityError:
            q = db.query(models.WindowVisit).filter(
                models.WindowVisit.user_id == user_id,
                models.WindowVisit.day == day,
                models.WindowVisit.app == app,
                models.WindowVisit.title == title,
            )
            if session_id is None:
                q = q.filter(models.WindowVisit.session_id.is_(None))
            else:
                q = q.filter(models.WindowVisit.session_id == session_id)
            row = q.first()
            if row is None:
                return
    delta = (now - row.last_seen).total_seconds()
    if 0 < delta <= 30:
        row.seconds += delta
    row.last_seen = now
    if session_id is not None and row.session_id is None:
        row.session_id = session_id


# --- Smart intervention state (window monitor) -----------------------------
# Classifier cache: label per (app, site) for 10 min  Ethe same window is
# sampled every 2.5s, so an Ollama round-trip only happens per NEW target.
_CLASSIFY_CACHE: dict[str, tuple[float, dict]] = {}
_CLASSIFY_TTL_SEC = 600.0
# App-block close/notify cooldown: one enforcement action per (user, app)
# per 60s so a stubborn target can't spam closes or nudge frames.
_ENFORCE_COOLDOWN: dict[tuple[int, str], float] = {}
_ENFORCE_COOLDOWN_SEC = 60.0

# Session-id -> task_description, memoized for the block-vs-guide check so the
# window tick doesn't re-query the session on every pass.
_SESSION_TASK_CACHE: dict[int, Optional[str]] = {}


def _session_task_cache(db: Session, session_id: int) -> Optional[str]:
    if session_id in _SESSION_TASK_CACHE:
        return _SESSION_TASK_CACHE[session_id]
    session = db.get(models.StudySession, session_id)
    task = (session.task_description if session else None)
    if len(_SESSION_TASK_CACHE) > 200:
        _SESSION_TASK_CACHE.clear()
    _SESSION_TASK_CACHE[session_id] = task
    return task


def _classify_cached(app: str, title: str, site: str) -> dict:
    """Label the foreground target, memoized. Never raises; Ollama down ->
    intervention.heuristic_label (inside ollama_client.classify_window)."""
    key = f"{app}|{site or ''}"
    now_ts = time.time()
    hit = _CLASSIFY_CACHE.get(key)
    if hit and hit[0] > now_ts:
        return hit[1]
    try:
        cls = ollama_client.classify_window(app, title, site)
    except Exception:
        cls = intervention.heuristic_label(app, title, site)
    if not isinstance(cls, dict) or cls.get("label") not in intervention.ALL_LABELS:
        cls = intervention.heuristic_label(app, title, site)
    _CLASSIFY_CACHE[key] = (now_ts + _CLASSIFY_TTL_SEC, cls)
    if len(_CLASSIFY_CACHE) > 500:
        for k, (exp, _) in list(_CLASSIFY_CACHE.items()):
            if exp <= now_ts:
                _CLASSIFY_CACHE.pop(k, None)
    return cls


def _intervention_auto_enabled(db: Session) -> bool:
    """The blueprint's optional AUTO branch (admin-only toggle)."""
    try:
        row = db.get(models.AppSetting, "intervention")
        if not row:
            return False
        return bool(json.loads(row.value or "{}").get("auto_block", False))
    except Exception:
        return False


def _enforce_blocked_app(db: Session, user_id: int, session_id: int,
                         app: str, in_stubilly: bool) -> None:
    """Session-scoped BLOCK enforcement for an APP (sites are enforced by
    the hosts file + interceptor, not here): if this live session owns an
    approved 'blocked' app ticket matching the foreground app, gracefully
    WM_CLOSE its windows (never TerminateProcess) and nudge the student,
    at most once per minute per user+app. Skipped while the study app is
    itself in front  Eclosing the browser there would kill the session.
    Also skipped during a Pomodoro break (the break lifts all bans)."""
    if not app or in_stubilly or app == "stubilly":
        return
    # Never block the browser/OS/tooling (the session lives in a browser tab).
    if intervention.should_never_block(app, None):
        return
    # A break temporarily lifts every ban so the student can actually rest.
    rt = state_machine.active_sessions.get(session_id)
    if rt is not None and getattr(rt, "on_break", False):
        return
    now_ts = time.time()
    if _ENFORCE_COOLDOWN.get((user_id, app), 0.0) > now_ts:
        return
    ticket = (
        db.query(models.BlockTicket)
        .filter(
            models.BlockTicket.user_id == user_id,
            models.BlockTicket.session_id == session_id,
            models.BlockTicket.kind == "app",
            models.BlockTicket.status == "blocked",
            func.lower(models.BlockTicket.app) == app,
        )
        .first()
    )
    if not ticket:
        return
    closed = window_probe.close_app_windows(app)
    if closed:
        _ENFORCE_COOLDOWN[(user_id, app)] = now_ts + _ENFORCE_COOLDOWN_SEC
        site_blocking.notify_user_blocked(user_id, app, reason="admin_blocked")


def _case_evidence(
    db: Session, session_id: int, count: int, seconds: float,
    cls: dict, title: str,
) -> tuple[dict, bool, float]:
    """Bundle the blueprint's three streams for one case: sightings (count +
    seconds passed in), quiz result, distraction metrics. Returns
    (evidence_dict, quiz_failed, distraction_seconds)."""
    session = db.get(models.StudySession, session_id)
    quiz = (
        db.query(models.Quiz)
        .filter(
            models.Quiz.session_id == session_id,
            models.Quiz.status == "completed",
        )
        .order_by(models.Quiz.id.desc())
        .first()
    )
    quiz_fail = intervention.latest_quiz_failed(
        quiz.score if quiz else None,
        quiz.question_count if quiz else None,
    )
    distraction = float((session.total_distracted_seconds if session else 0) or 0)
    evidence = {
        "task": (session.task_description if session else None),
        "sightings": count,
        "seconds": round(seconds, 1),
        "label": str(cls.get("label") or "neutral"),
        "confidence": round(float(cls.get("confidence") or 0), 2),
        "classifier": cls.get("source"),
        "distracted_seconds": round(distraction, 1),
        "paralysis_count": (session.paralysis_count if session else 0) or 0,
        "quiz_score": (
            f"{quiz.score}/{quiz.question_count}"
            if quiz and quiz.score is not None else None
        ),
        "quiz_failed": quiz_fail,
        "last_title": (title or "")[:240],
    }
    return evidence, quiz_fail, distraction


def _enrich_intel_signals(evidence: dict, site: Optional[str], app: str = "") -> None:
    """Attach deep-intel signals (screen-OCR relevance, cached URL score,
    learned model relevance) to a ticket's evidence so the admin sees WHY
    the window looked task-relevant even when its title said otherwise.
    Never raises."""
    try:
        if site:
            u = url_intel.latest_score(site)
            if u is not None:
                evidence["url_relevance"] = round(u, 2)
        s = screen_probe.latest()
        _age = s.get("age_sec")
        # age_sec can be 0.0 (falsy)  Enever use `or 999` here.
        if s.get("available") and _age is not None and float(_age) < 60.0:
            evidence["screen_relevance"] = round(float(s.get("relevance") or 0), 2)
            if s.get("matched"):
                evidence["screen_matches"] = list(s["matched"])[:5]
        m = ml_model.live_relevance(
            None,
            evidence.get("task"), app, site,
            evidence.get("last_title"), evidence.get("label"),
            evidence.get("confidence"),
            float(evidence.get("url_relevance") or 0),
            float(evidence.get("screen_relevance") or 0),
        )
        if m > 0:
            evidence["model_relevance"] = round(m, 2)
    except Exception:
        pass


def _create_block_ticket(
    db: Session,
    user_id: int,
    session_id: int,
    kind: str,
    key: str,
    cls: dict,
    count: int,
    seconds: float,
    app: str,
    site: str,
    title: str,
) -> None:
    """Proposal ticket from sightings  Ethe approval gate's work item.
    Evidence bundles the three streams the blueprint combines: sightings
    (count/seconds), quiz result, and distraction metrics. AUTO branch
    (admin toggle + obvious high-confidence case) creates it already
    'blocked'; a strong-evidence ticket also pings the guardian."""
    session = db.get(models.StudySession, session_id)
    user = db.get(models.User, user_id)
    name = ((user.full_name or user.email or user.serial_number or "").strip()
            if user else "") or f"User {user_id}"
    evidence, quiz_fail, distraction = _case_evidence(
        db, session_id, count, seconds, cls, title
    )
    _enrich_intel_signals(evidence, site, app=app)
    strength = intervention.compute_strength(quiz_fail, distraction, count)
    label = str(cls.get("label") or "neutral")
    conf = float(cls.get("confidence") or 0)
    auto = intervention.auto_block_decision(_intervention_auto_enabled(db), label, conf)
    status = "blocked" if auto else ("suggested" if strength == "strong" else "proposed")
    row = models.BlockTicket(
        session_id=session_id,
        user_id=user_id,
        key=key,
        kind=kind,
        app=(app or "")[:64],
        site=site or None,
        title=(title or "")[:240] or None,
        label=label,
        confidence=conf,
        sighting_count=count,
        seconds=round(seconds, 1),
        task=(session.task_description if session else None),
        status=status,
        strength=strength,
        evidence=json.dumps(evidence, ensure_ascii=False),
        auto_blocked=auto,
    )
    db.add(row)
    db.commit()
    db.refresh(row)

    shown = site or app or key
    if auto:
        # Immediate enforcement: site -> hosts file; app -> the per-tick
        # close pass above (status is already 'blocked').
        if kind == "site" and site and user:
            current = schemas.parse_stored_list(user.blocked_sites)
            if site not in current:
                current.append(site)
                user.blocked_sites = json.dumps(current)
                user.policy_updated_at = datetime.now()
                db.commit()
            site_blocking.refresh_enforcement(effects=True)
        admin_router._notify_admin_event(
            db,
            "block_auto",
            f"Auto-blocked {shown} ({label}) - {name}",
            {
                "ticket_id": row.id, "key": key, "kind": kind, "label": label,
                "confidence": round(conf, 2), "sightings": count,
                "strength": strength, "user_id": user_id,
            },
        )
        _emit_parent_alert(
            db, user_id, "blocked",
            f"Blocked {shown} - {name} kept returning to it during study",
            {"ticket_id": row.id, "key": key, "kind": kind}, session_id,
        )
        site_blocking.notify_user_blocked(user_id, shown, reason="auto_blocked")
    else:
        admin_router._notify_admin_event(
            db,
            "block_proposal",
            f"Block proposal: {key} ({label}, {count}x) - {name}",
            {
                "ticket_id": row.id, "key": key, "kind": kind, "label": label,
                "confidence": round(conf, 2), "sightings": count,
                "strength": strength, "user_id": user_id,
            },
        )
        if strength == "strong":
            _emit_parent_alert(
                db, user_id, "block_suggested",
                f"Suggested blocking {shown}: {name} returned to it "
                f"{count} times during study",
                {"ticket_id": row.id, "key": key, "kind": kind}, session_id,
            )


def _refresh_open_ticket(
    db: Session, ticket: models.BlockTicket, cls: dict,
    count: int, seconds: float, title: str,
) -> None:
    """An OPEN proposal keeps accumulating evidence as sightings pile up  E    the ticket opens at 2 sightings, and the strong combo (quiz fail +
    distraction + 3 sightings) may only complete LATER. Re-bundle evidence
    each new sighting and upgrade proposed -> suggested exactly once, which
    is also when the guardian first hears about it."""
    evidence, quiz_fail, distraction = _case_evidence(
        db, ticket.session_id, count, seconds, cls, title
    )
    _enrich_intel_signals(evidence, ticket.site, app=ticket.app or "")
    ticket.sighting_count = count
    ticket.seconds = round(seconds, 1)
    ticket.label = evidence["label"]
    ticket.confidence = evidence["confidence"]
    ticket.strength = intervention.compute_strength(
        quiz_fail, distraction, count
    )
    ticket.evidence = json.dumps(evidence, ensure_ascii=False)
    upgraded = ticket.strength == "strong" and ticket.status == "proposed"
    if upgraded:
        ticket.status = "suggested"
    db.commit()
    if upgraded:
        shown = ticket.site or ticket.app or ticket.key
        user = db.get(models.User, ticket.user_id)
        name = ((user.full_name or user.email or user.serial_number or "").strip()
                if user else "") or f"User {ticket.user_id}"
        _emit_parent_alert(
            db, ticket.user_id, "block_suggested",
            f"Suggested blocking {shown}: {name} returned to it "
            f"{count} times during study",
            {"ticket_id": ticket.id, "key": ticket.key, "kind": ticket.kind},
            ticket.session_id,
        )


def _record_intervention_sighting(
    db: Session,
    user_id: int,
    session_id: int,
    kind: str,
    key: str,
    cls: dict,
    app: str,
    site: str,
    title: str,
    now: datetime,
) -> None:
    """Stream 1 of the blueprint: count how many times THIS off-task target
    came back during the live session, then propose at the threshold."""
    row = (
        db.query(models.BlockSighting)
        .filter(
            models.BlockSighting.session_id == session_id,
            models.BlockSighting.key == key,
        )
        .first()
    )
    label = str(cls.get("label") or "neutral")
    conf = float(cls.get("confidence") or 0)
    new_count, credit = intervention.next_sighting_state(
        row.count if row else 0, row.last_seen if row else None, now
    )
    if row:
        row.count = new_count
        row.seconds += credit
        row.last_seen = now
        row.last_title = (title or row.last_title or "")[:240] or None
        row.label = label
        row.confidence = conf
    else:
        row = models.BlockSighting(
            session_id=session_id,
            user_id=user_id,
            key=key,
            kind=kind,
            label=label,
            confidence=conf,
            count=new_count,
            seconds=credit,
            first_seen=now,
            last_seen=now,
            last_title=(title or "")[:240] or None,
        )
        db.add(row)
    latest = (
        db.query(models.BlockTicket)
        .filter(
            models.BlockTicket.session_id == session_id,
            models.BlockTicket.key == key,
        )
        .order_by(models.BlockTicket.id.desc())
        .first()
    )
    # Open proposal keeps absorbing evidence (count 2 opens it, count 3+
    # may complete the strong combo)  Eno second ticket, just an upgrade.
    if latest is not None and latest.status in ("proposed", "suggested"):
        _refresh_open_ticket(db, latest, cls, new_count, row.seconds, title)
        return
    denied_before = (
        db.query(models.BlockTicket.id)
        .filter(
            models.BlockTicket.user_id == user_id,
            models.BlockTicket.key == key,
            models.BlockTicket.status == "denied",
        )
        .first()
        is not None
    )
    ok, _reason = intervention.should_propose(
        new_count,
        latest.status if latest else None,
        denied_before,
        latest.decided_at if (latest and latest.status == "allowed_once") else None,
        now,
    )
    if not ok:
        return
    _create_block_ticket(
        db, user_id, session_id, kind, key, cls, new_count, row.seconds,
        app, site, title,
    )


_BREAK_FALLBACK_MINUTES = 5.0
_GAME_SCAN_INTERVAL_SEC = 15.0
_GAME_CLOSE_COOLDOWN_SEC = 15.0
_GAME_CLOSE_COOLDOWN: dict = {}   # (user_id, proc) -> close-ts
_GAME_WARNED: dict = {}           # (user_id, proc) -> first-warn ts
_ERROR_RING: list = []            # last 100 internal errors for /admin/diagnostics


def _note_error(where: str, what: str) -> None:
    _ERROR_RING.append({
        "at": datetime.now().isoformat(timespec="seconds"),
        "where": where,
        "error": str(what)[:300],
    })
    if len(_ERROR_RING) > 100:
        del _ERROR_RING[:-100]


def _hard_block_site_for_session(db, session, payload) -> None:
    """full_block escalation: add the offending site to this SESSION's
    block list (session-scoped like every auto-block, so it dies with the
    run) and re-apply enforcement immediately. Never touches school
    allowlist entries."""
    site_now = str(payload.get("active_site") or "").strip().lower().split(":")[0]
    if not site_now or site_now in intervention.SCHOOL_ALLOWLIST:
        return
    try:
        current = json.loads(session.blocked_sites or "[]")
        if not isinstance(current, list):
            current = []
    except Exception:
        current = []
    if site_now in current:
        return
    current.append(site_now)
    session.blocked_sites = json.dumps(current)
    db.commit()
    site_blocking.refresh_enforcement()
    if session.user_id is not None:
        site_blocking.broadcast_policy_refresh(session.user_id)


async def _game_scan_task(interval: float = _GAME_SCAN_INTERVAL_SEC) -> None:
    """Background game scan: any running process matching a game name gets
    a fair warning first; still running after GAME_WARN_GRACE_SEC it gets
    WM_CLOSE'd and is re-closed on every relaunch for the rest of the
    session. Browsers/terminals/Stubilly are never touched
    (NEVER_BLOCK_APPS); breaks and End Session stop the scan."""
    while True:
        await asyncio.sleep(interval)
        try:
            await asyncio.to_thread(_game_scan_tick)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.exception("game scan tick failed")
            _note_error("game_scan_task", exc)


def _game_scan_tick() -> None:
    procs = window_probe.list_running_processes()
    if not procs:
        return
    games = sorted({p for p in procs if intervention.match_game_process(p)})
    if not games:
        return
    now_ts = time.time()
    db = next(get_db())
    try:
        open_sessions = (
            db.query(models.StudySession.id, models.StudySession.user_id)
            .filter(models.StudySession.ended_at.is_(None))
            .all()
        )
        if not open_sessions:
            return
        # NEWEST session per user owns the machine (same rule as the
        # window monitor); only sessions with a live runtime are enforced.
        session_by_user: dict = {}
        for sid, uid in open_sessions:
            if uid not in session_by_user or sid > session_by_user[uid]:
                session_by_user[uid] = sid
        users = (
            db.query(models.User)
            .filter(models.User.id.in_(list(session_by_user)))
            .all()
        )
        for user in users:
            if not admin_router.effective_settings(user).get(
                "monitoring_enabled", True
            ):
                continue
            sid = session_by_user.get(user.id)
            rt = state_machine.active_sessions.get(sid) if sid is not None else None
            if rt is None or rt.on_break:
                continue
            for game in games:
                key = (user.id, game)
                if key not in _GAME_WARNED:
                    # Fair warning before any close  Ethe student hears why.
                    _GAME_WARNED[key] = now_ts
                    message = (
                        f"\"{game}\" looks like a game. Close it now or "
                        f"Stubilly will close it  Egames wait for break time."
                    )
                    if sid is not None:
                        iv = models.Intervention(
                            session_id=sid,
                            intervention_type="game_warn",
                            trigger_state="off_task",
                            message=message,
                            channel="text",
                        )
                        db.add(iv)
                        db.commit()
                        db.refresh(iv)
                        site_blocking.push_focus_frame(user.id, {
                            "type": "intervention",
                            "id": iv.id,
                            "intervention_type": "game_warn",
                            "message": message,
                            "voice": False,
                            "tone": "firm",
                            "respondable": False,
                        })
                    continue
                if (now_ts - _GAME_WARNED[key]) < intervention.GAME_WARN_GRACE_SEC:
                    continue
                if _GAME_CLOSE_COOLDOWN.get(key, 0.0) > now_ts:
                    continue
                closed = window_probe.close_app_windows(game)
                if not closed:
                    continue
                _GAME_CLOSE_COOLDOWN[key] = now_ts + _GAME_CLOSE_COOLDOWN_SEC
                message = (
                    f"Closing \"{game}\"  Egames stay out until you take a "
                    f"break or end the session."
                )
                if sid is not None:
                    iv = models.Intervention(
                        session_id=sid,
                        intervention_type="off_task_block",
                        trigger_state="off_task",
                        message=message,
                        channel="text",
                    )
                    db.add(iv)
                    db.commit()
                    db.refresh(iv)
                    site_blocking.push_focus_frame(user.id, {
                        "type": "intervention",
                        "id": iv.id,
                        "intervention_type": "off_task_block",
                        "message": message,
                        "voice": False,
                        "tone": "firm",
                        "respondable": False,
                    })
        # Forget stale keys so a finished session starts fresh next time.
        live = set(session_by_user)
        for d in (_GAME_WARNED, _GAME_CLOSE_COOLDOWN):
            for k in [k for k in d if k[0] not in live]:
                d.pop(k, None)
    except Exception as exc:
        _note_error("game_scan_tick", exc)
    finally:
        db.close()


@app.post("/sessions/{session_id}/break")
def start_session_break(
    session_id: int,
    payload: schemas.BreakRequest,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Owner-scoped timed break: server timer is authoritative  Eit expires
    even if the client dies. Every ban lifts for the duration."""
    session = _get_owned_session(db, authorization, session_id)
    if session.ended_at is not None:
        raise HTTPException(409, "session already ended")
    rt = state_machine.get_or_create_runtime(session_id)
    ends_at = rt.start_break(payload.minutes)
    site_blocking.refresh_enforcement()
    if session.user_id is not None:
        site_blocking.push_focus_frame(session.user_id, {
            "type": "break_started",
            "ends_at": ends_at.isoformat(),
        })
    return {
        "session_id": session_id,
        "on_break": True,
        "ends_at": ends_at.isoformat(),
    }


@app.post("/sessions/{session_id}/break/end")
def end_session_break(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Owner-scoped break end (student returned to work). Re-applies every
    ban immediately."""
    session = _get_owned_session(db, authorization, session_id)
    rt = state_machine.active_sessions.get(session_id)
    if rt is not None:
        rt.end_break()
    site_blocking.refresh_enforcement()
    if session.user_id is not None:
        site_blocking.push_focus_frame(session.user_id, {"type": "break_ended"})
    return {"session_id": session_id, "on_break": False, "ends_at": None}


@app.post("/admin/sessions/{session_id}/break")
def admin_start_session_break(
    session_id: int,
    payload: schemas.BreakRequest,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Admin-granted timed break from Smart Ops (admin token). Same server
    timer  Eeven an admin cannot make a break that never ends."""
    if not auth_service.is_admin_token(admin_router.bearer_token(authorization)):
        raise HTTPException(403, "admin only")
    session = db.get(models.StudySession, session_id)
    if session is None or session.ended_at is not None:
        raise HTTPException(404, "no open session")
    rt = state_machine.get_or_create_runtime(session_id)
    ends_at = rt.start_break(payload.minutes)
    site_blocking.refresh_enforcement()
    if session.user_id is not None:
        site_blocking.push_focus_frame(session.user_id, {
            "type": "break_started",
            "ends_at": ends_at.isoformat(),
        })
    return {"session_id": session_id, "on_break": True, "ends_at": ends_at.isoformat()}


@app.post("/admin/sessions/{session_id}/break/end")
def admin_end_session_break(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Admin ends a student's break from Smart Ops (admin token)."""
    if not auth_service.is_admin_token(admin_router.bearer_token(authorization)):
        raise HTTPException(403, "admin only")
    rt = state_machine.active_sessions.get(session_id)
    if rt is not None:
        rt.end_break()
    session = db.get(models.StudySession, session_id)
    site_blocking.refresh_enforcement()
    if session is not None and session.user_id is not None:
        site_blocking.push_focus_frame(session.user_id, {"type": "break_ended"})
    return {"session_id": session_id, "on_break": False, "ends_at": None}


@app.get("/admin/diagnostics")
def admin_diagnostics(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Smart Ops Health tab: probe availability, live games, open-session
    break state, and the recent internal-error ring  Eeverything an admin
    needs to answer 'why didn't it block?' locally."""
    if not auth_service.is_admin_token(admin_router.bearer_token(authorization)):
        raise HTTPException(403, "admin only")
    open_sessions = (
        db.query(models.StudySession.id, models.StudySession.user_id)
        .filter(models.StudySession.ended_at.is_(None))
        .all()
    )
    live = []
    for sid, uid in open_sessions:
        rt = state_machine.active_sessions.get(sid)
        live.append({
            "session_id": sid,
            "user_id": uid,
            "on_break": bool(rt and rt.on_break),
            "break_ends_at": (
                rt.break_ends_at.isoformat() if rt and rt.break_ends_at else None
            ),
        })
    try:
        probe = window_probe.read_foreground()
    except Exception:
        probe = {"available": False}
    return {
        "window_probe_available": bool(probe.get("available")),
        "active_games_detected": [
            p for p in window_probe.list_running_processes()
            if intervention.match_game_process(p)
        ],
        "open_sessions": live,
        "recent_errors": list(_ERROR_RING)[::-1],
        "ml_model": ml_model.model_info(),
        "url_intel": url_intel.cache_summary(),
        "screen_probe": {
            "last_capture_chars": (screen_probe.latest() or {}).get("chars"),
        },
    }


def _window_monitor_tick() -> None:
    """One sampler pass: probe the machine's foreground window ONCE and
    credit every monitored student who has a session open (one probe per
    tick regardless of student count  Eit's this machine's window, and
    sessions run on this machine). Presence/window titles only, never
    page content or keystrokes."""
    now = datetime.now()
    day = now.strftime("%Y-%m-%d")
    db = next(get_db())
    try:
        # Timed-break expiry runs first every pass: the server timer is the
        # authority, so the instant a break ends every ban re-applies and the
        # student's live sockets are told  Eno client cooperation needed.
        expired_breaks = [
            (sid, rt) for sid, rt in state_machine.active_sessions.items()
            if rt.break_expired()
        ]
        if expired_breaks:
            for _sid, rt in expired_breaks:
                rt.end_break()
            site_blocking.refresh_enforcement()
            for sid, _rt in expired_breaks:
                sess = db.get(models.StudySession, sid)
                if sess is not None and sess.user_id is not None:
                    site_blocking.push_focus_frame(
                        sess.user_id, {"type": "break_ended"}
                    )
        open_sessions = (
            db.query(models.StudySession.id, models.StudySession.user_id)
            .filter(models.StudySession.ended_at.is_(None))
            .all()
        )
        if not open_sessions:
            if _USER_WINDOWS:
                _USER_WINDOWS.clear()
            return
        # A student should have one open session, but if two overlap the
        # NEWEST one (highest id) owns the foreground window.
        session_by_user: dict = {}
        for sid, uid in open_sessions:
            if uid not in session_by_user or sid > session_by_user[uid]:
                session_by_user[uid] = sid
        reading = window_probe.read_foreground()
        if not reading.get("available"):
            return
        app = (reading.get("app") or "").strip().lower()[:64]
        title = (reading.get("title") or "").strip()[:240]
        if not app and not title:
            return
        in_stubilly = bool(reading.get("in_stubilly"))
        site = (reading.get("site") or "").strip().lower()[:160]
        # Classify the foreground target ONCE per tick (cached per app/site)
        #  Eall students on this machine see the same window.
        cls = (
            _classify_cached(app, title, site)
            if app and not in_stubilly else None
        )
        changed: list = []
        users = (
            db.query(models.User)
            .filter(models.User.id.in_(list(session_by_user)))
            .all()
        )
        for user in users:
            if not admin_router.effective_settings(user).get(
                "monitoring_enabled", True
            ):
                _USER_WINDOWS.pop(user.id, None)
                continue
            sid = session_by_user.get(user.id)
            _credit_window_visit(
                db, user.id, sid, app, title, now, day
            )
            if sid is not None:
                # Approved app-block enforcement for this live session.
                _enforce_blocked_app(db, user.id, sid, app, in_stubilly)
                # Sightings only for off-task targets outside the study app,
                # and only when the smarter decision says block/guide (never
                # for the browser, school sites, or task-relevant windows).
                if cls is not None and cls.get("label") in intervention.OFF_TASK_LABELS:
                    _session_task = _session_task_cache(db, sid)
                    # Deep intelligence floor: last screen-OCR score + any
                    # cached URL-intel score for this domain raise relevance
                    # (never lower it). Background fetches refresh both.
                    min_rel = 0.0
                    url_rel = 0.0
                    screen_rel = 0.0
                    _is_yt = bool(site) and site in url_intel.YOUTUBE_HOSTS
                    if site:
                        # YouTube: don't use the url_intel YouTube-search
                        # score as a relevance floor (query echo makes every
                        # video look on-task). Rely on the current video title
                        # + screen OCR instead.
                        if not _is_yt:
                            _u = url_intel.latest_score(site)
                            if _u is not None:
                                url_rel = float(_u)
                                min_rel = max(min_rel, url_rel)
                            url_intel.ensure_fetched(site, _session_task)
                    _scr = screen_probe.latest()
                    _age = _scr.get("age_sec")
                    # age_sec can be 0.0 (falsy)  Enever use `or 999` here.
                    if _scr.get("available") and _age is not None and float(_age) < 25.0:
                        screen_rel = float(_scr.get("relevance") or 0.0)
                        min_rel = max(min_rel, screen_rel)
                    if _session_task:
                        screen_probe.request_capture(_session_task)
                    # Learned floor: L2-logistic model on admin block/deny
                    # history, gated by the ml_threshold bias-variance dial.
                    # 0.0 on cold start -> rules behave exactly as before.
                    min_rel = max(min_rel, ml_model.live_relevance(
                        db, _session_task, app, site, title,
                        str(cls.get("label") or "neutral"),
                        float(cls.get("confidence") or 0),
                        url_rel, screen_rel,
                    ))
                    decision = intervention.decide_block_vs_guide(
                        str(cls.get("label") or "neutral"),
                        float(cls.get("confidence") or 0),
                        app, site, title, _session_task,
                        min_relevance=min_rel,
                    )
                    if decision in ("block", "guide"):
                        s_kind, s_key = intervention.normalize_key(app, site)
                        if s_key:
                            _record_intervention_sighting(
                                db, user.id, sid, s_kind, s_key, cls,
                                app, site, title, now,
                            )
            prev = _USER_WINDOWS.get(user.id)
            if prev is None or prev.get("app") != app or prev.get("title") != title:
                _USER_WINDOWS[user.id] = {"app": app, "title": title}
                if user.parent_id is not None:
                    changed.append((user.parent_id, {
                        "type": "window_status",
                        "student_id": user.id,
                        "app": app,
                        "title": title,
                        "in_stubilly": bool(reading.get("in_stubilly")),
                        "at": now.isoformat(sep=" ", timespec="seconds"),
                    }))
        db.commit()
        for parent_id, frame in changed:
            _push_parent_sockets(parent_id, frame)
    finally:
        db.close()


async def _window_monitor_task(interval: float = 2.5) -> None:
    """Foreground-window sampler loop: watches what is actually on screen
    while sessions are open so the guardian sees window titles, not just
    app names. Started from the startup hook; never raises  Ea bad tick
    is logged and the loop continues."""
    while True:
        await asyncio.sleep(interval)
        try:
            _window_monitor_tick()
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("window monitor tick failed")


def _user_id_from_header(authorization: Optional[str]) -> Optional[int]:
    """Which logged-in account (if any) this request belongs to  ENone means
    legacy single-user mode (no accounts exist on the server yet)."""
    return auth_service.get_user_from_token(admin_router.bearer_token(authorization))


def _get_owned_session(db: Session, authorization: Optional[str], session_id: int) -> "models.StudySession":
    """Fetches a session the caller is allowed to see: their own account's
    session, or (legacy mode, no accounts) the machine's unowned sessions.
    Touching another account's data fails closed with a 404."""
    uid = _user_id_from_header(authorization)
    q = db.query(models.StudySession).filter(models.StudySession.id == session_id)
    if uid is not None:
        q = q.filter(models.StudySession.user_id == uid)
    else:
        q = q.filter(models.StudySession.user_id.is_(None))
    session = q.first()
    if not session:
        raise HTTPException(404, "Session not found")
    return session


@app.post("/sessions/{session_id}/end", response_model=schemas.SessionOut)
def end_session(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    session = _get_owned_session(db, authorization, session_id)
    if session.ended_at is not None:
        # Already closed (double-click / retry)  Ereturn as-is, never re-end.
        return session
    return _finalize_session(db, session)


@app.get("/sessions", response_model=list[schemas.SessionOut])
def list_sessions(
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """A signed-in student only ever sees their own sessions; legacy mode
    (no accounts on the server yet) shows the machine's unowned runs."""
    uid = _user_id_from_header(authorization)
    q = db.query(models.StudySession).options(selectinload(models.StudySession.tasks))
    if uid is not None:
        q = q.filter(models.StudySession.user_id == uid)
    else:
        q = q.filter(models.StudySession.user_id.is_(None))
    return q.order_by(models.StudySession.started_at.desc()).all()


@app.get("/sessions/{session_id}", response_model=schemas.SessionOut)
def get_session(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    return _get_owned_session(db, authorization, session_id)


@app.put("/sessions/{session_id}/blocked-sites", response_model=schemas.SessionOut)
def save_session_blocked_sites(
    session_id: int,
    payload: schemas.SessionBlockedSitesRequest,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Persists the domains currently blocked during this session (idempotent
    full replace). The frontend reports auto-blocked domains here as they are
    added, so a resumed/continued session can re-apply the same block-list
    enforcement instead of losing it when the app restarts."""
    session = _get_owned_session(db, authorization, session_id)
    session.blocked_sites = (
        json.dumps([s for s in payload.blocked_sites if s and s.strip()])
        if payload.blocked_sites
        else None
    )
    db.commit()
    db.refresh(session)
    # Realtime: push policy_refresh to this student's live focus socket AND
    # /ws/notifications tabs so a mid-session edit applies immediately, not
    # on the next 5s poll.
    if session.user_id is not None:
        site_blocking.broadcast_policy_refresh(session.user_id)
    return session


@app.put("/sessions/{session_id}/allowed-sites", response_model=schemas.SessionOut)
def save_session_allowed_sites(
    session_id: int,
    payload: schemas.SessionAllowedSitesRequest,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Persists the sites/apps explicitly allowed during this session
    (idempotent full replace)  Ethe counterpart to blocked-sites. An allow
    overrides the blocklist and Live Shutdown for the run it belongs to, and
    is re-applied when the session is resumed / continued / studied again,
    then lifted once that run ends."""
    session = _get_owned_session(db, authorization, session_id)
    session.allowed_sites = (
        json.dumps([s for s in payload.allowed_sites if s and s.strip()])
        if payload.allowed_sites
        else None
    )
    db.commit()
    db.refresh(session)
    # Realtime mirror of the admin list save: an allow typed mid-session must
    # reach the student's whitelist (badge / on-off-task classification / alarm
    # suppression) immediately, exactly like the blocked list's interceptor.
    if session.user_id is not None:
        site_blocking.broadcast_policy_refresh(session.user_id)
    return session


@app.get("/sessions/{session_id}/events", response_model=list[schemas.FocusEventOut])
def get_session_events(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Raw dataset export for a session  Ewhat a research analysis script would pull."""
    _get_owned_session(db, authorization, session_id)
    return (
        db.query(models.FocusEvent)
        .filter(models.FocusEvent.session_id == session_id)
        .order_by(models.FocusEvent.timestamp)
        .all()
    )


@app.get("/sessions/{session_id}/stats", response_model=schemas.SessionStats)
def get_session_stats(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    session = _get_owned_session(db, authorization, session_id)

    events = (
        db.query(models.FocusEvent)
        .filter(models.FocusEvent.session_id == session_id)
        .order_by(models.FocusEvent.timestamp)
        .all()
    )
    end_bound = _naive_utc(session.ended_at) or _naive_utc(datetime.now(timezone.utc))
    t = _compute_state_durations(events, end_bound)
    focused_sec, distracted_sec, sleeping_sec, absent_sec = (
        t["focused"], t["distracted"], t["sleeping"], t["absent"]
    )
    tracked = focused_sec + distracted_sec + sleeping_sec + absent_sec
    # "% focus" means share of the time actually spent at the desk that was
    # focused  Etime genuinely away (face never in frame, or abandoned gaps)
    # is reported separately as absent_sec, not diluted-into the focus %. A
    # "+74 hours absent" abandoned session would otherwise make a perfectly
    # good hour of studying read as 0.5% focus.
    at_desk = focused_sec + distracted_sec + sleeping_sec

    intervention_groups = dict(
        db.query(models.Intervention.intervention_type, func.count(models.Intervention.id))
        .filter(models.Intervention.session_id == session_id)
        .group_by(models.Intervention.intervention_type)
        .all()
    )

    first_distraction = next((e for e in events if e.state in ("distracted", "sleeping", "absent")), None)
    time_to_first = None
    if first_distraction and events:
        time_to_first = (first_distraction.timestamp - events[0].timestamp).total_seconds()

    # "How many times precisely": sessions ever done on this task, and where
    # THIS one falls in that ordered run.
    same_task = (
        db.query(models.StudySession.id)
        .filter(models.StudySession.task_description == session.task_description)
        .order_by(models.StudySession.started_at)
        .all()
    )
    task_study_count = len(same_task)
    session_number = next((i + 1 for i, (sid,) in enumerate(same_task) if sid == session.id), task_study_count)

    return schemas.SessionStats(
        session_id=session_id,
        duration_sec=round((end_bound - session.started_at).total_seconds(), 1),
        total_events=len(events),
        focused_sec=round(focused_sec, 1),
        distracted_sec=round(distracted_sec, 1),
        sleeping_sec=round(sleeping_sec, 1),
        absent_sec=round(absent_sec, 1),
        focused_pct=round(100 * focused_sec / at_desk, 1) if at_desk else 0.0,
        distracted_pct=round(100 * (distracted_sec + sleeping_sec) / at_desk, 1) if at_desk else 0.0,
        sleeping_pct=round(100 * sleeping_sec / at_desk, 1) if at_desk else 0.0,
        intervention_count=sum(intervention_groups.values()),
        intervention_groups=intervention_groups,
        avg_time_to_first_distraction_sec=round(time_to_first, 1) if time_to_first is not None else None,
        task_study_count=task_study_count,
        session_number=session_number,
    )


# ---------------------------------------------------------------------------
# Analytics  Eproductivity dashboard
# ---------------------------------------------------------------------------

RANGE_DAYS = {"today": 1, "week": 7, "month": 30, "year": 365}

# The user's actual calendar days, not UTC's. The DB stores naive UTC; the
# backend runs on the same machine as the student, so the host's local
# timezone is the user's  Esessions started at 1 AM local belong to "today",
# not the previous UTC date.
_LOCAL_TZ = datetime.now().astimezone().tzinfo


def _to_local_day(dt) -> date:
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(_LOCAL_TZ).date()


def _session_day(session: "models.StudySession") -> date:
    """Calendar day a session belongs to, based on when it started (local)."""
    return _to_local_day(session.started_at)


@app.get("/analytics/overview", response_model=schemas.AnalyticsOverview)
def get_analytics_overview(
    range: str = "month",
    user_id: Optional[int] = None,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """
    Aggregated productivity stats for the dashboard.

    `range` is one of "today" | "week" | "month" | "year" | "all" (current
    calendar day / last 7 / 30 / 365 days, or the full history). Completed
    sessions are counted, and a session still in progress is counted live (its
    durations run up to `now`) so "Today" never sits stale while the student is    actively studying. Each session's time is split across the calendar days it    spanned, so a session that crosses midnight bills its two halves to the    correct days instead of dumping everything on the start day.

    Every duration is recomputed from the raw focus_events (the same span
    math as the per-session stats endpoint), so focused / distracted /
    sleeping / absent totals are exact and never rely on the rounded
    denormalized totals.

    Privacy: this always stays inside ONE account's own data. A signed-in
    student calling without `user_id` sees only their sessions (or only the
    machine's legacy unowned sessions when no accounts exist yet). An admin
    may pass `?user_id=` to pull any student's overview.
    """
    if range not in ("today", "week", "month", "year", "all"):
        raise HTTPException(400, "range must be one of: today, week, month, year, all")

    if user_id is not None:
        if not auth_service.is_admin_token(admin_router.bearer_token(authorization)):
            raise HTTPException(401, "Admin token required")
    else:
        user_id = _user_id_from_header(authorization)

    base = db.query(models.StudySession)
    if user_id is not None:
        base = base.filter(models.StudySession.user_id == user_id)
    else:
        base = base.filter(models.StudySession.user_id.is_(None))
    all_completed = base.filter(models.StudySession.ended_at.isnot(None)).order_by(models.StudySession.started_at).all()
    # A live (still-open) session counts toward "Today" as it accrues, so the
    # dashboard never sits stale while the student is actively studying. Its
    # durations run from the first reading up to `now`.
    live_sessions = base.filter(models.StudySession.ended_at.is_(None)).order_by(models.StudySession.started_at).all()

    today = _to_local_day(datetime.now(timezone.utc))
    if range == "all":
        cutoff = None
    else:
        cutoff = today - timedelta(days=RANGE_DAYS[range] - 1)

    all_sessions = all_completed + live_sessions

    # Load every raw focus event for ALL of the caller's sessions once, in
    # order, and let the same span-based duration math decide where each
    # second went. (The streak's "meaningful days" check spans full history  E    # even for the narrow 7/30-day views  Eso durations are computed for the
    # whole of that history, not just the selected cutoff. Computing them for
    # only the in-range sessions was the old 500: older sessions' ids came up
    # missing from `per_session`.)
    all_sids = [s.id for s in all_sessions]
    by_session: dict[int, list] = defaultdict(list)
    if all_sids:
        events = (
            db.query(models.FocusEvent)
            .filter(models.FocusEvent.session_id.in_(all_sids))
            .order_by(models.FocusEvent.session_id, models.FocusEvent.timestamp)
            .all()
        )
        for e in events:
            by_session[e.session_id].append(e)

    now = datetime.now(timezone.utc)
    # Whole-session totals (start-day semantics preserved for best_session /
    # streak math) plus the per-calendar-day split used by the daily buckets.
    per_session: dict[int, dict] = {}
    per_session_days: dict[int, dict] = {}
    for s in all_sessions:
        end = s.ended_at if s.ended_at is not None else now
        evs = by_session.get(s.id, [])
        per_session[s.id] = _compute_state_durations(evs, end)
        per_session_days[s.id] = _state_seconds_by_day(evs, end)

    def _is_meaningful(sid: int) -> bool:
        t = per_session[sid]
        return (t["focused"] + t["distracted"] + t["sleeping"]) > 0.0

    meaningful = [s for s in all_sessions if _is_meaningful(s.id)]
    meaningful_ids = [s.id for s in meaningful]

    # --- group by calendar day: each session's time is split across every day
    #     it spanned, so a session crossing midnight bills its two halves to
    #     the correct days instead of dumping everything on the start day.
    #     session_count / intervention_count stay attributed to the day the
    #     session started (once per session, so nothing double counts). ---
    by_day: dict[date, dict] = defaultdict(lambda: {
        "session_count": 0,
        "focused_minutes": 0.0,
        "distracted_minutes": 0.0,
        "sleeping_minutes": 0.0,
        "absent_minutes": 0.0,
        "intervention_count": 0,
    })
    totals = {"focused": 0.0, "distracted": 0.0, "sleeping": 0.0, "absent": 0.0}

    for s in meaningful:
        start_day = _session_day(s)
        if cutoff is None or start_day >= cutoff:
            d = by_day[start_day]
            d["session_count"] += 1
            d["intervention_count"] += s.intervention_count or 0
        for day, states in per_session_days[s.id].items():
            if cutoff is not None and day < cutoff:
                continue
            d = by_day[day]
            for state in totals:
                minutes = states[state] / 60.0
                d[f"{state}_minutes"] += minutes
                totals[state] += minutes

    # Nudges, split by type across the whole range  Eexact counts straight
    # from the interventions table.
    intervention_groups: dict[str, int] = {}
    if meaningful_ids:
        intervention_groups = dict(
            db.query(models.Intervention.intervention_type, func.count(models.Intervention.id))
            .filter(models.Intervention.session_id.in_(meaningful_ids))
            .group_by(models.Intervention.intervention_type)
            .all()
        )

    daily = []
    for d, vals in sorted(by_day.items()):
        tracked = (vals["focused_minutes"] + vals["distracted_minutes"]
                   + vals["sleeping_minutes"] + vals["absent_minutes"])
        at_desk = vals["focused_minutes"] + vals["distracted_minutes"] + vals["sleeping_minutes"]
        daily.append(schemas.DailyStat(
            date=d.isoformat(),
            session_count=vals["session_count"],
            focused_minutes=round(vals["focused_minutes"], 1),
            distracted_minutes=round(vals["distracted_minutes"], 1),
            sleeping_minutes=round(vals["sleeping_minutes"], 1),
            absent_minutes=round(vals["absent_minutes"], 1),
            intervention_count=vals["intervention_count"],
            total_minutes=round(tracked, 1),
            focus_pct=round(100 * vals["focused_minutes"] / at_desk, 1) if at_desk else 0.0,
        ))

    total_at_desk = totals["focused"] + totals["distracted"] + totals["sleeping"]

    best_day = max(daily, key=lambda d: d.focused_minutes) if daily else None

    # The session with the strongest focus performance in the range  Ea
    # measure of "how well did I work", not just how long. Requires at
    # least a minute of at-desk time so a 20-second blip can't win.
    best_session = None
    best_session_key = None
    for s in meaningful:
        t = per_session[s.id]
        at_desk_s = t["focused"] + t["distracted"] + t["sleeping"]
        if at_desk_s < 60.0:
            continue
        pct = 100.0 * t["focused"] / at_desk_s
        if best_session_key is None or pct > best_session_key[1]:
            best_session_key = (s.id, pct)
            best_session = (s, pct)
    best_session_out = None
    if best_session is not None:
        s, pct = best_session
        best_session_out = schemas.SessionPerformance(
            session_id=s.id,
            task_description=s.task_description,
            started_at=s.started_at,
            focus_pct=round(pct, 1),
        )

    # --- current streak: consecutive local-calendar days up to today that had
    #     at least one meaningful session, over ALL history so it isn't
    #     truncated by the selected range. An abandoned-idle day is not a
    #     study day. ---
    meaningful_days = {_session_day(s) for s in meaningful}
    streak = 0
    cursor = today
    while cursor in meaningful_days:
        streak += 1
        cursor -= timedelta(days=1)

    # Best-ever consecutive-day run (over all history)  Ethe streak-gating
    # milestone that unlocks the 7-day / 30-day / Year views in the student
    # dashboard. "Meaningful day" == a completed session with tracked time.
    if meaningful_days:
        ordered = sorted(meaningful_days)
        best = run = 1
        for prev, cur in zip(ordered, ordered[1:]):
            run = run + 1 if (cur - prev).days == 1 else 1
            best = max(best, run)
    else:
        best = 0

    if cutoff:
        range_start = cutoff.isoformat()
    elif daily:
        range_start = daily[0].date
    else:
        range_start = today.isoformat()

    return schemas.AnalyticsOverview(
        range=range,
        range_start=range_start,
        range_end=today.isoformat(),
        total_sessions=len(meaningful),
        total_focused_minutes=round(totals["focused"], 1),
        total_distracted_minutes=round(totals["distracted"], 1),
        total_sleeping_minutes=round(totals["sleeping"], 1),
        total_absent_minutes=round(totals["absent"], 1),
        avg_focus_pct=round(100 * totals["focused"] / total_at_desk, 1) if total_at_desk else 0.0,
        total_interventions=sum(intervention_groups.values()),
        intervention_groups=intervention_groups,
        active_days=len(by_day),
        current_streak_days=streak,
        best_streak_days=best,
        best_day=best_day,
        best_session=best_session_out,
        daily=daily,
    )


# ---------------------------------------------------------------------------
# WebSocket  Elive focus stream in, live state + interventions out
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Parent module (OUTPUT): focus alerts + realtime push. Deliberately carries
# no chat/notes content  Eonly focus state, off-task and session summaries.
# ---------------------------------------------------------------------------

# parent_id -> set of live WebSockets (parents watching the dashboard).
_PARENT_SOCKETS: dict[int, set] = {}


def _push_parent_sockets(parent_id: int, frame: dict) -> None:
    """Best-effort push to a guardian's open dashboard sockets. Safe to call
    from the event loop; from a worker thread it's skipped (the parent's
    HTTP poll picks the alert up instead)."""
    sockets = _PARENT_SOCKETS.get(parent_id)
    if not sockets:
        return
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return
    for ws in list(sockets):
        try:
            asyncio.ensure_future(ws.send_json(frame))
        except Exception:
            sockets.discard(ws)


# Feed-rows kept per guardian: the live list is the newest 60 and the API
# caps at 500, so nothing ever reads past this  Ebut the table itself stays
# bounded no matter how many students are linked or how long the term runs.
_PARENT_ALERT_CAP = 1000


def _prune_parent_alerts(db: Session, parent_id: int) -> None:
    """Drop alerts beyond the newest _PARENT_ALERT_CAP for one guardian.
    Runs on insert (alerts are already throttled to a calm rate), so the
    table can never grow unbounded and every /parent/alerts query stays
    fast with many students."""
    stale = (
        db.query(models.ParentAlert.id)
        .filter(models.ParentAlert.parent_id == parent_id)
        .order_by(models.ParentAlert.created_at.desc())
        .offset(_PARENT_ALERT_CAP)
        .limit(500)
        .all()
    )
    if stale:
        db.query(models.ParentAlert).filter(
            models.ParentAlert.id.in_([r[0] for r in stale])
        ).delete(synchronize_session=False)
        db.commit()


def _emit_parent_alert(
    db: Session,
    student_id: Optional[int],
    kind: str,
    message: str,
    payload: Optional[dict] = None,
    session_id: Optional[int] = None,
) -> None:
    """Persist an alert for the student's linked guardian + push it live.
    Returns silently when the student has no guardian (adult/self-managed
    accounts) or when anything goes wrong  Ealerts must never break the
    focus loop."""
    if student_id is None:
        return
    try:
        student = db.query(models.User).filter(models.User.id == student_id).first()
        if student is None or student.parent_id is None:
            return
        row = models.ParentAlert(
            parent_id=student.parent_id,
            student_id=student_id,
            session_id=session_id,
            kind=kind,
            message=message,
            payload=json.dumps(payload or {}),
        )
        db.add(row)
        db.commit()
        db.refresh(row)
        _prune_parent_alerts(db, student.parent_id)
        _push_parent_sockets(student.parent_id, {
            "type": "alert",
            "alert": {
                "id": row.id,
                "student_id": student_id,
                "student_name": student.full_name or student.serial_number,
                "session_id": session_id,
                "kind": kind,
                "message": message,
                "payload": payload or {},
                "read_at": None,
                "created_at": row.created_at.isoformat() if row.created_at else None,
            },
        })
    except Exception:
        logger.exception("parent alert (%s) failed for student %s", kind, student_id)


# Wire the guardian-alert emitter into the admin router (it creates accounts
# but can't import this module without a cycle).
admin_router.set_parent_alert_emitter(_emit_parent_alert)


# ---------------------------------------------------------------------------
# Guardian site presence (Family-Link-style "where is my student / what do
# they use most"). Presence only  Ewhich site, never what's on it.
# ---------------------------------------------------------------------------

# Per-student throttle for the "is now on X" feed alert: real tab changes
# land seconds apart during normal browsing; a flipbook must not flood.
_SITE_ALERT_MIN_GAP_SEC = 3.0
# Repeats: a guardian sees NO value in "now on youtube" 40 times when the
# student flip-flops youtube <-> facebook. Each destination may re-alert
# at most this often; genuine new destinations pass immediately.
_SITE_ALERT_REPEAT_SEC = 45.0
# Quiet window across ALL destinations for one student: once anything has
# been announced, a flip-flop among already-seen sites yields at most one
# calm alert per minute instead of one per destination. A destination the
# guardian has never been told about bypasses this  Efirst sight is the
# news ("student just opened a brand-new site").
_SITE_ALERT_STUDENT_GAP_SEC = 60.0
# The study tab itself appears in the live card and most-used list but
# never raises a feed alert  Ereturning to Stubilly isn't news, the
# destinations are.
_SITE_ALERT_QUIET = {"stubilly"}
_site_alert_last: dict[int, tuple[str, float]] = {}
# site/app -> monotonic time last emitted for that student (repeat gate).
_site_alert_recency: dict[int, dict[str, float]] = {}

# App-change alerts ride the same throttle as site changes, with their own
# quiet list: shell/system processes fire constantly and say nothing a
# guardian needs ("explorer" is not news).
_APP_ALERT_QUIET = {
    "explorer", "searchhost", "startmenuexperiencehost", "textinputhost",
    "shellexperiencehost", "applicationframehost", "systemsettings",
    "sihost", "ctfmon", "stubilly-backend", "python", "powershell",
    "cmd", "windowsterminal",
}
_app_alert_last: dict[int, tuple[str, float]] = {}
_app_alert_recency: dict[int, dict[str, float]] = {}


def _feed_alert_allowed(
    state: dict[int, tuple[str, float]],
    recency: dict[int, dict[str, float]],
    user_id: int,
    dest: str,
    prev_dest_known: bool,
    prev_dest: Optional[str],
) -> Optional[float]:
    """Gate for the guardian feed's "now on X / now using X" alerts.
    Returns the timestamp to record when the alert MAY fire, None when
    suppressed. Layers: (1) the 3s global gap with the same-as-last
    suppression, (2) a per-student quiet window across ALL destinations
    so an A<->B flipbook calms down to one alert per minute, (3) a
    per-destination repeat cooldown. Brand-new destinations bypass the
    quiet window  Efirst sight is the news."""
    now = time.time()
    last = state.get(user_id)
    seen = recency.setdefault(user_id, {})
    first_time = dest not in seen
    if last is not None:
        same_as_last = last[0] == dest
        cooled = now - last[1] >= _SITE_ALERT_MIN_GAP_SEC
        returning = prev_dest_known and prev_dest == dest
        if (same_as_last and not returning) or not cooled:
            return None
        # Quiet window: only fresh destinations skip it.
        if not first_time and now - last[1] < _SITE_ALERT_STUDENT_GAP_SEC:
            return None
    if not first_time and now - seen.get(dest, 0.0) < _SITE_ALERT_REPEAT_SEC:
        return None
    if len(seen) > 32:
        for old in [k for k, t in seen.items() if now - t > 600]:
            seen.pop(old, None)
    return now
# Last time the parental-rules check ran per open session (throttled so
# the tick loop doesn't hit the DB for settings on every single frame).
_rule_check_state: dict[int, float] = {}


def _clean_site(raw) -> str:
    """Normalize a reported foreground site to a bare lowercase host (or the
    single token "stubilly"). Empty string when nothing usable."""
    value = str(raw or "").strip().lower()
    if not value or len(value) > 80:
        return ""
    if "://" in value:
        value = value.split("://", 1)[1]
    value = value.split("/", 1)[0].split("?", 1)[0].split("#", 1)[0].split(":", 1)[0]
    value = value.strip()
    if value == "stubilly":
        return value
    # Real sites carry a dot ("youtube.com"); bare app names ("word") are
    # not sites  Ethe off-task app alert already covers those.
    if not value or " " in value or "." not in value:
        return ""
    return value[:80]


def _clean_app(raw) -> str:
    """Normalize a reported foreground app to a bare lowercase process
    name ("chrome"). Empty string when nothing usable."""
    value = str(raw or "").strip().lower()
    if not value or len(value) > 60:
        return ""
    if "/" in value or "\\" in value:
        value = value.split("\\")[-1].split("/")[-1]
    if value.endswith(".exe"):
        value = value[:-4]
    value = "".join(ch for ch in value if ch.isalnum() or ch in "._-")
    if not value or " " in value:
        return ""
    return value[:40]


def _screen_seconds_today(db: Session, user_id: int) -> float:
    """Today's accumulated screen seconds (own counter  Enever the sum of
    site+app rows, which would double-count every tick)."""
    row = (
        db.query(models.ScreenTime)
        .filter(models.ScreenTime.user_id == user_id,
                models.ScreenTime.day == datetime.now().strftime("%Y-%m-%d"))
        .first()
    )
    return float(row.seconds) if row else 0.0


def _parental_block_reason(db: Session, user_id: Optional[int]) -> Optional[str]:
    """Family-Link-style screen rules: returns a student-facing reason when
    the guardian's rules forbid a session RIGHT NOW, else None.

    Checked at session start (403) and re-checked on every focus tick, so
    a pause toggle or a crossed daily limit ends a running session within
    a tick. Lives here rather than in admin.py because main.py owns the
    session lifecycle; it reads the same effective_settings the rest of
    the system uses."""
    if user_id is None:
        return None
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user is None:
        return None
    settings = admin_router.effective_settings(user)
    if settings.get("device_paused"):
        return "Your parent paused this device  Estudy time is off."
    limit = settings.get("daily_screen_limit_min")
    if isinstance(limit, int) and not isinstance(limit, bool):
        used = _screen_seconds_today(db, user_id)
        if used >= limit * 60:
            if limit <= 0:
                return "Your parent set today's screen time to 0 minutes."
            return f"Daily screen time limit reached ({limit} min)."
    start = settings.get("downtime_start")
    end = settings.get("downtime_end")
    if start and end:
        now_hm = datetime.now().strftime("%H:%M")
        in_window = (start <= now_hm < end) if start < end else (now_hm >= start or now_hm < end)
        if in_window:
            return f"Downtime  Escreens off from {start} to {end}."
    return None


def _track_site_visit(db: Session, user_id: Optional[int], site: str,
                      session_id: Optional[int] = None,
                      attempt: bool = False,
                      app: Optional[str] = None) -> None:
    """Upsert today's presence rows for this student: time-on-site (when
    `site` is given), time-on-app (when `app` is given), and the day's
    screen-time counter  Ethe latter accrues ONE delta per observation no
    matter how many presence rows that observation touches (summing
    site+app seconds would double-count every tick).

    When the foreground CHANGED (site or app switched, or the student
    returned to the same thing after >2 min away) push a live site_status
    frame to the guardian and add a throttled "is now on X" / "is now
    using Y" alert to their feed. Best-effort by design: an error here
    must never disturb the focus loop. attempt=True marks a hosts-file
    interceptor hit (browser mode's browsing signal), which credits a few
    seconds per distinct hit instead of tick deltas."""
    site = _clean_site(site) or None
    app = _clean_app(app) or None
    if user_id is None or (site is None and app is None):
        return
    try:
        now = datetime.now()
        day = now.strftime("%Y-%m-%d")

        # Change detection needs the PRE-mutation view: the previous rows
        # (and their staleness) are captured before any upsert below  E        # otherwise the very row being refreshed looks "fresh" and a
        # stale same-site/app return would never be noticed.
        prev_site = (
            db.query(models.SiteVisit)
            .filter(models.SiteVisit.user_id == user_id)
            .order_by(models.SiteVisit.last_seen.desc())
            .first()
            if site else None
        )
        prev_app = (
            db.query(models.AppVisit)
            .filter(models.AppVisit.user_id == user_id)
            .order_by(models.AppVisit.last_seen.desc())
            .first()
            if app else None
        )
        prev_site_name = prev_site.site if prev_site else None
        prev_app_name = prev_app.app if prev_app else None
        site_gap = (now - prev_site.last_seen).total_seconds() if prev_site else None
        app_gap = (now - prev_app.last_seen).total_seconds() if prev_app else None

        def _upsert_visit(model, field: str, name: str) -> float:
            """Upsert the day row; returns the seconds this observation
            credited (0 when the row was merely touched) so the same delta
            can be mirrored into the session-scoped activity rows."""
            row = (
                db.query(model)
                .filter(model.user_id == user_id,
                        getattr(model, field) == name,
                        model.day == day)
                .first()
            )
            if row is None:
                credited = 3.0 if attempt else 0.0
                row = model(
                    user_id=user_id, day=day,
                    first_seen=now, last_seen=now,
                    # A hosts-intercepted hit IS a real visit: open the row
                    # with credit so a single brief trip still ranks in
                    # "most used" (tick-based rows earn on the next tick).
                    seconds=credited,
                )
                setattr(row, field, name)
                try:
                    # Savepoint the insert: the interceptor thread and the
                    # focus tick can both see "no row yet" for the same
                    # day, and the loser must fall back to an update
                    # instead of losing the whole observation.
                    with db.begin_nested():
                        db.add(row)
                        # Keep the table bounded  Ea month of history is plenty.
                        cutoff = (now - timedelta(days=30)).strftime("%Y-%m-%d")
                        (db.query(model)
                           .filter(model.day < cutoff)
                           .delete(synchronize_session=False))
                    return credited
                except IntegrityError:
                    row = (
                        db.query(model)
                        .filter(model.user_id == user_id,
                                getattr(model, field) == name,
                                model.day == day)
                        .first()
                    )
                    if row is None:
                        return 0.0
            delta = (now - row.last_seen).total_seconds()
            credited = 0.0
            if attempt:
                # A page load fires a burst of interceptor hits; credit
                # at most one bump per 2 seconds so the burst counts
                # once while a longer stay still accumulates.
                if delta >= 2.0:
                    credited = max(delta, 3.0)
                    row.seconds += credited
            elif 0 < delta <= 30:
                credited = delta
                row.seconds += delta
            row.last_seen = now
            return credited

        def _credit_session(kind: str, name: str, credited: float) -> None:
            """Mirror the credited delta into the session-scoped activity
            rollup so the guardian can replay a session's sites/apps/screen
            time (per session and per day)."""
            if session_id is None or credited <= 0:
                return
            arow = (
                db.query(models.SessionActivity)
                .filter(models.SessionActivity.session_id == session_id,
                        models.SessionActivity.kind == kind,
                        models.SessionActivity.name == name)
                .first()
            )
            if arow is None:
                try:
                    # Same savepoint guard as the day-row upsert: two
                    # observers can race to create today's rollup row.
                    with db.begin_nested():
                        db.add(models.SessionActivity(
                            session_id=session_id, user_id=user_id, kind=kind,
                            name=name, seconds=credited, first_seen=now,
                            last_seen=now,
                        ))
                        (db.query(models.SessionActivity)
                           .filter(models.SessionActivity.first_seen
                                   < (now - timedelta(days=45)))
                           .delete(synchronize_session=False))
                    return
                except IntegrityError:
                    arow = (
                        db.query(models.SessionActivity)
                        .filter(models.SessionActivity.session_id == session_id,
                                models.SessionActivity.kind == kind,
                                models.SessionActivity.name == name)
                        .first()
                    )
                    if arow is None:
                        return
            arow.seconds += credited
            arow.last_seen = now

        if site:
            _credit_session("site", site, _upsert_visit(models.SiteVisit, "site", site))
        if app:
            _credit_session("app", app, _upsert_visit(models.AppVisit, "app", app))

        # Screen-time counter: independent last_seen, single delta.
        screen = (
            db.query(models.ScreenTime)
            .filter(models.ScreenTime.user_id == user_id,
                    models.ScreenTime.day == day)
            .first()
        )
        screen_credited = 0.0
        screen_row_fresh = False
        if screen is None:
            screen_row_fresh = True
            screen_credited = 3.0 if attempt else 0.0
            screen = models.ScreenTime(
                user_id=user_id, day=day, last_seen=now,
                seconds=screen_credited,
            )
            try:
                with db.begin_nested():
                    db.add(screen)
                    cutoff = (now - timedelta(days=30)).strftime("%Y-%m-%d")
                    (db.query(models.ScreenTime)
                       .filter(models.ScreenTime.day < cutoff)
                       .delete(synchronize_session=False))
            except IntegrityError:
                screen = (
                    db.query(models.ScreenTime)
                    .filter(models.ScreenTime.user_id == user_id,
                            models.ScreenTime.day == day)
                    .first()
                )
                if screen is None:
                    raise
                # lost the race  Ecredit as an update on the winner's row
                screen_row_fresh = False
                screen_credited = 0.0
        if not screen_row_fresh:
            delta = (now - screen.last_seen).total_seconds()
            if attempt:
                if delta >= 2.0:
                    screen_credited = max(delta, 3.0)
                    screen.seconds += screen_credited
            elif 0 < delta <= 30:
                screen_credited = delta
                screen.seconds += delta
            screen.last_seen = now
        _credit_session("screen", "", screen_credited)
        db.commit()

        site_changed = (
            site is not None
            and (prev_site is None or prev_site_name != site
                 or (site_gap is not None and site_gap > 120))
        )
        app_changed = (
            app is not None
            and (prev_app is None or prev_app_name != app
                 or (app_gap is not None and app_gap > 120))
        )
        if not site_changed and not app_changed:
            return
        student = db.query(models.User).filter(models.User.id == user_id).first()
        if student is None or student.parent_id is None:
            return

        # Live card update on any change  Ethe primary "where are they"
        # surface: merged site+app, inside-Stubilly flag, day's screen time.
        push_site = site or prev_site_name
        push_app = app or prev_app_name
        _push_parent_sockets(student.parent_id, {
            "type": "site_status",
            "student_id": student.id,
            "student_name": student.full_name or student.serial_number,
            "site": push_site,
            "app": push_app,
            "in_stubilly": push_site == "stubilly",
            "screen_seconds_today": round(_screen_seconds_today(db, user_id), 1),
            "at": now.isoformat(),
        })

        # Feed alerts: destinations only (quiet sites/apps stay card-only),
        # rate-limited per student: a 3s global gap PLUS a per-destination
        # repeat cooldown so a youtube<->facebook flipbook collapses into
        # one calm alert per destination instead of flooding the feed.
        if site_changed and site not in _SITE_ALERT_QUIET:
            stamp = _feed_alert_allowed(
                _site_alert_last, _site_alert_recency, user_id, site,
                prev_site is not None, prev_site_name,
            )
            if stamp is not None:
                _site_alert_last[user_id] = (site, stamp)
                _site_alert_recency.setdefault(user_id, {})[site] = stamp
                _emit_parent_alert(
                    db, user_id, "site_visit",
                    f"{student.full_name or student.serial_number} is now on "
                    f"\"{site}\".",
                    {"site": site, "session_id": session_id},
                    session_id=session_id,
                )
        if app_changed and app not in _APP_ALERT_QUIET:
            stamp = _feed_alert_allowed(
                _app_alert_last, _app_alert_recency, user_id, app,
                prev_app is not None, prev_app_name,
            )
            if stamp is not None:
                _app_alert_last[user_id] = (app, stamp)
                _app_alert_recency.setdefault(user_id, {})[app] = stamp
                _emit_parent_alert(
                    db, user_id, "app_visit",
                    f"{student.full_name or student.serial_number} is now using "
                    f"\"{app}\".",
                    {"app": app, "session_id": session_id},
                    session_id=session_id,
                )
    except Exception:
        logger.exception("site-visit tracking failed for user %s (%s)", user_id, site)


async def _record_blocked_site_visit(site: str) -> None:
    """site_blocking interceptor hook: hosts-file hits arrive on listener
    threads  Ehop onto the loop, then attribute the visit to this
    machine's student (open focus socket, else the most recent session)."""
    try:
        await asyncio.to_thread(_record_blocked_site_visit_sync, site)
    except Exception:
        logger.exception("blocked-site visit record failed (%s)", site)


def _resolve_machine_student(db: Session) -> Optional[int]:
    """Who is on THIS machine right now: the open focus socket when there
    is one (the newest session wins when several), else the most recent
    session started within 30 minutes. None when nobody can be identified.
    Shared by presence recording AND blocked-attempt attribution."""
    focus_ids = site_blocking.active_focus_user_ids()
    if len(focus_ids) == 1:
        return focus_ids[0]
    if len(focus_ids) > 1:
        row = (db.query(models.StudySession)
               .filter(models.StudySession.user_id.in_(focus_ids))
               .order_by(models.StudySession.started_at.desc()).first())
        return row.user_id if row else None
    # No open socket (brief reload): the most recent session that started
    # within 30 minutes still reflects who is on this machine. Freshness
    # is compared in Python  ESQLite may hand back naive or aware
    # datetimes depending on how the row was written, and a mismatched
    # comparison would raise.
    rows = (db.query(models.StudySession)
            .filter(models.StudySession.user_id.isnot(None))
            .order_by(models.StudySession.started_at.desc())
            .limit(10).all())
    now = datetime.now(timezone.utc)
    for row in rows:
        started = row.started_at
        if started is None:
            continue
        if started.tzinfo is None:
            started = started.replace(tzinfo=timezone.utc)
        if now - started <= timedelta(minutes=30):
            return row.user_id
    return None


def _record_blocked_site_visit_sync(site: str) -> None:
    db = next(get_db())
    try:
        user_id = _resolve_machine_student(db)
        if user_id is None:
            return
        # Attribute the visit to the student's OPEN session when there is
        # one  Eso browsing shows up in the guardian's per-session history,
        # not just the day's totals.
        active = (
            db.query(models.StudySession)
            .filter(models.StudySession.user_id == user_id,
                    models.StudySession.ended_at.is_(None))
            .order_by(models.StudySession.started_at.desc())
            .first()
        )
        _track_site_visit(db, user_id, site, active.id if active else None,
                          attempt=True)
    finally:
        db.close()


def _attribute_blocked_attempt(site: str) -> Optional[int]:
    """site_blocking hook: stamp each blocked_attempt with the machine's
    student so live fan-out AND connect-time replay only reach THAT
    student's own tabs (never siblings, guardians, or other accounts)."""
    db = next(get_db())
    try:
        return _resolve_machine_student(db)
    except Exception:
        return None
    finally:
        db.close()


site_blocking.set_site_visit_recorder(_record_blocked_site_visit)
site_blocking.set_user_attribution(_attribute_blocked_attempt)


# How often an open user socket refreshes its own token. Comfortably under
# auth_service.USER_TOKEN_TTL_SEC (75s) so an idle-but-open app is never
# mistaken for a signed-out one.
_SOCKET_KEEPALIVE_SEC = 30


async def _socket_keepalive(websocket: WebSocket, token: str) -> None:
    """Hold an authenticated socket open, keeping its token alive.

    A student or parent who leaves the app open without clicking anything
    makes no HTTP request, so the token aged past the presence TTL and the
    next call answered 401 - the app then claimed the session had expired
    even though the tab was never closed. Touching the token from the
    SERVER side fixes that regardless of what the browser does with
    timers, because a hidden tab throttles them to roughly once a minute.

    The small {"type": "ping"} frame also keeps intermediaries from
    dropping an idle socket. Returns when the client disconnects (or the
    token is gone, e.g. after an explicit sign-out)."""
    while True:
        try:
            await asyncio.wait_for(websocket.receive_text(), timeout=_SOCKET_KEEPALIVE_SEC)
        except asyncio.TimeoutError:
            pass
        except WebSocketDisconnect:
            return
        if auth_service.touch_user_token(token) is None:
            return
        try:
            await websocket.send_json({"type": "ping"})
        except Exception:
            return


# ---------------------------------------------------------------------------
# WebSockets
# ---------------------------------------------------------------------------

@app.websocket("/ws/notifications")
async def notifications_stream(websocket: WebSocket):
    """Push channel for blocked-site attempts, scoped to ONE student.

    Connect with `?token=<user token>` (WS cannot send headers)  Ethe
    authenticated user owns the socket, and every blocked_attempt carries
    the attributed machine-student, so only THEIR tabs are notified.

    Server sends:
        {"type": "blocked_attempt", "site": "...", "at": <epoch>,
         "user_id": <attributed student>}
        {"type": "ping"} (keepalive, see _socket_keepalive)

    On connect it also replays the short in-memory buffer so a tab that
    opens just after an attempt still hears about it  Efiltered to this
    user's own attempts. Client messages are ignored (keepalive only)."""
    token = websocket.query_params.get("token") or ""
    await websocket.accept()
    user_id = auth_service.get_user_from_token(token, touch=True)
    if not user_id:
        await websocket.close(code=4401)
        return
    site_blocking.set_client_origin(websocket.headers.get("host"))
    site_blocking.register_notify_ws(websocket, user_id)
    try:
        for entry in site_blocking.recent_attempts():
            # Only replay fresh attempts from THIS student  Ea tab opened
            # hours later must not re-alarm for an old hit, and another
            # student's hit never belongs here (client also dedups ~12s).
            if entry.get("user_id") != user_id:
                continue
            try:
                age = time.time() - float(entry.get("at") or 0)
            except (TypeError, ValueError):
                continue
            if age <= 30:
                await websocket.send_json(entry)
        await _socket_keepalive(websocket, token)
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.exception("notifications stream failed")
    finally:
        site_blocking.unregister_notify_ws(websocket)


@app.websocket("/ws/admin")
async def admin_presence_stream(websocket: WebSocket):
    """Admin Hub presence channel.

    Connect with `?token=<admin token>` (WS cannot send Authorization
    headers). On open the server snapshots every student's online/status,
    then pushes {"type":"presence", "user_id", "online", "status",
    "current_task"} whenever a value changes  Elogin, logout, focus-state
    flips, and the background sweeper. Client messages are ignored
    (keepalive only). The hub's 4s poll remains as fallback."""
    token = websocket.query_params.get("token") or ""
    if not auth_service.is_admin_token(token):
        # Accept first: closing pre-accept is a bare HTTP 403 handshake reject,
        # which browsers surface as a generic error with no close code. After
        # accept, close(4401) arrives as evt.code so the hub can show
        # "session expired" instead of reconnect-looping a dead admin token.
        await websocket.accept()
        await websocket.close(code=4401)
        return
    admin_id = auth_service.get_admin_id(token)
    await websocket.accept()
    site_blocking.register_admin_ws(websocket, admin_id)
    try:
        # Snapshot who is already around, then announce this join so other
        # hubs flip the chat roster dot live (clients dedupe by admin id).
        await websocket.send_json({
            "type": "admin_roster",
            "online_admin_ids": site_blocking.admin_online_ids(),
        })
        if admin_id is not None:
            site_blocking.broadcast_admin_presence({
                "type": "admin_presence",
                "admin_id": admin_id,
                "online": True,
            })
        db = next(get_db())
        try:
            for user in db.query(models.User).all():
                status, task = admin_router._user_status(db, user)
                await websocket.send_json({
                    "type": "presence",
                    "user_id": user.id,
                    "online": status != "offline",
                    "status": status,
                    "current_task": task,
                })
        finally:
            db.close()
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        site_blocking.unregister_admin_ws(websocket)


@app.websocket("/ws/parent")
async def parent_stream(websocket: WebSocket):
    """Parent/guardian realtime channel.

    Connect with `?token=<student-user token>` (WS cannot send headers).
    Only accounts with role="parent" are accepted; the server replays unread
    alerts on open, then pushes {"type":"alert", "alert": {...}} live.
    Client messages are ignored (keepalive only). The parent dashboard's
    HTTP poll of /parent/alerts remains the fallback."""
    token = websocket.query_params.get("token") or ""
    await websocket.accept()
    user_id = auth_service.get_user_from_token(token, touch=True)
    db = next(get_db())
    user = db.query(models.User).filter(models.User.id == user_id).first() if user_id else None
    if user is None or not user.is_active or (user.role or "student") != "parent":
        await websocket.close(code=4401)
        return
    parent_id = user.id
    _PARENT_SOCKETS.setdefault(parent_id, set()).add(websocket)
    try:
        unread = (
            db.query(models.ParentAlert)
            .filter(models.ParentAlert.parent_id == parent_id,
                    models.ParentAlert.read_at.is_(None))
            .order_by(models.ParentAlert.created_at.desc())
            .limit(50)
            .all()
        )
        names = {
            u.id: (u.full_name or u.serial_number)
            for u in db.query(models.User)
            .filter(models.User.id.in_([r.student_id for r in unread])).all()
        } if unread else {}
        for row in reversed(unread):
            await websocket.send_json({
                "type": "alert",
                "alert": {
                    "id": row.id,
                    "student_id": row.student_id,
                    "student_name": names.get(row.student_id, ""),
                    "session_id": row.session_id,
                    "kind": row.kind,
                    "message": row.message,
                    "payload": json.loads(row.payload) if row.payload else {},
                    "read_at": None,
                    "created_at": row.created_at.isoformat() if row.created_at else None,
                },
            })
        await _socket_keepalive(websocket, token)
    except WebSocketDisconnect:
        pass
    except Exception:
        logger.exception("parent stream failed")
    finally:
        _PARENT_SOCKETS.get(parent_id, set()).discard(websocket)


def _check_in_seed(db: Session, user_id: Optional[int]) -> float:
    """FEEDBACK LOOP across runs: the student's last finished run seeds this
    run's check-in cadence  E<60% focus checks in 0.7x sooner, >=80% gets
    1.25x more space, anything else (or no history) runs at the configured
    1.0x cadence. Progress data literally adjusting future check-ins."""
    if user_id is None:
        return 1.0
    prev = (
        db.query(models.StudySession)
        .filter(
            models.StudySession.user_id == user_id,
            models.StudySession.ended_at.isnot(None),
        )
        .order_by(models.StudySession.ended_at.desc())
        .first()
    )
    if prev is None:
        return 1.0
    dur = (prev.total_focused_seconds or 0.0) + (prev.total_distracted_seconds or 0.0)
    if dur <= 0:
        return 1.0
    pct = (prev.total_focused_seconds or 0.0) / dur
    if pct >= 0.8:
        return 1.25
    if pct < 0.6:
        return 0.7
    return 1.0


async def _upgrade_intervention_message(
    session_id: int,
    intervention_id: int,
    task_desc: str,
    seconds_in_state: int,
    websocket: WebSocket,
) -> None:
    """Replace an already-shown alarm's wording with the LLM's, once it lands.

    The alarm itself is sent immediately from the focus loop with a fixed,
    task-aware line, because waiting on the model made the intervention feel
    broken: Ollama serves one request at a time, so with a couple of students
    working at once a nudge could take many seconds to appear. This task runs in
    the background and only improves the sentence. It reuses the SAME
    intervention row (no second alarm, no double count) and pushes a single
    "intervention_update" frame for the student's UI to swap in.
    """
    try:
        text = await ollama_client.generate_nudge_message(task_desc, seconds_in_state)
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.debug("nudge upgrade failed for intervention %s", intervention_id,
                     exc_info=True)
        return
    if not text or not str(text).strip():
        return
    text = str(text).strip()
    try:
        db = next(get_db())
        try:
            row = (db.query(models.Intervention)
                   .filter(models.Intervention.id == intervention_id)
                   .first())
            if row is None or (row.message or "") == text:
                return
            row.message = text
            db.commit()
        finally:
            db.close()
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.debug("nudge upgrade write failed for %s", intervention_id, exc_info=True)
        return
    try:
        await websocket.send_json({
            "type": "intervention_update",
            "id": intervention_id,
            "message": text,
        })
    except Exception:
        # The student's socket is gone; the improved wording still shows in
        # their session summary.
        pass


async def _upgrade_check_in_message(
    session_id: int,
    check_in_id: int,
    task_desc: str,
    minutes_in: int,
    tone: str,
    focus_pct: Optional[float],
    websocket: WebSocket,
) -> None:
    """Rewrite a just-fired check-in with the model's task-aware wording.

    Mirrors _upgrade_intervention_message: the check-in is shown immediately
    with a fixed, task-aware line (so it never feels broken when Ollama is
    busy), then this background task improves the sentence in place  Esame
    row, no duplicate check-in, one "intervention_update" frame to swap in.
    Only used when the student opted into generative check-ins."""
    try:
        text = await ollama_client.generate_check_in_prompt(
            task_desc, minutes_in, tone, focus_pct,
        )
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.debug("check-in upgrade failed for %s", check_in_id, exc_info=True)
        return
    if not text or not str(text).strip():
        return
    text = str(text).strip()
    try:
        db = next(get_db())
        try:
            row = (db.query(models.Intervention)
                   .filter(models.Intervention.id == check_in_id)
                   .first())
            if row is None or (row.message or "") == text:
                return
            row.message = text
            db.commit()
        finally:
            db.close()
    except asyncio.CancelledError:
        raise
    except Exception:
        logger.debug("check-in upgrade write failed for %s", check_in_id, exc_info=True)
        return
    try:
        await websocket.send_json({
            "type": "intervention_update",
            "id": check_in_id,
            "message": text,
        })
    except Exception:
        pass


@app.websocket("/ws/{session_id}")
async def focus_stream(websocket: WebSocket, session_id: int):
    """
    Frontend sends one JSON message per webcam inference tick:
        {"state": "focused", "confidence": 0.92, "eye_aspect_ratio": 0.28, ...}

    Backend logs it, runs it through the state machine, and pushes back:
        {"type": "state_update", "state": "distracted", "seconds_in_state": 45}
        {"type": "intervention", "intervention_type": "alarm", "message": "..."}
    """
    # Optional student token (?token=...)  Eeach focus frame touches it so a
    # mid-session student stays "online" in the Admin Hub even when the 5s
    # HTTP policy poll is throttled by a backgrounded tab. When the session
    # belongs to an account, a matching token is REQUIRED (ownership check so
    # a stranger can't inject events into / read another student's stream).
    presence_token = websocket.query_params.get("token") or None

    db = None
    session = None
    runtime = None
    try:
        db = next(get_db())
        session = db.query(models.StudySession).filter(models.StudySession.id == session_id).first()
        if session is None:
            await websocket.accept()
            await websocket.close(code=4404)
            return
        caller_id = auth_service.get_user_from_token(presence_token, touch=True)
        if session.user_id is not None:
            if caller_id != session.user_id:
                await websocket.accept()
                await websocket.close(code=4401)
                return
        # Legacy unowned session: if any accounts exist, require a live token.
        elif caller_id is None and admin_router.db_has_users(db):
            await websocket.accept()
            await websocket.close(code=4401)
            return

        await websocket.accept()
        # Capture the origin this tab is served from so the HTTP interceptor can
        # 302 blocked HTTP hits back to the same host:port (/blocked?site=...).
        site_blocking.set_client_origin(websocket.headers.get("host"))
        runtime = state_machine.get_or_create_runtime(session_id)
        runtime.open_connections += 1
        runtime.detached_at = None
        # An attaching socket makes the session live again (first attach
        # after Start, or a resume after a reload)  Ere-derive hosts now so
        # blocking follows the actual session, not a stale row.
        try:
            await asyncio.to_thread(site_blocking.refresh_enforcement)
        except Exception:
            logger.exception("site blocking refresh on focus socket attach failed")
        task_desc = session.task_description
        # Student settings drive this run: adaptive check-in cadence, nudge
        # tone, voice flag (input layer of the framework). Defaults when the
        # session has no account or the row has no settings stored.
        session_user = (
            db.query(models.User).filter(models.User.id == session.user_id).first()
            if session.user_id is not None
            else None
        )
        runtime.configure(
            admin_router.effective_settings(session_user),
            seed=_check_in_seed(db, session.user_id),
        )
        if session.user_id is not None:
            site_blocking.register_focus_ws(session.user_id, websocket)
            # Parent output: "your student started focusing" (real-time alert).
            _emit_parent_alert(
                db, session.user_id, "focus_started",
                f"{session_user.full_name or session_user.serial_number} started focusing on "
                f"\"{task_desc[:80]}\".",
                {"session_id": session_id, "task": task_desc[:200]},
            )

        while True:
            payload = await websocket.receive_json()
            if presence_token:
                auth_service.get_user_from_token(presence_token, touch=True)

            # Validate the tick before writing  Ea malformed frame must not
            # tear down the socket mid-session (KeyError / NULL confidence).
            state_val = payload.get("state")
            if not isinstance(state_val, str) or not state_val:
                continue
            conf = payload.get("confidence", 0.0)
            try:
                conf = float(conf) if conf is not None else 0.0
            except (TypeError, ValueError):
                conf = 0.0
            face_raw = payload.get("face_detected", True)
            try:
                face_detected = int(bool(face_raw)) if not isinstance(face_raw, str) else int(face_raw.lower() != "false")
            except (TypeError, ValueError):
                face_detected = 1 if face_raw else 0
            app_state = payload.get("app_state")
            if app_state not in ("on_task", "off_task", None):
                app_state = None
            # Stubilly itself is never off-task: the student is studying in it.
            # (probe is assigned below; override applied after probe read)

            # --- Input signals for the paralysis classifier + gaze analytics ---
            idle_raw = payload.get("idle_seconds")
            try:
                idle_seconds = float(idle_raw) if idle_raw is not None else None
            except (TypeError, ValueError):
                idle_seconds = None
            if idle_seconds is not None and idle_seconds < 0:
                idle_seconds = None
            gaze = payload.get("gaze_direction")
            if gaze not in ("center", "left", "right", "down", "up", None):
                gaze = None

            # Foreground merge: the client's reading wins (Electron carries
            # richer data and tests fake it deterministically); the backend's
            # own Windows-API probe fills the gaps  Ebrowser mode, where the
            # page itself can't see any other window. One instantaneous
            # ctypes snapshot per tick, never a loop.
            probe = None
            try:
                probe = await asyncio.to_thread(window_probe.read_foreground)
            except Exception:
                probe = None
            client_app = str(payload.get("active_app") or "").strip() or None
            client_site = _clean_site(payload.get("active_site")) or None
            client_title = str(payload.get("active_title") or "").strip()[:120] or None
            merged_app = client_app or (probe or {}).get("app")
            merged_site = client_site or (probe or {}).get("site")
            merged_title = client_title or (probe or {}).get("title")
            # Stubilly itself is never off-task: the student is studying in it.
            # Force on_task whenever the foreground probe says we're in Stubilly,
            # so the 2-min alarm / hard-block path can never fire inside the
            # study app, regardless of what the client classified.
            if (probe or {}).get("in_stubilly") or "stubilly" in str(merged_title or "").lower() or "stubilly" in str(merged_app or "").lower():
                app_state = "on_task"

            event = models.FocusEvent(
                session_id=session_id,
                state=state_val,
                confidence=conf,
                eye_aspect_ratio=payload.get("eye_aspect_ratio"),
                head_pose_yaw=payload.get("head_pose_yaw"),
                head_pose_pitch=payload.get("head_pose_pitch"),
                face_detected=face_detected,
                app_state=app_state,
                active_app=merged_app,
                active_site=_clean_site(merged_site) or None,
                active_title=merged_title,
                idle_seconds=idle_seconds,
                gaze_direction=gaze,
            )
            db.add(event)
            db.commit()

            # Guardian presence: this tick's foreground site + app feed the
            # "currently on / using / most used today" card, the screen-time
            # estimate and the throttled "is now on X" / "is now using Y"
            # alerts (change detection + throttling inside _track_site_visit).
            if session.user_id is not None and (event.active_site or event.active_app):
                _track_site_visit(db, session.user_id, event.active_site,
                                  session_id, app=event.active_app)

            # --- Parental controls (Family-Link style), mid-session ---
            # Re-checked a few seconds apart so a guardian's pause, an
            # entered downtime window or a crossed daily screen limit ends
            # a running session promptly  Estudent sees why (intervention),
            # guardian gets the feed alert, hosts enforcement is lifted.
            now_ts = time.time()
            if (session.user_id is not None
                    and now_ts - _rule_check_state.get(session_id, 0.0) >= 5.0):
                _rule_check_state[session_id] = now_ts
                block_reason = await asyncio.to_thread(
                    _parental_block_reason, db, session.user_id
                )
                if block_reason:
                    limit_iv = models.Intervention(
                        session_id=session_id,
                        intervention_type="screen_limit",
                        trigger_state=state_val,
                        message=block_reason,
                        channel="text",
                    )
                    db.add(limit_iv)
                    db.commit()
                    db.refresh(limit_iv)
                    await websocket.send_json({
                        "type": "intervention",
                        "id": limit_iv.id,
                        "intervention_type": "screen_limit",
                        "message": block_reason,
                        "voice": False,
                        "tone": runtime.tone,
                        "respondable": False,
                    })
                    _emit_parent_alert(
                        db, session.user_id, "screen_limit",
                        f"Session ended: {block_reason}",
                        {"session_id": session_id, "reason": block_reason},
                        session_id=session_id,
                    )
                    await asyncio.to_thread(_finalize_session, db, session, False)
                    await asyncio.to_thread(site_blocking.refresh_enforcement)
                    await websocket.send_json({
                        "type": "session_end",
                        "session_id": session_id,
                        "reason": block_reason,
                    })
                    await websocket.close(code=1000)
                    break

            # Update break status first  Eboth intervention checks below
            # (webcam + app-based) need the current value, not last tick's.
            was_on_break = runtime.on_break
            client_break = bool(payload.get("on_break", False))
            if runtime.break_ends_at is not None:
                # Server-timed break (started via REST or the fallback below):
                # only the timer / the end endpoint stops it  Ethe client's
                # flag can neither shorten it nor steal it back.
                pass
            elif client_break and not runtime.on_break:
                # Client reported a break without hitting the REST endpoint:
                # arm a server timer anyway so it still always expires.
                runtime.start_break(_BREAK_FALLBACK_MINUTES)
            else:
                runtime.set_on_break(client_break)
            if runtime.on_break != was_on_break:
                # Breaks lift system-wide (hosts-file) blocking so the student
                # can actually reach the sites they're allowed to rest on;
                # coming back from break re-applies the admin's blocklist.
                await asyncio.to_thread(site_blocking.refresh_enforcement)

            changed = runtime.update_state(state_val)
            await websocket.send_json({
                "type": "state_update",
                "state": runtime.current_state,
                "state_changed": changed,
                "seconds_in_state": round(runtime.seconds_in_current_state(), 1),
            })

            # Baseline calibration (first ~2 min of ticks) + the paralysis
            # classifier both run BEFORE decide_intervention() so a student
            # who is stuck  Eface present, input dead, not on an off-task
            # window  Egets the paralysis assist instead of the generic
            # "you're distracted" alarm.
            runtime.note_baseline(state_val)
            paralysis_action = runtime.update_paralysis(
                state_val, idle_seconds, bool(face_detected), app_state
            )
            if paralysis_action:
                stuck_for = int(state_machine.PARALYSIS_SUSTAIN_SEC)
                if runtime.tone == "firm":
                    message = (
                        f"You've been still for over {stuck_for} seconds on "
                        f"\"{task_desc[:60]}\"  Epick the smallest next step and do just that."
                    )
                else:
                    message = (
                        f"Looks like you're stuck on \"{task_desc[:60]}\". "
                        f"Want to break the next step down smaller? I can help."
                    )
                paralysis_iv = models.Intervention(
                    session_id=session_id,
                    intervention_type="paralysis",
                    trigger_state=runtime.current_state,
                    message=message,
                    channel="voice" if runtime.voice_mode else "text",
                )
                db.add(paralysis_iv)
                session_row = db.query(models.StudySession).filter(
                    models.StudySession.id == session_id
                ).first()
                if session_row is not None:
                    session_row.paralysis_count = (session_row.paralysis_count or 0) + 1
                db.commit()
                db.refresh(paralysis_iv)
                await websocket.send_json({
                    "type": "intervention",
                    "id": paralysis_iv.id,
                    "intervention_type": "paralysis",
                    "message": message,
                    "voice": runtime.voice_mode,
                    "tone": runtime.tone,
                    "respondable": True,
                })
                if session.user_id is not None:
                    _emit_parent_alert(
                        db, session.user_id, "paralysis",
                        f"{(session_user.full_name if session_user else None) or 'Your student'} "
                        f"seems stuck on their task.",
                        {"session_id": session_id, "state": runtime.current_state},
                    )

            action = runtime.decide_intervention()
            if action:
                # "alarm" covers both triggers now: sleeping gets a fixed,
                # unmissable wake-up line; distracted/absent (the 30-Second
                # Focus Alarm) gets a task-aware line TOO, and it is shown this
                # instant. The LLM wording used to be awaited right here, which
                # delayed the alarm itself by however long the local model took
                # (one request at a time, so seconds under load). A nicer
                # sentence from the model is now applied as an upgrade in the
                # background instead - see _upgrade_intervention_message.
                off_task_secs = int(runtime.seconds_in_current_state())
                if runtime.current_state == "sleeping":
                    message = "Wake up! You've drifted off  Elet's get back to it."
                elif runtime.tone == "firm":
                    message = (
                        f"{off_task_secs} seconds off-task on \"{task_desc[:60]}\" "
                        f" Edrop what you're doing and do just the next step."
                    )
                else:
                    message = (
                        f"You've been off-task for {off_task_secs} seconds on "
                        f"\"{task_desc[:60]}\". Want to pick the next small step?"
                    )
                alarm_iv = models.Intervention(
                    session_id=session_id,
                    intervention_type=action,
                    trigger_state=runtime.current_state,
                    message=message,
                    channel="voice" if runtime.voice_mode else "text",
                )
                db.add(alarm_iv)
                db.commit()
                db.refresh(alarm_iv)
                runtime.mark_intervened()

                await websocket.send_json({
                    "type": "intervention",
                    "id": alarm_iv.id,
                    "intervention_type": action,
                    "message": message,
                    "voice": runtime.voice_mode,
                    "tone": runtime.tone,
                    "respondable": True,
                })

                if runtime.current_state != "sleeping":
                    # Sleeping already got its purpose-built line, so only the
                    # contextual nudge is worth asking the model about.
                    asyncio.create_task(_upgrade_intervention_message(
                        session_id, alarm_iv.id, task_desc, off_task_secs, websocket,
                    ))

            # --- adaptive periodic check-in (student's configured cadence) ---
            if runtime.decide_check_in():
                minutes = max(1, int(runtime.check_in_interval_sec // 60))
                if runtime.tone == "firm":
                    check_msg = (
                        f"Check-in  Eabout {minutes} min in. Where are you on "
                        f"\"{task_desc[:60]}\"? Say if you need a hand."
                    )
                else:
                    check_msg = (
                        f"Quick check-in: how's \"{task_desc[:60]}\" going? "
                        f"Tell me if you're stuck  EI can split the next step."
                    )
                check_iv = models.Intervention(
                    session_id=session_id,
                    intervention_type="check_in",
                    trigger_state=runtime.current_state,
                    message=check_msg,
                    channel="voice" if runtime.voice_mode else "text",
                )
                db.add(check_iv)
                check_row = db.query(models.StudySession).filter(
                    models.StudySession.id == session_id
                ).first()
                if check_row is not None:
                    check_row.check_in_count = (check_row.check_in_count or 0) + 1
                db.commit()
                db.refresh(check_iv)
                await websocket.send_json({
                    "type": "intervention",
                    "id": check_iv.id,
                    "intervention_type": "check_in",
                    "message": check_msg,
                    "voice": runtime.voice_mode,
                    "tone": runtime.tone,
                    "respondable": True,
                    "interval_sec": runtime.check_in_interval_sec,
                    "base_interval_sec": runtime.base_check_in_interval_sec,
                    "adaptive": runtime.check_in_interval_sec != runtime.base_check_in_interval_sec,
                })

                if runtime.adaptive_check_in:
                    window = runtime.window_focused_ticks / max(1, runtime.window_ticks)
                    focus_pct = round(100 * window, 1) if runtime.window_ticks >= 10 else None
                    asyncio.create_task(_upgrade_check_in_message(
                        session_id, check_iv.id, task_desc, minutes, runtime.tone,
                        focus_pct, websocket,
                    ))

            # --- background app/window monitoring track ---
            # Independent of the webcam state above: tracks whether the
            # foreground app/window is on the session's whitelist, and is
            # suppressed entirely while on a Pomodoro break (on_break was
            # already applied above, before either intervention check ran).
            runtime.update_app_state(payload.get("app_state"))

            app_action = runtime.decide_app_intervention()
            if app_action:
                active_app = payload.get("active_app") or "another app"
                if app_action == "off_task_block":
                    message = f"Bringing you back to Stubilly  E\"{active_app}\" is blocked until you're back on \"{task_desc}\"."
                elif app_action == "full_block":
                    message = f"5 minutes off-task: closing \"{active_app}\". Open it again and it closes again  Etake a break or refocus on \"{task_desc}\"."
                else:
                    message = f"You've been on {active_app} for 2 minutes  Etime to refocus on \"{task_desc}\"."

                app_iv = models.Intervention(
                    session_id=session_id,
                    intervention_type=app_action,
                    trigger_state="off_task",
                    message=message,
                    channel="voice" if runtime.voice_mode else "text",
                )
                db.add(app_iv)
                db.commit()
                db.refresh(app_iv)
                runtime.mark_app_intervened()

                await websocket.send_json({
                    "type": "intervention",
                    "id": app_iv.id,
                    "intervention_type": app_action,
                    "message": message,
                    "voice": runtime.voice_mode,
                    "tone": runtime.tone,
                    "respondable": True,
                })

                if app_action == "full_block":
                    # Escalation closes the app (client force-close on the
                    # frame) AND hard-blocks the offending site for the rest
                    # of this session  Esession-scoped, so End Session and
                    # breaks both put it back, like every other ban.
                    _hard_block_site_for_session(db, session, payload)

                # Parent output: first off-task escalation only (the repeats
                # of the 2-Minute Rule stay between student and system).
                if app_action == "app_alarm" and session.user_id is not None:
                    _emit_parent_alert(
                        db, session.user_id, "off_task",
                        f"{(session_user.full_name if session_user else None) or 'Your student'} "
                        f"went off task in \"{active_app}\".",
                        {"session_id": session_id, "app": str(active_app)[:80]},
                    )

    except WebSocketDisconnect:
        logger.info(f"WebSocket disconnected for session {session_id}")
    finally:
        if runtime is not None:
            runtime.open_connections = max(0, runtime.open_connections - 1)
            if runtime.open_connections == 0:
                # Last socket dropped: start the detach grace  Ethe block
                # survives brief reloads/network blips, but a session nobody
                # reattaches to stops blocking once the grace elapses.
                runtime.detached_at = time.time()
                if runtime.on_break:
                    # A break flag from a dead socket can't be trusted (nobody
                    # is left to send ticks), so tear it down and re-assert
                    # the admin's blocklist  Ethe session is still live for
                    # the duration of the grace.
                    runtime.set_on_break(False)
                    try:
                        await asyncio.to_thread(site_blocking.refresh_enforcement)
                    except Exception:
                        logger.exception("site blocking refresh after disconnect failed")
                _schedule_detach_refresh(session_id)
        if session is not None and session.user_id is not None:
            site_blocking.unregister_focus_ws(session.user_id, websocket)
        _rule_check_state.pop(session_id, None)
        if db is not None:
            db.close()


@app.get("/sessions/{session_id}/study-links")
async def get_study_links(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """On-demand: called when the frontend wants suggested links for a distracted student."""
    session = _get_owned_session(db, authorization, session_id)
    links = await ollama_client.generate_study_links(session.task_description)
    return {"links": links}


# ---------------------------------------------------------------------------
# Companion chat (body doubling) + auto-captured notes
# ---------------------------------------------------------------------------

@app.get("/companions")
def list_companions():
    """Picker payload for the AI companions (public fields only)."""
    return {"companions": companions.list_companions()}


# ---------------------------------------------------------------------------
# Google Classroom / Drive link (read-only schoolwork grounding for chat)
# ---------------------------------------------------------------------------

def _google_origin(origin_q: Optional[str], origin_header: Optional[str]) -> str:
    """Browsing origin for the Google OAuth redirect. Prefer the explicit
    query param (the frontend always knows window.location.origin), then the
    Origin header. Empty string -> google_link falls back to loopback."""
    for candidate in (origin_q, origin_header):
        if candidate:
            o = candidate.strip().rstrip("/")
            if o.startswith("http://") or o.startswith("https://"):
                return o
    return ""


@app.get("/api/google/status")
def google_status(
    authorization: Optional[str] = Header(None),
    origin_q: Optional[str] = Query(None, alias="origin"),
    origin: Optional[str] = Header(None),
):
    uid = _user_id_from_header(authorization)
    email = google_link.connected_email(uid) if uid is not None else None
    return {
        "configured": google_link.configured(),
        "connected": email is not None,
        "email": email or "",
        "redirect_uri": google_link.redirect_uri_for(_google_origin(origin_q, origin)),
    }


@app.get("/api/google/connect")
def google_connect(
    authorization: Optional[str] = Header(None),
    origin_q: Optional[str] = Query(None, alias="origin"),
    origin: Optional[str] = Header(None),
):
    uid = _user_id_from_header(authorization)
    if uid is None:
        raise HTTPException(401, "Sign in to connect Google")
    if not google_link.configured():
        raise HTTPException(503, "Google login is not configured on this device")
    redirect_uri = google_link.redirect_uri_for(_google_origin(origin_q, origin))
    state = google_link.new_state(uid, redirect_uri)
    return {"url": google_link.auth_url(state, redirect_uri), "redirect_uri": redirect_uri}


@app.get("/api/google/callback")
async def google_callback(code: str = "", state: str = ""):
    """Google redirects here on the machine's loopback - exchange the code,
    store the refresh token for that user, land back on the app."""
    from fastapi.responses import RedirectResponse

    popped = google_link.pop_state(state)
    if popped is None or not code:
        raise HTTPException(400, "Invalid or expired Google sign-in link")
    uid, redirect_uri = popped
    tok = await google_link.exchange_code(code, redirect_uri)
    if not tok or not tok.get("refresh_token"):
        raise HTTPException(400, "Google did not return a refresh token - try Connect again")
    email = await google_link.fetch_email(tok.get("access_token") or "")
    google_link.save_tokens(uid, tok, email)
    # Land back on THIS deployment's public path (default: prototype 2's /proto2;
    # the llamacpp instance passes STUBILLY_PUBLIC_PATH=/proto2-llamacpp).
    public_path = os.environ.get("STUBILLY_PUBLIC_PATH", "/proto2").strip().rstrip("/") or "/proto2"
    return RedirectResponse(f"{public_path}?google=connected")


@app.post("/api/google/disconnect")
def google_disconnect(
    authorization: Optional[str] = Header(None),
):
    uid = _user_id_from_header(authorization)
    if uid is None:
        raise HTTPException(401, "Sign in first")
    google_link.forget(uid)
    return {"connected": False}


@app.get("/companions/learning")
def get_companion_learning(
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Per-account companion learning profile, assembled from finished
    sessions. Returns {} for legacy single-user mode (no account)."""
    uid = _user_id_from_header(authorization)
    if uid is None:
        return {"learning_profile": {}}
    return {"learning_profile": learning.load_profile(db, uid)}



@app.post("/stt")
async def speech_to_text(
    file: UploadFile = File(...),
    language: Optional[str] = Form(None),
):
    """
    Whisper transcription endpoint (optional quality path).

    The primary voice-command path is the browser's Web Speech API, which
    streams partial results with zero upload delay. This endpoint exists for
    longer dictation or environments where Web Speech is unavailable: upload
    a webm/opus or wav blob and get back text via OpenAI Whisper. Requires
    OPENAI_API_KEY; without it returns 503 so the client falls back cleanly.
    """
    openai_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not openai_key:
        raise HTTPException(503, "Whisper transcription not configured (OPENAI_API_KEY missing)")

    raw = await file.read()
    if not raw:
        raise HTTPException(400, "Empty audio upload")
    if len(raw) > 25 * 1024 * 1024:
        raise HTTPException(413, "Audio too large (25 MB max)")

    filename = file.filename or "audio.webm"
    # Whisper accepts webm, mp4, mpeg, mpga, m4a, wav, ogg
    content_type = file.content_type or "audio/webm"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                "https://api.openai.com/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {openai_key}"},
                files={"file": (filename, raw, content_type)},
                data={"model": "whisper-1", **({"language": language} if language else {})},
            )
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPStatusError as e:
        logger.warning(f"Whisper API error: {e.response.status_code}")
        raise HTTPException(502, "Transcription service error")
    except httpx.HTTPError as e:
        logger.warning(f"Whisper unreachable: {e}")
        raise HTTPException(502, "Transcription service unreachable")

    return {"text": (data.get("text") or "").strip()}


@app.get("/sessions/{session_id}/chat", response_model=list[schemas.ChatMessageOut])
def get_chat_history(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """So reopening/reloading the app restores the chat transcript, not just a blank box."""
    _get_owned_session(db, authorization, session_id)
    return (
        db.query(models.ChatMessage)
        .filter(models.ChatMessage.session_id == session_id)
        .order_by(models.ChatMessage.timestamp)
        .all()
    )


@app.get("/sessions/{session_id}/notes", response_model=list[schemas.StudyNoteOut])
def get_session_notes(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    _get_owned_session(db, authorization, session_id)
    return (
        db.query(models.StudyNote)
        .filter(models.StudyNote.session_id == session_id)
        .order_by(models.StudyNote.timestamp)
        .all()
    )


# In-memory rolling context for companion chat: session_id -> deque of the
# last CHAT_CONTEXT_TURNS {role, content} dicts. Loaded once from the DB when
# the chat socket connects, then appended to as turns happen  Eso a reply
# never re-queries (and re-shapes) the whole history mid-turn.
CHAT_CONTEXT_TURNS = 16
_chat_context: dict[int, deque] = {}


async def _extract_and_push_note(
    session_id: int, task_description: str, user_text: str, companion_reply: str, websocket: WebSocket
):
    """
    Runs after a chat exchange, in the background  Edeliberately NOT awaited
    by the handler that sent the reply, so note-taking never adds a single
    millisecond of perceived latency to the chat itself. If it finds
    something worth saving, it's written to the DB immediately (so it
    survives even if the socket drops) and pushed live if the socket is
    still open. The existing notes are passed along so the model refuses
    near-duplicates instead of piling the same idea up twice.
    """
    db = next(get_db())
    try:
        existing = [
            n.content
            for n in db.query(models.StudyNote)
            .filter(models.StudyNote.session_id == session_id)
            .order_by(models.StudyNote.timestamp.desc())
            .all()
        ]
        note_text = await ollama_client.extract_note(
            task_description, user_text, companion_reply, existing_notes=existing
        )
        if not note_text:
            return
        note = models.StudyNote(session_id=session_id, content=note_text, source="chat")
        db.add(note)
        db.commit()
        db.refresh(note)
        try:
            await websocket.send_json({"type": "note", "id": note.id, "content": note.content})
        except RuntimeError:
            pass  # socket already closed by the time the note was ready  Eit's still saved
    finally:
        db.close()


async def _refine_and_push_tasks(session_id: int, task_description: str, transcript: str, websocket: WebSocket):
    """
    The live "Today's steps" adjuster, run in the background after a chat
    turn. Asks the model whether the conversation proves the plan should
    change; only then rewrites the session's micro-tasks (keeping completion
    flags on items that survive) and pushes the new checklist to the open
    chat socket  Eso the checklist updates in real time while the student
    chats, instead of being frozen at session start. Self-limiting: skips
    entirely when the target list is identical to what's already there.
    """
    db = next(get_db())
    try:
        rows = (
            db.query(models.MicroTask)
            .filter(models.MicroTask.session_id == session_id)
            .order_by(models.MicroTask.order_index)
            .all()
        )
        target = await ollama_client.refine_tasks(
            task_description, [t.description for t in rows], transcript
        )
        if not target:
            return

        current = [t.description.strip().lower() for t in rows]
        wanted = [t["description"].strip().lower() for t in target]
        if current == wanted:
            return

        # Rebuild the plan. Items whose description survives keep their
        # completed flag (keyed by normalized description); new items replace
        # anything the conversation proved obsolete.
        survived = {r.description.strip().lower(): bool(r.completed) for r in rows}
        for r in rows:
            db.delete(r)
        db.flush()
        for i, item in enumerate(target):
            desc = item["description"].strip()
            db.add(models.MicroTask(
                session_id=session_id,
                description=desc,
                estimated_minutes=item.get("estimated_minutes"),
                completed=1 if survived.get(desc.lower()) else 0,
                order_index=i,
            ))
        db.commit()

        fresh = (
            db.query(models.MicroTask)
            .filter(models.MicroTask.session_id == session_id)
            .order_by(models.MicroTask.order_index)
            .all()
        )
        payload = [
            {
                "id": t.id,
                "description": t.description,
                "estimated_minutes": t.estimated_minutes,
                "completed": bool(t.completed),
                "order_index": t.order_index,
            }
            for t in fresh
        ]
        try:
            await websocket.send_json({"type": "tasks", "tasks": payload})
        except RuntimeError:
            pass  # socket closed  Ethe DB already carries the new plan
    except Exception:
        logger.info("Checklist refine skipped", exc_info=True)
    finally:
        db.close()


def _live_app_context(db: Session, session_id: int) -> dict:
    """What the companion's "connectors" see: this machine's live state and
    how the session is actually going. Feeds build_companion_system_prompt so
    the chat can answer "what am I doing / how am I doing" from real data."""
    app: dict = {}
    ev = (
        db.query(models.FocusEvent)
        .filter(models.FocusEvent.session_id == session_id)
        .order_by(models.FocusEvent.timestamp.desc())
        .first()
    )
    if ev is not None:
        window = " / ".join(p for p in (ev.active_app, ev.active_title) if p)
        app["active_window"] = window or None
        app["active_site"] = ev.active_site

    events = (
        db.query(models.FocusEvent)
        .filter(models.FocusEvent.session_id == session_id)
        .order_by(models.FocusEvent.timestamp)
        .all()
    )
    if len(events) >= 2:
        d = learning._compute_durations(events)
        at_desk = d["focused"] + d["distracted"] + d["sleeping"]
        if at_desk > 0:
            app["focused_pct"] = round(100.0 * d["focused"] / at_desk, 1)

    # Checklist state (SQLite tasks table)  Ethe companion can steer the
    # student to the next planned step instead of guessing.
    tasks = (
        db.query(models.MicroTask)
        .filter(models.MicroTask.session_id == session_id)
        .order_by(models.MicroTask.order_index)
        .all()
    )
    if tasks:
        app["tasks_total"] = len(tasks)
        app["tasks_done"] = sum(1 for t in tasks if t.completed)
        nxt = next((t.description for t in tasks if not t.completed), None)
        app["next_task"] = nxt

    # Most frequent off-task site this session (focus ticks carrying a site;
    # on-task lives in app_state as "on_task" | "off_task", not a bool column).
    site_off: dict = {}
    for e in events:
        if e.active_site and e.app_state == "off_task":
            site_off[e.active_site] = site_off.get(e.active_site, 0) + 1
    if site_off:
        app["top_distraction"] = max(site_off, key=site_off.get)

    counts: dict = {}
    feedback: dict = {}
    for iv in (
        db.query(models.Intervention)
        .filter(models.Intervention.session_id == session_id)
        .all()
    ):
        k = iv.intervention_type or "other"
        counts[k] = counts.get(k, 0) + 1
        r = (iv.user_response or "").strip().lower()
        if r:
            feedback[r] = feedback.get(r, 0) + 1
    app["intervention_counts"] = counts
    if feedback:
        app["nudge_feedback"] = feedback
    return app


async def _web_context(user_text: str) -> list[dict]:
    """Live-web grounding: top DuckDuckGo hits for the student's question so
    the companion can answer with current facts. Never blocks chat  Eany
    failure returns [] and the reply just proceeds without web context."""
    if len(user_text) < 8:
        return []
    try:
        from ddgs import DDGS
    except Exception:
        logger.info("ddgs not installed - web context disabled")
        return []

    def _search() -> list[dict]:
        with DDGS() as ddgs:
            return [
                {
                    "title": r.get("title", ""),
                    "snippet": r.get("body", ""),
                    "url": r.get("href", ""),
                }
                for r in ddgs.text(user_text, max_results=3)
            ]

    try:
        # 2.5s cap: search is a bonus, never the reason a reply feels slow.
        return await asyncio.wait_for(asyncio.to_thread(_search), timeout=2.5)
    except Exception:
        logger.info("web search skipped", exc_info=True)
        return []


# Chit-chat ("can you hear me", "thanks") must not wait on the network  E# only messages that look like they need current facts trigger a search.
_WEB_CUE = re.compile(
    r"\b(who|what|when|where|which|why|how much|how many|how long|how far|"
    r"latest|current|today|yesterday|tomorrow|news|recent|this week|"
    r"right now|define|meaning|explain|weather|price|score|president|"
    r"election|capital of|invented|discovered|founded)\b",
    re.I,
)
_WEB_NOISE = re.compile(
    r"\b(are you|you doing|you there|can you hear|thanks|thank you|"
    r"good morning|good night)\b",
    re.I,
)


def _needs_web_search(user_text: str) -> bool:
    """True only when the message plausibly wants a live fact."""
    if len(user_text) < 16:
        return False
    if not _WEB_CUE.search(user_text):
        return False
    return not _WEB_NOISE.search(user_text)


# Words that carry no search signal in "what is these you see on the
# picture"-style photo questions; everything else (nouns like "character",
# "space suit") is kept because it's what actually narrows the search.
_IMAGE_TEXT_NOISE = re.compile(
    r"\b(what|what's|whats|is|are|am|the|a|an|this|that|these|those|in|on|of|"
    r"to|my|your|you|see|see|please|can|could|tell|give|show|identify|"
    r"picture|photo|image|attached|here|it|them|and|or|name)\b",
    re.I,
)


def _image_search_queries(image_name, user_text: str) -> list[str]:
    """Search queries for a photo-identification turn.

    The filename usually encodes the source name (RhounFull1.webp ->
    "Rhoun Full"), so it leads; the student's own words follow with
    question scaffolding stripped. Order matters: the caller stops at the
    first query that returns hits.
    """
    queries: list[str] = []
    if image_name and isinstance(image_name, str):
        stem = os.path.splitext(os.path.basename(image_name.strip()))[0]
        words = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", stem)
        words = re.sub(r"[_\-.]+", " ", words)
        words = re.sub(r"\d+", " ", words)
        words = re.sub(r"\s+", " ", words).strip()
        if words:
            queries.append(words)
        if stem and stem.lower() != words.lower().replace(" ", ""):
            queries.append(stem)
    text = _IMAGE_TEXT_NOISE.sub(" ", user_text or "")
    text = re.sub(r"[^\w\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) >= 4:
        queries.append(text)
    return queries


async def _link_context(user_text: str) -> list[dict]:
    """Fetch title + opening text for any URLs the student pasted into
    chat, so the companion answers from the actual page. Failures skip
    that link; chat never waits more than ~2.5s per link."""
    urls = re.findall(r"https?://[^\s<>\"')\]]+", user_text)[:3]
    hits: list[dict] = []
    for url in urls:
        try:
            async with httpx.AsyncClient(
                timeout=2.5,
                follow_redirects=True,
                headers={"User-Agent": "StubillyStudy/1.0"},
            ) as client:
                r = await client.get(url)
                if r.status_code >= 400:
                    continue
                ctype = r.headers.get("content-type", "")
                if "html" not in ctype and "text/" not in ctype and "json" not in ctype:
                    continue
                text = r.text[:6000]
            title_m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
            title = (
                re.sub(r"\s+", " ", title_m.group(1)).strip()[:200]
                if title_m
                else url
            )
            body = re.sub(
                r"<script[\s\S]*?</script>|<style[\s\S]*?</style>", " ", text, flags=re.I
            )
            body = re.sub(r"<[^>]+>", " ", body)
            body = re.sub(r"\s+", " ", body).strip()[:1500]
            if body:
                hits.append({"title": title, "snippet": body, "url": url})
        except Exception:
            continue
    return hits


# Chat photo attachments: data-URL (or bare b64) capped at ~3MB, only the
# types the vision models handle. Anything else is dropped silently.
_MAX_IMAGE_B64 = 4_000_000
_IMAGE_MIMES = ("image/jpeg", "image/png", "image/webp")


def _parse_chat_image(raw) -> dict | None:
    """Validate a photo payload from the chat socket.

    Accepts `data:<mime>;base64,<b64>` (what the frontend canvas
    downscaler emits) or bare base64. Returns a part the multimodal
    providers understand, or None when the payload is oversized,
    malformed, or not a supported image type.
    """
    if not raw or not isinstance(raw, str) or len(raw) > _MAX_IMAGE_B64:
        return None
    mime = "image/jpeg"
    if raw.startswith("data:"):
        try:
            header, b64 = raw.split(",", 1)
        except ValueError:
            return None
        mt = header[5:].split(";")[0].strip().lower()
        if mt not in _IMAGE_MIMES:
            return None
        mime, raw = mt, b64
    if not raw:
        return None
    try:
        base64.b64decode(raw, validate=True)
    except Exception:
        return None
    return {"type": "image", "mime": mime, "data": raw}


def _detect_emotion(text: str) -> str | None:
    """Coarse emotion from a message, for the avatar face.

    Sent as its own WS frame BEFORE generation starts so the blob reacts
    within milliseconds of the send - the delay people feel is mostly "the
    face never moved". Values map 1:1 to CompanionAvatar states. Neutral
    text returns None so the face stays on its ambient state instead of
    forcing a grin on every ordinary request.
    """
    t = (text or "").lower()
    if any(
        w in t
        for w in (
            "stuck", "don't get", "dont get", "hard", "can't", "cant",
            "confus", "lost", "fail", "hate", "sad", "bored", "tired",
            "sleepy", "give up", "so difficult", "hiccup", "sorry",
        )
    ):
        return "concerned"
    if "!!" in t or any(
        w in t
        for w in (
            "amazing", "awesome", "yay", "let's go", "lets go", "excited",
            "finished", "done!", "passed", "won", "yes!", "crushed it",
            "nailed", "first place",
        )
    ):
        return "excited"
    if "!" in t or any(
        w in t for w in ("thank", "thanks", "good job", "nice", "cool", "love it")
    ):
        return "happy"
    if t.rstrip().endswith("?") or t.startswith(
        ("who ", "what ", "when ", "where ", "why ", "how ", "can you", "could you", "do you")
    ) or "think" in t or "figure out" in t:
        return "thinking"
    return None


@app.websocket("/ws/{session_id}/chat")
async def companion_chat(websocket: WebSocket, session_id: int):
    """
    Body-doubling companion chat.

    Client sends:  {"content": "..."}
    Server sends:  {"type": "token", "content": "..."}            (repeated, streamed)
                   {"type": "message_done", "message_id": 12}
                   {"type": "note", "id": 3, "content": "..."}     (only when one is captured)
                   {"type": "tasks", "tasks": [...]}               (live checklist adjustment)

    Streaming + fire-and-forget note extraction are both about the same
    goal: the chat reply should never wait on anything except the tokens
    themselves.
    """
    token = websocket.query_params.get("token") or None
    db = next(get_db())
    session = db.query(models.StudySession).filter(models.StudySession.id == session_id).first()
    if not session:
        await websocket.accept()
        await websocket.close(code=4404)
        db.close()
        return

    # Ownership: an owned session requires the owner's token; a legacy unowned
    # session still requires any live account when managed mode is on  Esame
    # rule as the focus stream, so the HTTP twin's _get_owned_session can't
    # be bypassed by opening the chat socket instead.
    caller_id = auth_service.get_user_from_token(token, touch=True)
    if session.user_id is not None:
        if caller_id != session.user_id:
            await websocket.accept()
            await websocket.close(code=4401)
            db.close()
            return
    elif caller_id is None and admin_router.db_has_users(db):
        await websocket.accept()
        await websocket.close(code=4401)
        db.close()
        return

    await websocket.accept()

    # Load the rolling context once per connection, not per message.
    context = _chat_context.get(session_id)
    if context is None:
        recent = (
            db.query(models.ChatMessage)
            .filter(models.ChatMessage.session_id == session_id)
            .order_by(models.ChatMessage.timestamp.desc())
            .limit(CHAT_CONTEXT_TURNS)
            .all()
        )[::-1]
        context = deque(
            ({"role": "user" if m.role == "user" else "assistant", "content": m.content} for m in recent),
            maxlen=CHAT_CONTEXT_TURNS,
        )
        _chat_context[session_id] = context

    try:
        while True:
            payload = await websocket.receive_json()
            user_text = (payload.get("content") or "").strip()
            image_part = _parse_chat_image(payload.get("image"))
            image_name = payload.get("image_name")
            if isinstance(image_name, str):
                image_name = image_name.strip()[:200]
            else:
                image_name = None
            if not user_text and image_part is None:
                continue

            # What gets stored + echoed: the student's words plus a marker
            # so the text history still shows a photo was part of the turn.
            stored_text = user_text
            if image_part is not None:
                stored_text = f"{user_text}\n[photo attached]".strip() if user_text else "[photo attached]"

            db.add(models.ChatMessage(session_id=session_id, role="user", content=stored_text))
            db.commit()
            if image_part is not None:
                # Keep the actual pixels in the rolling in-memory context so
                # follow-ups ("what's the NAME of the character I sent you?")
                # still carry the photo  Ethe DB history keeps the text
                # marker, but the model re-sees the image itself here.
                context.append({
                    "role": "user",
                    "content": [{"type": "text", "text": stored_text}, image_part],
                })
            else:
                context.append({"role": "user", "content": stored_text})

            runtime = state_machine.active_sessions.get(session_id)
            focus_state = runtime.current_state if runtime else "focused"
            seconds_in_state = int(runtime.seconds_in_current_state()) if runtime else 0

            try:
                # Instant face: react to the student's words before any
                # network or model work - the avatar moves immediately.
                await websocket.send_json(
                    {"type": "emotion", "content": _detect_emotion(user_text)}
                )
                # Web search only for fact-shaped questions; chit-chat
                # skips the network entirely (0 added latency). Pasted
                # links always get fetched - the page IS the context.
                # Photo turns search unconditionally: filename + question
                # cues are the query, and identification without search is
                # just guessing (the cue gate never fires on "what is this").
                link_hits = await _link_context(user_text)
                web_hits = link_hits
                if image_part is not None:
                    for q in _image_search_queries(image_name, user_text)[:2]:
                        found = await _web_context(q)
                        if found:
                            web_hits = link_hits + found
                            break
                elif _needs_web_search(user_text):
                    web_hits = link_hits + await _web_context(user_text)
                notes = [
                    n.content
                    for n in reversed(
                        db.query(models.StudyNote)
                        .filter(models.StudyNote.session_id == session_id)
                        .order_by(models.StudyNote.timestamp.desc())
                        .limit(5)
                        .all()
                    )
                ]
                messages = [
                    {
                        "role": "system",
                        "content": companions.build_companion_system_prompt(
                            getattr(session, "companion_id", None),
                            session.task_description, focus_state, seconds_in_state,
                            context={
                                "profile": (
                                    learning.load_profile(db, session.user_id)
                                    if session.user_id is not None else {}
                                ),
                                "app": _live_app_context(db, session_id),
                                "web": web_hits,
                                "notes": notes,
                                "image": image_part is not None,
                                "image_name": image_name,
                            },
                        ),
                    },
                    *list(context),
                ]
                # The model sees the photo as real image parts (Gemini +
                # Grok vision); the text history keeps the marker above.
                if image_part is not None:
                    lead = user_text or "What is in this photo?"
                    messages[-1] = {
                        "role": "user",
                        "content": [{"type": "text", "text": lead}, image_part],
                    }

                full_reply = ""
                async for piece in companion_llm.stream_companion_reply_hybrid(messages):
                    full_reply += piece
                    await websocket.send_json({"type": "token", "content": piece})
                if not full_reply.strip():
                    full_reply = "I'm here  Esay that again?"
                    await websocket.send_json({"type": "token", "content": full_reply})
            except Exception:
                # Any failure here must NOT kill the socket  Ethe student
                # gets a friendly apology and the conversation continues.
                logger.exception(f"companion turn failed for session {session_id}")
                try:
                    db.rollback()
                except Exception:
                    pass
                full_reply = "Sorry  EI hit a hiccup answering that. Please try again."
                await websocket.send_json({"type": "token", "content": full_reply})

            context.append({"role": "assistant", "content": full_reply})
            # Face matches what Billy actually said (also covers the
            # apology path - concerned fits "hit a hiccup").
            await websocket.send_json(
                {"type": "emotion", "content": _detect_emotion(full_reply)}
            )

            companion_msg = models.ChatMessage(session_id=session_id, role="companion", content=full_reply)
            db.add(companion_msg)
            db.commit()
            db.refresh(companion_msg)

            await websocket.send_json({"type": "message_done", "message_id": companion_msg.id})

            asyncio.create_task(
                _extract_and_push_note(session_id, session.task_description, stored_text, full_reply, websocket)
            )

            # Live "Today's steps" adjustment  Esame fire-and-forget pattern as
            # notes: the reply was already streamed, so the agent's conservati-
            # ve plan review never adds latency to what the student sees.
            def _flat(m_content):
                if isinstance(m_content, str):
                    return m_content
                if isinstance(m_content, list):
                    return " ".join(
                        p.get("text", "") for p in m_content
                        if isinstance(p, dict) and p.get("text")
                    )
                return str(m_content)

            transcript = "\n".join(
                f"{'Student' if m['role'] == 'user' else 'Companion'}: {_flat(m['content'])}"
                for m in context
            )
            asyncio.create_task(
                _refine_and_push_tasks(session_id, session.task_description, transcript, websocket)
            )

    except WebSocketDisconnect:
        logger.info(f"Chat WebSocket disconnected for session {session_id}")
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Intervention feedback (INPUT back into the framework loop): the student
# says whether a nudge/check-in actually helped  Ethis is the
# intervention-reliability signal the evaluation output is built from.
# ---------------------------------------------------------------------------

@app.post("/interventions/{intervention_id}/respond", response_model=schemas.InterventionOut)
def respond_to_intervention(
    intervention_id: int,
    req: schemas.InterventionRespondRequest,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    row = db.query(models.Intervention).filter(models.Intervention.id == intervention_id).first()
    if not row:
        raise HTTPException(404, "Intervention not found")
    # Ownership: the responding caller must own the intervention's session
    # (same rule as every other session read). Legacy unowned sessions stay
    # open only while no accounts exist.
    _get_owned_session(db, authorization, row.session_id)
    response = (req.response or "").strip().lower()
    allowed = {"helpful", "dismissed", "acting_on_it", "ignored"}
    if response not in allowed:
        raise HTTPException(400, f"response must be one of: {', '.join(sorted(allowed))}")
    row.user_response = response
    db.commit()
    db.refresh(row)
    # Feedback loop: an engaged check-in answer backs the next check-in off.
    if row.intervention_type == "check_in":
        rt = state_machine.active_sessions.get(row.session_id)
        if rt is not None:
            rt.note_check_in_response(response)
    return row


# ---------------------------------------------------------------------------
# Analytics outputs (theoretical framework): distraction patterns + the
# pre/post session evaluation students and evaluators read back.
# ---------------------------------------------------------------------------

@app.get("/analytics/patterns", response_model=schemas.DistractionPatternsOut)
def distraction_patterns(days: int = 14, db: Session = Depends(get_db),
                         authorization: Optional[str] = Header(None)):
    """When/where this account goes off task, over the last `days` days.
    Scoped to the signed-in account (or the whole deployment in legacy
    no-accounts mode)."""
    user_id = auth_service.get_user_from_token(admin_router.bearer_token(authorization))
    cutoff = datetime.now(timezone.utc) - timedelta(days=max(1, min(90, days)))

    q = db.query(models.FocusEvent).join(
        models.StudySession, models.FocusEvent.session_id == models.StudySession.id
    ).filter(models.StudySession.started_at >= _naive_utc(cutoff))
    if user_id is not None:
        q = q.filter(models.StudySession.user_id == user_id)
    events = q.all()

    app_seconds: dict[str, float] = defaultdict(float)
    by_hour = [0] * 24
    idle_ticks = 0
    total_ticks = 0
    focused_start: list[float] = []
    focused_end: list[float] = []
    for ev in events:
        total_ticks += 1
        ts = ev.timestamp.replace(tzinfo=timezone.utc) if ev.timestamp and ev.timestamp.tzinfo is None else ev.timestamp
        if ts is not None and ev.state in ("distracted", "absent", "sleeping"):
            by_hour[ts.hour % 24] += 1
        if ev.idle_seconds is not None:
            idle_ticks += 1
        # app_state is per-tick, not a duration  Ecount off-task ticks as
        # ~TICK seconds using the gap between consecutive ticks (~3s typical).
        if ev.app_state == "off_task" and ev.active_app:
            app_seconds[ev.active_app] += 3.0

    # Focus % in the first/last 10 minutes, per session then averaged.
    session_ids = {ev.session_id for ev in events}
    start_pcts: list[float] = []
    end_pcts: list[float] = []
    for sid in session_ids:
        evs = [e for e in events if e.session_id == sid]
        evs.sort(key=lambda e: e.timestamp or datetime.min)
        if len(evs) < 10:
            continue
        n = max(1, len(evs) // 10)
        first, last = evs[:n], evs[-n:]
        start_pcts.append(100.0 * sum(1 for e in first if e.state == "focused") / len(first))
        end_pcts.append(100.0 * sum(1 for e in last if e.state == "focused") / len(last))

    # Intervention reliability across the window.
    reliability: dict[str, int] = defaultdict(int)
    iq = db.query(models.Intervention).join(
        models.StudySession, models.Intervention.session_id == models.StudySession.id
    ).filter(models.StudySession.started_at >= _naive_utc(cutoff))
    if user_id is not None:
        iq = iq.filter(models.StudySession.user_id == user_id)
    for iv in iq.all():
        reliability[iv.user_response or "unanswered"] += 1

    top = sorted(app_seconds.items(), key=lambda kv: kv[1], reverse=True)[:8]
    return schemas.DistractionPatternsOut(
        top_off_task=[{"name": name, "seconds": round(sec, 1)} for name, sec in top],
        distraction_by_hour=by_hour,
        idle_fraction=round(idle_ticks / total_ticks, 3) if total_ticks else 0.0,
        focus_start_pct=round(sum(start_pcts) / len(start_pcts), 1) if start_pcts else None,
        focus_end_pct=round(sum(end_pcts) / len(end_pcts), 1) if end_pcts else None,
        intervention_reliability=dict(reliability),
        total_events=total_ticks,
    )


@app.get("/sessions/{session_id}/evaluation", response_model=schemas.EvaluationOut)
def session_evaluation(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Post-session evaluation: how this run compares with the student's
    earlier runs on the same task (the pre/post "did focus improve?" read)."""
    session = _get_owned_session(db, authorization, session_id)
    duration = 0.0
    if session.ended_at is not None:
        duration = (_naive_utc(session.ended_at) - _naive_utc(session.started_at)).total_seconds()
    elif session.started_at is not None:
        duration = (datetime.now(timezone.utc).replace(tzinfo=None)
                    - _naive_utc(session.started_at)).total_seconds()
    dur = (session.total_focused_seconds or 0.0) + (session.total_distracted_seconds or 0.0)
    focus_pct = round(100.0 * (session.total_focused_seconds or 0.0) / dur, 1) if dur > 0 else 0.0

    prior_q = (
        db.query(models.StudySession)
        .filter(
            models.StudySession.ended_at.isnot(None),
            models.StudySession.id != session.id,
            models.StudySession.user_id == session.user_id
            if session.user_id is not None
            else models.StudySession.user_id.is_(None),
        )
    )
    if session.subject:
        prior_q = prior_q.filter(models.StudySession.subject == session.subject)
    else:
        # No declared subject  Efall back to the same free-text task.
        prior_q = prior_q.filter(models.StudySession.task_description == session.task_description)
    prior = prior_q.order_by(models.StudySession.ended_at.desc()).limit(20).all()
    prior_pcts = []
    for p in prior:
        d = (p.total_focused_seconds or 0.0) + (p.total_distracted_seconds or 0.0)
        if d > 0:
            prior_pcts.append(100.0 * (p.total_focused_seconds or 0.0) / d)
    prior_avg = round(sum(prior_pcts) / len(prior_pcts), 1) if prior_pcts else None
    delta = round(focus_pct - prior_avg, 1) if prior_avg is not None else None
    if prior_avg is None:
        trend = "first_run"
    elif delta is None or abs(delta) < 3.0:
        trend = "steady"
    elif delta > 0:
        trend = "improved"
    else:
        trend = "declined"

    iv_rows = db.query(models.Intervention).filter(
        models.Intervention.session_id == session.id
    ).all()
    responded = sum(1 for r in iv_rows if r.user_response)
    if trend == "first_run":
        verdict = f"Baseline run: {focus_pct}% focused over {duration / 60.0:.0f} min."
    else:
        word = {"improved": "up", "declined": "down", "steady": "holding steady"}[trend]
        verdict = (
            f"{focus_pct}% focused ({word} {abs(delta or 0):.1f} pts vs your "
            f"{len(prior_pcts)} earlier run{'s' if len(prior_pcts) != 1 else ''} on this "
            f"{'subject' if session.subject else 'task'})."
        )
    return schemas.EvaluationOut(
        session_id=session.id,
        subject=session.subject,
        priority=session.priority,
        duration_minutes=round(duration / 60.0, 1),
        focus_pct=focus_pct,
        prior_avg_focus_pct=prior_avg,
        delta_vs_prior=delta,
        paralysis_count=session.paralysis_count or 0,
        check_in_count=session.check_in_count or 0,
        interventions_total=len(iv_rows),
        interventions_responded=responded,
        trend=trend,
        verdict=verdict,
    )


# ---------------------------------------------------------------------------
# Post-session quiz  Eauto-generated from the session's study content
# ---------------------------------------------------------------------------

def _session_focus_pct(session: "models.StudySession") -> float:
    """Focus % from the session's denormalized totals (the same formula the
    evaluation endpoint uses)."""
    dur = (session.total_focused_seconds or 0.0) + (session.total_distracted_seconds or 0.0)
    return round(100.0 * (session.total_focused_seconds or 0.0) / dur, 1) if dur > 0 else 0.0


def _quiz_difficulty(focus_pct: float) -> str:
    """Fully automatic difficulty: no teacher/parent knob anywhere. Strong
    focus for the session means the material was actually engaged with, so
    the quiz challenges (hard); a middling run gets a balanced set (medium);
    a weak run gets a gentler recall check (easy)."""
    if focus_pct >= 75.0:
        return "hard"
    if focus_pct >= 45.0:
        return "medium"
    return "easy"


# Generic off-task distractors for the deterministic fallback quiz. They are
# deliberately NOT study-plan steps, so a step-recall question stays solvable.
_FALLBACK_STEP_DISTRACTORS = [
    "Skip the session entirely and do it another day",
    "Scroll through unrelated videos for an hour",
    "Chat with friends instead of following the plan",
    "Ignore the checklist and improvise without a plan",
]
_FALLBACK_SUBJECT_DISTRACTORS = [
    "Physical Education", "Home Economics", "Music and Arts", "Practical Driving",
]
_FALLBACK_TASK_DISTRACTORS = [
    "Clean and organize the study desk",
    "Buy groceries for the week",
    "Set up a new productivity app",
    "Plan next week's schedule",
]


def _mcq(prompt: str, correct: str, distractors: list[str], slot: int) -> dict:
    """One multiple-choice question with the correct answer rotating through
    the option positions (deterministic  Eno RNG needed for tests)."""
    options = [str(correct)]
    for d in distractors:
        if str(d).strip().lower() == str(correct).strip().lower():
            continue
        if str(d) in options:
            continue
        options.append(str(d))
        if len(options) >= 4:
            break
    # Rotate so the correct answer isn't always in position 0.
    rotate = slot % len(options)
    options = options[rotate:] + options[:rotate]
    return {
        "prompt": prompt,
        "options": options,
        "correct_index": (len(options) - rotate) % len(options),
    }


def _fallback_quiz_questions(
    session: "models.StudySession",
    steps: list[str],
    cap: int = 5,
) -> list[dict]:
    """Deterministic quiz built purely from the session's own records  Eused
    when the LLM is unreachable AND to top up a short LLM result. Every
    question is answerable from data that definitely exists for this run."""
    task = (session.task_description or "").strip() or "this session's task"
    task_short = task if len(task) <= 90 else task[:87] + "…"
    questions: list[dict] = []

    for i, step in enumerate(steps[:3]):
        if len(questions) >= cap:
            break
        questions.append(_mcq(
            f"Which of these was a step in your plan for “{task_short} E",
            step,
            _FALLBACK_STEP_DISTRACTORS,
            slot=i,
        ))

    if len(questions) < cap:
        questions.append(_mcq(
            "What was the main task of this session?",
            task_short,
            _FALLBACK_TASK_DISTRACTORS,
            slot=len(questions),
        ))

    subject = (session.subject or "").strip()
    if subject and len(questions) < cap:
        questions.append(_mcq(
            "This session's work belonged to which subject?",
            subject,
            _FALLBACK_SUBJECT_DISTRACTORS,
            slot=len(questions),
        ))

    if len(steps) >= 2 and len(questions) < cap:
        done = sum(1 for t in session.tasks if t.completed)
        correct = str(done)
        distractors = [str(n) for n in sorted({0, 1, 2, len(steps)} - {done})]
        questions.append(_mcq(
            "How many steps from your plan were marked completed?",
            correct, distractors, slot=len(questions),
        ))

    priority = (session.priority or "").strip().lower()
    if priority in ("low", "medium", "high") and len(questions) < cap:
        others = [p for p in ("low", "medium", "high") if p != priority]
        questions.append(_mcq(
            "Which priority did you set for this session?",
            priority.capitalize(),
            [p.capitalize() for p in others],
            slot=len(questions),
        ))

    return questions[:cap]


def _quiz_out(quiz: "models.Quiz", include_correct: bool) -> dict:
    """Serialize a quiz; correct answers are withheld until it's graded."""
    qs = sorted(quiz.questions, key=lambda q: q.order_index)
    answers = None
    if quiz.answers:
        try:
            answers = [int(a) for a in json.loads(quiz.answers)]
        except (ValueError, TypeError):
            answers = None
    return {
        "id": quiz.id,
        "session_id": quiz.session_id,
        "difficulty": quiz.difficulty or "medium",
        "focus_pct": quiz.focus_pct or 0.0,
        "source": quiz.source or "ollama",
        "status": quiz.status or "pending",
        "question_count": quiz.question_count or len(qs),
        "total_questions": quiz.question_count or len(qs),
        "score": quiz.score,
        "answers": answers,
        "created_at": quiz.created_at,
        "completed_at": quiz.completed_at,
        "questions": [
            {
                "id": q.id,
                "order_index": q.order_index,
                "prompt": q.prompt,
                "options": json.loads(q.options) if q.options else [],
                "correct_index": q.correct_index if include_correct else None,
            }
            for q in qs
        ],
    }


def _get_session_quiz(db: Session, session_id: int) -> Optional["models.Quiz"]:
    return (
        db.query(models.Quiz)
        .filter(models.Quiz.session_id == session_id)
        .first()
    )


@app.get("/sessions/{session_id}/quiz", response_model=schemas.QuizOut)
def get_session_quiz(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """The session's quiz (404 until one has been generated). Correct answers
    are only included once the quiz has been graded."""
    session = _get_owned_session(db, authorization, session_id)
    quiz = _get_session_quiz(db, session.id)
    if quiz is None:
        raise HTTPException(404, "No quiz for this session yet")
    return _quiz_out(quiz, include_correct=quiz.status == "completed")


@app.post("/sessions/{session_id}/quiz/generate", response_model=schemas.QuizOut)
async def generate_session_quiz(
    session_id: int,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Generate the post-session quiz from what the student studied (task,
    subject, checklist, captured notes, chat excerpt). Difficulty comes
    fully automatically from this session's focus performance. Idempotent:
    an existing quiz is returned as-is."""
    session = _get_owned_session(db, authorization, session_id)
    if session.ended_at is None:
        raise HTTPException(409, "Finish the session first  Ethe quiz covers what you studied")
    existing = _get_session_quiz(db, session.id)
    if existing is not None:
        return _quiz_out(existing, include_correct=existing.status == "completed")

    focus_pct = _session_focus_pct(session)
    difficulty = _quiz_difficulty(focus_pct)

    steps = [
        t.description
        for t in sorted(session.tasks, key=lambda t: t.order_index or 0)
        if t.description
    ]
    notes = [
        n.content
        for n in sorted(session.study_notes, key=lambda n: n.timestamp or datetime.min)
    ]
    chat_rows = (
        db.query(models.ChatMessage)
        .filter(models.ChatMessage.session_id == session.id)
        .order_by(models.ChatMessage.timestamp.desc())
        .limit(6)
        .all()
    )
    chat_excerpt = [
        f"{'Student' if m.role == 'user' else 'Companion'}: {m.content[:160]}"
        for m in reversed(chat_rows)
    ]

    try:
        questions = await ollama_client.generate_quiz(
            task_description=session.task_description,
            subject=session.subject,
            steps=steps,
            notes=notes,
            chat_excerpt=chat_excerpt,
            difficulty=difficulty,
        )
        source = "ollama"
    except Exception:  # never let quiz generation break End Session's summary
        logger.exception("quiz generation failed")
        questions, source = [], "fallback"

    # Top up a short/empty LLM result with deterministic questions so the
    # quiz is never a single token question, and a dead LLM still yields a
    # complete, gradeable set.
    if len(questions) < 5:
        seen = {q["prompt"].lower() for q in questions}
        for fb in _fallback_quiz_questions(session, steps):
            if len(questions) >= 5:
                break
            if fb["prompt"].lower() in seen:
                continue
            seen.add(fb["prompt"].lower())
            questions.append(fb)
        if not questions:
            source = "fallback"
    if not questions:
        raise HTTPException(
            503, "Couldn't build a quiz for this session  Eno study material found"
        )

    quiz = models.Quiz(
        session_id=session.id,
        difficulty=difficulty,
        focus_pct=focus_pct,
        source=source,
        status="pending",
        question_count=len(questions),
    )
    db.add(quiz)
    db.flush()
    for i, q in enumerate(questions):
        db.add(models.QuizQuestion(
            quiz_id=quiz.id,
            order_index=i,
            prompt=q["prompt"],
            options=json.dumps([str(o) for o in q["options"]]),
            correct_index=int(q["correct_index"]),
        ))
    db.commit()
    db.refresh(quiz)
    return _quiz_out(quiz, include_correct=False)


@app.post("/sessions/{session_id}/quiz/submit", response_model=schemas.QuizOut)
def submit_session_quiz(
    session_id: int,
    payload: schemas.QuizSubmitIn,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Grade the quiz against the stored correct answers and record the
    result  Ethe score then feeds the academic-progress view. Re-submitting
    a completed quiz returns the stored result (idempotent retries)."""
    session = _get_owned_session(db, authorization, session_id)
    quiz = _get_session_quiz(db, session.id)
    if quiz is None:
        raise HTTPException(404, "No quiz for this session yet")
    if quiz.status == "completed":
        return _quiz_out(quiz, include_correct=True)

    questions = sorted(quiz.questions, key=lambda q: q.order_index)
    if not questions:
        raise HTTPException(503, "Quiz has no questions  Eregenerate it")
    if len(payload.answers) != len(questions):
        raise HTTPException(
            400, f"Expected {len(questions)} answers, got {len(payload.answers)}"
        )
    score = 0
    for i, (answer, q) in enumerate(zip(payload.answers, questions)):
        options = json.loads(q.options) if q.options else []
        if not (0 <= answer < len(options)):
            raise HTTPException(
                400, f"Answer {i} out of range for its {len(options)} options"
            )
        if answer == q.correct_index:
            score += 1

    quiz.answers = json.dumps([int(a) for a in payload.answers])
    quiz.score = score
    quiz.status = "completed"
    quiz.completed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(quiz)
    return _quiz_out(quiz, include_correct=True)


@app.put("/sessions/{session_id}/tasks", response_model=schemas.SessionOut)
def update_session_tasks(
    session_id: int,
    payload: schemas.SessionTasksUpdate,
    db: Session = Depends(get_db),
    authorization: Optional[str] = Header(None),
):
    """Persist checklist completion  Ethe server-side record of exactly what
    the student worked through (and what they finished) during the run.
    Matched by description because the AI's mid-session rewrites recreate
    the rows (and their ids) while keeping the wording of surviving steps."""
    session = _get_owned_session(db, authorization, session_id)
    wanted = {
        t.description.strip().lower(): bool(t.completed)
        for t in payload.tasks
        if t.description and t.description.strip()
    }
    for task in session.tasks:
        key = (task.description or "").strip().lower()
        if key in wanted:
            task.completed = 1 if wanted[key] else 0
    db.commit()
    db.refresh(session)
    return session


# ---------------------------------------------------------------------------
# Academic progress  Esessions x quizzes x interventions, per account
# ---------------------------------------------------------------------------

@app.get("/analytics/academic", response_model=schemas.AcademicProgressOut)
def get_academic_progress(
    range: str = "month",
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db),
):
    """Academic-progress view: subject-level focus, quiz results and the
    system's interventions computed together, in real time, for THIS account
    only. There is deliberately no `user_id` override  Ea signed-in student
    always and only sees their own data (legacy mode sees the machine's
    unowned sessions). Parents/teachers go through the parent overview."""
    if range not in ("today", "week", "month", "year", "all"):
        raise HTTPException(400, "range must be one of: today, week, month, year, all")

    user_id = _user_id_from_header(authorization)
    q = db.query(models.StudySession).filter(models.StudySession.ended_at.isnot(None))
    if user_id is not None:
        q = q.filter(models.StudySession.user_id == user_id)
    else:
        q = q.filter(models.StudySession.user_id.is_(None))
    all_completed = q.order_by(models.StudySession.started_at).all()

    today = _to_local_day(datetime.now(timezone.utc))
    cutoff = None if range == "all" else today - timedelta(days=RANGE_DAYS[range] - 1)
    in_range = [s for s in all_completed if cutoff is None or _session_day(s) >= cutoff]

    # Focus per session from the denormalized totals (same formula as the
    # evaluation endpoint). Sessions with no tracked time are counted but
    # excluded from focus averages.
    tracked_secs = sum(
        (s.total_focused_seconds or 0.0) + (s.total_distracted_seconds or 0.0)
        for s in in_range
    )
    focus_vals = []
    for s in in_range:
        dur = (s.total_focused_seconds or 0.0) + (s.total_distracted_seconds or 0.0)
        if dur > 0:
            focus_vals.append(100.0 * (s.total_focused_seconds or 0.0) / dur)
    avg_focus = round(sum(focus_vals) / len(focus_vals), 1) if focus_vals else 0.0
    total_iv = sum(s.intervention_count or 0 for s in in_range)

    # Quizzes attached to these sessions (one per session, enforced by the
    # idempotent generate endpoint).
    sids = [s.id for s in in_range]
    quizzes = (
        db.query(models.Quiz).filter(models.Quiz.session_id.in_(sids)).all()
        if sids else []
    )
    quiz_by_session = {qq.session_id: qq for qq in quizzes}
    completed = [
        qq for qq in quizzes
        if qq.status == "completed" and qq.score is not None and (qq.question_count or 0) > 0
    ]

    def _score_pct(qq) -> float:
        return round(100.0 * qq.score / qq.question_count, 1)

    quiz_attempts = len(completed)
    avg_quiz = (
        round(sum(_score_pct(qq) for qq in completed) / len(completed), 1)
        if completed else None
    )

    # Focus/intervention movement across the range: first chronological half
    # vs second half.
    focus_trend_pts = None
    intervention_trend_pct = None
    if len(in_range) >= 2:
        mid = len(in_range) // 2
        halves = (in_range[:mid], in_range[mid:])
        half_pcts = []
        for half in halves:
            vals = []
            for s in half:
                dur = (s.total_focused_seconds or 0.0) + (s.total_distracted_seconds or 0.0)
                if dur > 0:
                    vals.append(100.0 * (s.total_focused_seconds or 0.0) / dur)
            half_pcts.append(sum(vals) / len(vals) if vals else None)
        if half_pcts[0] is not None and half_pcts[1] is not None:
            focus_trend_pts = round(half_pcts[1] - half_pcts[0], 1)
        iv_halves = [
            sum(s.intervention_count or 0 for s in half) / len(half)
            for half in halves
        ]
        if iv_halves[0] > 0:
            intervention_trend_pct = round(
                100.0 * (iv_halves[1] - iv_halves[0]) / iv_halves[0], 1
            )

    # Human sentence tying focus and interventions together (the "feedback
    # loop" read of the theoretical framework, in plain language).
    if not in_range:
        note = "No finished sessions in this range yet."
    elif len(in_range) < 2:
        note = ("One session in this range  Efinish another to see how your "
                "focus and nudge count move together.")
    else:
        if focus_trend_pts is None:
            focus_phrase = "has no comparable focus data yet"
        elif abs(focus_trend_pts) < 3.0:
            focus_phrase = "is holding steady"
        elif focus_trend_pts > 0:
            focus_phrase = f"is rising (+{focus_trend_pts} pts)"
        else:
            focus_phrase = f"is falling ({focus_trend_pts} pts)"
        if intervention_trend_pct is None:
            iv_phrase = ("stayed at zero" if total_iv == 0
                         else "has no reliable trend yet")
        elif abs(intervention_trend_pct) < 10.0:
            iv_phrase = "is holding steady"
        elif intervention_trend_pct > 0:
            iv_phrase = f"is rising (+{intervention_trend_pct:.0f}%)"
        else:
            iv_phrase = f"is falling ({intervention_trend_pct:.0f}%)"
        note = f"Focus {focus_phrase} while the nudge count {iv_phrase}."

    # --- per-subject slices ---
    by_subject: dict[str, list] = defaultdict(list)
    for s in in_range:
        key = (s.subject or "").strip() or "Unassigned"
        by_subject[key].append(s)

    subjects_out = []
    for name, group in by_subject.items():
        g_focus = []
        for s in group:
            dur = (s.total_focused_seconds or 0.0) + (s.total_distracted_seconds or 0.0)
            if dur > 0:
                g_focus.append(100.0 * (s.total_focused_seconds or 0.0) / dur)
        g_completed = [quiz_by_session[s.id] for s in group
                       if s.id in quiz_by_session
                       and quiz_by_session[s.id].status == "completed"
                       and quiz_by_session[s.id].score is not None
                       and (quiz_by_session[s.id].question_count or 0) > 0]
        g_trend = "first_run"
        if len(group) >= 2:
            mid = len(group) // 2
            halves = (group[:mid], group[mid:])
            hv = []
            for half in halves:
                vals = []
                for s in half:
                    dur = (s.total_focused_seconds or 0.0) + (s.total_distracted_seconds or 0.0)
                    if dur > 0:
                        vals.append(100.0 * (s.total_focused_seconds or 0.0) / dur)
                hv.append(sum(vals) / len(vals) if vals else None)
            if hv[0] is not None and hv[1] is not None:
                delta = hv[1] - hv[0]
                g_trend = ("steady" if abs(delta) < 3.0
                           else "improved" if delta > 0 else "declined")
        subjects_out.append(schemas.SubjectProgressOut(
            subject=name,
            session_count=len(group),
            avg_focus_pct=round(sum(g_focus) / len(g_focus), 1) if g_focus else 0.0,
            best_focus_pct=round(max(g_focus), 1) if g_focus else None,
            total_interventions=sum(s.intervention_count or 0 for s in group),
            quiz_attempts=len(g_completed),
            avg_quiz_score=(
                round(sum(_score_pct(qq) for qq in g_completed) / len(g_completed), 1)
                if g_completed else None
            ),
            trend=g_trend,
        ))
    subjects_out.sort(key=lambda x: (-x.session_count, x.subject.lower()))

    # --- most recent sessions, newest first (incl. past sessions) ---
    recent = []
    for s in reversed(in_range[-10:]):
        qq = quiz_by_session.get(s.id)
        quiz_score = None
        quiz_diff = None
        if qq is not None:
            quiz_diff = qq.difficulty
            if qq.status == "completed" and qq.score is not None and (qq.question_count or 0) > 0:
                quiz_score = _score_pct(qq)
        dur = (s.total_focused_seconds or 0.0) + (s.total_distracted_seconds or 0.0)
        recent.append(schemas.AcademicSessionOut(
            session_id=s.id,
            task_description=s.task_description,
            subject=s.subject,
            started_at=s.started_at,
            focus_pct=round(100.0 * (s.total_focused_seconds or 0.0) / dur, 1) if dur > 0 else 0.0,
            intervention_count=s.intervention_count or 0,
            quiz_score=quiz_score,
            quiz_difficulty=quiz_diff,
        ))

    if cutoff:
        range_start = cutoff.isoformat()
    elif all_completed:
        range_start = _session_day(all_completed[0]).isoformat()
    else:
        range_start = today.isoformat()

    return schemas.AcademicProgressOut(
        range=range,
        range_start=range_start,
        range_end=today.isoformat(),
        total_sessions=len(in_range),
        avg_focus_pct=avg_focus,
        total_interventions=total_iv,
        interventions_per_hour=round(total_iv / (tracked_secs / 3600.0), 2) if tracked_secs > 0 else 0.0,
        quiz_attempts=quiz_attempts,
        avg_quiz_score=avg_quiz,
        focus_trend_pts=focus_trend_pts,
        intervention_trend_pct=intervention_trend_pct,
        note=note,
        subjects=subjects_out,
        recent_sessions=recent,
    )


# ---------------------------------------------------------------------------
# Web-hosted frontend (browser mode)
#
# When a browser opens Stubilly instead of the Electron shell, the backend
# itself serves the built React app  Eone server is the whole product: UI,
# API, and WebSockets on :8420. Registered LAST so every explicit API / WS
# route above keeps priority. Dev serves the source tree's frontend/dist; the
# PyInstaller bundle gets it from sys._MEIPASS/web.
# ---------------------------------------------------------------------------

_API_PATH_PREFIXES = frozenset({
    "auth", "admin", "sessions", "analytics", "policy", "health", "meta", "ws",
    "me", "parent", "interventions",
})


def _web_dist_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "web"
    return Path(__file__).resolve().parent.parent / "frontend" / "dist"


_WEB_DIST = _web_dist_dir()
_WEB_INDEX = _WEB_DIST / "index.html"

if _WEB_INDEX.is_file():
    from fastapi.responses import FileResponse, JSONResponse
    from starlette.staticfiles import StaticFiles

    _ASSETS = _WEB_DIST / "assets"
    if _ASSETS.is_dir():
        app.mount("/assets", StaticFiles(directory=_ASSETS), name="assets")

    # Vision model + WASM for the focus-cam. Served by the backend so browsers
    # load them locally (no CDN needed). Mounted on a prefix because the focus
    # detector probes it with HEAD, which the GET-only SPA catch-all below
    # rejects with 405.
    _MODELS = _WEB_DIST / "models"
    if _MODELS.is_dir():
        app.mount("/models", StaticFiles(directory=_MODELS), name="models")

    @app.get("/{full_path:path}")
    async def _serve_web(full_path: str):
        root = _WEB_DIST.resolve()
        candidate = (root / full_path).resolve()
        if full_path and candidate.is_file() and candidate.is_relative_to(root):
            return FileResponse(candidate)
        first = full_path.split("/", 1)[0]
        if first in _API_PATH_PREFIXES:
            return JSONResponse({"detail": "Not Found"}, status_code=404)
        # No-cache so browsers never keep a stale index.html/bundle after
        # redeploys.
        return FileResponse(
            _WEB_INDEX, headers={"Cache-Control": "no-cache, must-revalidate"}
        )
