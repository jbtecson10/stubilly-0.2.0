import { useState } from "react";

/**
 * Notes the companion captured on its own during the chat — nothing here
 * was manually saved by the student. `notes` is newest-first. Collapsed to
 * a slim header by default so long note lists never crowd the chat card.
 */
export default function NotesPanel({ notes }) {
  const [open, setOpen] = useState(false);

  if (!notes.length) {
    return (
      <div className="notes-panel notes-panel-empty">
        <h3 className="panel-heading">Notes</h3>
        <p className="notes-empty-text">
          Nothing captured yet — chat with Stubilly about your topic. Only the genuinely
          important points worth remembering get saved here.
        </p>
      </div>
    );
  }

  return (
    <div className="notes-panel">
      <button
        type="button"
        className="notes-panel-head side-panel-toggle"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <h3 className="panel-heading">Notes</h3>
        <span className="side-panel-badge">{notes.length}</span>
        <span className="side-panel-caret">{open ? "▾" : "▸"}</span>
      </button>
      {open && (
        <div className="side-panel-body">
          <span className="notes-auto-tag">Captured automatically · selective</span>
          <ul className="notes-list">
            {notes.map((n) => (
              <li key={n.id} className="notes-item">
                {n.content}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
