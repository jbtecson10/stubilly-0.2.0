import { useEffect, useRef, useState } from "react";
import { CameraOff } from "lucide-react";
import CompanionAvatar from "./CompanionAvatar";

const STATE_LABELS = {
  focused: "Focused",
  distracted: "Distracted",
  sleeping: "Waking you up",
  absent: "Away from desk",
};

// The companion's face reflects the student's live focus state, so the
// desk reads as a real presence watching alongside — not a static blob.
const AVATAR_STATE_BY_FOCUS = {
  focused: "focused",
  distracted: "distracted",
  sleeping: "sleeping",
  absent: "absent",
};

const MAX_ATTEMPTS = 6;
const RETRY_DELAY_MS = 900;

// Turn getUserMedia failures into advice a human can act on — never a
// raw exception name. The old code printed e.name, so a broken/missing
// mediaDevices API showed a bare "TypeError" under "No camera detected".
function describeCamError(e) {
  const name = typeof e === "string" ? "" : e?.name || "";
  switch (name) {
    case "NotAllowedError":
    case "PermissionDeniedError":
      return "Camera permission denied  Eallow camera access for this site (padlock icon in the address bar), then reopen the session.";
    case "NotReadableError":
    case "TrackStartError":
      return "The camera is busy in another app (Iriun/OBS/Zoom)  Eclose it and reopen the session.";
    case "OverconstrainedError":
      return "No camera matches the requested mode  Econnect a different webcam and reopen the session.";
    case "SecurityError":
    case "TypeError":
      return "The browser blocked the camera API on this page  Eopen Stubilly via the https tunnel link or http://127.0.0.1:8422, then reopen the session.";
    case "NotFoundError":
    case "DevicesNotFoundError":
      return "";
    default:
      return e?.message ? String(e.message).slice(0, 200) : "";
  }
}

export default function WebcamPanel({ videoRef, state, companion, onStreamReady }) {
  const containerRef = useRef(null);
  const [unavailable, setUnavailable] = useState(false);
  const [errorTitle, setErrorTitle] = useState("No camera detected");
  const [errorDetail, setErrorDetail] = useState("");

  useEffect(() => {
    let stream;
    let cancelled = false;
    let attempt = 0;

    async function tryOpen() {
      attempt += 1;
      // getUserMedia exists only in secure contexts (https or
      // localhost/127.0.0.1). Over plain http on a LAN/Tailscale IP the
      // API is simply absent, and the old code surfaced the resulting
      // TypeError verbatim instead of explaining it.
      if (typeof window !== "undefined" && !window.isSecureContext) {
        if (!cancelled) {
          setUnavailable(true);
          setErrorTitle("Camera unavailable on this address");
          setErrorDetail(
            "Browsers only expose the webcam on secure pages. Open Stubilly via the https tunnel link or http://127.0.0.1:8422, then reopen the session."
          );
        }
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        if (!cancelled) {
          setUnavailable(true);
          setErrorTitle("Camera blocked by the browser");
          setErrorDetail(
            "This browser hides the webcam on this page. Open via the https tunnel link or http://127.0.0.1:8422, then reopen the session."
          );
        }
        return;
      }
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 480, height: 360, facingMode: "user" },
        });
        if (cancelled) {
          stream?.getTracks().forEach((t) => t.stop());
          return;
        }
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          if (onStreamReady) onStreamReady();
          setUnavailable(false);
          setErrorTitle("No camera detected");
          setErrorDetail("");
        }
      } catch (e) {
        // "busy" error: another instance/app owns the camera. Retry a few
        // times instead of failing permanently on a transient lock.
        const transient = e?.name === "NotReadableError" && attempt < MAX_ATTEMPTS;
        if (transient) {
          await new Promise((r) => setTimeout(r, RETRY_DELAY_MS));
          if (!cancelled) tryOpen();
          return;
        }
        console.error("Webcam access failed:", e);
        if (!cancelled) {
          const detail = describeCamError(e);
          setUnavailable(true);
          setErrorTitle(
            e?.name === "NotAllowedError" || e?.name === "PermissionDeniedError"
              ? "Camera blocked"
              : e?.name === "NotReadableError"
                ? "Camera busy"
                : detail
                  ? "Camera unavailable"
                  : "No camera detected"
          );
          setErrorDetail(
            detail ||
              "Connect a webcam (for example, start Iriun Webcam + phone) and reopen the session to enable it. All other features keep working."
          );
        }
      }
    }

    tryOpen();
    return () => {
      cancelled = true;
      stream?.getTracks().forEach((t) => t.stop());
    };
  }, [videoRef, onStreamReady]);

  // The self-view is hidden: the camera still runs (and still feeds
  // MediaPipe through the hidden <video>), but the student sees their
  // companion's face on the stage instead of a mirror. The frame ring
  // keeps the focus state color, so the signal is never lost.
  const avatarState = AVATAR_STATE_BY_FOCUS[state] || "idle";

  return (
    <div className="webcam-panel">
      <div ref={containerRef} className={`webcam-frame companion-stage state-${state}`}>
        <video ref={videoRef} muted playsInline className="webcam-video webcam-video-hidden" />
        <CompanionAvatar
          companionId={companion?.id}
          color={companion?.color}
          size={260}
          state={avatarState}
          className="companion-stage-avatar"
        />
        <span className="companion-stage-name">
          {companion?.name || "Your companion"}
        </span>
        {unavailable && (
          <span className="companion-stage-camoff" title={errorDetail || errorTitle}>
            <CameraOff size={13} /> {errorTitle}
          </span>
        )}
      </div>
      {/* The focus line keeps moving even without a camera (app/window
          monitoring fills the ticks), so show the REAL state — a hardcoded
          "Focused" used to lie whenever the student drifted onto a
          non-whitelisted window with the webcam off. */}
      {state ? (
        <div className={`state-pill state-pill-${state}`}>
          <span className="state-dot" />
          {STATE_LABELS[state] || "Focused"}
        </div>
      ) : (
        <div className="state-pill state-pill-focusing">Focused</div>
      )}
    </div>
  );
}
