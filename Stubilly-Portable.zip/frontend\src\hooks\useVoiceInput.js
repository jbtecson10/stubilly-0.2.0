import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Real-time voice commands via the browser's Web Speech API.
 *
 * Streams partial results as the student speaks (zero upload delay), then
 * fires `onCommand` with the final transcript. Push-to-talk by default:
 * call `start()` to open the mic, `stop()` to close. The recognition
 * object auto-restarts once after a no-speech timeout so the mic stays
 * hot during a session without the student re-clicking every time.
 *
 * Returns null from the hook when the browser has no SpeechRecognition
 * (Firefox, some WebViews) so the UI can hide the mic button cleanly.
 */
export default function useVoiceInput({ onCommand, onPartial, lang = "en-US" }) {
  const [listening, setListening] = useState(false);
  const [partial, setPartial] = useState("");
  const [supported, setSupported] = useState(true);
  const recRef = useRef(null);
  const onCommandRef = useRef(onCommand);
  const onPartialRef = useRef(onPartial);
  const wantListeningRef = useRef(false);
  const bufferRef = useRef([]);
  const sendTimerRef = useRef(null);

  useEffect(() => {
    onCommandRef.current = onCommand;
    onPartialRef.current = onPartial;
  }, [onCommand, onPartial]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setSupported(false);
      return;
    }
    const rec = new SR();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = lang;
    rec.maxAlternatives = 1;

    rec.onresult = (event) => {
      let interim = "";
      let finalText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const t = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalText += t;
        else interim += t;
      }
      if (interim || bufferRef.current.length) {
        const shown = [...bufferRef.current, interim].filter(Boolean).join(" ");
        setPartial(shown);
        onPartialRef.current?.(shown);
      }
      if (finalText) {
        bufferRef.current.push(finalText.trim());
        // Chrome finalizes on short pauses mid-sentence. Buffer every chunk
        // and only hand the full utterance to the AI after REAL silence, so
        // it never replies while the student is still talking. 2.6s beats
        // the natural "it just… it just…" hesitation that fired the old
        // 1.3s timer early; a new final result restarts the window anyway.
        clearTimeout(sendTimerRef.current);
        sendTimerRef.current = setTimeout(() => {
          const text = bufferRef.current.join(" ").trim();
          bufferRef.current = [];
          setPartial("");
          if (text) onCommandRef.current?.(text);
        }, 2600);
      }
    };

    rec.onend = () => {
      setListening(false);
      // Auto-restart if the student still wants the mic open (e.g. after a
      // no-speech timeout) so voice stays hands-free for the whole session.
      if (wantListeningRef.current) {
        try {
          rec.start();
          setListening(true);
        } catch {
          // Already starting — ignore.
        }
      } else {
        window.stubillyMicHot = false;
      }
    };

    rec.onerror = (event) => {
      if (event.error === "not-allowed" || event.error === "service-not-allowed") {
        wantListeningRef.current = false;
        window.stubillyMicHot = false;
        setListening(false);
        setSupported(false);
      }
      // "no-speech" and "aborted" are normal — onend handles the restart.
    };

    recRef.current = rec;
    return () => {
      wantListeningRef.current = false;
      window.stubillyMicHot = false;
      clearTimeout(sendTimerRef.current);
      bufferRef.current = [];
      try {
        rec.abort();
      } catch {
        // Already stopped.
      }
      recRef.current = null;
    };
  }, [lang]);

  const start = useCallback(() => {
    if (!recRef.current) return;
    wantListeningRef.current = true;
    window.stubillyMicHot = true;
    // Never talk over the student: opening the mic kills any in-flight
    // speech (a check-in banner speaking through speechSynthesis would
    // otherwise be transcribed INTO the student's message).
    try {
      window.speechSynthesis?.cancel();
    } catch {
      /* ignore */
    }
    try {
      recRef.current.start();
      setListening(true);
    } catch {
      // Already started.
    }
  }, []);

  const stop = useCallback(() => {
    wantListeningRef.current = false;
    window.stubillyMicHot = false;
    clearTimeout(sendTimerRef.current);
    const text = bufferRef.current.join(" ").trim();
    bufferRef.current = [];
    setPartial("");
    try {
      recRef.current?.stop();
    } catch {
      // Already stopped.
    }
    setListening(false);
    // Closing the mic means "that's what I meant" — send it.
    if (text) onCommandRef.current?.(text);
  }, []);

  const toggle = useCallback(() => {
    if (listening) stop();
    else start();
  }, [listening, start, stop]);

  return { listening, partial, supported, start, stop, toggle };
}
