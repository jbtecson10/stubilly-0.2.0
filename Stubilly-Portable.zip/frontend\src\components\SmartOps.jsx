import { useCallback, useEffect, useState } from "react";
import {
  Activity,
  Brain,
  Check,
  Clock,
  HeartPulse,
  KeyRound,
  LayoutDashboard,
  RefreshCw,
  ShieldAlert,
  ShieldBan,
  Timer,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { api } from "../api/client";

/**
 * Smart Ops — admin control panel for onboarding + the AI intervention
 * pipeline. Layout borrows a dashboard sidebar pattern: left rail nav with
 * icons, a blue hero banner, stat cards, then the active section's cards.
 * All data comes in as props (AdminHub owns state + the 4s poll).
 */
const SECTIONS = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "proposals", label: "Proposals", icon: ShieldAlert },
  { id: "accounts", label: "Accounts", icon: Users },
  { id: "access", label: "Access", icon: KeyRound },
  { id: "breaks", label: "Breaks", icon: Timer },
  { id: "model", label: "Model", icon: Brain },
  { id: "health", label: "Health", icon: HeartPulse },
];

export default function SmartOps({
  adminToken,
  acctRequests,
  acctReqStatus,
  setAcctReqStatus,
  blockTickets,
  autoBlock,
  updateAutoBlock,
  decideAccountRequest,
  decideTicket,
  refresh,
  opsError,
  opsLoading,
  fmt,
  sessions = [],
  section: controlledSection,
  onSectionChange,
}) {
  const [internalSection, setInternalSection] = useState("overview");
  const section = controlledSection ?? internalSection;
  const setSection = onSectionChange ?? setInternalSection;
  const [diag, setDiag] = useState(null);
  const [diagError, setDiagError] = useState(null);
  const [diagLoading, setDiagLoading] = useState(false);
  const [breakBusy, setBreakBusy] = useState(null);
  const [ml, setMl] = useState(null);
  const [mlError, setMlError] = useState(null);
  const [thrDraft, setThrDraft] = useState(null);
  const [thrBusy, setThrBusy] = useState(false);

  const loadDiag = useCallback(async () => {
    if (!adminToken) return;
    setDiagLoading(true);
    try {
      const d = await api.adminDiagnostics(adminToken);
      setDiag(d);
      setDiagError(null);
    } catch (e) {
      setDiagError(e?.message || "Couldn't load diagnostics.");
    } finally {
      setDiagLoading(false);
    }
  }, [adminToken]);

  const loadMl = useCallback(async () => {
    if (!adminToken) return;
    try {
      const d = await api.adminMlModel(adminToken);
      setMl(d);
      setThrDraft(d.threshold);
      setMlError(null);
    } catch (e) {
      setMlError(e?.message || "Couldn't load the model snapshot.");
    }
  }, [adminToken]);

  useEffect(() => {
    if (section === "health" || section === "breaks") loadDiag();
    if (section === "model") loadMl();
  }, [section, loadDiag, loadMl]);

  async function saveThreshold() {
    if (thrDraft == null) return;
    setThrBusy(true);
    try {
      const d = await api.adminSetMlThreshold(adminToken, Number(thrDraft));
      setMl(d);
      setThrDraft(d.threshold);
      setMlError(null);
    } catch (e) {
      setMlError(e?.message || "Couldn't save the threshold.");
    } finally {
      setThrBusy(false);
    }
  }

  function pct(v) {
    return v == null ? "—" : `${Math.round(v * 100)}%`;
  }

  const openSessions = (sessions || []).filter((s) => !s.ended_at);
  const onBreakCount = (diag?.open_sessions || []).filter((s) => s.on_break).length;
  const pendingReqs = acctRequests.filter((r) => r.status === "pending").length;

  async function grantBreak(sessionId, minutes = 5) {
    setBreakBusy(sessionId);
    try {
      await api.adminStartSessionBreak(adminToken, sessionId, minutes);
      await loadDiag();
    } catch (e) {
      setDiagError(e?.message || "Couldn't start the break.");
    } finally {
      setBreakBusy(null);
    }
  }

  async function endBreak(sessionId) {
    setBreakBusy(sessionId);
    try {
      await api.adminEndSessionBreak(adminToken, sessionId);
      await loadDiag();
    } catch (e) {
      setDiagError(e?.message || "Couldn't end the break.");
    } finally {
      setBreakBusy(null);
    }
  }

  function sessionLabel(s) {
    return s.student_name || s.user_name || s.email || `Session #${s.id}`;
  }

  const current = SECTIONS.find((s) => s.id === section) || SECTIONS[0];

  const stats = [
    {
      key: "proposals",
      label: "Open proposals",
      value: blockTickets.length,
      note: blockTickets.length ? "Waiting on your decision" : "All caught up",
      icon: ShieldAlert,
    },
    {
      key: "requests",
      label: "Account requests",
      value: acctRequests.length,
      note: pendingReqs > 0 ? `${pendingReqs} pending approval` : `Filter: ${acctReqStatus}`,
      icon: UserPlus,
    },
    {
      key: "sessions",
      label: "Live sessions",
      value: openSessions.length,
      note: onBreakCount > 0 ? `${onBreakCount} on break` : "Everyone studying",
      icon: Activity,
    },
    {
      key: "autoblock",
      label: "Auto-block",
      value: autoBlock ? "ON" : "OFF",
      note: autoBlock ? "Strong cases block alone" : "You approve every block",
      icon: ShieldBan,
      isText: true,
    },
  ];

  return (
    <div className="smartops admin-subpage">
      <aside className="so-nav" aria-label="Smart Ops navigation">
        <span className="so-nav-title">Smart Ops</span>
        {SECTIONS.map((s) => {
          const Icon = s.icon;
          const badge =
            s.id === "proposals" && blockTickets.length
              ? blockTickets.length
              : s.id === "accounts" && pendingReqs > 0
                ? pendingReqs
                : s.id === "breaks" && openSessions.length
                  ? openSessions.length
                  : null;
          return (
            <button
              key={s.id}
              type="button"
              className={`so-nav-item${section === s.id ? " is-active" : ""}`}
              aria-current={section === s.id ? "page" : undefined}
              onClick={() => setSection(s.id)}
            >
              <Icon size={18} strokeWidth={2.2} />
              <span>{s.label}</span>
              {badge != null && <span className="so-nav-badge">{badge}</span>}
            </button>
          );
        })}
      </aside>

      <div className="so-main">
        <header className="so-hero">
          <div>
            <span className="so-hero-badge">ADMIN CONTROL</span>
            <h2>Smart Operations</h2>
            <p>
              Proposals, accounts, breaks and health — nothing happens without
              your approval.
            </p>
          </div>
          <button
            type="button"
            className="so-hero-btn"
            onClick={() => {
              refresh();
              if (section === "health" || section === "breaks") loadDiag();
              if (section === "model") loadMl();
            }}
          >
            <RefreshCw size={16} /> Refresh
          </button>
        </header>

        <div className="so-stats">
          {stats.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.key} className="so-stat">
                <span className="so-stat-label">
                  <Icon size={14} /> {s.label}
                </span>
                <span className={`so-stat-value${s.isText ? " is-text" : ""}`}>
                  {s.value}
                </span>
                <span className="so-stat-note">{s.note}</span>
              </div>
            );
          })}
        </div>

        {opsError && <p className="login-error">{opsError}</p>}
        {opsLoading && <p className="admin-subtext">Loading…</p>}

        <section className="so-section" aria-label={current.label}>
          {section === "overview" && (
            <div className="so-grid">
              <div className="so-card">
                <div className="so-card-head">
                  <ShieldAlert size={18} />
                  <h4>How the intervention decides</h4>
                </div>
                <ul className="so-list">
                  <li>
                    <strong>Never blocked:</strong> browser, terminal, code
                    editors and Stubilly — the session lives in a tab.
                  </li>
                  <li>
                    <strong>Guide first:</strong> task-relevant windows get a
                    nudge, not a block (research videos, related docs).
                  </li>
                  <li>
                    <strong>Block:</strong> high-confidence off-task games,
                    social and video. Breaks lift every ban while they last.
                  </li>
                  <li>
                    <strong>Games:</strong> warned first, closed ~30s later if
                    ignored; reopening mid-session just closes it again.
                  </li>
                  <li>
                    <strong>5-minute rule:</strong> five straight minutes
                    off-task = hard block for the rest of the session.
                  </li>
                  <li>
                    <strong>Adaptive:</strong> the focus model nudges earlier
                    when it predicts drift for that student.
                  </li>
                </ul>
              </div>

              <div className="so-card">
                <div className="so-card-head">
                  <ShieldBan size={18} />
                  <h4>Auto-block mode</h4>
                </div>
                <p className="so-card-text">
                  {autoBlock
                    ? "High-confidence, task-irrelevant games block by themselves — you still see the ticket. Browsers, school sites and task-relevant windows are never auto-blocked."
                    : "Strong off-task evidence opens a proposal instead — only you can block. The AI still nudges obvious distractions."}
                </p>
                <div className="so-switch-row">
                  <span className="so-switch-label">
                    {autoBlock ? "Auto-block ON" : "Auto-block OFF"}
                  </span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={autoBlock}
                    className={`so-switch${autoBlock ? " on" : ""}`}
                    onClick={() => updateAutoBlock(!autoBlock)}
                  />
                </div>
              </div>
            </div>
          )}

          {section === "proposals" && (
            <div className="so-card">
              <div className="so-card-head">
                <ShieldAlert size={18} />
                <h4>Open intervention proposals</h4>
                <span className="so-count-chip">{blockTickets.length} open</span>
              </div>
              {blockTickets.length === 0 ? (
                <div className="so-empty">
                  <ShieldBan size={28} />
                  <p>Nothing to review — no open proposals.</p>
                </div>
              ) : (
                <table className="admin-table so-table">
                  <thead>
                    <tr>
                      <th>Student</th>
                      <th>What</th>
                      <th>Evidence</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {blockTickets.map((t) => (
                      <tr key={t.id}>
                        <td>
                          <strong className="so-strong">
                            {t.student_name || `User #${t.user_id}`}
                          </strong>
                        </td>
                        <td>
                          <div className="so-strong">{t.label}</div>
                          <span className="admin-subtext">
                            {t.app || t.kind}
                            {t.site ? ` · ${t.site}` : ""}
                          </span>
                        </td>
                        <td>
                          <div className="so-chips">
                            {t.strength === "strong" && (
                              <span className="so-chip blue">Strong</span>
                            )}
                            {t.strength !== "strong" && (
                              <span className="so-chip muted">Pending</span>
                            )}
                            {t.seconds > 0 && (
                              <span className="so-chip muted">
                                {Math.round(t.seconds / 60)} min
                              </span>
                            )}
                            {t.confidence > 0 && (
                              <span className="so-chip muted">
                                {Math.round(t.confidence * 100)}%
                              </span>
                            )}
                            {t.sighting_count > 0 && (
                              <span className="so-chip muted">
                                {t.sighting_count}×
                              </span>
                            )}
                          </div>
                          {t.title && (
                            <span className="admin-subtext">{t.title}</span>
                          )}
                        </td>
                        <td>
                          <div className="so-actions" role="group" aria-label="Proposal actions">
                            <button
                              type="button"
                              className="so-icon-btn danger"
                              title="Block"
                              onClick={() => decideTicket(t.id, "block")}
                            >
                              <ShieldBan size={16} />
                            </button>
                            <button
                              type="button"
                              className="so-icon-btn primary"
                              title="Allow once"
                              onClick={() => decideTicket(t.id, "allow_once")}
                            >
                              <Check size={16} />
                            </button>
                            <button
                              type="button"
                              className="so-icon-btn"
                              title="Defer"
                              onClick={() => decideTicket(t.id, "defer")}
                            >
                              <Clock size={16} />
                            </button>
                            <button
                              type="button"
                              className="so-icon-btn muted"
                              title="Deny"
                              onClick={() => decideTicket(t.id, "deny")}
                            >
                              <X size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {section === "accounts" && (
            <div className="so-card">
              <div className="so-card-head">
                <UserPlus size={18} />
                <h4>Account requests</h4>
                <div className="so-seg" role="group" aria-label="Filter requests">
                  {["pending", "approved", "denied", "all"].map((s) => (
                    <button
                      key={s}
                      type="button"
                      className={`so-seg-btn${acctReqStatus === s ? " is-active" : ""}`}
                      onClick={() => setAcctReqStatus(s)}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              {acctRequests.length === 0 ? (
                <div className="so-empty">
                  <Users size={28} />
                  <p>No {acctReqStatus} requests.</p>
                </div>
              ) : (
                <table className="admin-table so-table">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Role</th>
                      <th>Requested</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {acctRequests.map((r) => (
                      <tr key={r.id}>
                        <td>
                          <div className="so-strong">{r.full_name}</div>
                          {r.message && (
                            <span className="admin-subtext">{r.message}</span>
                          )}
                        </td>
                        <td>
                          <code>{r.email}</code>
                        </td>
                        <td>
                          <span className="so-chip muted">{r.role}</span>
                        </td>
                        <td>{fmt(r.created_at)}</td>
                        <td>
                          {r.status === "pending" ? (
                            <div className="so-actions" role="group" aria-label="Request actions">
                              <button
                                type="button"
                                className="so-icon-btn primary"
                                title="Approve"
                                onClick={() => decideAccountRequest(r.id, "approve")}
                              >
                                <Check size={16} />
                              </button>
                              <button
                                type="button"
                                className="so-icon-btn danger"
                                title="Deny"
                                onClick={() => decideAccountRequest(r.id, "deny")}
                              >
                                <X size={16} />
                              </button>
                            </div>
                          ) : (
                            <span className={`so-chip ${r.status === "approved" ? "blue" : "muted"}`}>
                              {r.status}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {section === "access" && (
            <div className="so-card">
              <div className="so-card-head">
                <KeyRound size={18} />
                <h4>Access rules the system never breaks</h4>
              </div>
              <ul className="so-list">
                <li>
                  <strong>Never-blocked apps:</strong> Chrome, Brave, Edge,
                  Firefox, terminals, code editors and Stubilly itself.
                </li>
                <li>
                  <strong>School allowlist:</strong> Classroom, Drive, Docs,
                  Canva, Office/Teams and Khan Academy always stay reachable.
                </li>
                <li>
                  <strong>Breaks lift everything:</strong> every hosts ban is
                  suspended for the break, re-applied the moment it ends.
                </li>
                <li>
                  <strong>End Session ends everything:</strong> bans, game
                  closes and interventions all stop at once.
                </li>
              </ul>
            </div>
          )}

          {section === "breaks" && (
            <div className="so-card">
              <div className="so-card-head">
                <Timer size={18} />
                <h4>Live sessions &amp; breaks</h4>
                <span className="so-count-chip">{openSessions.length} live</span>
              </div>
              <p className="so-card-text">
                Breaks run on the server timer — they always end, even if the
                student's tab dies. Ending one re-applies every ban instantly.
              </p>
              {diagError && <p className="login-error">{diagError}</p>}
              {openSessions.length === 0 ? (
                <div className="so-empty">
                  <Timer size={28} />
                  <p>No open sessions right now.</p>
                </div>
              ) : (
                <table className="admin-table so-table">
                  <thead>
                    <tr>
                      <th>Session</th>
                      <th>Student</th>
                      <th>Break state</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {openSessions.map((s) => {
                      const live = (diag?.open_sessions || []).find(
                        (d) => d.session_id === s.id
                      );
                      const onBreak = Boolean(live?.on_break);
                      return (
                        <tr key={s.id}>
                          <td>
                            <strong className="so-strong">#{s.id}</strong>
                            <span className="admin-subtext"> · {fmt(s.started_at)}</span>
                          </td>
                          <td>{sessionLabel(s)}</td>
                          <td>
                            {onBreak ? (
                              <span className="so-chip blue">
                                On break
                                {live?.break_ends_at
                                  ? ` till ${live.break_ends_at.slice(11, 19)}`
                                  : ""}
                              </span>
                            ) : (
                              <span className="so-chip muted">Studying</span>
                            )}
                          </td>
                          <td>
                            {onBreak ? (
                              <button
                                type="button"
                                className="so-pill-btn"
                                disabled={breakBusy === s.id}
                                onClick={() => endBreak(s.id)}
                              >
                                <X size={15} /> End break
                              </button>
                            ) : (
                              <button
                                type="button"
                                className="so-pill-btn"
                                disabled={breakBusy === s.id}
                                onClick={() => grantBreak(s.id, 5)}
                              >
                                <Clock size={15} /> Grant 5-min break
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          )}

          {section === "model" && (
            <div className="so-grid">
              <div className="so-card">
                <div className="so-card-head">
                  <Brain size={18} />
                  <h4>On-task model accuracy</h4>
                  <button
                    type="button"
                    className="so-pill-btn"
                    onClick={loadMl}
                  >
                    <RefreshCw size={15} /> Reload
                  </button>
                </div>
                <p className="so-card-text">
                  Trains on your block/deny decisions: Block = off-task,
                  Deny = on-task. The model never overrides the rules — it
                  only raises the "guide" floor, and only above the dial
                  below.
                </p>
                {mlError && <p className="login-error">{mlError}</p>}
                {!ml && !mlError && (
                  <div className="so-empty">
                    <Brain size={28} />
                    <p>Loading model snapshot…</p>
                  </div>
                )}
                {ml && (
                  <table className="admin-table so-table">
                    <tbody>
                      <tr>
                        <td className="so-key">Status</td>
                        <td>
                          {ml.trained ? (
                            <span className="so-chip blue">Trained</span>
                          ) : (
                            <span className="so-chip muted">
                              Rules only — needs {ml.min_labeled_to_train} labeled
                              decisions
                            </span>
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className="so-key">Labeled decisions</td>
                        <td>
                          {ml.n_samples} total
                          {ml.trained && (
                            <span className="admin-subtext">
                              {" "}· {ml.label_counts.blocked || 0} blocked /{" "}
                              {ml.label_counts.denied || 0} denied
                            </span>
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className="so-key">Train accuracy</td>
                        <td>{pct(ml.stats?.train_acc)}</td>
                      </tr>
                      <tr>
                        <td className="so-key">Holdout accuracy</td>
                        <td>
                          {pct(ml.stats?.holdout_acc)}
                          {ml.trained && ml.stats?.n_holdout > 0 && (
                            <span className="admin-subtext">
                              {" "}· last {ml.stats.n_holdout} chronological
                              samples
                            </span>
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className="so-key">Last trained</td>
                        <td>{ml.trained_at || "—"}</td>
                      </tr>
                      <tr>
                        <td className="so-key">Regularization (L2 λ)</td>
                        <td>{ml.l2_lambda}</td>
                      </tr>
                    </tbody>
                  </table>
                )}
              </div>

              <div className="so-card">
                <div className="so-card-head">
                  <Activity size={18} />
                  <h4>Bias–variance dial</h4>
                </div>
                <p className="so-card-text">
                  Lower the dial and the model nudges borderline windows
                  toward "guide" more often (more lenient). Raise it and the
                  model stays quiet unless very confident (rules dominate).
                  The dial only ever <em>adds</em> to the guide floor — it
                  can never make blocking stricter on its own.
                </p>
                {ml && (
                  <div className="so-slider-block">
                    <div className="so-slider-row">
                      <span className="so-slider-label">Threshold</span>
                      <span className="so-chip blue">
                        {Number(thrDraft ?? ml.threshold).toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0.05"
                      max="0.95"
                      step="0.05"
                      value={thrDraft ?? ml.threshold}
                      onChange={(e) => setThrDraft(Number(e.target.value))}
                      className="so-slider"
                      aria-label="Model threshold"
                    />
                    <div className="so-slider-scale">
                      <span>0.05 · lenient</span>
                      <span>0.95 · strict</span>
                    </div>
                    <button
                      type="button"
                      className="so-pill-btn"
                      disabled={
                        thrBusy || thrDraft == null || thrDraft === ml.threshold
                      }
                      onClick={saveThreshold}
                    >
                      {thrBusy ? "Saving…" : "Save threshold"}
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {section === "health" && (
            <div className="so-card">
              <div className="so-card-head">
                <HeartPulse size={18} />
                <h4>System health</h4>
                <button
                  type="button"
                  className="so-pill-btn"
                  onClick={loadDiag}
                  disabled={diagLoading}
                >
                  <RefreshCw size={15} /> {diagLoading ? "Checking…" : "Re-check"}
                </button>
              </div>
              {diagError && <p className="login-error">{diagError}</p>}
              {!diag && !diagError && (
                <div className="so-empty">
                  <HeartPulse size={28} />
                  <p>Loading diagnostics…</p>
                </div>
              )}
              {diag && (
                <table className="admin-table so-table">
                  <tbody>
                    <tr>
                      <td className="so-key">Window monitor probe</td>
                      <td>
                        {diag.window_probe_available ? (
                          <span className="so-chip blue">Available</span>
                        ) : (
                          <span className="so-chip red">Unavailable — monitoring is blind</span>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className="so-key">Games running right now</td>
                      <td>
                        {(diag.active_games_detected || []).length === 0 ? (
                          <span className="so-chip muted">None detected</span>
                        ) : (
                          <span className="so-chip red">
                            {diag.active_games_detected.join(", ")}
                          </span>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className="so-key">Open sessions</td>
                      <td>
                        {(diag.open_sessions || []).length === 0 ? (
                          <span className="so-chip muted">None</span>
                        ) : (
                          <span className="admin-subtext">
                            {diag.open_sessions
                              .map(
                                (s) =>
                                  `#${s.session_id}${s.on_break ? " (break)" : ""}`
                              )
                              .join(", ")}
                          </span>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className="so-key">Recent internal errors</td>
                      <td>
                        {(diag.recent_errors || []).length === 0 ? (
                          <span className="so-chip blue">None — clean</span>
                        ) : (
                          <ul className="so-list">
                            {diag.recent_errors.slice(0, 10).map((err, i) => (
                              <li key={`${err.at}-${i}`}>
                                <code>{err.where}</code> · {err.error} · {err.at}
                              </li>
                            ))}
                          </ul>
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
