import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, getWsUrl, getToken } from "../api/client";
import "../parent.css";
import useParentTheme from "../hooks/useParentTheme";
import { serverNow, setServerSkew, parseServerTime, detailOf } from "./parent/shared.jsx";
import ParentShell from "./parent/ParentShell.jsx";
import OverviewSection from "./parent/sections/OverviewSection.jsx";
import AlertsSection from "./parent/sections/AlertsSection.jsx";
import HistorySection from "./parent/sections/HistorySection.jsx";
import ControlsSection from "./parent/sections/ControlsSection.jsx";
import FamilySection from "./parent/sections/FamilySection.jsx";
import SettingsSection from "./parent/sections/SettingsSection.jsx";

/**
 * Parent/guardian dashboard — the OUTPUT layer for accountability.
 *
 * Shows linked students' focus status, live site presence (which site they
 * are on now and most used today — Family-Link style, site only), live
 * alerts and session reports. Deliberately NO chat transcript, notes or
 * window content: this view only ever receives focus state, site presence,
 * off-task events and numeric summaries.
 *
 * This component owns ALL state, cadences and handlers; the left-rail
 * layout and section JSX live in ./parent/* (pure presentation).
 */
export default function ParentDashboard({ user, setUser, onLogout }) {
  const [overview, setOverview] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [sites, setSites] = useState(null);
  // Parental controls and History open as ONE panel at a time
  // ({ type: "controls" | "history", id }) — the rail's History/Controls
  // sections render whichever panel is active (or a student picker).
  const [panel, setPanel] = useState(null);
  // Which rail section is showing (panels follow the panel state below).
  const [section, setSection] = useState("overview");
  const [drafts, setDrafts] = useState({});
  const [ctlMsg, setCtlMsg] = useState({});
  const [error, setError] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [adding, setAdding] = useState(false);
  const [addError, setAddError] = useState(null);
  const [form, setForm] = useState({
    full_name: "",
    email: "",
    password: "",
    date_of_birth: "",
  });
  const wsRef = useRef(null);
  // Add-student box: create a NEW account vs link an EXISTING one.
  const [addMode, setAddMode] = useState("create");
  const [linkIdent, setLinkIdent] = useState("");
  const [linking, setLinking] = useState(false);
  const [linkMsg, setLinkMsg] = useState(null);
  // Per-student history: active tab + fetched data (open state lives in panel).
  const [histTab, setHistTab] = useState({});
  const [histData, setHistData] = useState({});
  const [dayData, setDayData] = useState({});
  const [histDate, setHistDate] = useState({});
  // Alert feed controls: one stream per student + unread-only view, so the
  // feed stays readable no matter how many students are linked.
  const [alertStudent, setAlertStudent] = useState("all");
  const [unreadOnly, setUnreadOnly] = useState(false);
  // Inline Block button per alert id: "busy" | "error".
  const [blockState, setBlockState] = useState({});
  // Live clock tick: re-render every 5s so relative labels keep counting
  // ("12s ago" -> "17s ago") in realtime, with no polling involved.
  const [, setClockTick] = useState(0);
  // Realtime channel status for the header Live badge:
  // "connecting" | "live" | "reconnecting".
  const [wsState, setWsState] = useState("connecting");
  // Guardian light/dark skin (localStorage: stubilly-parent-theme).
  const { theme, toggleTheme } = useParentTheme();

  // First-time parent tutorial (coach-mark style, per-user localStorage key).
  const [showTutorial, setShowTutorial] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [tutorialRect, setTutorialRect] = useState(null);

  const TUTORIAL_STEPS = useMemo(() => ([
    {
      selector: '[data-tutorial="pnav-overview"]',
      title: "Overview",
      desc: "See your child's focus status, screen time and current activity at a glance.",
    },
    {
      selector: '[data-tutorial="pnav-alerts"]',
      title: "Alerts",
      desc: "Get notified in real time when your child goes off-task. Block distracting sites with one tap.",
    },
    {
      selector: '[data-tutorial="pnav-history"]',
      title: "History",
      desc: "Review past sessions, daily screen time and which sites or apps were used most.",
    },
    {
      selector: '[data-tutorial="pnav-controls"]',
      title: "Controls",
      desc: "Set screen time limits, downtime schedules and blocked sites. Pause the device anytime.",
    },
    {
      selector: '[data-tutorial="pnav-family"]',
      title: "Family",
      desc: "Add your child's account or link one they already have. Grant or withdraw monitoring consent.",
    },
    {
      selector: '[data-tutorial="pnav-settings"]',
      title: "Settings",
      desc: "Switch between light and dark theme, manage your account and sign out.",
    },
  ]), []);

  // Show the tutorial once per NEW parent account (server flag tutorial_seen).
  // Legacy accounts arrive with tutorial_seen=true and never see it.
  useEffect(() => {
    if (!user) return;
    if (user.tutorial_seen === false) {
      setShowTutorial(true);
      setTutorialStep(0);
    }
  }, [user]);

  // Track the highlighted element's viewport rect for the coach-mark spotlight.
  useEffect(() => {
    if (!showTutorial) { setTutorialRect(null); return undefined; }
    const step = TUTORIAL_STEPS[tutorialStep];
    if (!step) { setTutorialRect(null); return undefined; }
    let raf;
    const measure = () => {
      const el = document.querySelector(step.selector);
      if (!el) { setTutorialRect(null); return; }
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      raf = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect();
        setTutorialRect({ top: r.top, left: r.left, width: r.width, height: r.height });
      });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", measure); };
  }, [showTutorial, tutorialStep, TUTORIAL_STEPS]);

  const loadAll = useCallback(async () => {
    try {
      const [ov, al] = await Promise.all([api.parentOverview(), api.parentAlerts()]);
      setOverview(ov);
      setAlerts(al);
      // Site presence is a bonus view — a failure here must not blank the
      // whole dashboard.
      try {
        setSites(await api.parentSites());
      } catch {
        /* keep the last known presence */
      }
      setError(null);
    } catch (e) {
      const msg = e.message || "";
      if (msg.includes("403") || msg.includes("Parent/guardian")) {
        setError("This account does not have parent/guardian permissions. Please ask an administrator to update your account role to 'parent'.");
      } else {
        setError(`Couldn't load focus data (${e.message})`);
      }
    }
  }, []);

  useEffect(() => {
    loadAll();
    const timer = setInterval(loadAll, 15000);
    return () => clearInterval(timer);
  }, [loadAll]);

  // Clock sync: cheap /meta/time probe at mount and every minute, so the
  // skew-corrected "2m ago" stays exact even after hours offline or on a
  // device whose clock is wrong.
  useEffect(() => {
    let alive = true;
    async function syncClock() {
      try {
        const t = await api.serverTime();
        const ms = parseServerTime(t?.server_time)?.getTime();
        if (alive && ms) setServerSkew(ms - Date.now());
      } catch {
        /* keep the last known skew */
      }
    }
    syncClock();
    const timer = setInterval(syncClock, 60000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, []);

  // Realtime relative labels: one cheap re-render every 5s refreshes every
  // timeAgo() on screen (alerts, presence, window ages) — no polling of
  // data, just the clock.
  useEffect(() => {
    const timer = setInterval(() => setClockTick((t) => t + 1), 5000);
    return () => clearInterval(timer);
  }, []);

  // Realtime channel: alerts pushed the moment they happen.
  useEffect(() => {
    let active = true;
    let reconnectTimer = null;
    let attempt = 0;

    async function connect() {
      setWsState("connecting");
      const token = getToken();
      if (!token) return;
      const url = await getWsUrl(`/ws/parent?token=${encodeURIComponent(token)}`);
      if (!active) return;
      const ws = new WebSocket(url);
      wsRef.current = ws;
      ws.onopen = () => {
        if (active) setWsState("live");
      };
      ws.onmessage = (evt) => {
        if (!active) return;
        try {
          const msg = JSON.parse(evt.data);
          if (msg.type === "alert" && msg.alert) {
            setAlerts((prev) =>
              prev.some((a) => a.id === msg.alert.id) ? prev : [msg.alert, ...prev]
            );
            setOverview((prev) =>
              prev ? { ...prev, unread_alerts: (prev.unread_alerts || 0) + 1 } : prev
            );
          }
          if (msg.type === "presence" && msg.student_id) {
            // Live status push (login/logout/status change) — the card's
            // online/offline chip flips without waiting for the HTTP poll.
            setOverview((prev) =>
              prev
                ? {
                    ...prev,
                    students: prev.students.map((s) =>
                      s.id === msg.student_id
                        ? {
                            ...s,
                            status:
                              msg.status ||
                              (msg.online ? "signed_in" : "offline"),
                            current_task:
                              msg.current_task !== undefined
                                ? msg.current_task
                                : s.current_task,
                          }
                        : s
                    ),
                  }
                : prev
            );
          }
          if (msg.type === "site_status" && msg.student_id) {
            // Live presence update — the card refreshes the moment the
            // student switches sites or apps, including the inside-
            // Stubilly flag and the day's running screen-time estimate.
            setSites((prev) =>
              prev
                ? {
                    ...prev,
                    students: prev.students.map((s) =>
                      s.id === msg.student_id
                        ? {
                            ...s,
                            current_site: msg.site ?? null,
                            current_site_at: msg.at,
                            current_app: msg.app ?? null,
                            current_app_at: msg.at,
                            in_stubilly:
                              typeof msg.in_stubilly === "boolean"
                                ? msg.in_stubilly
                                : s.in_stubilly ?? null,
                            screen_seconds_today:
                              typeof msg.screen_seconds_today === "number"
                                ? msg.screen_seconds_today
                                : s.screen_seconds_today,
                          }
                        : s
                    ),
                  }
                : prev
            );
          }
          if (msg.type === "window_status" && msg.student_id) {
            // Foreground-window change pushed by the server-side sampler:
            // the card's "On screen" line updates the moment the student
            // switches windows (title only, never content).
            setSites((prev) =>
              prev
                ? {
                    ...prev,
                    students: prev.students.map((s) =>
                      s.id === msg.student_id
                        ? {
                            ...s,
                            current_window: msg.title ?? null,
                            current_window_at: msg.at,
                          }
                        : s
                    ),
                  }
                : prev
            );
          }
        } catch {
          /* malformed frame — ignore */
        }
      };
      ws.onclose = () => {
        if (!active) return;
        setWsState("reconnecting");
        const delay = Math.min(1000 * 2 ** attempt, 15000);
        attempt++;
        reconnectTimer = setTimeout(connect, delay);
      };
      ws.onerror = () => ws.close();
    }

    connect();
    return () => {
      active = false;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
      wsRef.current = null;
    };
  }, []);

  async function markRead(alertId) {
    setAlerts((prev) =>
      prev.map((a) =>
        a.id === alertId ? { ...a, read_at: new Date(serverNow()).toISOString() } : a
      )
    );
    try {
      await api.parentMarkAlertRead(alertId);
    } catch {
      loadAll(); // resync if the server rejected it
    }
  }

  // Bulk read — one call for everything visible (or one student's stream).
  // Optimistic: labels flip instantly, resync on failure.
  async function markAllRead() {
    const sid = alertStudent === "all" ? null : Number(alertStudent);
    const stamp = new Date(serverNow()).toISOString();
    setAlerts((prev) =>
      prev.map((a) =>
        !a.read_at && (sid === null || a.student_id === sid)
          ? { ...a, read_at: stamp }
          : a
      )
    );
    try {
      await api.parentMarkAllAlertsRead(sid || undefined);
    } catch {
      loadAll();
    }
  }

  // "Block youtube.com" straight from the alert — the guardian's most
  // common reaction to a site_visit row, without opening parental controls.
  async function blockSiteFromAlert(a) {
    const site = a?.payload?.site;
    const s = students.find((x) => x.id === a.student_id);
    if (!site || !s || (s.blocked_sites || []).includes(site)) return;
    setBlockState((p) => ({ ...p, [a.id]: "busy" }));
    try {
      const out = await api.parentStudentPolicy(s.id, {
        blocked_sites: [...(s.blocked_sites || []), site],
        allowed_sites: s.allowed_sites || [],
      });
      replaceStudent({
        ...s,
        blocked_sites: out.blocked_sites || [],
        allowed_sites: out.allowed_sites || [],
      });
      if (drafts[s.id]) updateDraft(s.id, { sites: [...(out.blocked_sites || [])] });
      setBlockState((p) => ({ ...p, [a.id]: "done" }));
    } catch {
      setBlockState((p) => ({ ...p, [a.id]: "error" }));
    }
  }

  async function setConsent(student, granted) {
    try {
      await api.parentConsent(student.id, granted);
      await loadAll();
    } catch (e) {
      setError(`Couldn't update consent (${e.message})`);
    }
  }

  // --- Parental controls (Family-Link style): block/allow lists, screen
  // limit, downtime window and the device pause switch. All parent-owned;
  // saves take effect live (mid-session enforcement included). ---

  function replaceStudent(updated) {
    setOverview((prev) =>
      prev
        ? {
            ...prev,
            students: prev.students.map((x) =>
              x.id === updated.id ? { ...x, ...updated } : x
            ),
          }
        : prev
    );
  }

  function toggleControls(s) {
    const open = !(panel?.type === "controls" && panel.id === s.id);
    setPanel(open ? { type: "controls", id: s.id } : null);
    if (open && !drafts[s.id]) {
      setDrafts((prev) => ({
        ...prev,
        [s.id]: {
          limit: s.daily_screen_limit_min ?? "",
          ds: s.downtime_start || "",
          de: s.downtime_end || "",
          sites: [...(s.blocked_sites || [])],
          newSite: "",
        },
      }));
    }
  }

  function updateDraft(id, patch) {
    setDrafts((prev) => ({ ...prev, [id]: { ...prev[id], ...patch } }));
  }

  function addSite(id) {
    const d = drafts[id];
    if (!d) return;
    const value = (d.newSite || "").trim().toLowerCase();
    if (!value) return;
    updateDraft(id, {
      sites: d.sites.includes(value) ? d.sites : [...d.sites, value],
      newSite: "",
    });
  }

  function removeSite(id, site) {
    const d = drafts[id];
    if (!d) return;
    updateDraft(id, { sites: d.sites.filter((x) => x !== site) });
  }

  async function savePolicy(s) {
    const d = drafts[s.id];
    if (!d) return;
    setCtlMsg((m) => ({ ...m, [s.id]: null }));
    try {
      const out = await api.parentStudentPolicy(s.id, {
        blocked_sites: d.sites,
        allowed_sites: s.allowed_sites || [],
      });
      replaceStudent({
        ...s,
        blocked_sites: out.blocked_sites || [],
        allowed_sites: out.allowed_sites || [],
      });
      updateDraft(s.id, { sites: [...(out.blocked_sites || [])] });
      setCtlMsg((m) => ({ ...m, [s.id]: "Sites saved — applied live." }));
    } catch (e) {
      setCtlMsg((m) => ({ ...m, [s.id]: detailOf(e) }));
    }
  }

  async function saveLimits(s) {
    const d = drafts[s.id];
    if (!d) return;
    setCtlMsg((m) => ({ ...m, [s.id]: null }));
    try {
      const parsed = d.limit === "" || d.limit === null ? null : parseInt(d.limit, 10);
      const updated = await api.parentStudentLimits(s.id, {
        daily_screen_limit_min: Number.isFinite(parsed) ? parsed : null,
        downtime_start: d.ds || null,
        downtime_end: d.de || null,
      });
      replaceStudent(updated);
      setCtlMsg((m) => ({ ...m, [s.id]: "Screen rules saved — enforced at once." }));
    } catch (e) {
      setCtlMsg((m) => ({ ...m, [s.id]: detailOf(e) }));
    }
  }

  async function togglePause(s) {
    setCtlMsg((m) => ({ ...m, [s.id]: null }));
    try {
      const updated = await api.parentStudentLimits(s.id, {
        device_paused: !s.device_paused,
      });
      replaceStudent(updated);
      setCtlMsg((m) => ({
        ...m,
        [s.id]: updated.device_paused
          ? "Device paused — no new session, current one ends."
          : "Device resumed.",
      }));
    } catch (e) {
      setCtlMsg((m) => ({ ...m, [s.id]: detailOf(e) }));
    }
  }

  // Activity monitoring switch: window sampling + the click timeline the
  // Activity tab renders. Server enforces it on every flush and sampler
  // tick, so the button is just the friendly surface.
  async function toggleMonitoring(s) {
    setCtlMsg((m) => ({ ...m, [s.id]: null }));
    try {
      const updated = await api.parentStudentLimits(s.id, {
        monitoring_enabled: s.monitoring_enabled === false,
      });
      replaceStudent(updated);
      setCtlMsg((m) => ({
        ...m,
        [s.id]: updated.monitoring_enabled
          ? "Activity monitoring on — window titles and clicks recorded while a session runs."
          : "Activity monitoring off — window sampling and the click timeline stopped.",
      }));
    } catch (e) {
      setCtlMsg((m) => ({ ...m, [s.id]: detailOf(e) }));
    }
  }

  // USERS box: the guardian creates their own student's account.
  async function createStudent(e) {
    e.preventDefault();
    setAdding(true);
    setAddError(null);
    try {
      await api.parentCreateStudent({
        full_name: form.full_name.trim(),
        email: form.email.trim(),
        password: form.password,
        date_of_birth: form.date_of_birth || null,
      });
      setForm({ full_name: "", email: "", password: "", date_of_birth: "" });
      setShowAdd(false);
      await loadAll();
    } catch (err) {
      setAddError(detailOf(err));
    } finally {
      setAdding(false);
    }
  }

  // Link an EXISTING account (the student already registered — maybe
  // they're studying right now) to this guardian, by email or serial.
  async function linkStudent(e) {
    e.preventDefault();
    const ident = linkIdent.trim();
    if (!ident) return;
    setLinking(true);
    setLinkMsg(null);
    try {
      const s = await api.parentLinkStudent(ident);
      setLinkMsg({
        ok: true,
        text: `${s.full_name || s.serial_number} is now linked to you.`,
      });
      setLinkIdent("");
      await loadAll();
    } catch (err) {
      setLinkMsg({ ok: false, text: detailOf(err) });
    } finally {
      setLinking(false);
    }
  }

  // --- Per-student history: session list + by-day activity. Both refresh
  // live (open panels re-fetch on the dashboard's cadence) so screen time
  // keeps ticking per session while the guardian watches. ---

  const refreshHistory = async (studentId) => {
    try {
      const sessions = await api.parentStudentSessions(studentId, 30);
      setHistData((prev) => ({ ...prev, [studentId]: sessions }));
    } catch {
      /* keep the last known list */
    }
  };

  const refreshDay = async (studentId, date) => {
    try {
      const act = await api.parentStudentActivity(studentId, date || undefined);
      setDayData((prev) => ({ ...prev, [studentId]: act }));
    } catch {
      /* keep the last known day */
    }
  };

  function toggleHistory(s) {
    const open = !(panel?.type === "history" && panel.id === s.id);
    setPanel(open ? { type: "history", id: s.id } : null);
    if (open) {
      if (!histTab[s.id]) setHistTab((prev) => ({ ...prev, [s.id]: "sessions" }));
      refreshHistory(s.id);
      refreshDay(s.id, histDate[s.id]);
    }
  }

  function switchHistTab(s, tab) {
    setHistTab((prev) => ({ ...prev, [s.id]: tab }));
    if (tab === "sessions" && !histData[s.id]) refreshHistory(s.id);
    if ((tab === "day" || tab === "activity") && !dayData[s.id]) refreshDay(s.id, histDate[s.id]);
  }

  function setHistDay(s, date) {
    setHistDate((prev) => ({ ...prev, [s.id]: date }));
    refreshDay(s.id, date);
  }

  // Keep an OPEN history panel live: screen time and session rollups accrue
  // while the guardian watches, at the same cadence as the cards.
  useEffect(() => {
    if (!(panel && panel.type === "history")) return undefined;
    const id = panel.id;
    const timer = setInterval(() => {
      refreshHistory(id);
      refreshDay(id, histDate[id]);
    }, 15000);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [panel, histDate]);

  // Navigation follows the panel: opening History/Controls from a card
  // also lands the shell on that section. Closing a panel (or picking a
  // student from a section's picker, which opens the panel) flows the
  // same way — no modal, no Escape/scroll-lock needed anymore.
  useEffect(() => {
    if (panel) setSection(panel.type);
  }, [panel]);

  const students = overview?.students || [];
  const unread = alerts.filter((a) => !a.read_at).length;
  // Feed view: per-student stream and/or unread-only, capped at the
  // newest 60 like before — but now the cap is visible and explainable.
  const shownAlerts = alerts.filter(
    (a) =>
      (alertStudent === "all" || a.student_id === Number(alertStudent)) &&
      (!unreadOnly || !a.read_at)
  );
  const sitesById = {};
  for (const s of sites?.students || []) sitesById[s.id] = s;

  // Focus switcher (the scalable view for MANY linked students): one
  // selector drives the cards AND the alert feed. Pick a ward and the page
  // collapses to just them; "All students" is the overview grid.
  const focusMatch =
    alertStudent !== "all" && students.some((s) => String(s.id) === alertStudent);
  const visibleStudents = focusMatch
    ? students.filter((s) => String(s.id) === alertStudent)
    : students;
  const panelStudent = panel ? students.find((s) => s.id === panel.id) || null : null;

  // Feed grouped by day ("Today" / "Yesterday" / weekday): a precise
  // timeline with quiet section headers instead of one flat shouty list.
  const feedItems = [];
  {
    let lastDay = null;
    for (const a of shownAlerts.slice(0, 60)) {
      const d = parseServerTime(a.created_at);
      const key = d ? d.toISOString().slice(0, 10) : "";
      if (key !== lastDay) {
        feedItems.push({ day: a.created_at, key: `day-${key}-${feedItems.length}` });
        lastDay = key;
      }
      feedItems.push({ alert: a, key: `alert-${a.id}` });
    }
  }

  const alertFeedProps = {
    students,
    alerts,
    shownAlerts,
    feedItems,
    alertStudent,
    setAlertStudent,
    focusMatch,
    unread,
    unreadOnly,
    setUnreadOnly,
    markAllRead,
    markRead,
    blockSiteFromAlert,
    blockState,
  };

  const addBoxProps = {
    showAdd,
    setShowAdd,
    addMode,
    setAddMode,
    addError,
    setAddError,
    linkMsg,
    setLinkMsg,
    form,
    setForm,
    createStudent,
    adding,
    linkIdent,
    setLinkIdent,
    linkStudent,
    linking,
  };

  const historyStudent = panel?.type === "history" ? panelStudent : null;
  const controlsStudent = panel?.type === "controls" ? panelStudent : null;

  return (
    <div className={"parent-skin" + (theme === "dark" ? " parent-theme-dark" : "")}>
      <ParentShell
        user={user}
        onLogout={onLogout}
        section={section}
        setSection={setSection}
        unread={unread}
        wsState={wsState}
        theme={theme}
        toggleTheme={toggleTheme}
      >
        {error && <p className="settings-error">{error}</p>}

        {section === "overview" && (
          <>
            <OverviewSection
              overview={overview}
              students={students}
              visibleStudents={visibleStudents}
              sitesById={sitesById}
              alerts={alerts}
              unread={unread}
              alertStudent={alertStudent}
              setAlertStudent={setAlertStudent}
              focusMatch={focusMatch}
              panel={panel}
              setConsent={setConsent}
              toggleHistory={toggleHistory}
              toggleControls={toggleControls}
              {...addBoxProps}
            />
            <AlertsSection {...alertFeedProps} standalone={false} />
          </>
        )}

        {section === "alerts" && <AlertsSection {...alertFeedProps} standalone />}

        {section === "history" && (
          <HistorySection
            students={students}
            student={historyStudent}
            tab={historyStudent ? histTab[historyStudent.id] : undefined}
            sessions={historyStudent ? histData[historyStudent.id] : undefined}
            day={historyStudent ? dayData[historyStudent.id] : undefined}
            date={historyStudent ? histDate[historyStudent.id] : undefined}
            onSwitchTab={(tab) => historyStudent && switchHistTab(historyStudent, tab)}
            onSetDay={(date) => historyStudent && setHistDay(historyStudent, date)}
            onOpenStudent={(id) => {
              const st = students.find((x) => x.id === id);
              if (st) toggleHistory(st);
            }}
          />
        )}

        {section === "controls" && (
          <ControlsSection
            students={students}
            student={controlsStudent}
            draft={controlsStudent ? drafts[controlsStudent.id] : null}
            ctlMsg={ctlMsg}
            updateDraft={updateDraft}
            addSite={addSite}
            removeSite={removeSite}
            saveLimits={saveLimits}
            savePolicy={savePolicy}
            togglePause={togglePause}
            toggleMonitoring={toggleMonitoring}
            onOpenStudent={(id) => {
              const st = students.find((x) => x.id === id);
              if (st) toggleControls(st);
            }}
          />
        )}

        {section === "family" && (
          <FamilySection students={students} setConsent={setConsent} {...addBoxProps} />
        )}

        {section === "settings" && (
          <SettingsSection
            user={user}
            onLogout={onLogout}
            theme={theme}
            toggleTheme={toggleTheme}
          />
        )}
      </ParentShell>
      {showTutorial && (() => {
        const step = TUTORIAL_STEPS[tutorialStep];
        const isLast = tutorialStep >= TUTORIAL_STEPS.length - 1;
        const isFirst = tutorialStep <= 0;
        const finish = () => {
          setShowTutorial(false);
          // Flip the server flag so this account never sees the tutorial
          // again on any browser. Best-effort: local state still hides it
          // for this session if the call fails.
          api.tutorialSeen().catch(() => {});
          if (setUser) setUser((u) => (u ? { ...u, tutorial_seen: true } : u));
        };
        const advance = () => { if (isLast) finish(); else setTutorialStep((v) => v + 1); };
        const goBack = () => { if (!isFirst) setTutorialStep((v) => v - 1); };
        let popTop = 0, popLeft = 0, popPos = "bottom", arrowLeft = 0;
        if (tutorialRect) {
          const POP_W = 320, GAP = 16, POP_H = 175;
          popLeft = Math.max(16, Math.min(tutorialRect.left, window.innerWidth - POP_W - 16));
          if (tutorialRect.top + tutorialRect.height + GAP + POP_H < window.innerHeight) {
            popTop = tutorialRect.top + tutorialRect.height + GAP;
            popPos = "bottom";
          } else {
            popTop = Math.max(16, tutorialRect.top - GAP - POP_H);
            popPos = "top";
          }
          const targetCx = tutorialRect.left + tutorialRect.width / 2;
          arrowLeft = Math.max(18, Math.min(targetCx - popLeft - 7, POP_W - 36));
        }
        return (
          <>
            <div style={{ position: "fixed", inset: 0, zIndex: 999, background: "rgba(15,23,42,0.55)" }} />
            {tutorialRect && (
              <div
                style={{
                  position: "fixed", zIndex: 1001, pointerEvents: "none",
                  top: tutorialRect.top - 5, left: tutorialRect.left - 5,
                  width: tutorialRect.width + 10, height: tutorialRect.height + 10,
                  borderRadius: 10,
                  boxShadow: "0 0 0 4px #f59e0b, 0 0 24px rgba(245,158,11,0.45)",
                  transition: "top 0.3s ease, left 0.3s ease, width 0.3s ease, height 0.3s ease",
                }}
              />
            )}
            <div
              style={{
                position: "fixed", zIndex: 1002,
                top: tutorialRect ? popTop : "40%", left: tutorialRect ? popLeft : "50%",
                transform: tutorialRect ? "none" : "translateX(-50%)",
                width: 320, maxWidth: "calc(100vw - 32px)",
                background: "#fef9ee", borderRadius: 14,
                boxShadow: "0 12px 40px rgba(0,0,0,0.35)",
                padding: "18px 20px 16px", fontFamily: "inherit",
              }}
            >
              {tutorialRect && (
                <div
                  style={{
                    position: "absolute", width: 14, height: 14,
                    background: "#fef9ee", transform: "rotate(45deg)",
                    ...(popPos === "bottom"
                      ? { top: -7, left: arrowLeft }
                      : { bottom: -7, left: arrowLeft }),
                  }}
                />
              )}
              <button
                aria-label="Skip tutorial"
                onClick={finish}
                style={{
                  position: "absolute", top: 8, right: 8, width: 28, height: 28,
                  border: "none", background: "transparent", cursor: "pointer",
                  fontSize: 18, color: "#92400e", borderRadius: "50%", lineHeight: 1,
                }}
              >&#10005;</button>
              <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
                {TUTORIAL_STEPS.map((_, i) => (
                  <span
                    key={i}
                    style={{
                      width: i === tutorialStep ? 18 : 8, height: 8, borderRadius: 4,
                      background: i === tutorialStep ? "#f59e0b" : "#fcd34d",
                      transition: "width 0.25s ease, background 0.25s ease",
                    }}
                  />
                ))}
              </div>
              <h3 style={{ margin: "0 0 6px", fontSize: 15, fontWeight: 700, color: "#78350f" }}>
                {step?.title}
              </h3>
              <p style={{ margin: "0 0 14px", fontSize: 13, lineHeight: 1.55, color: "#92400e" }}>
                {step?.desc}
              </p>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                  <button
                    onClick={finish}
                    style={{
                      border: "none", background: "transparent", cursor: "pointer",
                      fontSize: 12.5, color: "#b45309", fontWeight: 600, padding: "4px 0",
                    }}
                  >Skip</button>
                  {!isFirst && (
                    <button
                      onClick={goBack}
                      style={{
                        border: "none", background: "transparent", cursor: "pointer",
                        fontSize: 12.5, color: "#b45309", fontWeight: 600, padding: "4px 0",
                      }}
                    >Back</button>
                  )}
                </div>
                <button
                  onClick={advance}
                  style={{
                    border: "none", background: "#92400e", color: "#fef9ee",
                    borderRadius: 8, padding: "7px 18px", cursor: "pointer",
                    fontSize: 13, fontWeight: 700,
                  }}
                >{isLast ? "Got it" : "Next"}</button>
              </div>
            </div>
          </>
        );
      })()}
    </div>
  );
}
