import { useCallback, useState } from "react";

const STORAGE_KEY = "stubilly-admin-theme";

function readInitialTheme() {
  if (typeof window === "undefined") return "light";
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved === "light" || saved === "dark") return saved;
  } catch {
    // localStorage can throw in private/blocked contexts — ignore.
  }
  // No saved choice: keep the hub's original cream ("1am desk lamp") skin.
  return "light";
}

/**
 * Admin hub ONLY. Separate key from the student-home theme so flipping the
 * hub never repaints the student side, and vice versa. The consuming hub
 * applies an "admin-theme-dark" class when theme === "dark", which
 * re-declares the color tokens locally (see App.css) so just that subtree
 * flips — the default light skin stays untouched.
 */
export default function useAdminTheme() {
  const [theme, setTheme] = useState(readInitialTheme);

  const toggleTheme = useCallback(() => {
    setTheme((t) => {
      const next = t === "light" ? "dark" : "light";
      try {
        window.localStorage.setItem(STORAGE_KEY, next);
      } catch {
        // Ignore storage failures — the choice still holds this session.
      }
      return next;
    });
  }, []);

  return { theme, toggleTheme };
}
