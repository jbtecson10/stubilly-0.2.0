"""Pydantic schemas — the contract between frontend and backend."""
import json

from pydantic import BaseModel, field_validator
from datetime import datetime
from typing import Optional, List


# ---- Sessions ----

class SessionStartRequest(BaseModel):
    task_description: str
    # Optional: reuse the saved task breakdown (the micro-task checklist) from
    # an existing session instead of asking Ollama for a fresh one — this is
    # what lets a user "continue based on their saved process" instead of
    # getting a brand-new breakdown every time. Completion flags carry over
    # too, so the resumed session starts where the old one left off.
    microtasks_from_session_id: Optional[int] = None

    # --- Declared academic task (INPUT) ---
    # Structured metadata the student declares at setup. All optional so
    # legacy clients that only send task_description keep working unchanged.
    subject: Optional[str] = None        # e.g. "Thesis", "Math 101"
    deadline: Optional[datetime] = None  # when it's due
    priority: Optional[str] = None       # "low" | "medium" | "high"

    # Chosen AI companion for this session (billy/fokus/shola/conan/akira).
    # Optional so legacy clients keep working; unknown ids fall back to the
    # default companion on the backend.
    companion_id: Optional[str] = None


class MicroTaskOut(BaseModel):
    id: int
    description: str
    estimated_minutes: Optional[int]
    completed: bool
    order_index: int
    is_placeholder: bool = False

    # Same legacy-NULL protection as SessionOut.zero_if_null: is_placeholder,
    # completed and order_index are added columns on a live database, so rows
    # that predate them carry SQL NULL (ALTER TABLE ... ADD COLUMN has no
    # default). Pydantic would reject None for a non-optional bool/int and turn
    # GET /sessions into a 500 — that is what broke the student Past Sessions
    # panel on long-lived databases. Coerce NULL to its natural 0/False.
    @field_validator("is_placeholder", mode="before")
    @classmethod
    def placeholder_bool(cls, v):
        return bool(v) if v is not None else False

    @field_validator("completed", "order_index", mode="before")
    @classmethod
    def zero_if_null(cls, v):
        return 0 if v is None else v

    class Config:
        from_attributes = True


def parse_stored_list(v):
    """Parses a JSON-array string column (or a plain CSV string) into a list."""
    if isinstance(v, str):
        if not v.strip():
            return []
        try:
            parsed = json.loads(v)
            if isinstance(parsed, list):
                return [str(x) for x in parsed if str(x).strip()]
        except ValueError:
            pass
        return [x.strip() for x in v.split(",") if x.strip()]
    if v is None:
        return []
    return v


class SessionOut(BaseModel):
    id: int
    task_description: str
    started_at: datetime
    ended_at: Optional[datetime]
    total_focused_seconds: float
    total_distracted_seconds: float
    intervention_count: int
    tasks: List[MicroTaskOut] = []
    # Declared academic task metadata (optional — null for legacy sessions).
    subject: Optional[str] = None
    deadline: Optional[datetime] = None
    priority: Optional[str] = None
    # Chosen AI companion (billy/fokus/shola/conan/akira); NULL on legacy rows.
    companion_id: Optional[str] = None
    # Adaptive-check-in / paralysis counters (evaluation data).
    check_in_count: int = 0
    paralysis_count: int = 0
    # Domains auto-blocked during the session (the block-list enforcement that
    # was in effect). Stored on the row as a JSON string; surfaced here as a
    # list so the frontend can re-apply them when the session is resumed or
    # continued, and lift them again once that run ends.
    blocked_sites: List[str] = []
    # Sites/apps explicitly allowed during the session — the counterpart to
    # blocked_sites. Re-applied when the run is resumed / continued / studied
    # again, lifted once that run ends, and always a winner over the
    # blocklist and Live Shutdown for the run it belongs to.
    allowed_sites: List[str] = []

    @field_validator("blocked_sites", "allowed_sites", mode="before")
    @classmethod
    def parse_sites(cls, v):
        return parse_stored_list(v)

    # Legacy rows (created before these columns were backfilled) carry SQL
    # NULLs; Pydantic would reject None for the non-optional numeric fields
    # and FastAPI would turn that into a 500 on GET /sessions. Coerce to 0.
    @field_validator(
        "total_focused_seconds", "total_distracted_seconds",
        "intervention_count", "check_in_count", "paralysis_count",
        mode="before",
    )
    @classmethod
    def zero_if_null(cls, v):
        return 0 if v is None else v

    class Config:
        from_attributes = True


class SessionBlockedSitesRequest(BaseModel):
    """Replaces the list of domains blocked during a session (idempotent)."""
    blocked_sites: List[str] = []


class BreakRequest(BaseModel):
    """Timed break request — server timer is authoritative on expiry."""
    minutes: float = 5.0


class SessionAllowedSitesRequest(BaseModel):
    """Replaces the list of sites/apps allowed during a session (idempotent)."""
    allowed_sites: List[str] = []


class SessionEndRequest(BaseModel):
    session_id: int


# ---- Focus events (sent frequently from the webcam loop) ----

class FocusEventIn(BaseModel):
    session_id: int
    state: str  # focused | distracted | sleeping | absent
    confidence: float
    eye_aspect_ratio: Optional[float] = None
    head_pose_yaw: Optional[float] = None
    head_pose_pitch: Optional[float] = None
    face_detected: bool = True

    # Background app/window monitoring — optional so older clients (or a
    # plain-web build with no Electron access) keep working unchanged.
    app_state: Optional[str] = None  # "on_task" | "off_task" | None
    active_app: Optional[str] = None
    on_break: bool = False  # Pomodoro break in progress — suppresses the off-task alarm

    # --- Idle-time + gaze proxy (INPUT for paralysis classifier) ---
    # Optional so web builds without keyboard/mouse access keep working.
    idle_seconds: Optional[float] = None      # seconds since last key/mouse input
    gaze_direction: Optional[str] = None      # "center"|"left"|"right"|"down"|"up"|None


class FocusEventOut(BaseModel):
    id: int
    timestamp: datetime
    state: str
    confidence: float
    # Additive raw signals so a session export carries the off-task evidence
    # ("what window/site were they on"), not just the derived state.
    app_state: Optional[str] = None
    active_app: Optional[str] = None
    active_site: Optional[str] = None
    active_title: Optional[str] = None
    idle_seconds: Optional[float] = None
    gaze_direction: Optional[str] = None

    class Config:
        from_attributes = True


# ---- Interventions ----

class InterventionOut(BaseModel):
    id: int
    timestamp: datetime
    intervention_type: str
    trigger_state: str
    message: Optional[str]
    # Filled in by the feedback UI ("helpful" | "dismissed" | None) — the
    # intervention-reliability signal the evaluation output is built from.
    user_response: Optional[str] = None
    channel: Optional[str] = None  # "text" | "voice" — separates voice effectiveness

    class Config:
        from_attributes = True


class InterventionRespondRequest(BaseModel):
    """The student tells us whether a nudge/check-in actually helped."""
    intervention_id: int
    # "helpful" | "dismissed" | "acting_on_it" | "ignored"
    response: str


# ---- Dataset export ----

class SessionStats(BaseModel):
    session_id: int
    duration_sec: float            # wall-clock session length (ended_at, or now if still active)
    total_events: int
    focused_sec: float             # duration-based (sum of consecutive focus_event spans)
    distracted_sec: float          # pure "distracted" spans (looking away mid-task)
    sleeping_sec: float            # eyes closed at the desk
    absent_sec: float              # face not detected — away from the keyboard
    focused_pct: float             # focused / tracked time
    distracted_pct: float          # (distracted + sleeping + absent) / tracked time
    sleeping_pct: float
    intervention_count: int
    intervention_groups: dict[str, int] = {}   # {"alarm": 3, "app_alarm": 1, "off_task_block": 2}
    avg_time_to_first_distraction_sec: Optional[float]
    task_study_count: int          # how many sessions have been done on this same task, ever
    session_number: int            # this session's position among those (1 = first time)


# ---- Productivity analytics dashboard ----

class DailyStat(BaseModel):
    date: str  # "YYYY-MM-DD", local calendar day the session(s) started on
    session_count: int
    focused_minutes: float
    distracted_minutes: float
    sleeping_minutes: float
    absent_minutes: float
    intervention_count: int
    total_minutes: float  # focused + distracted + sleeping + absent
    focus_pct: float  # focused / total tracked time for that day, 0 if no tracked time


class SessionPerformance(BaseModel):
    """One completed session's focus performance — the "how well did I
    actually concentrate" measure used to headline the progress page."""
    session_id: int
    task_description: str
    started_at: datetime
    focus_pct: float


class AnalyticsOverview(BaseModel):
    range: str  # "today" | "week" | "month" | "year" | "all"
    range_start: str  # "YYYY-MM-DD"
    range_end: str  # "YYYY-MM-DD"
    total_sessions: int
    total_focused_minutes: float
    total_distracted_minutes: float
    total_sleeping_minutes: float
    total_absent_minutes: float
    avg_focus_pct: float
    total_interventions: int
    intervention_groups: dict[str, int] = {}  # {"alarm": 3, "app_alarm": 1, "off_task_block": 2}
    active_days: int
    current_streak_days: int
    best_streak_days: int = 0  # longest consecutive-day study run ever (streak-gated views)
    best_day: Optional[DailyStat]
    best_session: Optional[SessionPerformance]
    daily: List[DailyStat]


# ---- Companion chat (body doubling) ----

class ChatMessageIn(BaseModel):
    content: str


class ChatMessageOut(BaseModel):
    id: int
    role: str  # "user" | "companion"
    content: str
    timestamp: datetime

    class Config:
        from_attributes = True


# ---- Auto-captured notes ----

class StudyNoteOut(BaseModel):
    id: int
    content: str
    source: str
    timestamp: datetime

    class Config:
        from_attributes = True


# ---- Auth / users (administration hub) ----

class BootstrapInfo(BaseModel):
    """Tells the client whether this deployment enforces accounts. When no
    users exist yet on the server, the app runs in original single-user mode
    — the admin hub can create the first user and flip it to managed mode.
    `has_admins` mirrors the same idea for administrators: when no admin
    exists yet, the hub shows a "create the first administrator" form
    instead of a login form."""
    requires_login: bool
    has_admins: bool = False
    host: str = ""


class RegisterRequest(BaseModel):
    """Self-service registration. `email` is the modern handle (also used for
    social sign-in and password recovery); `serial_number` is optional — for
    legacy admin-created students or anyone who explicitly wants one — and is
    auto-generated from the email when omitted.

    Role + age/consent (conceptual framework, input step 1):
      role="student" (default) creates a focus account; role="parent" creates
      a linked guardian account that reads focus reports (never chat).
      `date_of_birth` decides minor status; minors get `consent_granted`
      stamped only by a real parent login (this field alone never authorises).
    """
    serial_number: Optional[str] = ""
    full_name: str = ""
    email: str = ""
    password: str = ""
    # "student" (default) | "parent"
    role: str = "student"
    # ISO date, e.g. "2010-05-17". Optional (legacy clients omit it).
    date_of_birth: Optional[str] = None
    # When registering a minor student, the parent account that owns them
    # (its user id). Optional — admin can link later too.
    parent_id: Optional[int] = None


class LoginRequest(BaseModel):
    # The identifier field historically held the serial number; it now accepts
    # either a serial number or an email (matched case-insensitively).
    serial_number: str
    password: str
    device: Optional[str] = None  # free-form client/platform label


class ForgotPasswordRequest(BaseModel):
    email: str


class ResetPasswordRequest(BaseModel):
    email: str
    code: str
    new_password: str


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


class ResetCodeResponse(BaseModel):
    """Password recovery, phase 1. Stubilly has no mail server (everything is
    local), so on the LOCAL machine the one-time code is returned to the
    caller + logged — the requester types it into the reset form directly.
    A REMOTE caller (public funnel / non-local Host header) gets the same
    `ok` response but reset_code=None: the code exists only at the machine
    (and the administrator is notified of the remote attempt)."""
    ok: bool
    reset_code: Optional[str] = None  # only when the account exists AND caller is local
    expires_in_sec: int = 900


class SocialProvidersOut(BaseModel):
    providers: List[str] = []


class UserOut(BaseModel):
    id: int
    serial_number: str
    full_name: str = ""
    email: Optional[str] = None
    is_active: bool = True
    blocked_sites: List[str] = []
    allowed_sites: List[str] = []
    last_login_at: Optional[datetime] = None
    online: bool = False
    # Live task state ("focusing" | "off_task" | "studying" | "signed_in" |
    # "offline") + the current session's task, computed from the user's most
    # recent focus/app events so the hub shows what the student is doing
    # right now, not just whether they're signed in.
    status: str = "offline"
    current_task: Optional[str] = None
    # Plaintext password. Populated ONLY in authentic admin responses (the
    # hub must show student credentials); the student's own /auth/me and
    # /auth/login responses leave it null.
    password: Optional[str] = None
    created_at: Optional[datetime] = None

    # --- Role + age/consent (framework input step 1) ---
    role: str = "student"           # "student" | "parent"
    date_of_birth: Optional[datetime] = None
    is_minor: bool = False
    parent_id: Optional[int] = None
    consent_granted: Optional[bool] = None
    consent_at: Optional[datetime] = None
    # Effective settings (merged with defaults) — returned on login/me so the
    # app knows its check-in interval / tone / voice-mode without an extra call.
    settings: dict = {}
    # First-run tutorial flag. False = still owed the one-time walkthrough
    # (only newly created accounts). True = finished/skipped, or a legacy row
    # that predates the column (NULL coerced to True) — never shown again.
    tutorial_seen: bool = True

    @field_validator("blocked_sites", "allowed_sites", mode="before")
    @classmethod
    def parse_sites(cls, v):
        return parse_stored_list(v)

    @field_validator("tutorial_seen", mode="before")
    @classmethod
    def tutorial_seen_bool(cls, v):
        # NULL (legacy row) counts as already seen.
        return True if v is None else bool(v)


class LoginResponse(BaseModel):
    """A signed-in session. A student sign-in fills `token`/`user`; the same
    `/auth/login` form also accepts an administrator's username, in which
    case `admin_token`/`admin` are filled instead and `token`/`user` stay
    null. The two account tables remain separate — a student can never receive
    an admin token, and an admin can never receive a student token."""
    token: Optional[str] = None
    user: Optional[UserOut] = None
    admin_token: Optional[str] = None
    admin: Optional["AdminOut"] = None


class AdminLoginRequest(BaseModel):
    username: str = ""
    password: str = ""


class AdminBootstrapRequest(BaseModel):
    name: str
    username: str
    password: str


class AdminCreateRequest(BaseModel):
    name: str
    username: str
    password: str


class AdminPasswordRequest(BaseModel):
    password: str


class AdminOut(BaseModel):
    id: int
    name: str
    username: str
    is_active: bool = True
    created_at: Optional[datetime] = None
    # The owning administrator's own password (so they can read it); every
    # other admin row returns null — names are shared, passwords are not.
    password: Optional[str] = None


# LoginResponse references AdminOut before it is defined; resolve the forward
# reference now that the target class exists.
LoginResponse.model_rebuild()


class AdminLoginResponse(BaseModel):
    admin_token: str
    admin: AdminOut


class PolicyOut(BaseModel):
    blocked_sites: List[str] = []
    allowed_sites: List[str] = []
    updated_at: Optional[datetime] = None


class PolicyUpdateRequest(BaseModel):
    blocked_sites: List[str] = []
    allowed_sites: List[str] = []


class LoginEventOut(BaseModel):
    id: int
    user_id: int
    login_at: datetime
    logout_at: Optional[datetime]
    device: Optional[str]

    class Config:
        from_attributes = True


class UserDetailOut(BaseModel):
    user: UserOut
    session_count: int = 0
    active_session_count: int = 0
    login_history: List[LoginEventOut] = []


class AdminSessionOut(BaseModel):
    id: int
    user_id: Optional[int]
    serial_number: str = ""
    full_name: str = ""
    task_description: str
    started_at: datetime
    ended_at: Optional[datetime]
    total_focused_seconds: float
    total_distracted_seconds: float
    intervention_count: int
    # Declared academic task (optional; null on legacy sessions).
    subject: Optional[str] = None
    deadline: Optional[datetime] = None
    priority: Optional[str] = None


# ---- User settings (input preferences: check-in / tone / webcam / voice) ----

class UserSettingsUpdate(BaseModel):
    """Partial update of a student's preferences. Unspecified keys keep
    their current/default value."""
    # Seconds between adaptive progress check-ins. 0/None = off.
    # Defaults come from admin.DEFAULT_SETTINGS (300).
    check_in_interval_sec: Optional[int] = None
    # "gentle" | "firm" — the intervention tone.
    tone: Optional[str] = None
    # Webcam monitoring on/off for future sessions.
    webcam_enabled: Optional[bool] = None
    # Speak interventions aloud via the browser's speechSynthesis.
    voice_mode: Optional[bool] = None
    # AI-written, context-aware check-in wording (generative check-ins).
    adaptive_check_in: Optional[bool] = None
    # Learnt per-user behavior profile (JSON blob, partial updates allowed).
    learning_profile: Optional[dict] = None
    # Student's own subject labels (on top of the frontend's built-in
    # presets). Sanitized server-side: strings only, trimmed, deduped, capped.
    custom_subjects: Optional[List[str]] = None


class UserSettingsOut(BaseModel):
    check_in_interval_sec: int = 300
    tone: str = "gentle"
    webcam_enabled: bool = True
    voice_mode: bool = False
    adaptive_check_in: bool = False
    learning_profile: dict = {}
    custom_subjects: List[str] = []
    # Read-only for the student (parent-owned): shown so the UI can be
    # honest about what is being tracked; writable only via /parent/.../limits.
    monitoring_enabled: bool = True


# ---- Age / consent (process step 2) ----

class ConsentRequest(BaseModel):
    """Grant or withhold monitoring consent for an account. Minors must pass
    `granted_by` = their linked parent account's id (checked server-side);
    adults may consent for themselves."""
    granted: bool
    scope: Optional[str] = "webcam,window,site-blocking"
    # Who is granting: parent user id (minors), or self (adults).
    granted_by: Optional[int] = None
    note: Optional[str] = None


class ConsentRecordOut(BaseModel):
    id: int
    user_id: int
    granted_by: Optional[int]
    granted_at: datetime
    granted: bool
    scope: Optional[str]
    age_band: Optional[str]
    note: Optional[str]

    class Config:
        from_attributes = True


class ParentConsentRequest(BaseModel):
    """A guardian granting/withdrawing consent for one of THEIR linked
    students. The server verifies both sides: caller is role=parent and the
    target is actually linked to them."""
    user_id: int
    granted: bool
    scope: Optional[str] = "webcam,window,site-blocking"
    note: Optional[str] = None


class ParentCreateStudentRequest(BaseModel):
    """USERS box of the conceptual framework: "Parents creates student
    account". The new student is born linked to the calling guardian, so the
    consent gate applies from their very first session."""
    full_name: str
    email: str
    password: str
    date_of_birth: Optional[str] = None


# ---- Parent module (output: focus alerts, no chat access) ----

class ParentStudentOut(BaseModel):
    """A student linked to a parent account ? focus summary only."""
    id: int
    serial_number: str
    full_name: str = ""
    is_minor: bool = False
    consent_granted: Optional[bool] = None
    status: str = "offline"
    current_task: Optional[str] = None
    last_session_at: Optional[datetime] = None
    # Headline numbers for the linked student's most recent finished session.
    last_focus_pct: Optional[float] = None
    last_off_task_minutes: Optional[float] = None
    # How many off-task/paralysis alerts this student has raised recently.
    recent_alert_count: int = 0
    # Parental controls owned by this guardian (Family-Link style): the
    # block/allow lists plus screen-time rules. Read here so the controls
    # panel opens with the current values; written only via the parent
    # policy/limits endpoints, never through the student's /me/settings.
    blocked_sites: List[str] = []
    allowed_sites: List[str] = []
    daily_screen_limit_min: Optional[int] = None
    downtime_start: Optional[str] = None   # "HH:MM" local, None = off
    downtime_end: Optional[str] = None
    device_paused: bool = False
    # Guardian's activity-monitoring switch (window sampler + click
    # timeline). Parent-owned, written via the limits endpoint.
    monitoring_enabled: bool = True

    class Config:
        from_attributes = True


class ParentOverviewOut(BaseModel):
    students: List[ParentStudentOut] = []
    unread_alerts: int = 0
    # Aggregate over linked students (last 7 days), for the dashboard header.
    total_sessions: int = 0
    avg_focus_pct: Optional[float] = None


class ParentAlertOut(BaseModel):
    id: int
    student_id: int
    student_name: str = ""
    session_id: Optional[int] = None
    kind: str
    message: str
    payload: dict = {}
    read_at: Optional[datetime] = None
    created_at: datetime

    class Config:
        from_attributes = True


class ParentSiteTop(BaseModel):
    """One entry of the guardian's "most used today" ranking."""
    site: str
    seconds: float


class ParentAppTop(BaseModel):
    """One entry of the guardian's "apps today" ranking."""
    app: str
    seconds: float


class ParentWindowTime(BaseModel):
    """One foreground-window entry ("what was actually on screen"): the
    window title plus how long it was in front — presence only."""
    app: str = ""
    title: str
    seconds: float = 0.0


class ParentActivityEvent(BaseModel):
    """One click/view breadcrumb on the guardian's Activity timeline."""
    at: datetime
    kind: str = "click"
    label: str = ""
    session_id: Optional[int] = None


class ActivityEventIn(BaseModel):
    """One client-reported interaction. Labels are element text/aria only."""
    kind: str = "click"          # "click" | "view"
    label: str = ""              # capped server-side
    session_id: Optional[int] = None


class ActivityBatchIn(BaseModel):
    """Small batch of interactions flushed by the client tracker."""
    events: List[ActivityEventIn] = []


class ActivityBatchOut(BaseModel):
    """How many events of the submitted batch were accepted."""
    accepted: int = 0


class ParentStudentSites(BaseModel):
    """Family-Link-style presence for one linked student: where they are
    right now (if seen in the last 2 minutes) + today's time-on-site and
    app ranking + the day's screen-time estimate."""
    id: int
    name: str = ""
    current_site: Optional[str] = None
    current_site_at: Optional[datetime] = None
    current_app: Optional[str] = None
    current_app_at: Optional[datetime] = None
    # Foreground state on the last live sighting: inside Stubilly or in
    # some other app/site  Ethe "are they studying right now" bit.
    in_stubilly: Optional[bool] = None
    # The window title in front right now (window sampler, fresh only).
    current_window: Optional[str] = None
    current_window_at: Optional[datetime] = None
    # Is this guardian's activity monitoring switched on for the student?
    monitoring_enabled: bool = True
    screen_seconds_today: float = 0.0
    top_sites: List[ParentSiteTop] = []
    top_apps: List[ParentAppTop] = []


class ParentSitesOut(BaseModel):
    students: List[ParentStudentSites] = []


class ParentLinkStudentRequest(BaseModel):
    """Guardian links an ALREADY-EXISTING student account (self-signed-up,
    admin-created, or studying right now) to this guardian by email or
    serial number. No password needed — the guardian proves parenthood by
    being signed in as a parent; the target must be unlinked."""
    identifier: str = ""


class ParentSessionTaskOut(BaseModel):
    """One micro-task of a session's AI-generated breakdown."""
    description: str
    estimated_minutes: Optional[int] = None
    completed: bool = False


class ParentSessionOut(BaseModel):
    """One study session as the guardian sees it: when, on what, how it
    went, and WHAT THE SESSION WAS MADE OF — screen seconds plus the
    sites/app opened during it and the task list. Focus/effort numbers
    only, never content."""
    id: int
    task_description: str = ""
    started_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    is_active: bool = False
    duration_seconds: float = 0.0
    focus_pct: Optional[float] = None
    off_task_minutes: float = 0.0
    screen_seconds: float = 0.0
    top_sites: List[ParentSiteTop] = []
    top_apps: List[ParentAppTop] = []
    # Foreground windows seen during this session (title + seconds).
    recent_windows: List[ParentWindowTime] = []
    tasks: List[ParentSessionTaskOut] = []


class ParentActivityOut(BaseModel):
    """A calendar day of one student's activity — screen-time estimate,
    site/app/window time-on rows, every session that ran that day, and
    the click/view breadcrumb timeline for the day."""
    date: str = ""
    screen_seconds: float = 0.0
    top_sites: List[ParentSiteTop] = []
    top_apps: List[ParentAppTop] = []
    top_windows: List[ParentWindowTime] = []
    sessions: List[ParentSessionOut] = []
    events: List[ParentActivityEvent] = []


class ParentLimitsUpdate(BaseModel):
    """Parent-owned screen rules for one linked student. Partial update:
    unspecified keys keep their current value. Times are local "HH:MM"."""
    daily_screen_limit_min: Optional[int] = None   # 0..1440; 0 = no screen time
    downtime_start: Optional[str] = None
    downtime_end: Optional[str] = None
    device_paused: Optional[bool] = None
    # Activity monitoring (window sampler + click timeline) on/off.
    monitoring_enabled: Optional[bool] = None


class LiveWindowOut(BaseModel):
    """One-shot foreground-window snapshot from the backend itself — the
    bridge that makes window monitoring available in browser mode (no
    Electron process needed)."""
    available: bool = False
    app: Optional[str] = None
    title: Optional[str] = None
    site: Optional[str] = None
    in_stubilly: bool = False


# ---- Analytics outputs (patterns + evaluation) ----

class DistractionPatternsOut(BaseModel):
    """When/where the student goes off task — the analytics VIEW input to the
    theoretical framework's feedback loop."""
    # Top off-task domains/apps with seconds spent.
    top_off_task: List[dict] = []           # [{"name": "youtube.com", "seconds": 420}]
    # Hour-of-day histogram of distraction events (0..23 -> count).
    distraction_by_hour: List[int] = []
    # Fraction of events where the input device was idle (stuck vs browsing).
    idle_fraction: float = 0.0
    # Correlation-style summary: avg focus pct in the first/last 10 min.
    focus_start_pct: Optional[float] = None
    focus_end_pct: Optional[float] = None
    # Nudge reliability: interventions grouped by response.
    intervention_reliability: dict = {}     # {"helpful": 3, "dismissed": 1, "unanswered": 5}
    total_events: int = 0


class EvaluationOut(BaseModel):
    """Session evaluation (theoretical framework OUTPUT). One row of the
    pre/post comparison: does focus actually improve over runs?"""
    session_id: int
    subject: Optional[str] = None
    priority: Optional[str] = None
    duration_minutes: float = 0.0
    focus_pct: float = 0.0
    # Same-task average from earlier sessions (null on the first run).
    prior_avg_focus_pct: Optional[float] = None
    # focus_pct - prior_avg_focus_pct (positive = improved).
    delta_vs_prior: Optional[float] = None
    paralysis_count: int = 0
    check_in_count: int = 0
    interventions_total: int = 0
    interventions_responded: Optional[int] = None
    # "improved" | "declined" | "steady" | "first_run"
    trend: str = "first_run"
    verdict: str = ""  # short human-readable evaluation line


# ---- Post-session quiz (auto-generated from the session's study content) ----

class QuizQuestionOut(BaseModel):
    id: int
    order_index: int
    prompt: str
    options: List[str]
    # Withheld (None) until the quiz has been graded — the client only gets
    # the correct answers back in review mode.
    correct_index: Optional[int] = None

    @field_validator("options", mode="before")
    @classmethod
    def parse_options(cls, v):
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return [str(x) for x in parsed]
            except ValueError:
                pass
            return [v]
        return v

    class Config:
        from_attributes = True


class QuizOut(BaseModel):
    id: int
    session_id: int
    difficulty: str                 # "easy" | "medium" | "hard"
    focus_pct: float                # focus performance the difficulty came from
    source: str                     # "ollama" | "fallback"
    status: str                     # "pending" | "completed"
    question_count: int
    total_questions: int
    score: Optional[int] = None     # correct answers once completed
    answers: Optional[List[int]] = None   # the student's chosen indexes
    created_at: datetime
    completed_at: Optional[datetime] = None
    questions: List[QuizQuestionOut] = []

    @field_validator("answers", mode="before")
    @classmethod
    def parse_answers(cls, v):
        if isinstance(v, str):
            try:
                parsed = json.loads(v)
                if isinstance(parsed, list):
                    return [int(x) for x in parsed]
            except (ValueError, TypeError):
                pass
            return None
        return v

    class Config:
        from_attributes = True


class QuizSubmitIn(BaseModel):
    """The student's chosen option index per question, in order."""
    answers: List[int]


class SessionTaskStateIn(BaseModel):
    """One checklist row the client wants persisted (matched by description,
    which survives the AI's mid-session checklist rewrites)."""
    description: str
    completed: bool


class SessionTasksUpdate(BaseModel):
    tasks: List[SessionTaskStateIn]


# ---- Academic progress (sessions x quizzes x interventions, per user) ----

class SubjectProgressOut(BaseModel):
    """One subject's slice of the academic-progress view."""
    subject: str                     # declared subject, or "Unassigned"
    session_count: int
    avg_focus_pct: float
    best_focus_pct: Optional[float] = None
    total_interventions: int
    quiz_attempts: int               # completed quizzes in range
    avg_quiz_score: Optional[float] = None   # percent 0-100
    # focus trend across this subject's sessions in range (first half -> second half)
    trend: str = "first_run"         # "improved" | "declined" | "steady" | "first_run"


class AcademicSessionOut(BaseModel):
    """One recent session row for the progress table — focus, nudges and the
    quiz result side by side."""
    session_id: int
    task_description: str
    subject: Optional[str] = None
    started_at: datetime
    focus_pct: float
    intervention_count: int
    quiz_score: Optional[float] = None      # percent 0-100, None = no quiz yet
    quiz_difficulty: Optional[str] = None


class AcademicProgressOut(BaseModel):
    """The academic-progress overview: how focus, quiz results and the
    system's interventions move together for THIS account only."""
    range: str                       # "week" | "month" | "year" | "all"
    range_start: str                 # "YYYY-MM-DD"
    range_end: str                   # "YYYY-MM-DD"
    total_sessions: int
    avg_focus_pct: float
    total_interventions: int
    interventions_per_hour: float    # nudges per tracked hour
    quiz_attempts: int               # completed quizzes in range
    avg_quiz_score: Optional[float] = None  # percent 0-100
    # Focus change across the range in percentage points (first half -> second
    # half); positive = rising.
    focus_trend_pts: Optional[float] = None
    # Intervention change across the range in percent; positive = rising.
    intervention_trend_pct: Optional[float] = None
    # Human sentence tying the two together ("focus rising while nudges drop").
    note: str = ""
    subjects: List[SubjectProgressOut] = []
    recent_sessions: List[AcademicSessionOut] = []


# ---- Admin: create accounts with role/age/parent ----

class AdminCreateUserRequest(BaseModel):
    """Admin hub account creation — now role-aware so the hub can also
    provision parent/guardian accounts and link students to them."""
    serial_number: str = ""          # auto-generated when omitted (create)
    full_name: str = ""
    email: Optional[str] = None
    password: str
    role: str = "student"           # "student" | "parent"
    date_of_birth: Optional[str] = None  # ISO date
    parent_id: Optional[int] = None      # link a student to a parent account


class AdminConsentRequest(BaseModel):
    """Administrator grants/revokes monitoring consent on a student account
    — the only path that can unlock an INDEPENDENT (unlinked) minor, who by
    definition has no guardian to grant it."""

    granted: bool
    scope: Optional[str] = None          # "webcam + window only" etc.
    note: Optional[str] = None


class AdminNotificationOut(BaseModel):
    """One row of the Admin Hub's new-account feed."""
    id: int
    kind: str
    message: str
    payload: dict = {}
    read_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


class AdminNotificationDismissRequest(BaseModel):
    """Notification ids to remove from the CALLING admin's own bell only."""
    ids: list[int]


class AdminChatMessageOut(BaseModel):
    """One Admin Hub chat message (shared admin-to-admin room)."""
    id: int
    admin_id: Optional[int] = None
    sender_name: str
    body: str
    created_at: Optional[datetime] = None
    # Additive: older clients ignore these, newer ones use them for the reply
    # quote, the "edited" marker, the deleted tombstone and the picture /
    # voice-note bubble.
    reply_to_id: Optional[int] = None
    reply_to_name: Optional[str] = None
    reply_to_body: Optional[str] = None
    edited_at: Optional[datetime] = None
    deleted_at: Optional[datetime] = None
    attachment_kind: Optional[str] = None
    attachment_token: Optional[str] = None
    attachment_name: Optional[str] = None
    attachment_mime: Optional[str] = None
    attachment_size: Optional[int] = None
    attachment_seconds: Optional[float] = None
    # Pin + important label (any admin may set these; NULL never pinned/labelled).
    pinned: bool = False
    important_label: Optional[str] = None


class AdminChatFlagsIn(BaseModel):
    """Toggle a message's pin and/or IMPORTANT label. `model_fields_set`
    decides which of the two actually changes, so a caller can pin a message
    without touching an existing label."""
    pinned: Optional[bool] = None
    important_label: Optional[str] = None


class AdminChatMessageEdit(BaseModel):
       """Editing an existing message: only the text changes, and only the
       author may do it."""
       body: str


class AdminChatMessageIn(BaseModel):
    # Defaults to "" so a picture or voice note can be sent on its own, with no
    # caption - the way a voice message works in any chat app. The endpoint
    # still refuses a message with neither text nor attachment.
    body: str = ""
    # Telegram-style reply: id of the message being answered. Optional, and
    # ignored when it does not exist, so an old client that only sends "body"
    # keeps working exactly as before.
    reply_to_id: Optional[int] = None
    # Token returned by POST /admin/chat/media for a picture or voice note
    # attached to this message. Optional; a text-only message omits it.
    attachment_token: Optional[str] = None


class AccountRequestIn(BaseModel):
    """Public form: 'Don't have an account? -> Request one'. The password is
    the one THEY choose — approval mints the account with exactly it."""
    full_name: str
    email: str
    role: str = "parent"  # "parent" | "student"
    password: str
    message: str = ""


class AccountRequestStatusOut(BaseModel):
    """Poll result for the requester at the login screen (no auth: they have
    no account yet). status: none | pending | approved | denied."""
    status: str
    email: str
    created_at: Optional[str] = None
    decided_at: Optional[str] = None


class AccountRequestOut(BaseModel):
    id: int
    full_name: str
    email: str
    role: str
    message: str
    status: str
    created_at: Optional[str] = None
    decided_at: Optional[str] = None
    decided_by: Optional[str] = None

    class Config:
        from_attributes = True


class AccountRequestDecisionOut(BaseModel):
    id: int
    status: str
    user_id: Optional[int] = None
    email: Optional[str] = None


class BlockTicketOut(BaseModel):
    id: int
    session_id: int
    user_id: int
    student_name: Optional[str] = None
    key: str
    kind: str
    app: str
    site: Optional[str] = None
    title: Optional[str] = None
    label: str
    confidence: float
    sighting_count: int
    seconds: float
    task: Optional[str] = None
    status: str
    strength: str
    evidence: Optional[str] = None  # JSON text
    auto_blocked: bool = False
    created_at: Optional[str] = None
    decided_at: Optional[str] = None
    decided_by: Optional[str] = None

    class Config:
        from_attributes = True


class BlockTicketDecisionIn(BaseModel):
    """Admin approval-gate action: block | allow_once | deny | defer."""
    action: str


class InterventionSettingsIn(BaseModel):
    auto_block: bool


class InterventionSettingsOut(BaseModel):
    auto_block: bool


class MlThresholdIn(BaseModel):
    threshold: float

