"""
Per-session state machine that decides WHEN to intervene, based on a stream
of focus_event ticks coming in from the webcam. Kept separate from the
websocket/route handling so the thresholds are easy to find and tune.

Thresholds start as fixed constants. If you want the "adapts to the
student" behavior described in the proposal, the realistic version of that
is: calibrate DISTRACTED_THRESHOLD_SEC per-user from their first ~2 minutes
of baseline data, not fine-tune the LLM. See calibrate_thresholds() below.
"""
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from os import environ
from typing import Optional


def _env_sec(name: str, default: float) -> float:
    """Seconds-valued env override (tests shrink these; production leaves
    them unset and gets the tuned defaults above/below)."""
    raw = environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        value = float(raw)
    except ValueError:
        return default
    return value if value > 0 else default


DISTRACTED_THRESHOLD_SEC = 30    # 30-Second Focus Alarm: continuous distraction/absence this long triggers an alarm
SLEEPING_THRESHOLD_SEC = 5       # alarm after 5 sec of "sleeping" classification
NUDGE_COOLDOWN_SEC = 30          # once alarming, keep re-firing every 30s while it's still true (reads as persistent, not a single missable beep)

# Background app/window monitoring (off-task = active window isn't on the
# whitelist). "Live shutdown" mode: 2 minutes continuously off-task
# triggers immediate enforcement, then keeps re-enforcing every 30s for as
# long as it's still true. No excuses, breaks aside.
APP_OFF_TASK_THRESHOLD_SEC = 120   # alarm once off-task continuously for 2 min
APP_TRANSFER_DELAY_SEC = 15        # short gap between the alarm and the forced transfer, so the alarm/notification has a moment to land before the window gets yanked
APP_ALARM_REPEAT_SEC = 30          # once transferring, keep re-transferring + re-notifying every 30s for as long as they stay off-task
# HARDENING: 5 continuous minutes off-task escalates the re-firing
# "off_task_block" into "full_block" — the frontend force-closes the
# offending app AND pulls Stubilly to the front; sites also get hosts-
# blocked when a domain was recorded. (2-min rule stays the first block.)
FULL_BLOCK_THRESHOLD_SEC = 300

# --- Adaptive check-ins (student-controlled cadence; 0 in settings = off) ---
CHECK_IN_MIN_INTERVAL_SEC = _env_sec("STUBILLY_CHECK_IN_MIN_INTERVAL_SEC", 60)  # hard floor so a bad setting can't nag every tick

# --- Paralysis-vs-distraction classifier ---
# "Paralysis" = face still there, input device DEAD, not on a break and not
# browsing an off-task window — i.e. stuck on the task, not pulled away from
# it. Ordinary distraction keeps the normal alarm track.
PARALYSIS_IDLE_SEC = _env_sec("STUBILLY_PARALYSIS_IDLE_SEC", 90)            # no key/mouse for this long = stuck, not browsing
PARALYSIS_SUSTAIN_SEC = _env_sec("STUBILLY_PARALYSIS_SUSTAIN_SEC", 90)      # conditions must hold this long before firing
PARALYSIS_COOLDOWN_SEC = _env_sec("STUBILLY_PARALYSIS_COOLDOWN_SEC", 300)   # at most one paralysis assist per 5 minutes

# --- Baseline calibration (first ~2 minutes of ticks, see calibrate_thresholds) ---
BASELINE_TICKS = 40                # ≈2 min of the client's ~3s inference tick


@dataclass
class SessionRuntimeState:
    """In-memory (not DB) tracking for one active session, one instance per open session."""
    session_id: int
    current_state: str = "focused"
    state_since: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_intervention_at: Optional[datetime] = None
    distracted_threshold_sec: int = DISTRACTED_THRESHOLD_SEC
    sleeping_threshold_sec: int = SLEEPING_THRESHOLD_SEC

    # Background app/window monitoring track — separate from the webcam
    # state above so the two never overwrite each other's timers.
    app_state: str = "on_task"
    app_state_since: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    last_app_intervention_at: Optional[datetime] = None
    app_alarm_count: int = 0
    on_break: bool = False
    # Server-authoritative break timer: while set, the break lasts until
    # this UTC instant; the monitor loop force-ends it on expiry so a dead
    # client can never hold a permanent break (and the admin's Breaks tab
    # can grant one without the student's pomodoro running).
    break_ends_at: Optional[datetime] = None
    # Focus-WebSocket connections currently attached to this session. Used by
    # site_blocking: break state only counts (and only lifts hosts-file
    # blocking) while at least one live socket is actually reporting it.
    open_connections: int = 0
    # Liveness anchors for hosts enforcement (site_blocking.effective_hosts):
    # a session only holds the machine-wide block while it is actually being
    # driven. created_at covers "just started, socket not attached yet";
    # detached_at is set when the LAST socket drops, so a session nobody
    # reconnects to stops blocking once the detach grace elapses (stale
    # sessions must never keep the machine blocked).
    created_at: float = field(default_factory=time.time)
    detached_at: Optional[float] = None

    # --- Adaptive check-ins (cadence/tone come from the student's settings) ---
    connected_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    check_in_interval_sec: int = 300   # 0 = periodic check-ins disabled
    tone: str = "gentle"
    voice_mode: bool = False
    adaptive_check_in: bool = False     # AI-written, task-aware check-in wording
    last_check_in_at: Optional[datetime] = None
    check_in_count: int = 0

    # --- Feedback loop: progress/behavior re-times the next check-in ---
    # base = the (settings x last-run seed) cadence this run started with;
    # the window tracks the stretch since the last check-in so a struggling
    # student gets checked on sooner and a clean streak gets more space.
    base_check_in_interval_sec: int = 300
    window_ticks: int = 0
    window_focused_ticks: int = 0
    window_interventions: int = 0      # alarms/paralysis assists in the window
    check_in_answered: int = 0

    # --- Paralysis-vs-distraction classifier state ---
    paralysis_since: Optional[datetime] = None
    last_paralysis_at: Optional[datetime] = None
    paralysis_count: int = 0
    paralysis_active: bool = False     # current tick qualifies as "stuck"

    # --- Baseline calibration (first BASELINE_TICKS of this run) ---
    baseline_ticks: int = 0
    baseline_stuck_ticks: int = 0
    calibrated: bool = False

    def seconds_in_current_state(self) -> float:
        return (datetime.now(timezone.utc) - self.state_since).total_seconds()

    def seconds_since_last_intervention(self) -> Optional[float]:
        if self.last_intervention_at is None:
            return None
        return (datetime.now(timezone.utc) - self.last_intervention_at).total_seconds()

    def update_state(self, new_state: str) -> bool:
        """Returns True if the state actually changed (resets the state_since clock)."""
        # Every tick feeds the feedback-loop window that re-times check-ins.
        self.window_ticks += 1
        if new_state == "focused":
            self.window_focused_ticks += 1
        if new_state != self.current_state:
            self.current_state = new_state
            self.state_since = datetime.now(timezone.utc)
            return True
        return False

    def decide_intervention(self) -> Optional[str]:
        """
        Called after every focus_event. Returns an intervention_type string
        ("alarm") if one should fire now, else None.

        Both branches are "alarm": sleeping is urgent immediately (5 sec,
        no cooldown), and distracted/absent becomes urgent once it's held
        for DISTRACTED_THRESHOLD_SEC (30 sec, the "30-Second Focus Alarm"),
        re-firing every NUDGE_COOLDOWN_SEC while it's still true so it
        reads as a persistent reminder rather than a single easy-to-miss
        beep. Entirely suppressed on a break — see set_on_break().
        """
        if self.on_break:
            # Breaks are sanctioned rest time — "distracted"/"sleeping" during
            # one isn't a problem to interrupt, it's the point.
            return None

        if self.current_state == "sleeping" and self.seconds_in_current_state() >= self.sleeping_threshold_sec:
            # First sleep alarm is immediate (urgent); re-fires share the same
            # cooldown as distracted so a long doze doesn't beep every tick.
            cooldown_elapsed = self.seconds_since_last_intervention()
            if cooldown_elapsed is None or cooldown_elapsed >= NUDGE_COOLDOWN_SEC:
                return "alarm"

        if self.current_state in ("distracted", "absent") and self.seconds_in_current_state() >= self.distracted_threshold_sec:
            cooldown_elapsed = self.seconds_since_last_intervention()
            in_cooldown = cooldown_elapsed is not None and cooldown_elapsed < NUDGE_COOLDOWN_SEC
            if not in_cooldown:
                # Stuck, not wandering: when the paralysis classifier owns this
                # stretch (dead input + face present), the paralysis assist is
                # the right nudge — don't pile the generic alarm on top of it.
                if self.paralysis_active:
                    return None
                return "alarm"

        return None

    # ------------------------------------------------------------------
    # Adaptive check-ins (periodic progress check-in on the student's
    # cadence — the settings layer of the input/process framework)
    # ------------------------------------------------------------------

    def configure(self, settings: dict, seed: float = 1.0) -> None:
        """Apply the signed-in student's settings to this run's runtime.

        `seed` is the cross-run feedback loop (1.0 = no usable history): the
        previous run's focus result shifts this run's starting cadence — a
        rough last run checks in sooner (0.7x), a strong one backs off
        (1.25x). See main._check_in_seed()."""
        try:
            interval = int(settings.get("check_in_interval_sec", 300))
        except (TypeError, ValueError):
            interval = 300
        interval = max(0, min(3600, interval))
        try:
            seed = float(seed)
        except (TypeError, ValueError):
            seed = 1.0
        if seed <= 0 or seed > 4:
            seed = 1.0
        seeded = int(round(interval * seed)) if interval > 0 else 0
        self.base_check_in_interval_sec = max(0, min(3600, seeded))
        self.check_in_interval_sec = (
            self._clamp_cadence(self.base_check_in_interval_sec)
            if self.base_check_in_interval_sec > 0 else 0
        )
        tone = settings.get("tone")
        self.tone = tone if tone in ("gentle", "firm") else "gentle"
        self.voice_mode = bool(settings.get("voice_mode"))
        self.adaptive_check_in = bool(settings.get("adaptive_check_in"))

    def _clamp_cadence(self, value: int) -> int:
        """Keep an adapted cadence sane: never tighter than the env floor
        (and never tighter than the configured base when that base is itself
        tiny, e.g. test overrides), never looser than 3x the base."""
        base = self.base_check_in_interval_sec or value
        lo = max(CHECK_IN_MIN_INTERVAL_SEC, min(60, base))
        hi = max(lo, min(3600, base * 3))
        return max(lo, min(hi, int(value)))

    def _adapt_from_window(self) -> None:
        """FEEDBACK LOOP (conceptual framework): the stretch that just passed
        re-times the next check-in. Struggling — low focus ratio or repeated
        nudges — tightens the cadence; a clean, well-answered streak backs it
        off. Needs >=10 ticks of signal before it moves anything."""
        if self.base_check_in_interval_sec <= 0:
            return
        if self.window_ticks < 10:
            return  # not enough signal yet — keep the current cadence
        ratio = self.window_focused_ticks / max(1, self.window_ticks)
        base = float(self.base_check_in_interval_sec)
        if self.window_interventions >= 2 or ratio < 0.5:
            nxt = base * 0.6          # struggling -> check in sooner
        elif self.window_interventions == 0 and ratio >= 0.85:
            nxt = base * 1.4          # thriving -> give them space
        else:
            nxt = base                 # mixed -> configured cadence
        self.check_in_interval_sec = self._clamp_cadence(int(round(nxt)))
        self.window_ticks = 0
        self.window_focused_ticks = 0
        self.window_interventions = 0

    def note_check_in_response(self, response: str) -> None:
        """The student answered a check-in (output -> feedback): an engaged
        reply backs the next one off a little; a dismissal leaves it alone."""
        if response in ("helpful", "acting_on_it"):
            self.check_in_answered += 1
            if self.base_check_in_interval_sec > 0 and self.check_in_interval_sec > 0:
                self.check_in_interval_sec = self._clamp_cadence(
                    int(round(self.check_in_interval_sec * 1.15))
                )

    def decide_check_in(self) -> bool:
        """True when it's time for the next periodic progress check-in.
        Anchor is connect time for the first one, the previous check-in
        afterwards; suppressed during breaks and when interval is 0/off.
        Each firing first re-times the NEXT cadence from the behavior since
        the previous one (the feedback loop)."""
        if self.on_break or self.base_check_in_interval_sec <= 0 or self.check_in_interval_sec <= 0:
            return False
        now = datetime.now(timezone.utc)
        anchor = self.last_check_in_at or self.connected_at
        elapsed = (now - anchor).total_seconds()
        if elapsed < max(CHECK_IN_MIN_INTERVAL_SEC, self.check_in_interval_sec):
            return False
        self._adapt_from_window()
        self.last_check_in_at = now
        self.check_in_count += 1
        return True

    # ------------------------------------------------------------------
    # Paralysis vs distraction: is the student STUCK (idle input, face
    # present, on-task window) or actively DISTRACTED (looking away /
    # off-task app)? Only the stuck case fires the paralysis assist.
    # ------------------------------------------------------------------

    def update_paralysis(
        self,
        state: str,
        idle_seconds: Optional[float],
        face_detected: bool,
        app_state: Optional[str],
    ) -> Optional[str]:
        """Call once per tick, BEFORE decide_intervention().

        Returns "paralysis" exactly once per sustained stuck stretch (then
        restarts the cooldown clock), else None. Also sets
        self.paralysis_active so the ordinary distraction alarm stands down
        while we're classifying this stretch as paralysis."""
        now = datetime.now(timezone.utc)
        try:
            idle = float(idle_seconds) if idle_seconds is not None else None
        except (TypeError, ValueError):
            idle = None
        stuck = (
            not self.on_break
            and bool(face_detected)
            and state in ("focused", "distracted")   # absent = away, sleeping = dozing
            and app_state != "off_task"              # off-task window = distraction, not paralysis
            and idle is not None
            and idle >= PARALYSIS_IDLE_SEC
        )
        self.paralysis_active = stuck
        if not stuck:
            self.paralysis_since = None
            return None

        if self.paralysis_since is None:
            self.paralysis_since = now
            return None
        held = (now - self.paralysis_since).total_seconds()
        if held < PARALYSIS_SUSTAIN_SEC:
            return None
        if self.last_paralysis_at is not None:
            since_last = (now - self.last_paralysis_at).total_seconds()
            if since_last < PARALYSIS_COOLDOWN_SEC:
                # Keep re-arming from now so the next assist is a full
                # cooldown later, not immediately (held is already past).
                self.paralysis_since = now
                return None
        self.last_paralysis_at = now
        self.paralysis_since = now
        self.paralysis_count += 1
        self.window_interventions += 1
        return "paralysis"

    def note_baseline(self, state: str) -> None:
        """Feed one tick into the session's first ~2 minutes of baseline.
        Once BASELINE_TICKS are in, calibrate the distraction threshold to
        this student's natural restlessness (see calibrate_thresholds)."""
        if self.calibrated:
            return
        self.baseline_ticks += 1
        if state in ("distracted", "absent", "sleeping"):
            self.baseline_stuck_ticks += 1
        if self.baseline_ticks >= BASELINE_TICKS:
            ratio = self.baseline_stuck_ticks / max(1, self.baseline_ticks)
            self.calibrate_thresholds(ratio)
            self.calibrated = True

    def mark_intervened(self):
        self.last_intervention_at = datetime.now(timezone.utc)
        self.window_interventions += 1

    def update_app_state(self, new_state: Optional[str]) -> bool:
        """
        Same shape as update_state() but for the "on_task"/"off_task"
        classification from background window monitoring. `None` means the
        client sent no reading this tick (e.g. monitoring unavailable) —
        leave the existing state alone rather than guessing.
        """
        if new_state is None or new_state == self.app_state:
            return False
        self.app_state = new_state
        self.app_state_since = datetime.now(timezone.utc)
        if new_state == "on_task":
            # Back on task wipes the slate — the next off-task stretch
            # starts counting escalation from zero again, not where it
            # left off.
            self.app_alarm_count = 0
        return True

    def set_on_break(self, on_break: bool):
        """
        Freezes both the app/window clock and the webcam distraction/sleep
        clock across a work<->break transition, in either direction — so
        (a) time spent off-task, distracted, or eyes-closed *during* a
        break never counts toward an alarm, and (b) neither alarm fires
        the instant a break ends just because the student was distracted
        or on an unrelated tab two minutes ago. "Distraction detection
        resumes immediately" after a break means a clean slate, not an
        alarm that was quietly counting down the whole time.
        """
        if on_break != self.on_break:
            now = datetime.now(timezone.utc)
            self.app_state_since = now
            self.last_app_intervention_at = None
            self.app_alarm_count = 0
            self.state_since = now
            self.last_intervention_at = None
            # A break is sanctioned rest — the paralysis stretch (and the
            # check-in clock) must not keep counting across it.
            self.paralysis_since = None
            self.paralysis_active = False
            self.last_check_in_at = now
        self.on_break = on_break

    def start_break(self, minutes: float = 5.0) -> datetime:
        """Start (or restart) a timed break. Duration is clamped to
        1-60 minutes. Returns the UTC instant the break auto-ends — the
        monitor loop calls end_break() then, re-applying every block."""
        try:
            minutes = float(minutes)
        except (TypeError, ValueError):
            minutes = 5.0
        minutes = max(1.0, min(60.0, minutes))
        self.set_on_break(True)
        self.break_ends_at = datetime.now(timezone.utc) + timedelta(minutes=minutes)
        return self.break_ends_at

    def end_break(self) -> None:
        """End the break now (manual end or timer expiry)."""
        self.break_ends_at = None
        self.set_on_break(False)

    def break_expired(self, now: Optional[datetime] = None) -> bool:
        """True when a timed break has run past its end instant."""
        if not self.on_break or self.break_ends_at is None:
            return False
        return (now or datetime.now(timezone.utc)) >= self.break_ends_at

    def decide_app_intervention(self) -> Optional[str]:
        """
        Implements the "2-Minute Rule": once the student has been off-
        whitelist continuously for APP_OFF_TASK_THRESHOLD_SEC (~2 min, but
        never while on a Pomodoro break — see set_on_break):

          1. First fires "app_alarm" — the alarm + "notify the user to
             refocus" step.
          2. APP_TRANSFER_DELAY_SEC later, if they're still off-task,
             fires "off_task_block" — the frontend responds by forcing
             Stubilly's window back to the front (the "automatic transfer")
             and shows a second notification ("once transferred, notify
             the user again to focus on the session").
          3. From then on, re-fires "off_task_block" every
             APP_ALARM_REPEAT_SEC for as long as they remain off-task —
             it keeps re-transferring and re-notifying rather than firing
             once and going quiet. Once the stretch passes
             FULL_BLOCK_THRESHOLD_SEC (5 min) the re-firing type becomes
             "full_block" (force-close the app + hosts-block the site).
             Breaks are the only exception; there
             are no others ("no excuses").
        """
        if self.on_break or self.app_state != "off_task":
            return None

        now = datetime.now(timezone.utc)
        elapsed = (now - self.app_state_since).total_seconds()
        if elapsed < APP_OFF_TASK_THRESHOLD_SEC:
            return None
        # Past the 5-minute mark the alarm step is pointless — escalate
        # straight to the hard form (also covers a stalled monitor loop
        # that only just noticed a long off-task stretch).
        hard = elapsed >= FULL_BLOCK_THRESHOLD_SEC

        if self.app_alarm_count == 0:
            self.app_alarm_count = 1
            return "full_block" if hard else "app_alarm"

        if self.last_app_intervention_at is not None:
            since_last = (now - self.last_app_intervention_at).total_seconds()
            required_gap = APP_TRANSFER_DELAY_SEC if self.app_alarm_count == 1 else APP_ALARM_REPEAT_SEC
            if since_last < required_gap:
                return None

        self.app_alarm_count += 1
        return "full_block" if hard else "off_task_block"

    def mark_app_intervened(self):
        self.last_app_intervention_at = datetime.now(timezone.utc)
        self.window_interventions += 1

    def calibrate_thresholds(self, baseline_distracted_ratio: float):
        """
        Simple per-user calibration: if someone is naturally more prone to
        brief distraction (based on their first couple minutes), loosen the
        threshold slightly so the system doesn't nag. This is the realistic
        version of "adapting to the student's data" without needing to
        fine-tune the underlying LLM.
        """
        if baseline_distracted_ratio > 0.3:
            self.distracted_threshold_sec = int(DISTRACTED_THRESHOLD_SEC * 1.5)
        elif baseline_distracted_ratio < 0.1:
            self.distracted_threshold_sec = int(DISTRACTED_THRESHOLD_SEC * 0.8)


# Registry of active sessions' runtime state, keyed by session_id.
# Lives in-memory in the FastAPI process — fine for a single-user local app.
active_sessions: dict[int, SessionRuntimeState] = {}


def get_or_create_runtime(session_id: int) -> SessionRuntimeState:
    if session_id not in active_sessions:
        active_sessions[session_id] = SessionRuntimeState(session_id=session_id)
    return active_sessions[session_id]


def end_runtime(session_id: int):
    active_sessions.pop(session_id, None)
