@echo off
rem ============================================================
rem  Stubilly — one-time setup
rem  Installs Python dependencies into a local virtual env.
rem  Run this ONCE before the first launch.
rem ============================================================
cd /d "%~dp0"

echo.
echo === Stubilly setup ===
echo.

rem --- Check Python --------------------------------------------------------
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not on PATH.
    echo.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/
    echo IMPORTANT: tick "Add Python to PATH" during install.
    echo Then run this script again.
    echo.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo Found Python %PYVER%

rem --- Create virtual environment -------------------------------------------
if not exist ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
    if %errorlevel% neq 0 (
        echo [ERROR] Could not create virtual environment.
        pause
        exit /b 1
    )
) else (
    echo Virtual environment already exists.
)

rem --- Install dependencies -------------------------------------------------
echo Installing dependencies (this takes a minute the first time)...
call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip --quiet
pip install -r backend\requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [ERROR] Dependency install failed. Check your internet connection
    echo and make sure Python + pip are working, then run this again.
    pause
    exit /b 1
)

echo.
echo === Setup complete! ===
echo.
echo Next steps:
echo   1. Make sure Ollama is running  (https://ollama.com  -  "ollama serve")
echo      or llama.cpp server is running on :8080.
echo   2. Double-click  run-ollama.bat   OR   run-llamacpp.bat
echo   3. Open the URL it prints (usually http://localhost:8422 or :8423)
echo.
pause
