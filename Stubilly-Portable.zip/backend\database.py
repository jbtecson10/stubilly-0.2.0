"""
Database setup for Stubilly.
Uses SQLite so the whole app is a single-file, zero-config local database —
no separate DB server needed, which matches the "install and run locally" goal.
"""
import os
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, declarative_base

# In dev, the .db file lives next to the backend code. In the packaged app,
# run_server.py sets STUBILLY_DB_PATH to a proper per-user app-data folder
# (since a packaged app's own install directory is typically read-only).
db_path = os.environ.get("STUBILLY_DB_PATH", "./stubilly.db")
DATABASE_URL = f"sqlite:///{db_path}"

# --- Concurrency tuning -------------------------------------------------------
# The public link serves a whole school at once, so several people log in, start
# sessions, send chat messages and change presence in the same second. SQLite's
# DEFAULT rollback journal makes every writer block every reader and vice versa,
# and the default 5s busy timeout turns a busy burst into
# "OperationalError: database is locked" - which the client sees as a random
# failed request. WAL mode + a generous busy timeout makes those overlapping
# writes queue politely instead of failing. Neither changes the file format or
# any query, and an existing database switches to WAL on its first connection.
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},  # needed because FastAPI/uvicorn use multiple threads
    pool_size=20,          # keep connections warm so a burst of users doesn't pay for new ones
    max_overflow=20,       # ...and still allow a spike beyond that
    pool_pre_ping=True,    # a recycled connection never hands out a stale handle
    pool_recycle=1800,     # and is refreshed every 30 minutes
)


@event.listens_for(engine, "connect")
def _sqlite_pragmas(dbapi_connection, _record):
    """Per-connection pragmas. WAL is persistent in the file header, but
    synchronous and busy_timeout are per-connection, so they must be applied
    to every new connection. Failures are ignored: a read-only or exotic
    filesystem still runs, just without the extra concurrency headroom."""
    cur = dbapi_connection.cursor()
    for pragma in (
        ("journal_mode", "WAL"),        # readers never block the writer
        ("busy_timeout", "30000"),      # wait up to 30s for a busy write instead of failing
        ("synchronous", "NORMAL"),      # the safe-and-fast pairing for WAL
        ("foreign_keys", "ON"),
        ("cache_size", "-16000"),       # ~16 MB page cache per connection
        ("temp_store", "MEMORY"),
    ):
        try:
            cur.execute("PRAGMA %s=%s" % pragma)
        except Exception:
            pass
    cur.close()

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI dependency: yields a DB session per-request and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
