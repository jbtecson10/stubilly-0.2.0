"""One-shot foreground-window reading straight from the Windows API.

Why this exists: the Electron build gets the foreground app/window from
`active-win` in the main process, but a browser-mode deployment (any
browser, any profile) has no such bridge — so the guardian's badge showed
"Monitoring unavailable". The backend runs on the student's own machine in
web mode, so it can read the same signal itself with ctypes (no new
dependency): one instantaneous snapshot per call, never a loop.

Signals produced per snapshot:
  app   - foreground process name, lowercase, without ".exe" ("chrome")
  title - full window title (capped)
  site  - domain embedded in the title ("youtube.com") or None — the same
          conservative extraction the frontend uses; hostnames only ever
          appear in titles when a page put them there.
  in_stubilly - the foreground title mentions Stubilly (the study app/tab)

Callers merge this with whatever the client reported: the client's reading
wins (deterministic for tests, Electron carries richer data), the probe
fills the gaps (browser mode where wm.available used to be false).
Availability is reported, not assumed: non-Windows or any API failure
returns available=False and the UI keeps its honest "unavailable" badge.
"""
import re
import sys
from typing import Any, Dict, Optional

# Port of the frontend's extractDomainFromTitle: only a domain literal
# inside the title counts — brand names stay conservative (None).
_TITLE_DOMAIN_RE = re.compile(
    r"(?:^|[\s(['\"(])([a-z0-9-]+\.[a-z]{2,})(?:[\s)'.'\"\](!]|$)"
)

_MAX_TITLE = 240

if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    _u32 = ctypes.windll.user32
    _k32 = ctypes.windll.kernel32

    _u32.GetForegroundWindow.restype = wintypes.HWND
    _u32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    _u32.GetWindowTextW.restype = ctypes.c_int
    _u32.GetWindowThreadProcessId.argtypes = [
        wintypes.HWND, ctypes.POINTER(wintypes.DWORD),
    ]
    _u32.GetWindowThreadProcessId.restype = wintypes.DWORD
    _k32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    _k32.OpenProcess.restype = wintypes.HANDLE
    _k32.QueryFullProcessImageNameW.argtypes = [
        wintypes.HANDLE, wintypes.DWORD, wintypes.LPCWSTR,
        ctypes.POINTER(wintypes.DWORD),
    ]
    _k32.QueryFullProcessImageNameW.restype = wintypes.BOOL
    _k32.CloseHandle.argtypes = [wintypes.HANDLE]
    _PROCESS_QUERY_LIMITED_INFORMATION = 0x1000


def _process_name(hwnd) -> Optional[str]:
    """Foreground window's executable basename (no path, no .exe), lower."""
    pid = wintypes.DWORD(0)
    # GetWindowThreadProcessId lives in user32 — calling it on kernel32
    # raised AttributeError on every snapshot, which the caller swallowed
    # as available=False ("Monitoring unavailable") forever.
    _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value:
        return None
    handle = _k32.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
    if not handle:
        return None
    try:
        size = wintypes.DWORD(260)
        buf = ctypes.create_unicode_buffer(261)
        if not _k32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return None
        name = (buf.value or "").split("\\")[-1].split("/")[-1]
        if name.lower().endswith(".exe"):
            name = name[:-4]
        return name.lower() or None
    finally:
        _k32.CloseHandle(handle)


def _title_site(title: str) -> Optional[str]:
    m = _TITLE_DOMAIN_RE.search(title.lower())
    return m.group(1) if m else None


def read_foreground() -> Dict[str, Any]:
    """Instantaneous foreground snapshot. Never raises; on any failure
    (unsupported OS, permission hiccup) reports available=False."""
    out: Dict[str, Any] = {
        "available": False,
        "app": None,
        "title": None,
        "site": None,
        "in_stubilly": False,
    }
    if sys.platform != "win32":
        return out
    try:
        hwnd = _u32.GetForegroundWindow()
        if not hwnd:
            return out
        length = _u32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer((length or 0) + 1)
        _u32.GetWindowTextW(hwnd, buf, (length or 0) + 1)
        title = buf.value or ""
        app = _process_name(hwnd)
        lowered = title.lower()
        out.update({
            "available": True,
            "app": app,
            "title": title[:_MAX_TITLE] or None,
            "site": _title_site(title),
            "in_stubilly": "stubilly" in lowered,
        })
        # The study app window itself has no domain in its title — tag it
        # the same way the client tags a focused study tab.
        if out["in_stubilly"] and not out["site"]:
            out["site"] = "stubilly"
        return out
    except Exception:
        return {"available": False, "app": None, "title": None,
                "site": None, "in_stubilly": False}


# --- app enforcement (smart intervention: BLOCK an app) -------------------
if sys.platform == "win32":
    _u32.IsWindowVisible.argtypes = [wintypes.HWND]
    _u32.IsWindowVisible.restype = wintypes.BOOL
    _u32.PostMessageW.argtypes = [
        wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM,
    ]
    _u32.PostMessageW.restype = wintypes.BOOL
    _u32.EnumWindows.argtypes = [ctypes.c_void_p, wintypes.LPARAM]
    _u32.EnumWindows.restype = wintypes.BOOL
    _WM_CLOSE = 0x0010

_WNFUNC = None
if sys.platform == "win32":
    _WNFUNC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)


def _pid_process_name(pid: int) -> Optional[str]:
    """Executable basename (no path, no .exe) for a pid, lower; None if the
    process can't be opened (access denied, exited)."""
    if not pid:
        return None
    handle = _k32.OpenProcess(_PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
    if not handle:
        return None
    try:
        size = wintypes.DWORD(260)
        buf = ctypes.create_unicode_buffer(261)
        if not _k32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            return None
        name = (buf.value or "").split("\\")[-1].split("/")[-1]
        if name.lower().endswith(".exe"):
            name = name[:-4]
        return name.lower() or None
    finally:
        _k32.CloseHandle(handle)


def _process_name(hwnd) -> Optional[str]:
    """Foreground window's executable basename (no path, no .exe), lower."""
    pid = wintypes.DWORD(0)
    # GetWindowThreadProcessId lives in user32 — calling it on kernel32
    # raised AttributeError on every snapshot, which the caller swallowed
    # as available=False ("Monitoring unavailable") forever.
    _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return _pid_process_name(pid.value)


def close_app_windows(app_name: str) -> int:
    """Gracefully ask every VISIBLE top-level window owned by the given
    process basename ("roblox", "steam") to close (WM_CLOSE — apps can show
    their own confirm/quit flow, we never TerminateProcess). This is how the
    proposal gate enforces BLOCK on an app: window titles are OS-visible,
    but the app windows themselves are. Returns how many windows got the
    message. Never raises; 0 on non-Windows or any API failure."""
    if sys.platform != "win32" or not app_name:
        return 0
    target = str(app_name).strip().lower()
    if target.endswith(".exe"):
        target = target[:-4]
    if not target:
        return 0
    try:
        hwnds = []

        @_WNFUNC
        def _collect(hwnd, _lparam):
            if _u32.IsWindowVisible(hwnd):
                hwnds.append(hwnd)
            return True

        if not _u32.EnumWindows(_collect, 0) and not hwnds:
            return 0
        closed = 0
        for hwnd in hwnds:
            pid = wintypes.DWORD(0)
            _u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if _pid_process_name(pid.value) == target:
                if _u32.PostMessageW(hwnd, _WM_CLOSE, 0, 0):
                    closed += 1
        return closed
    except Exception:
        return 0


def list_running_processes() -> list:
    """One snapshot of every running executable basename (original case,
    no ".exe") via Toolhelp32 — used by the background game scan so a game
    launched outside Steam (or minimized behind the browser) is still
    seen. Case is preserved on purpose: match_game_process relies on
    camel-case word boundaries (RobloxPlayerBeta.exe). No new dependency;
    never raises; [] on non-Windows/failure."""
    if sys.platform != "win32":
        return []
    try:
        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [
                ("dwSize", wintypes.DWORD),
                ("cntUsage", wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.c_void_p),
                ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", ctypes.c_long),
                ("dwFlags", wintypes.DWORD),
                ("szExeFile", ctypes.c_wchar * 260),
            ]

        TH32CS_SNAPPROCESS = 0x00000002
        snapshot = _k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if not snapshot or snapshot == ctypes.c_void_p(-1).value:
            return []
        try:
            entry = PROCESSENTRY32W()
            entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            names = []
            ok = _k32.Process32FirstW(snapshot, ctypes.byref(entry))
            while ok:
                name = (entry.szExeFile or "").strip()
                if name.lower().endswith(".exe"):
                    name = name[:-4]
                if name:
                    names.append(name)
                ok = _k32.Process32NextW(snapshot, ctypes.byref(entry))
            return names
        finally:
            _k32.CloseHandle(snapshot)
    except Exception:
        return []
