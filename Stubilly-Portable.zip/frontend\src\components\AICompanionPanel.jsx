import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Keyboard, Mic, MicOff, Paperclip, Send, Settings, Volume2, VolumeX } from "lucide-react";
import CompanionAvatar from "./CompanionAvatar";
import useVoiceInput from "../hooks/useVoiceInput";
import useVoiceOutput from "../hooks/useVoiceOutput";

/**
 * The session companion surface: OpenHuman-style dark chat card — animated
 * avatar header, streamed chat, voice commands, TTS, and a live insights
 * drawer fed by the account's learning profile.
 *
 * Voice architecture:
 *   - Commands: Web Speech API streams partial transcripts with zero
 *     upload delay; the final transcript is sent as a chat message.
 *   - Replies: stream in token-by-token (same WS path as before) and are
 *     spoken aloud sentence-by-sentence the moment each sentence completes
 *     (chunked queue in useVoiceOutput) — the first words reach the
 *     student while the rest of the reply is still generating, instead of
 *     waiting for the whole message. Emotion frames from the backend make
 *     the avatar face react instantly to both the student's words and
 *     Billy's reply.
 *
 * The companion is only active during a session — this component is
 * mounted inside the active-phase desk, never on the setup screen.
 */

// Compact timestamp for message meta: "just now" → "12m ago" → clock time.
function timeAgo(at) {
  if (!at) return "";
  const s = Math.max(0, Math.round((Date.now() - at) / 1000));
  if (s < 60) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m ago`;
  return new Date(at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export default function AICompanionPanel({
  companion,
  messages,
  companionTyping,
  connected,
  onSend,
  voiceMode = false,
  onToggleVoiceMode,
  learningProfile = null,
  focusState = "",
  emotion = null,
  onOpenSettings,
}) {
  const [draft, setDraft] = useState("");
  const [pendingImage, setPendingImage] = useState(null);
  const [pendingImageName, setPendingImageName] = useState(null);
  const [avatarState, setAvatarState] = useState("idle");
  const scrollRef = useRef(null);
  const inputRef = useRef(null);
  const fileInputRef = useRef(null);
  const greetedRef = useRef(false);
  const spokenIdsRef = useRef(new Set());

  // Attach a study file: photos become a downscaled data-URL the vision
  // models can read; plain text (notes, CSV, JSON) lands in the draft so
  // the next message carries the file as real text.
  function handleFilePick(e) {
    const file = e.target?.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (file.type.startsWith("image/")) {
      if (file.size > 10_000_000) return;
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          // Cap at 800px / JPEG ~80% — enough for the models to read
          // whiteboards and worksheets, small enough for one WS frame.
          const max = 800;
          const scale = Math.min(1, max / Math.max(img.width, img.height));
          const w = Math.max(1, Math.round(img.width * scale));
          const h = Math.max(1, Math.round(img.height * scale));
          const canvas = document.createElement("canvas");
          canvas.width = w;
          canvas.height = h;
          canvas.getContext("2d").drawImage(img, 0, 0, w, h);
          setPendingImage(canvas.toDataURL("image/jpeg", 0.8));
          // The ORIGINAL filename rides along — it often encodes the
          // source/character name and is the strongest search keyword
          // an identification request has (the canvas data-URL drops it).
          setPendingImageName(file.name);
        };
        img.onerror = () => {};
        img.src = String(reader.result);
      };
      reader.readAsDataURL(file);
      return;
    }
    const okExt = /\.(txt|md|csv|json|log)$/i.test(file.name);
    if (!okExt || file.size > 200_000) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result || "").slice(0, 8000);
      setDraft((prev) => `${prev}${prev ? "\n" : ""}Attached ${file.name}:\n${text}\n`);
      inputRef.current?.focus();
    };
    reader.readAsText(file);
  }

  // Body-doubling: the companion opens with what it remembers about this
  // student's past sessions, so the desk feels like a study partner who
  // knows them rather than a cold chatbot. Empty when there's no history.
  const personalGreeting = useMemo(() => {
    const n = Number(learningProfile?.sessions_count || 0);
    if (!n) return "";
    const avg = learningProfile?.avg_focused_pct;
    const last = learningProfile?.last_focused_pct;
    const facts = [];
    if (avg != null && Number.isFinite(Number(avg))) facts.push(`you average ${avg}% focus`);
    if (last != null && Number.isFinite(Number(last))) facts.push(`last session ${last}%`);
    const tail = facts.length ? ` — ${facts.join(", ")}` : "";
    return `Welcome back${tail} across ${n} session${n === 1 ? "" : "s"}.`;
  }, [learningProfile]);

  const profile = useMemo(
    () => ({
      pitch: companion?.voice_pitch ?? 1.0,
      rate: companion?.voice_rate ?? 1.0,
      preferredVoices: companion?.voice_preferred ?? [],
    }),
    [companion]
  );
  const { speak, enqueue, cancel, speaking } = useVoiceOutput(profile, voiceMode);

  // Greeting on mount — a personalized hello when the companion remembers
  // this student, else the companion's stock greeting. Spoken once when
  // voice mode is already on.
  const greetingText = personalGreeting || companion?.greeting || "";
  useEffect(() => {
    if (greetedRef.current || !voiceMode || !personalGreeting) return;
    greetedRef.current = true;
    setAvatarState("talking");
    speak(personalGreeting);
    const t = setTimeout(() => setAvatarState("idle"), 2600);
    return () => clearTimeout(t);
  }, [voiceMode, personalGreeting, speak]);

  // Fall back to the companion's canned greeting when there is no
  // personalized line yet (brand-new account).
  useEffect(() => {
    if (greetedRef.current || !voiceMode || personalGreeting || !companion?.greeting) return;
    greetedRef.current = true;
    setAvatarState("talking");
    speak(companion.greeting);
    const t = setTimeout(() => setAvatarState("idle"), 2200);
    return () => clearTimeout(t);
  }, [voiceMode, companion, personalGreeting, speak]);

  // Chunked TTS: the reply streams in token-by-token; speak each completed
  // sentence the moment its punctuation lands instead of waiting for the
  // whole reply. useVoiceOutput's queue keeps sentences in order without
  // cutting off the one already playing.
  const ttsSpokenLenRef = useRef(0);
  const ttsBufRef = useRef("");
  const ttsActiveIdRef = useRef(null);

  useEffect(() => {
    if (!voiceMode) return undefined;
    const last = messages[messages.length - 1];
    if (!last || last.role !== "companion" || !String(last.id || "").startsWith("stream-")) return undefined;
    const text = last.content || "";

    if (ttsActiveIdRef.current !== last.id) {
      ttsActiveIdRef.current = last.id;
      ttsSpokenLenRef.current = 0;
      ttsBufRef.current = "";
    }

    ttsBufRef.current += text.slice(ttsSpokenLenRef.current);
    ttsSpokenLenRef.current = text.length;

    if (last.streaming) {
      // Enqueue every finished sentence; hold the tail (may be mid-word).
      const parts = ttsBufRef.current.split(/(?<=[.!?…\n])\s+/);
      while (parts.length > 1) {
        const sentence = parts.shift().trim();
        if (sentence.replace(/[^A-Za-z0-9]/g, "").length >= 2) {
          setAvatarState("talking");
          enqueue(sentence);
        }
      }
      ttsBufRef.current = parts.join(" ");
      return undefined;
    }

    // Stream finished — flush whatever is left, once per message.
    const rest = ttsBufRef.current.trim();
    ttsBufRef.current = "";
    ttsActiveIdRef.current = null;
    if (!rest || spokenIdsRef.current.has(last.id)) return undefined;
    spokenIdsRef.current.add(last.id);
    if (rest.replace(/[^A-Za-z0-9]/g, "").length >= 2) {
      setAvatarState("talking");
      enqueue(rest);
      const t = setTimeout(() => setAvatarState("idle"), 2200);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [messages, voiceMode, enqueue]);

  // Avatar state follows typing/listening — but an active emotion reaction
  // wins, so "I'm stuck" keeps the concerned face through generation.
  useEffect(() => {
    if (companionTyping && !emotion) setAvatarState("thinking");
    else setAvatarState((s) => (s === "thinking" ? "idle" : s));
  }, [companionTyping, emotion]);

  // The mouth should move whenever a reply is actually streaming in, even
  // with voice OFF — otherwise the companion looks dead while it answers.
  // (The voice path above also sets "talking" per spoken sentence; this
  // covers the silent case and keeps the two from fighting because an
  // in-flight emotion still wins via visualState.)
  useEffect(() => {
    if (emotion) return undefined;
    const last = messages[messages.length - 1];
    if (last && last.role === "companion" && last.streaming) {
      setAvatarState("talking");
      return undefined;
    }
    setAvatarState((s) => (s === "talking" ? "idle" : s));
    return undefined;
  }, [messages, emotion]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, companionTyping]);

  const voiceModeRef = useRef(voiceMode);
  useEffect(() => {
    voiceModeRef.current = voiceMode;
  }, [voiceMode]);
  // Set when a voice command closes the mic for the AI's turn (half-duplex:
  // its spoken reply must never be transcribed back into chat as the
  // student's words). Cleared when the reply + its speech finish, or when
  // the student takes the mic back manually.
  const autoResumeRef = useRef(false);
  // Indirection so useVoiceInput can be wired below while the real handler
  // (defined after the hook returns stopMic) is what actually runs.
  const commandHandlerRef = useRef(() => {});

  const {
    listening,
    partial,
    supported,
    start: startMic,
    stop: stopMic,
    toggle: toggleMic,
  } = useVoiceInput({
    onCommand: (text) => commandHandlerRef.current(text),
  });

  const handleVoiceCommand = useCallback(
    (text) => {
      if (!text) return;
      // Never talk over the student — cut any ongoing reply speech first.
      cancel();
      if (voiceModeRef.current) {
        autoResumeRef.current = true;
        stopMic();
      }
      onSend(text);
    },
    [onSend, cancel, stopMic]
  );

  useEffect(() => {
    commandHandlerRef.current = handleVoiceCommand;
  }, [handleVoiceCommand]);

  // The student's turn is over when the reply finished streaming AND its
  // speech finished — only then reopen the mic, or recognition would hear
  // the AI instead of the student.
  useEffect(() => {
    if (!autoResumeRef.current) return;
    if (listening || companionTyping || speaking) return;
    const t = setTimeout(() => {
      if (autoResumeRef.current && !companionTyping && !speaking && !listening) {
        autoResumeRef.current = false;
        startMic();
      }
    }, 400);
    return () => clearTimeout(t);
  }, [listening, companionTyping, speaking, startMic]);

  const handleMicToggle = useCallback(() => {
    // Manual tap wins: any pending auto-reopen is cancelled here, before
    // toggleMic can fire a buffered command that re-arms it.
    autoResumeRef.current = false;
    toggleMic();
  }, [toggleMic]);

  useEffect(() => {
    if (listening) cancel();
  }, [listening, cancel]);

  useEffect(() => {
    if (listening) setAvatarState("listening");
    else setAvatarState((s) => (s === "listening" ? "idle" : s));
  }, [listening]);

  function handleSubmit(e) {
    e.preventDefault();
    if (!draft.trim() && !pendingImage) return;
    onSend(draft, pendingImage, pendingImageName);
    setDraft("");
    setPendingImage(null);
    setPendingImageName(null);
    if (inputRef.current) inputRef.current.style.height = "auto";
  }

  const name = companion?.name || "Stubilly";
  const color = companion?.color || "#3b82f6";
  const emoji = companion?.emoji || "🤖";
  // Emotion frames override the ambient state (thinking/listening/idle)
  // so the face reacts to content, not just activity.
  const visualState = emotion || avatarState;

  const nSessions = Number(learningProfile?.sessions_count || 0);
  const avgFocus = learningProfile?.avg_focused_pct;
  const lastFocus = learningProfile?.last_focused_pct;
  const lastTask = learningProfile?.last_task;
  const [insightsOpen, setInsightsOpen] = useState(false);
  // Tick so "just now" ages into minutes without a re-render storm.
  const [, setNowTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setNowTick((n) => n + 1), 30000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="ai-companion" style={{ "--companion-color": color }}>
      <header className="ai-companion-header">
        <CompanionAvatar
          companionId={companion?.id}
          color={color}
          size={40}
          state={visualState}
        />
        <div className="ai-companion-title">
          <span className="ai-companion-name">
            {name} <span className="ai-companion-emoji">{emoji}</span>
          </span>
          <span className="ai-companion-status">
            {listening
              ? "Listening…"
              : companionTyping
                ? "Thinking…"
                : connected
                  ? companion?.tagline || "Here with you"
                  : "Reconnecting…"}
          </span>
        </div>
        {onToggleVoiceMode && (
          <button
            type="button"
            className="ai-companion-icon-btn"
            title={voiceMode ? "Voice replies off" : "Voice replies on"}
            aria-pressed={voiceMode}
            onClick={onToggleVoiceMode}
          >
            {voiceMode ? <Volume2 size={16} /> : <VolumeX size={16} />}
          </button>
        )}
      </header>

      {nSessions > 0 && (
        <button
          type="button"
          className={`ai-insights${insightsOpen ? " ai-insights-open" : ""}`}
          onClick={() => setInsightsOpen((v) => !v)}
          aria-expanded={insightsOpen}
        >
          <span className="ai-insights-caret">{insightsOpen ? "▾" : "▸"}</span>
          <span className="ai-insights-label">Agentic task insights</span>
          <span className="ai-insights-summary">View full agent process</span>
        </button>
      )}
      {nSessions > 0 && insightsOpen && (
        <div className="ai-insights-body">
          <div>
            Average focus <b>{avgFocus != null ? `${avgFocus}%` : "—"}</b>
          </div>
          <div>
            Past sessions <b>{nSessions}</b>
          </div>
          {lastFocus != null && (
            <div>
              Last session <b>{lastFocus}%</b>
            </div>
          )}
          {lastTask && (
            <div>
              Last task <b>{lastTask}</b>
            </div>
          )}
          {focusState && (
            <div>
              Right now <b>{focusState}</b>
            </div>
          )}
        </div>
      )}

      <div className="ai-companion-thread" ref={scrollRef}>
        {messages.length === 0 && (
          <p className="ai-companion-empty">
            {greetingText || `Hi, I'm ${name} — ask me anything about your task.`}
          </p>
        )}
        {messages.map((m) =>
          m.role === "user" ? (
            <div key={m.id || m.tempId} className="ai-msg ai-msg-user">
              <div className="ai-bubble ai-bubble-user">
                {m.image ? (
                  <img
                    className="ai-bubble-img"
                    src={m.image}
                    alt="attached"
                  />
                ) : null}
                {m.content}
              </div>
              {m.at ? <span className="ai-msg-meta">{timeAgo(m.at)}</span> : null}
            </div>
          ) : (
            <div
              key={m.id || m.tempId}
              className={`ai-msg ai-msg-companion${m.streaming ? " ai-bubble-streaming" : ""}`}
            >
              <div className="ai-msg-content">
                {m.content || (m.streaming ? "▍" : "")}
              </div>
              <span className="ai-msg-meta">{m.at ? timeAgo(m.at) : ""}</span>
            </div>
          )
        )}
        {companionTyping && (
          <div className="ai-msg ai-msg-companion">
            <div className="ai-msg-content ai-bubble-typing">
              <span className="ai-typing-dot" />
              <span className="ai-typing-dot" />
              <span className="ai-typing-dot" />
            </div>
          </div>
        )}
        {partial && <div className="ai-bubble ai-bubble-partial">{partial}</div>}
      </div>

      <form className="ai-companion-input-row" onSubmit={handleSubmit}>
        <textarea
          ref={inputRef}
          className="ai-companion-input ai-companion-textarea"
          rows={1}
          placeholder={
            listening
              ? "Listening…"
              : supported
                ? `Message ${name} or tap the mic…`
                : connected
                  ? `Message ${name}…`
                  : "Reconnecting…"
          }
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            const el = e.target;
            el.style.height = "auto";
            el.style.height = `${Math.min(el.scrollHeight, 160)}px`;
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              handleSubmit(e);
            }
          }}
        />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.txt,.md,.csv,.json,.log,text/plain"
          style={{ display: "none" }}
          onChange={handleFilePick}
        />
        {pendingImage && (
          <div className="ai-attach-chip">
            <img src={pendingImage} alt="attachment preview" />
            <button
              type="button"
              className="ai-attach-chip-x"
              title="Remove photo"
              onClick={() => {
                setPendingImage(null);
                setPendingImageName(null);
              }}
            >
              ×
            </button>
          </div>
        )}
        <button
          type="button"
          className="ai-companion-icon-btn"
          title="Attach a photo or text file"
          onClick={() => fileInputRef.current?.click()}
        >
          <Paperclip size={15} />
        </button>
        <button
          type="submit"
          className="ai-companion-send"
          disabled={!draft.trim() && !pendingImage}
        >
          <Send size={15} />
        </button>
      </form>

      <div className="ai-controls">
        {supported && (
          <button
            type="button"
            className={`ai-mic-btn${listening ? " ai-mic-btn-live" : ""}`}
            onClick={handleMicToggle}
            title={listening ? "Stop listening" : "Tap and speak"}
            aria-pressed={listening}
          >
            {listening ? <Mic size={20} /> : <MicOff size={20} />}
          </button>
        )}
        {onOpenSettings && (
          <button
            type="button"
            className="ai-ctl-btn"
            title="Settings"
            onClick={onOpenSettings}
          >
            <Settings size={16} />
          </button>
        )}
        <button
          type="button"
          className="ai-ctl-btn"
          title="Type a message"
          onClick={() => inputRef.current?.focus()}
        >
          <Keyboard size={16} />
        </button>
        {supported && <span className="ai-hint-inline">Tap and speak</span>}
      </div>

      <footer className="ai-companion-footstat">
        FOCUS {avgFocus != null ? `${avgFocus}% avg` : "—"} · {nSessions} session
        {nSessions === 1 ? "" : "s"}
        {focusState ? ` · now ${focusState}` : ""}
      </footer>
    </div>
  );
}
