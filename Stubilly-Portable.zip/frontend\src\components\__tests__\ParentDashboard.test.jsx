import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import ParentDashboard from '../ParentDashboard.jsx';
import { api, getWsUrl, getToken } from '../../api/client';

vi.mock('../../api/client', () => ({
  api: {
    parentOverview: vi.fn(),
    parentAlerts: vi.fn(),
    parentSites: vi.fn(),
    serverTime: vi.fn(),
    parentMarkAlertRead: vi.fn(),
    parentMarkAllAlertsRead: vi.fn(),
    parentStudentPolicy: vi.fn(),
    parentConsent: vi.fn(),
    parentStudentLimits: vi.fn(),
    parentCreateStudent: vi.fn(),
    parentLinkStudent: vi.fn(),
    parentStudentSessions: vi.fn(),
    parentStudentActivity: vi.fn(),
  },
  getWsUrl: vi.fn(),
  getToken: vi.fn(),
}));

class NoopWebSocket {
  constructor(url) {
    this.url = url;
    this.onopen = null;
    this.onmessage = null;
    this.onclose = null;
    this.onerror = null;
    // Fire onopen async (like a real socket) so the Live badge flips to
    // "live" — handlers are attached synchronously right after construction.
    setTimeout(() => this.onopen && this.onopen(), 0);
  }

  close() {}
}

const makeOverview = () => ({
  students: [
    {
      id: 1,
      full_name: 'Maria Cruz',
      serial_number: '2024-0099',
      status: 'signed_in',
      is_minor: true,
      consent_granted: true,
      device_paused: false,
      monitoring_enabled: true,
      last_focus_pct: 88,
      last_off_task_minutes: 3,
      blocked_sites: ['youtube.com'],
      allowed_sites: [],
      daily_screen_limit_min: 60,
      downtime_start: null,
      downtime_end: null,
      current_task: 'Math homework',
    },
  ],
  total_sessions: 4,
  avg_focus_pct: 82,
  unread_alerts: 1,
});

const makeAlerts = () => [
  {
    id: 101,
    student_id: 1,
    student_name: 'Maria Cruz',
    kind: 'site_visit',
    created_at: '2026-10-15 07:55:00',
    read_at: null,
    payload: { site: 'youtube.com' },
    message: 'Visited youtube.com',
  },
  {
    id: 102,
    student_id: 1,
    student_name: 'Maria Cruz',
    kind: 'blocked',
    created_at: '2026-10-15 07:50:00',
    read_at: '2026-10-15 07:51:00',
    payload: {},
    message: 'Site blocked',
  },
];

const makeSites = () => ({
  students: [
    {
      id: 1,
      current_site: 'khanacademy.org',
      current_site_at: new Date(Date.now() - 120000).toISOString(),
      in_stubilly: false,
      screen_seconds_today: 900,
      current_window: 'Algebra worksheet',
    },
  ],
});

function renderDashboard() {
  return render(
    <ParentDashboard
      user={{ full_name: 'Ana Parent', email: 'ana@example.com', role: 'parent' }}
      onLogout={() => {}}
    />
  );
}

// Renders and waits until the mocked overview has landed, so every
// assertion runs against the fully loaded dashboard.
async function renderLoaded() {
  renderDashboard();
  await screen.findByText('Maria Cruz', { selector: '.parent-student-name' });
}

beforeEach(() => {
  vi.clearAllMocks();
  vi.stubGlobal('WebSocket', NoopWebSocket);
  getToken.mockReturnValue('test-token');
  getWsUrl.mockResolvedValue('ws://test.local/ws/parent?token=test-token');
  api.parentOverview.mockResolvedValue(makeOverview());
  api.parentAlerts.mockResolvedValue(makeAlerts());
  api.parentSites.mockResolvedValue(makeSites());
  api.serverTime.mockResolvedValue({ server_time: '2026-10-15 08:00:00' });
  api.parentMarkAlertRead.mockResolvedValue({});
  api.parentMarkAllAlertsRead.mockResolvedValue({});
  api.parentStudentPolicy.mockImplementation(async (id, body) => ({
    blocked_sites: body.blocked_sites || [],
    allowed_sites: body.allowed_sites || [],
  }));
  api.parentConsent.mockResolvedValue({ granted: true });
  api.parentStudentLimits.mockResolvedValue(makeOverview().students[0]);
  api.parentCreateStudent.mockResolvedValue({ id: 2 });
  api.parentLinkStudent.mockResolvedValue({ id: 2, full_name: 'Linked Student' });
  api.parentStudentSessions.mockResolvedValue([]);
  api.parentStudentActivity.mockResolvedValue({
    date: null,
    screen_seconds: 0,
    events: [],
    top_windows: [],
    top_sites: [],
    top_apps: [],
    sessions: [],
  });
});

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

describe('ParentDashboard baseline (pre-refactor contract)', () => {
  it('shows the Focus overview heading', async () => {
    await renderLoaded();
    expect(screen.getByRole('heading', { name: 'Focus overview' })).toBeTruthy();
  });

  it('shows the four stats labels', async () => {
    await renderLoaded();
    expect(screen.getByText('Linked students')).toBeTruthy();
    expect(screen.getByText('Sessions (7 days)')).toBeTruthy();
    expect(screen.getByText('Average focus')).toBeTruthy();
    expect(screen.getByText('Unread alerts')).toBeTruthy();
  });

  it('reveals Create account / Link existing tabs when Add student is clicked', async () => {
    await renderLoaded();
    const addBtn = await screen.findByRole('button', { name: 'Add student' });
    fireEvent.click(addBtn);
    expect(await screen.findByRole('button', { name: 'Link existing' })).toBeTruthy();
    expect(screen.getAllByRole('button', { name: 'Create account' })).toHaveLength(2);
  });

  it('renders the student card with status, consent and live presence', async () => {
    await renderLoaded();
    expect(
      screen.getByText('Maria Cruz', { selector: '.parent-student-name' })
    ).toBeTruthy();
    expect(screen.getByText('signed in', { selector: '.parent-status' })).toBeTruthy();
    expect(screen.getByText(/consent granted/)).toBeTruthy();
    const site = screen.getByText('khanacademy.org');
    expect(site.closest('.parent-site')).toBeTruthy();
    expect(site.parentElement.textContent).toMatch(/^Now on/);
  });

  it('renders the student filter chips', async () => {
    await renderLoaded();
    expect(
      await screen.findByRole('button', { name: /All students/ })
    ).toBeTruthy();
    expect(screen.getByRole('button', { name: /Maria Cruz/ })).toBeTruthy();
  });

  it('renders both alert labels and Mark all read', async () => {
    await renderLoaded();
    expect(screen.getByText('Now on', { selector: '.parent-alert-kind' })).toBeTruthy();
    expect(screen.getByText('Blocked', { selector: '.parent-alert-kind' })).toBeTruthy();
    expect(screen.getByRole('button', { name: /Mark all read/ })).toBeTruthy();
  });

  it('keeps Sign out reachable through the rail account card', async () => {
    await renderLoaded();
    // Sign out moved off the header into the pinned account card (the
    // student-sidebar pattern) — assert it is still reachable after one click.
    const account = screen.getByRole('button', { name: /Ana Parent/ });
    expect(account).toBeTruthy();
    expect(account.getAttribute('aria-expanded')).toBe('false');
    fireEvent.click(account);
    expect(account.getAttribute('aria-expanded')).toBe('true');
    // The menu item is role="menuitem", same as the student sidebar's.
    expect(screen.getByRole('menuitem', { name: 'Sign out' })).toBeTruthy();
  });

  it('opens the history panel with the empty state', async () => {
    await renderLoaded();
    // Scoped to the card's own toggle: the new left rail also has a
    // "History" button, so the old bare-name role query is ambiguous now.
    const historyBtn = await screen.findByText('History', {
      selector: '.parent-history-toggle',
    });
    fireEvent.click(historyBtn);
    expect(await screen.findByText(/No sessions yet/)).toBeTruthy();
  });
});

describe('ParentDashboard left-rail redesign', () => {
  it('renders the section rail with aria-current on Overview', async () => {
    await renderLoaded();
    const nav = screen.getByRole('navigation', { name: 'Parent sections' });
    expect(nav).toBeTruthy();
    const active = nav.querySelector('[aria-current="page"]');
    expect(active).toBeTruthy();
    expect(active.textContent).toMatch(/Overview/);
  });

  it('opens History as an All-students view with a subsection per linked student', async () => {
    await renderLoaded();
    // Rail History, no student picked: every linked student gets a big
    // name-header subsection with their own itemized sessions.
    const nav = screen.getByRole('navigation', { name: 'Parent sections' });
    fireEvent.click(within(nav).getByRole('button', { name: 'History' }));
    expect(
      await screen.findByText('Maria Cruz', { selector: '.parent-hist-student-name' })
    ).toBeTruthy();
    // Her status chip rides in the subsection header.
    expect(
      screen.getByText('signed in', { selector: '.parent-hist-student-head .parent-status' })
    ).toBeTruthy();
    // The per-student fetch uses the documented endpoint + limit.
    expect(api.parentStudentSessions).toHaveBeenCalledWith(1, 30);
    // Friendly empty state names the REAL student.
    expect(
      await screen.findByText(/No sessions yet — when Maria starts/)
    ).toBeTruthy();
  });

  it('switching to Alerts in the rail shows the standalone feed', async () => {
    await renderLoaded();
    fireEvent.click(screen.getByRole('button', { name: /Alerts/ }));
    expect(await screen.findByRole('heading', { name: /Alerts/, level: 1 })).toBeTruthy();
    expect(screen.getByText('Now on', { selector: '.parent-alert-kind' })).toBeTruthy();
    expect(screen.getByRole('button', { name: /Mark all read/ })).toBeTruthy();
  });

  it('theme toggle flips the wrapper class to the dark skin', async () => {
    const { container } = renderDashboard();
    await screen.findByText('Maria Cruz', { selector: '.parent-student-name' });
    const wrap = container.querySelector('.parent-skin');
    expect(wrap).toBeTruthy();
    expect(wrap.classList.contains('parent-theme-dark')).toBe(false);
    fireEvent.click(screen.getByRole('button', { name: 'Switch to dark theme' }));
    expect(wrap.classList.contains('parent-theme-dark')).toBe(true);
  });

  it('shows the Live badge once the socket opens', async () => {
    await renderDashboard();
    expect(await screen.findByText('Live', { selector: '.prail-live' })).toBeTruthy();
  });

  it('renders the Account removed alert label', async () => {
    api.parentAlerts.mockResolvedValue([
      {
        id: 103,
        student_id: 1,
        student_name: 'Maria Cruz',
        kind: 'account_removed',
        created_at: '2026-10-15 07:40:00',
        read_at: null,
        payload: {},
        message: 'Student account was removed',
      },
    ]);
    await renderLoaded();
    expect(screen.getByText('Account removed', { selector: '.parent-alert-kind' })).toBeTruthy();
  });
});
