# Runs the frontend test suite from a clean-path mirror of this app.
#
# WHY THIS EXISTS: the project lives in a folder whose path contains "#"
# (...\Stubilly protoype #2 scratch\frontend). Vite turns absolute paths into
# file:// URLs; a raw "#" becomes a URL fragment and truncates everything after
# it. `vite build` survives (it falls back to Node fs reads), but Vitest's
# module runner does not — every test fails with
# "Cannot find module '/src/...'" even though the file exists. Junctions and
# SUBST drives cannot hide it: Windows re-canonicalises them back to the real
# path. Until the project folder is renamed to drop "#", tests run from a
# mirror at %LOCALAPPDATA%\stubilly-fe-test (no "#", real files, own
# node_modules). This script keeps that mirror in sync and runs Vitest there.
#
# Usage:  npm test        (delegates here)
#         powershell -NoProfile -ExecutionPolicy Bypass -File scripts\test.ps1

$ErrorActionPreference = 'Stop'

$frontend = Split-Path -Parent $PSScriptRoot
$mirror = Join-Path $env:LOCALAPPDATA 'stubilly-fe-test'

Write-Host "==> Syncing test mirror: $mirror"

# 1. node_modules: only re-install when package.json or the lockfile changed.
#    (The mirror keeps its own real node_modules — a junction back into the
#    "#" path would reintroduce the bug, because realpath() follows it.)
$pkgSrc = Join-Path $frontend 'package.json'
$lockSrc = Join-Path $frontend 'package-lock.json'
$stampSrc = Get-FileHash -Algorithm SHA256 -LiteralPath $pkgSrc, $lockSrc |
    ForEach-Object { $_.Hash } | Out-String
$stampDstPath = Join-Path $mirror '.deps-stamp'
$stampDst = if (Test-Path -LiteralPath $stampDstPath) { Get-Content -LiteralPath $stampDstPath -Raw } else { '' }

if ($stampSrc -ne $stampDst) {
    Write-Host '==> package.json/lock changed — installing deps in mirror'
    New-Item -ItemType Directory -Force -Path $mirror | Out-Null
    Copy-Item -LiteralPath $pkgSrc -Destination $mirror -Force
    if (Test-Path -LiteralPath $lockSrc) {
        Copy-Item -LiteralPath $lockSrc -Destination $mirror -Force
        & npm ci --prefix $mirror --no-audit --no-fund
    } else {
        & npm install --prefix $mirror --no-audit --no-fund
    }
    if ($LASTEXITCODE -ne 0) { throw "npm install in mirror failed (exit $LASTEXITCODE)" }
    Set-Content -LiteralPath $stampDstPath -Value $stampSrc -NoNewline
}

# 2. Sources + configs: full mirror each run (robocopy /MIR). Quiet flags
#    keep CI-style output readable; robocopy exit codes 0-7 mean success.
$items = @('src', 'vite.config.js', 'vitest.config.js')
foreach ($item in $items) {
    $from = Join-Path $frontend $item
    if (-not (Test-Path -LiteralPath $from)) { throw "missing $item in $frontend" }
    if (Test-Path -LiteralPath $from -PathType Container) {
        robocopy $from (Join-Path $mirror $item) /MIR /NFL /NDL /NJH /NJS /NP /R:2 /W:2 | Out-Null
        if ($LASTEXITCODE -ge 8) { throw "robocopy failed for $item (exit $LASTEXITCODE)" }
    } else {
        Copy-Item -LiteralPath $from -Destination $mirror -Force
    }
    # robocopy sets $LASTEXITCODE >= 1 even on success — reset for callers.
    $global:LASTEXITCODE = 0
}

# 3. Run Vitest in the mirror (clean path, no "#").
Push-Location $mirror
try {
    & npx vitest run @args
    $code = $LASTEXITCODE
} finally {
    Pop-Location
}
exit $code
