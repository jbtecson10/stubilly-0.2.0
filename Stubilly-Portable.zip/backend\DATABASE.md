# Stubilly Database — `backend/stubilly.db` (readable guide)

This file is a **human-readable snapshot** of the live SQLite database so it can be
studied without any extension. The real file is `backend/stubilly.db` (a binary SQLite
database). For the running **installed** app, the database lives at `%APPDATA%\Stubilly\stubilly.db`;
this copy is the development one used by `run_server.py` in this folder.

- **Driver:** Python stdlib `sqlite3` — see `backend/database.py`.
- **ORM / schema definitions:** `backend/models.py`.
- **View interactively:** install the free *SQLite Viewer* VS Code extension (qwtel) and click the `.db` file.

## Tables

| chat_messages | 78 rows |
| focus_events | 28247 rows |
| interventions | 89 rows |
| login_events | 0 rows |
| sessions | 81 rows |
| study_notes | 18 rows |
| tasks | 135 rows |
| users | 0 rows |

## `chat_messages` (78 rows)

```sql
CREATE TABLE chat_messages (
	id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	timestamp DATETIME, 
	role VARCHAR NOT NULL, 
	content TEXT NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id)
)
```

Sample rows (sensitive columns masked):

| id | session_id | timestamp | role | content |
| --- | --- | --- | --- | --- |
| 1 | 9 | 2026-09-05 15:24:47.695826 | user | hello |
| 2 | 9 | 2026-09-05 15:24:48.069994 | companion | hey, just getting back to it? |
| 3 | 9 | 2026-09-05 15:24:59.958380 | user | hello |

---

## `focus_events` (28247 rows)

```sql
CREATE TABLE focus_events (
	id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	timestamp DATETIME, 
	state VARCHAR NOT NULL, 
	confidence FLOAT NOT NULL, 
	eye_aspect_ratio FLOAT, 
	head_pose_yaw FLOAT, 
	head_pose_pitch FLOAT, 
	face_detected INTEGER, 
	app_state VARCHAR, 
	active_app VARCHAR, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id)
)
```

Sample rows (sensitive columns masked):

| id | session_id | timestamp | state | confidence | eye_aspect_ratio | head_pose_yaw | head_pose_pitch | face_detected | app_state | active_app |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 2026-09-05 12:03:47.390845 | distracted | 0.41 | 0.888 | 36.5 | -10.0 | 1 | off_task | NULL |
| 2 | 1 | 2026-09-05 12:03:47.761261 | focused | 0.99 | 0.989 | 15.8 | -8.2 | 1 | off_task | NULL |
| 3 | 1 | 2026-09-05 12:03:48.418132 | focused | 0.99 | 0.989 | 13.1 | -6.9 | 1 | off_task | NULL |

---

## `interventions` (89 rows)

```sql
CREATE TABLE interventions (
	id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	timestamp DATETIME, 
	intervention_type VARCHAR NOT NULL, 
	trigger_state VARCHAR NOT NULL, 
	message TEXT, 
	user_response VARCHAR, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id)
)
```

Sample rows (sensitive columns masked):

| id | session_id | timestamp | intervention_type | trigger_state | message | user_response |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 2026-09-05 12:06:25.931899 | app_alarm | off_task | You've been on Google Chrome for 2 minutes — time to refocus on "american history on civil war". | NULL |
| 2 | 1 | 2026-09-05 12:09:04.132711 | app_alarm | off_task | You've been on Google Chrome for 2 minutes — time to refocus on "american history on civil war". | NULL |
| 3 | 1 | 2026-09-05 12:09:19.532402 | off_task_block | off_task | Bringing you back to Stubilly — "Google Chrome" is blocked until you're back on "american history on civil war". | NULL |

---

## `login_events` (0 rows)

```sql
CREATE TABLE login_events (
	id INTEGER NOT NULL, 
	user_id INTEGER NOT NULL, 
	login_at DATETIME, 
	logout_at DATETIME, 
	device VARCHAR, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)
```

Sample rows (sensitive columns masked):

| id | user_id | login_at | logout_at | device |
| --- | --- | --- | --- | --- |

---

## `sessions` (81 rows)

```sql
CREATE TABLE sessions (
	id INTEGER NOT NULL, 
	task_description TEXT NOT NULL, 
	started_at DATETIME, 
	ended_at DATETIME, 
	total_focused_seconds FLOAT, 
	total_distracted_seconds FLOAT, 
	intervention_count INTEGER, "blocked_sites" TEXT, "allowed_sites" TEXT, "user_id" INTEGER, 
	PRIMARY KEY (id)
)
```

Sample rows (sensitive columns masked):

| id | task_description | started_at | ended_at | total_focused_seconds | total_distracted_seconds | intervention_count | blocked_sites | allowed_sites | user_id |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | american history on civil war | 2026-09-05 12:03:40.658524 | 2026-09-05 12:26:17.858299 | 742.28 | 608.19 | 20 | NULL | NULL | NULL |
| 2 | test 6 | 2026-09-05 12:30:40.778105 | 2026-09-05 12:31:08.916995 | 10.07 | 11.88 | 0 | NULL | NULL | NULL |
| 3 | test 7 | 2026-09-05 13:56:17.075119 | 2026-09-05 14:02:07.365730 | 170.99 | 172.07 | 3 | NULL | NULL | NULL |

---

## `study_notes` (18 rows)

```sql
CREATE TABLE study_notes (
	id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	timestamp DATETIME, 
	content TEXT NOT NULL, 
	source VARCHAR, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id)
)
```

Sample rows (sensitive columns masked):

| id | session_id | timestamp | content | source |
| --- | --- | --- | --- | --- |
| 1 | 10 | 2026-09-05 15:26:33.634399 | Take bus 32 or 34 to main branch library | chat |
| 2 | 21 | 2026-09-06 03:03:36.735782 | discuss techniques in literature | chat |
| 3 | 31 | 2026-09-06 04:17:19.662380 | Brainstorming needed for science project | chat |

---

## `tasks` (135 rows)

```sql
CREATE TABLE tasks (
	id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	description TEXT NOT NULL, 
	estimated_minutes INTEGER, 
	completed INTEGER, 
	order_index INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(session_id) REFERENCES sessions (id)
)
```

Sample rows (sensitive columns masked):

| id | session_id | description | estimated_minutes | completed | order_index |
| --- | --- | --- | --- | --- | --- |
| 1 | 1 | Read 2 chapters on the 1860 presidential election | 8 | 0 | 0 |
| 2 | 1 | Annotate 10 key dates in the lead-up to the Civil War | 9 | 0 | 1 |
| 3 | 1 | Watch 2 historical documentaries on the Civil War causes | 8 | 0 | 2 |

---

## `users` (0 rows)

```sql
CREATE TABLE users (
	id INTEGER NOT NULL, 
	serial_number VARCHAR NOT NULL, 
	full_name VARCHAR, 
	is_active BOOLEAN, 
	password_hash TEXT NOT NULL, 
	created_at DATETIME, 
	blocked_sites TEXT, 
	allowed_sites TEXT, 
	policy_updated_at DATETIME, 
	PRIMARY KEY (id)
)
```

Sample rows (sensitive columns masked):

| id | serial_number | full_name | is_active | password_hash | created_at | blocked_sites | allowed_sites | policy_updated_at |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

---
