import { useCallback, useEffect, useRef, useState } from "react";

/**
 * speechSynthesis wrapper with per-companion voice profiles.
 *
 * Each companion has a pitch/rate preset and a list of preferred system
 * voice names — the first installed match wins, otherwise the browser
 * default. Speaking cancels any in-flight utterance so a new nudge never
 * stacks on top of the previous one.
 *
 * `enabled` mirrors the existing voice_mode setting; when false,
 * `speak()` is a no-op and the caller relies on the text banner alone.
 */
export default function useVoiceOutput(profile, enabled = true) {
  const profileRef = useRef(profile);
  profileRef.current = profile;
  const keepAliveRef = useRef(null);
  // Chunked-TTS queue for streamed replies: sentences enqueue as they
  // complete and drain one at a time. speak() always cancels + replaces;
  // enqueue() never interrupts the utterance already playing.
  const queueRef = useRef([]);
  const drainingRef = useRef(false);
  // True while anything is actually being spoken (speak() utterance or
  // a non-empty queue). The voice input uses it to know when the AI has
  // stopped talking — only then is it safe to reopen the mic, or the
  // recognition would transcribe the AI's own reply back into chat.
  const [speaking, setSpeaking] = useState(false);

  const stopKeepAlive = useCallback(() => {
    if (keepAliveRef.current) {
      clearInterval(keepAliveRef.current);
      keepAliveRef.current = null;
    }
  }, []);

  // Chrome silently pauses speechSynthesis after ~15 seconds, which cut
  // long replies off mid-sentence. A slow resume() ping while the
  // utterance is active keeps the WHOLE reply speaking to the end.
  const startKeepAlive = useCallback(() => {
    stopKeepAlive();
    keepAliveRef.current = setInterval(() => {
      try {
        const synth = window.speechSynthesis;
        if (synth && !synth.speaking && !synth.pending) {
          stopKeepAlive();
          return;
        }
        synth?.resume();
      } catch {
        stopKeepAlive();
      }
    }, 9000);
  }, [stopKeepAlive]);

  const pickVoice = useCallback(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return null;
    const voices = window.speechSynthesis.getVoices();
    if (!voices.length) return null;
    const prefs = profileRef.current?.preferredVoices || [];
    for (const needle of prefs) {
      const hit = voices.find(
        (v) => v.name.includes(needle) || v.lang.startsWith(needle)
      );
      if (hit) return hit;
    }
    return voices.find((v) => v.lang.startsWith("en")) || voices[0];
  }, []);

  // Chrome loads voices asynchronously — warm the cache once.
  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return undefined;
    const warm = () => window.speechSynthesis.getVoices();
    warm();
    window.speechSynthesis.addEventListener?.("voiceschanged", warm);
    return () => {
      window.speechSynthesis.removeEventListener?.("voiceschanged", warm);
    };
  }, []);

  const speak = useCallback(
    (text, { firm = false } = {}) => {
      if (!enabled || !text) return;
      if (typeof window === "undefined" || !window.speechSynthesis) return;
      try {
        // A firm/immediate speak replaces any queued chunk speech too.
        queueRef.current = [];
        drainingRef.current = false;
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(text);
        const p = profileRef.current || {};
        // Firm interventions (alarm / 2-minute rule) override the companion
        // profile slightly so urgency always reads as urgency.
        utter.pitch = firm ? Math.max(0.6, (p.pitch ?? 1) - 0.1) : (p.pitch ?? 1);
        utter.rate = firm ? Math.max(1.0, (p.rate ?? 1) + 0.08) : (p.rate ?? 1);
        const voice = pickVoice();
        if (voice) utter.voice = voice;
        utter.onend = () => {
          setSpeaking(false);
          stopKeepAlive();
        };
        utter.onerror = () => {
          setSpeaking(false);
          stopKeepAlive();
        };
        setSpeaking(true);
        window.speechSynthesis.speak(utter);
        startKeepAlive();
      } catch {
        // Speech synthesis unavailable — text banner already shows it.
        // Reset here too: a throw after setSpeaking(true) would otherwise
        // leave `speaking` true forever and the mic would never reopen.
        setSpeaking(false);
      }
    },
    [enabled, pickVoice, startKeepAlive, stopKeepAlive]
  );

  // Drain the sentence queue: one utterance at a time, in order, with no
  // gap between sentences (each onend pulls the next immediately).
  const drainQueue = useCallback(() => {
    if (drainingRef.current) return;
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const next = queueRef.current.shift();
    if (!next) {
      setSpeaking(false);
      return;
    }
    drainingRef.current = true;
    try {
      const utter = new SpeechSynthesisUtterance(next);
      const p = profileRef.current || {};
      utter.pitch = p.pitch ?? 1;
      utter.rate = p.rate ?? 1;
      const voice = pickVoice();
      if (voice) utter.voice = voice;
      const finish = () => {
        drainingRef.current = false;
        drainQueue();
      };
      utter.onend = finish;
      utter.onerror = finish;
      setSpeaking(true);
      window.speechSynthesis.speak(utter);
      startKeepAlive();
    } catch {
      drainingRef.current = false;
      setSpeaking(false);
    }
  }, [pickVoice, startKeepAlive]);

  const enqueue = useCallback(
    (text) => {
      if (!enabled || !text) return;
      if (typeof window === "undefined" || !window.speechSynthesis) return;
      queueRef.current.push(String(text).trim());
      drainQueue();
    },
    [enabled, drainQueue]
  );

  const cancel = useCallback(() => {
    queueRef.current = [];
    drainingRef.current = false;
    setSpeaking(false);
    stopKeepAlive();
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    try {
      window.speechSynthesis.cancel();
    } catch {
      // Ignore.
    }
  }, [stopKeepAlive]);

  // Never leak the ping interval across unmounts.
  useEffect(() => stopKeepAlive, [stopKeepAlive]);

  return { speak, enqueue, cancel, speaking };
}
