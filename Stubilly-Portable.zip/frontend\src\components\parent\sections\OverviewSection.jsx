import { History as HistoryIcon, ShieldCheck, ShieldOff, SlidersHorizontal, Users } from "lucide-react";
import { timeAgo, fmtDur, AddStudentBox } from "../shared.jsx";

/**
 * Overview section: stats strip, Add-student box, the focus switcher
 * (student filter chips) and the per-student cards — moved verbatim from
 * the old single-page ParentDashboard return.
 */
export default function OverviewSection({
  overview,
  students,
  visibleStudents,
  sitesById,
  alerts,
  unread,
  alertStudent,
  setAlertStudent,
  focusMatch,
  panel,
  setConsent,
  toggleHistory,
  toggleControls,
  showAdd,
  setShowAdd,
  addMode,
  setAddMode,
  addError,
  setAddError,
  linkMsg,
  setLinkMsg,
  form,
  setForm,
  createStudent,
  adding,
  linkIdent,
  setLinkIdent,
  linkStudent,
  linking,
}) {
  return (
    <>
      <h1 className="setup-title">Focus overview</h1>
      <p className="setup-subtitle">
        Live focus status, site activity and alerts for your linked students.
        Chat content is never shown here.
      </p>

      <div className="parent-stats">
        <div className="parent-stat">
          <span className="parent-stat-value">{students.length}</span>
          <span className="parent-stat-label">Linked students</span>
        </div>
        <div className="parent-stat">
          <span className="parent-stat-value">{overview?.total_sessions ?? 0}</span>
          <span className="parent-stat-label">Sessions (7 days)</span>
        </div>
        <div className="parent-stat">
          <span className="parent-stat-value">
            {overview?.avg_focus_pct != null ? `${overview.avg_focus_pct}%` : "—"}
          </span>
          <span className="parent-stat-label">Average focus</span>
        </div>
        <div className="parent-stat">
          <span className="parent-stat-value">{unread}</span>
          <span className="parent-stat-label">Unread alerts</span>
        </div>
      </div>

      <AddStudentBox
        showAdd={showAdd}
        setShowAdd={setShowAdd}
        addMode={addMode}
        setAddMode={setAddMode}
        addError={addError}
        setAddError={setAddError}
        linkMsg={linkMsg}
        setLinkMsg={setLinkMsg}
        form={form}
        setForm={setForm}
        createStudent={createStudent}
        adding={adding}
        linkIdent={linkIdent}
        setLinkIdent={setLinkIdent}
        linkStudent={linkStudent}
        linking={linking}
      />

      {students.length === 0 ? (
        <p className="setup-notice">
          No students linked yet — use <strong>Add student</strong> above to create
          your child's account, or link one they already have.
        </p>
      ) : (
        <>
          {/* Focus switcher: sits ABOVE the cards so it scales to any
              number of students (chips scroll sideways, never pile up)
              and drives both the cards and the alert feed below. */}
          <div className="parent-alert-bar parent-focus-bar">
            <span className="parent-focus-label">Students</span>
            <div
              className="parent-alert-filter parent-alert-chips"
              aria-label="Focus on a student"
            >
              <button
                type="button"
                className={`parent-alert-chip${alertStudent === "all" ? " is-active" : ""}`}
                onClick={() => setAlertStudent("all")}
              >
                All students
                <span className="parent-alert-chip-n">{alerts.length}</span>
              </button>
              {students.map((s) => {
                const total = alerts.filter((a) => a.student_id === s.id).length;
                const fresh = alerts.filter(
                  (a) => a.student_id === s.id && !a.read_at
                ).length;
                return (
                  <button
                    key={s.id}
                    type="button"
                    className={`parent-alert-chip${
                      alertStudent === String(s.id) ? " is-active" : ""
                    }`}
                    onClick={() => setAlertStudent(String(s.id))}
                  >
                    {s.full_name || s.serial_number}
                    <span className="parent-alert-chip-n">{total}</span>
                    {fresh > 0 && (
                      <span className="parent-alert-chip-new">{fresh} new</span>
                    )}
                  </button>
                );
              })}
            </div>
            {focusMatch && (
              <button
                type="button"
                className="btn-secondary"
                onClick={() => setAlertStudent("all")}
              >
                <Users size={15} aria-hidden="true" />
                Show everyone
              </button>
            )}
          </div>
          <div className="parent-students">
          {visibleStudents.map((s) => {
            const p = sitesById[s.id];
            const where = p?.current_site || p?.current_app || null;
            const whenAt = p?.current_site ? p?.current_site_at : p?.current_app_at;
            const historyLabel =
              panel?.type === "history" && panel.id === s.id ? "Hide history" : "History";
            const controlsLabel =
              panel?.type === "controls" && panel.id === s.id
                ? "Hide parental controls"
                : "Parental controls";
            return (
            <div key={s.id} className="parent-student">
              <div className="parent-student-head">
                <span className="parent-student-name">
                  {s.full_name || s.serial_number}
                  {s.is_minor && <><span className="parent-tag-sep"> </span><em className="parent-minor-tag">minor</em></>}
                  {s.device_paused && <><span className="parent-tag-sep"> </span><em className="parent-paused-tag">paused</em></>}
                  {s.monitoring_enabled === false && (
                    <><span className="parent-tag-sep"> </span><em className="parent-monitor-tag">monitoring off</em></>
                  )}
                </span>
                <span className={`parent-status parent-status-${s.status}`}>
                  {s.status.replace(/_/g, " ")}
                </span>
              </div>
              <div className="parent-student-meta">
                <span>
                  Last focus:{" "}
                  {s.last_focus_pct != null ? `${s.last_focus_pct}%` : "no sessions yet"}
                </span>
                <span>
                  Off task:{" "}
                  {s.last_off_task_minutes != null ? `${s.last_off_task_minutes} min` : "—"}
                </span>
              </div>
              <div className="parent-student-consent">
                <span
                  className={`parent-consent parent-consent-${
                    s.consent_granted ? "granted" : "pending"
                  }`}
                >
                  Monitoring:{" "}
                  {s.consent_granted ? "consent granted" : "consent not granted"}
                </span>
                <button
                  type="button"
                  className="btn-secondary parent-consent-btn"
                  onClick={() => setConsent(s, !s.consent_granted)}
                >
                  {s.consent_granted ? (
                    <ShieldOff size={15} aria-hidden="true" />
                  ) : (
                    <ShieldCheck size={15} aria-hidden="true" />
                  )}
                  {s.consent_granted ? "Withdraw consent" : "Grant consent"}
                </button>
              </div>
              {s.current_task && (
                <div className="parent-student-task">Now: {s.current_task}</div>
              )}
              <div className="parent-site">
                <div className="parent-site-now">
                  <span className="parent-site-live" aria-hidden="true" />
                  {where ? (
                    <span>
                      {p.current_site ? "Now on" : "Using"} <strong>{where}</strong>
                      {whenAt && (
                        <em className="parent-site-when">
                          {" · "}
                          {timeAgo(whenAt)}
                        </em>
                      )}
                    </span>
                  ) : (
                    <span className="parent-site-none">No live presence right now</span>
                  )}
                  {p?.in_stubilly != null && (
                    <em
                      className={`parent-place ${
                        p.in_stubilly ? "parent-place-in" : "parent-place-out"
                      }`}
                    >
                      {p.in_stubilly ? "in Stubilly" : "elsewhere"}
                    </em>
                  )}
                </div>
                {p?.current_window && (
                  <div className="parent-site-window">
                    On screen: <strong>{p.current_window}</strong>
                    {p.current_window_at && (
                      <em className="parent-site-when">
                        {" · "}
                        {timeAgo(p.current_window_at)}
                      </em>
                    )}
                  </div>
                )}
                <div className="parent-screen-time">
                  Screen time today{" "}
                  <strong>{p ? fmtDur(p.screen_seconds_today) : "—"}</strong>
                </div>
                {(p?.top_sites?.length || 0) > 0 && (
                  <div className="parent-site-top">
                    <span className="parent-site-top-label">Most used today</span>
                    {p.top_sites.slice(0, 5).map((t) => (
                      <div className="parent-site-row" key={t.site}>
                        <span className="parent-site-name">{t.site}</span>
                        <span className="parent-site-track">
                          <span
                            className="parent-site-fill"
                            style={{
                              width: `${Math.max(
                                6,
                                Math.round(
                                  (t.seconds /
                                    (p.top_sites[0]?.seconds || 1)) *
                                    100
                                )
                              )}%`,
                            }}
                          />
                        </span>
                        <span className="parent-site-time">{fmtDur(t.seconds)}</span>
                      </div>
                    ))}
                  </div>
                )}
                {(p?.top_apps?.length || 0) > 0 && (
                  <div className="parent-site-top">
                    <span className="parent-site-top-label">Apps today</span>
                    {p.top_apps.slice(0, 4).map((t) => (
                      <div className="parent-site-row" key={t.app}>
                        <span className="parent-site-name">{t.app}</span>
                        <span className="parent-site-track">
                          <span
                            className="parent-site-fill parent-app-fill"
                            style={{
                              width: `${Math.max(
                                6,
                                Math.round(
                                  (t.seconds / (p.top_apps[0]?.seconds || 1)) *
                                    100
                                )
                              )}%`,
                            }}
                          />
                        </span>
                        <span className="parent-site-time">{fmtDur(t.seconds)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="parent-controls">
                <div className="parent-card-actions">
                  <button
                    type="button"
                    className="btn-secondary parent-history-toggle"
                    onClick={() => toggleHistory(s)}
                  >
                    <HistoryIcon size={16} aria-hidden="true" />
                    {historyLabel}
                  </button>
                  <button
                    type="button"
                    className="btn-secondary parent-controls-toggle"
                    onClick={() => toggleControls(s)}
                  >
                    <SlidersHorizontal size={16} aria-hidden="true" />
                    {controlsLabel}
                  </button>
                </div>
              </div>
            </div>
            );
          })}
          </div>
        </>
      )}
    </>
  );
}
