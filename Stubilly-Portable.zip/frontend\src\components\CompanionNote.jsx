import { useEffect, useRef, useState } from "react";
import { api } from "../api/client";

const DEFAULT_MESSAGES = {
  focused: "Good focus — I'll stay quiet.",
  distracted: "Take your time, I'm still here.",
  sleeping: "Hey — wake up. Splash some water, then come back.",
  absent: "Whenever you're ready, I'll be here.",
};

// Per-kind styling: the three framework interventions look different from a
// plain focus-state line so "you're stuck" never reads as "you're distracted".
const KIND_LABEL = {
  check_in: "Check-in",
  paralysis: "Stuck?",
  alarm: "Focus alarm",
  app_alarm: "2-minute rule",
  off_task_block: "Back on task",
  game_warn: "Game detected",
  full_block: "Hard block",
};

export default function CompanionNote({ state, intervention, voiceMode = false }) {
  const [responded, setResponded] = useState(null); // "helpful" | "dismissed"
  const spokenRef = useRef(null);

  const kind = intervention?.interventionType;
  const isIntervention = Boolean(intervention?.message && intervention?.at);
  const message = intervention?.message || DEFAULT_MESSAGES[state] || DEFAULT_MESSAGES.focused;
  const isUrgent = ["alarm", "app_alarm", "off_task_block", "game_warn", "full_block"].includes(kind);
  const isCheckIn = kind === "check_in";
  const isParalysis = kind === "paralysis";

  // Reset the feedback buttons whenever a NEW intervention arrives.
  useEffect(() => {
    setResponded(null);
  }, [intervention?.at]);

  // Voice delivery: speak the line when the server says this run is in
  // voice mode (settings.voice_mode) or the frame itself asked for it.
  // While the student's mic is OPEN this must stay silent: the browser
  // transcribes system speech back into the transcript, so a check-in
  // speaking mid-dictation got injected into the student's own message.
  useEffect(() => {
    if (!intervention?.message || !intervention?.at) return;
    if (!(intervention.voice || voiceMode)) return;
    if (spokenRef.current === intervention.at) return;
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    spokenRef.current = intervention.at;
    if (window.stubillyMicHot) return; // text banner already shows it
    try {
      window.speechSynthesis.cancel();
      const utter = new SpeechSynthesisUtterance(intervention.message);
      utter.rate = intervention.tone === "firm" ? 1.1 : 0.98;
      utter.pitch = intervention.tone === "firm" ? 0.95 : 1.05;
      window.speechSynthesis.speak(utter);
    } catch {
      // Speech synthesis unavailable — the text banner already shows it.
    }
  }, [intervention, voiceMode]);

  async function respond(value) {
    if (!intervention?.id || responded) return;
    setResponded(value);
    try {
      await api.respondToIntervention(intervention.id, value);
    } catch {
      // Best-effort: the local confirmation still hides the buttons; the
      // evaluation just won't count this response.
    }
  }

  const showFeedback = intervention?.id && intervention?.respondable && !responded;

  return (
    <div
      className={[
        "companion-note",
        isUrgent ? "companion-note-urgent" : "",
        isCheckIn ? "companion-note-checkin" : "",
        isParalysis ? "companion-note-paralysis" : "",
      ]
        .filter(Boolean)
        .join(" ")}
    >
      {isIntervention && KIND_LABEL[kind] && (
        <span className="companion-note-kind">{KIND_LABEL[kind]}</span>
      )}
      <p className="companion-note-text">{message}</p>
      {showFeedback && (
        <div className="companion-note-actions">
          <button type="button" className="companion-note-btn" onClick={() => respond("helpful")}>
            Helped
          </button>
          <button
            type="button"
            className="companion-note-btn companion-note-btn-ghost"
            onClick={() => respond("dismissed")}
          >
            Dismiss
          </button>
        </div>
      )}
      {responded && (
        <span className="companion-note-ack">
          {responded === "helpful" ? "Noted — thanks!" : "Dismissed."}
        </span>
      )}
    </div>
  );
}
