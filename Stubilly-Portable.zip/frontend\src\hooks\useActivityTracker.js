import { useEffect, useRef } from "react";
import { api, getToken } from "../api/client";

const FLUSH_MS = 5000;
const MAX_BATCH = 40;

// What to call the thing that was clicked — element text, aria-label or
// id only. Never input VALUES (a typed password or message must not end
// up in the guardian timeline).
function elementLabel(el) {
  if (!el) return "";
  const raw =
    el.getAttribute?.("aria-label") ||
    el.textContent ||
    el.value ||
    "";
  let label = String(raw).replace(/\s+/g, " ").trim().slice(0, 60);
  if (!label && el.id) label = `#${el.id}`;
  if (!label) label = (el.tagName || "").toLowerCase();
  return label;
}

function currentHeading() {
  const el = document.querySelector(
    "main h1, main h2, main h3, .app-desk h1, .app-desk h2, .setup-title"
  );
  return (el?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 60);
}

/**
 * Activity tracker: small click/view breadcrumbs for the guardian's
 * Activity timeline ("what did they actually do"). Buffers in memory and
 * flushes every few seconds while the account has monitoring on; a 403
 * (guardian turned monitoring off) silences the tracker until it's
 * re-enabled. Presence/activity labels only — no input values, no keys,
 * no page HTML, no content.
 */
export function useActivityTracker({ enabled, sessionId }) {
  const bufferRef = useRef([]);
  const enabledRef = useRef(Boolean(enabled));
  const sessionIdRef = useRef(sessionId ?? null);
  const viewRef = useRef("");

  enabledRef.current = Boolean(enabled);
  sessionIdRef.current = sessionId ?? null;

  useEffect(() => {
    if (!enabled) return undefined;
    if (typeof document === "undefined") return undefined;
    if (!getToken()) return undefined;

    const flush = async (keepalive = false) => {
      const events = bufferRef.current.splice(0, MAX_BATCH);
      if (events.length === 0) return;
      if (!getToken()) return; // signed out — drop
      try {
        await api.postActivity(events, keepalive);
      } catch (e) {
        if (e?.status === 403) {
          // Guardian switched monitoring off mid-flight — stop queueing.
          enabledRef.current = false;
        }
        // Network hiccup: the batch is already drained; skip it rather
        // than re-sending stale clicks later.
      }
    };

    const noteView = () => {
      const heading = currentHeading();
      if (heading && heading !== viewRef.current) {
        viewRef.current = heading;
        bufferRef.current.push({
          kind: "view",
          label: heading,
          session_id: sessionIdRef.current,
        });
      }
    };

    const onClick = (e) => {
      if (!enabledRef.current) return;
      const el = e.target?.closest?.(
        "button, a, [role=button], summary, input[type=checkbox], input[type=radio], select, [data-track]"
      );
      if (!el) return;
      const label = elementLabel(el);
      if (!label) return;
      bufferRef.current.push({
        kind: "click",
        label,
        session_id: sessionIdRef.current,
      });
    };

    const tick = () => {
      if (enabledRef.current) noteView();
      flush();
    };

    noteView();
    document.addEventListener("click", onClick, true);
    const interval = setInterval(tick, FLUSH_MS);
    const onVisibility = () => {
      if (document.visibilityState === "hidden") flush(true);
    };
    const onPageHide = () => flush(true);
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", onPageHide);

    return () => {
      document.removeEventListener("click", onClick, true);
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", onPageHide);
      clearInterval(interval);
      flush(true);
    };
  }, [enabled]);
}
