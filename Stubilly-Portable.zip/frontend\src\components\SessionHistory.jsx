import { useEffect, useState } from "react";
import { api } from "../api/client";

function formatDate(iso) {
  return new Date(iso).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function formatTime(min) {
  const totalM = Math.round(min);
  if (totalM < 60) return `${totalM}m`;
  const h = Math.floor(totalM / 60);
  const r = totalM % 60;
  return r ? `${h}h ${r}m` : `${h}h`;
}

export default function SessionHistory({ onClose, onStudyAgain, onContinue, onResumeInProgress }) {
  const [sessions, setSessions] = useState(null);
  const [error, setError] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [detailError, setDetailError] = useState(null);

  useEffect(() => {
    api.listSessions().then(setSessions).catch((e) => setError(e.message));
  }, []);

  async function selectSession(id) {
    setSelectedId(id);
    setDetail(null);
    setDetailError(null);
    setLoadingDetail(true);
    try {
      // The session row + its stats are the core of the detail (Total result,
      // "Study again"). Chat and notes are supplementary — a failure loading
      // either one must NOT take down the whole view, so load them leniently
      // and default to empty lists.
      const [session, stats] = await Promise.all([
        api.getSession(id),
        api.getSessionStats(id),
      ]);
      let chat = [];
      let notes = [];
      try {
        chat = await api.getChatHistory(id);
      } catch {
        /* chat history unavailable — show the rest of the session anyway */
      }
      try {
        notes = await api.getSessionNotes(id);
      } catch {
        /* notes unavailable — show the rest of the session anyway */
      }
      setDetail({ session, stats, chat, notes });
    } catch (e) {
      setDetailError(e.message);
    } finally {
      setLoadingDetail(false);
    }
  }

  return (
    <div className="history-overlay" role="dialog" aria-label="Past sessions">
      <div className="history-panel history-panel-wide">
        <div className="history-header">
          <h2 className="history-title">Past sessions</h2>
          <button className="btn-secondary" onClick={onClose}>
            Close
          </button>
        </div>

        {error && <p className="history-empty">Couldn't load sessions: {error}</p>}

        {sessions?.length > 0 && (
          <div className="history-layout">
            <ul className="history-list">
              {sessions.map((s) => {
                const focusedMin = Math.round(s.total_focused_seconds / 60);
                const distractedMin = Math.round(s.total_distracted_seconds / 60);
                return (
                  <li key={s.id} className="history-item">
                    <button
                      type="button"
                      className={`history-item-btn${s.id === selectedId ? " is-active" : ""}`}
                      onClick={() => selectSession(s.id)}
                    >
                      <span className="history-item-main">
                        <span className="history-item-task">{s.task_description}</span>
                        <span className="history-item-date">{formatDate(s.started_at)}</span>
                      </span>
                      <span className="history-item-stats">
                        {s.ended_at ? (
                          <>
                            <span>{focusedMin}m focused</span>
                            <span>{distractedMin}m distracted</span>
                            <span>{s.intervention_count} nudges</span>
                          </>
                        ) : (
                          <span className="history-item-inprogress">In progress</span>
                        )}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>

            <div className="history-detail">
              {loadingDetail && <p className="history-empty">Loading session…</p>}
              {detailError && (
                <p className="history-empty">Couldn't load this session: {detailError}</p>
              )}

              {detail && (
                <>
                  <div className="history-detail-head">
                    <div>
                      <h3 className="history-detail-task">{detail.session.task_description}</h3>
                      <p className="history-detail-meta">
                        {formatDate(detail.session.started_at)}
                        {detail.session.ended_at ? " · finished" : " · in progress"}
                        {detail.stats?.task_study_count > 1 &&
                          ` · ${detail.stats.session_number}${ordinal(detail.stats.session_number)} time on this task`}
                      </p>
                    </div>
                    {detail.session.ended_at ? (
                      <div className="history-detail-actions">
{detail.session.tasks?.length > 0 && (
                  <button
                    className="btn-secondary"
                    onClick={() => onContinue?.(detail.session)}
                    title="Starts a new session reusing this session's saved task steps, so you pick up exactly where you left off."
                  >
                    Continue saved steps
                  </button>
                )}
                <button
                  className="btn-primary"
                  onClick={() => onStudyAgain(detail.session)}
                  title="Starts a fresh session on this task with a brand-new breakdown."
                >
                  Study again
                </button>
              </div>
            ) : (
              <div className="history-detail-actions">
                <button
                  className="btn-primary"
                  onClick={() => onResumeInProgress?.(detail.session.id)}
                  title="Resumes this session as-is: its saved task steps, chat, and notes are all restored."
                >
                  Resume session
                </button>
              </div>
            )}
          </div>

                  {detail.session.ended_at && (
                    <div className="history-detail-section">
                      <h4 className="history-detail-label">Total result</h4>
                      {detail.stats ? (
                        <>
                          <div className="session-result">
                            <div className="session-result-head">
                              <span className="session-result-time">
                                {formatTime(detail.stats.duration_sec / 60)}
                              </span>
                              <span className="session-result-focus">
                                {detail.stats.focused_pct}% focus
                              </span>
                            </div>
                            <div className="summary-bar">
                              <div
                                className="summary-bar-fill"
                                style={{ width: `${detail.stats.focused_pct}%` }}
                              />
                            </div>
                            <div className="history-stat-grid">
                              <span className="history-stat-box">
                                <b>{formatTime(detail.stats.focused_sec / 60)}</b>
                                focus
                              </span>
                              <span className="history-stat-box">
                                <b>{formatTime(detail.stats.distracted_sec / 60)}</b>
                                distracted
                              </span>
                              <span className="history-stat-box">
                                <b>{formatTime(detail.stats.sleeping_sec / 60)}</b>
                                eyes closed
                              </span>
                              <span className="history-stat-box">
                                <b>{formatTime(detail.stats.absent_sec / 60)}</b>
                                away from keyboard
                              </span>
                              <span className="history-stat-box">
                                <b>{detail.stats.intervention_count}</b>
                                nudges
                              </span>
                            </div>
                          </div>
                          {detail.stats.total_events === 0 && (
                            <p className="history-empty">
                              No focus readings were recorded for this session.
                            </p>
                          )}
                          <p className="history-detail-note">
                            {detail.stats.total_events > 0 &&
                              detail.stats.avg_time_to_first_distraction_sec != null &&
                              `First distraction after ${Math.round(detail.stats.avg_time_to_first_distraction_sec / 60)}m.`}
                            {detail.stats.total_events > 0 && (
                              <>
                                {" "}
                                This task has been studied {detail.stats.task_study_count} time
                                {detail.stats.task_study_count === 1 ? "" : "s"} in total.
                              </>
                            )}
                          </p>
                        </>
                      ) : (
                        <p className="history-empty">No focus readings recorded.</p>
                      )}
                    </div>
                  )}

                  {detail.session.tasks?.length > 0 && (
                    <div className="history-detail-section">
                      <h4 className="history-detail-label">Tasks</h4>
                      <ul className="task-checklist">
                        {detail.session.tasks.map((t) => (
                          <li key={t.id} className={t.completed ? "task-done" : ""}>
                            <span className="task-checkbox" aria-hidden="true">
                              {t.completed ? "✓" : "○"}
                            </span>
                            <span className="task-description">{t.description}</span>
                            <span className="task-minutes">{t.estimated_minutes}m</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="history-detail-section">
                    <h4 className="history-detail-label">
                      Conversation
                      {detail.chat.length > 0 && ` (${detail.chat.length} messages)`}
                    </h4>
                    {detail.chat.length === 0 ? (
                      <p className="history-empty">No chat this session — it's kept if you talked.</p>
                    ) : (
                      <div className="history-chat">
                        {detail.chat.map((m) => (
                          <div key={m.id} className={`chat-bubble chat-bubble-${m.role === "user" ? "user" : "companion"}`}>
                            {m.content}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="history-detail-section">
                    <h4 className="history-detail-label">Auto-captured notes</h4>
                    {detail.notes.length === 0 ? (
                      <p className="history-empty">Nothing was auto-captured this session.</p>
                    ) : (
                      <ul className="notes-list">
                        {detail.notes.map((n) => (
                          <li key={n.id} className="notes-item">
                            {n.content}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {sessions?.length === 0 && <p className="history-empty">No sessions yet — start your first one.</p>}
      </div>
    </div>
  );
}

function ordinal(n) {
  if (n === 1) return "st";
  if (n === 2) return "nd";
  if (n === 3) return "rd";
  return "th";
}