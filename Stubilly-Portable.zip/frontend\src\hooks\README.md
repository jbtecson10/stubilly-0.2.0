# hooks/ — feature logic, one hook per feature

| Hook | Purpose |
|---|---|
| `useFocusDetector.js` | **Webcam detection.** Loads MediaPipe FaceLandmarker (bundled WASM, CDN fallback), runs the face/eye/pose loop, and emits a tick every ~700ms. |
| `useFocusSocket.js` | WebSocket to the backend focus stream. Sends ticks, receives live state + interventions. Auto-reconnects once. |
| `useWindowMonitor.js` | Turns main-process foreground-window readings into `on_task`/`off_task` against the whitelist; extracts site names from titles/URLs. |
| `useTabBlocking.js` | The student's editable blocklist (localStorage) + session-scoped bans + re-applying to the OS. |
| `useServerPolicy.js` | Polls the admin-published block/allow policy every **5s** so admin changes apply mid-session. |
| `useCompanionChat.js` | Companion chat WebSocket: streamed replies, auto-notes, live task updates, and a send-queue that never drops a message. |
| `usePomodoro.js` | Work/break Pomodoro cycle (client-side). |
| `useAlarmSound.js` | Synthesized two-tone alarm (Web Audio API, no asset file). |

Start reading: **`useFocusDetector.js`** (video), **`useServerPolicy.js`** (smallest, cleanest).