import { useEffect, useState } from "react";

/**
 * Only renders anything useful inside Electron (window.stubilly is injected
 * by preload.cjs). In plain-browser dev mode (npm run dev without
 * npm run electron) this silently does nothing, since there's no IPC bridge
 * to check installation status through — the existing backend /health check
 * in App.jsx still covers "is Ollama reachable" either way.
 */
export default function OllamaStatusBanner() {
  const [status, setStatus] = useState(null); // { installed, running } | null

  useEffect(() => {
    if (!window.stubilly) return; // not running inside Electron
    window.stubilly.getOllamaStatus().then(setStatus);
  }, []);

  if (!status || status.running) return null; // nothing to say

  if (!status.installed) {
    return (
      <div className="ollama-banner">
        <p>
          Stubilly works best with Ollama running locally for task breakdowns and nudges. It's not
          installed on this machine yet.
        </p>
        <button className="btn-secondary" onClick={() => window.stubilly.openExternal("https://ollama.com/download")}>
          Get Ollama
        </button>
      </div>
    );
  }

  // Installed but not running — main.cjs already tried auto-starting it once
  // before this component ever renders, so if we're still here, that attempt
  // didn't take (permissions, first-run model download, etc).
  return (
    <div className="ollama-banner">
      <p>Ollama is installed but doesn't seem to be running. Try opening a terminal and running:</p>
      <code className="ollama-banner-code">ollama serve</code>
    </div>
  );
}
