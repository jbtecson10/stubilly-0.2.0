import { useCallback, useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  Legend,
} from "recharts";
import { api } from "../api/client";

const RANGE_OPTIONS = [
  { label: "Today", value: "today", streak: 0 },
  { label: "7 days", value: "week", streak: 7 },
  { label: "30 days", value: "month", streak: 30 },
  { label: "Year", value: "year", streak: 365 },
  { label: "All time", value: "all", streak: 0 },
];

const NUDGE_LABELS = {
  alarm: "Focus alarms",
  app_alarm: "Site alarms",
  off_task_block: "Off-task blocks",
  study_link: "Study links",
};

const TREND_LABELS = {
  improved: "Improving",
  declined: "Slipping",
  steady: "Steady",
  first_run: "First run",
};

function formatDayLabel(iso) {
  // iso is a plain "YYYY-MM-DD" calendar day (UTC), not a moment in time —
  // append T00:00:00Z so it doesn't shift to the previous day in negative
  // UTC-offset timezones.
  const d = new Date(`${iso}T00:00:00Z`);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric", timeZone: "UTC" });
}

// Precise human-readable duration: "37m", "1h 5m", "40s".
function formatTime(minutes) {
  const totalM = Math.round(minutes);
  if (totalM <= 0 && minutes > 0) return `${Math.round(minutes * 60)}s`;
  if (totalM < 60) return `${totalM}m`;
  const h = Math.floor(totalM / 60);
  const r = totalM % 60;
  return r ? `${h}h ${r}m` : `${h}h`;
}

// Used inside the chart tooltip where decimal precision matters.
function formatMinutesPrecise(minutes) {
  if (minutes <= 0) return "0m";
  return `${minutes.toFixed(1)}m`;
}

function formatShortDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export default function AnalyticsDashboard({ onClose }) {
  const [range, setRange] = useState("today");
  const [data, setData] = useState(null);
  const [acad, setAcad] = useState(null);
  const [error, setError] = useState(null);
  const [acadError, setAcadError] = useState(null);
  const [loading, setLoading] = useState(true);

  // Loads BOTH datasets: the focus-time overview and the academic view
  // (subjects x quizzes x nudges). `showLoading` is only true for the first
  // load and explicit range switches/refreshes — event-driven reloads swap
  // the data in place so the view never flashes.
  const load = useCallback(
    (showLoading) => {
      let cancelled = false;
      if (showLoading) {
        setLoading(true);
        setError(null);
        setAcadError(null);
      }
      Promise.all([
        api.getAnalyticsOverview(range).then(
          (res) => ({ ok: true, res }),
          (e) => ({ ok: false, err: e })
        ),
        api.getAcademicProgress(range).then(
          (res) => ({ ok: true, res }),
          (e) => ({ ok: false, err: e })
        ),
      ])
        .then(([overview, academic]) => {
          if (cancelled) return;
          // Whichever request failed is the one to surface; the other still
          // renders (a failed academic call never blanks the focus view).
          if (overview.ok) {
            setData(overview.res);
            setError(null);
          } else {
            setError(overview.err.message);
          }
          if (academic.ok) {
            setAcad(academic.res);
            setAcadError(null);
          } else {
            setAcadError(academic.err.message);
          }
        })
        .finally(() => {
          if (!cancelled && showLoading) setLoading(false);
        });
      return () => {
        cancelled = true;
      };
    },
    [range]
  );

  useEffect(() => {
    const cancel = load(true);
    return cancel;
  }, [load]);

  // Real-time: refetch when the window regains focus, when a session ends,
  // when a quiz is graded, and on a slow heartbeat — so the view reflects
  // the latest server-side computation without a manual reload.
  useEffect(() => {
    const refresh = () => load(false);
    const interval = setInterval(refresh, 30000);
    window.addEventListener("focus", refresh);
    window.addEventListener("stubilly:session-ended", refresh);
    window.addEventListener("stubilly:quiz-completed", refresh);
    return () => {
      clearInterval(interval);
      window.removeEventListener("focus", refresh);
      window.removeEventListener("stubilly:session-ended", refresh);
      window.removeEventListener("stubilly:quiz-completed", refresh);
    };
  }, [load]);

  const chartData =
    data?.daily.map((d) => ({
      day: formatDayLabel(d.date),
      Focused: d.focused_minutes,
      Distracted: d.distracted_minutes,
      Sleeping: d.sleeping_minutes,
      "Away from keyboard": d.absent_minutes,
      Nudges: d.intervention_count,
    })) ?? [];

  const nudgeTypes = data?.intervention_groups ?? {};
  const sortedNudgeTypes = Object.keys(nudgeTypes).sort(
    (a, b) => (nudgeTypes[b] ?? 0) - (nudgeTypes[a] ?? 0)
  );
  const hasNudges = (data?.total_interventions ?? 0) > 0;

  const bothEmpty =
    Boolean(data) && !loading && !error &&
    data.total_sessions === 0 && (!acad || acad.total_sessions === 0);

  // Streak-gated tabs: 7-day / 30-day / Year unlock only once the student has
  // actually reached that consecutive-day milestone (best_streak_days comes
  // from the same overview, computed over all history). Today/All time always
  // show. If the current range is locked (e.g. a long gap reset the streak),
  // fall back to Today so the view never lands on an unreachable tab.
  const bestStreak = data?.best_streak_days ?? 0;
  const visibleRanges = RANGE_OPTIONS.filter(
    (opt) => opt.streak === 0 || bestStreak >= opt.streak
  );
  const rangeLocked = !visibleRanges.some((opt) => opt.value === range);

  useEffect(() => {
    if (rangeLocked) setRange("today");
  }, [rangeLocked]);

  return (
    <div className="history-overlay" role="dialog" aria-label="Productivity dashboard">
      <div className="history-panel analytics-panel">
        <div className="history-header">
          <div>
            <h2 className="history-title">Your progress</h2>
            <p className="analytics-subtitle">
              Today's progress first — precise time by category, measured straight from every
              focus tick. Longer views (7-day / 30-day / year) unlock as you build consecutive
              study-day streaks. Only your own account's data.
            </p>
          </div>
          <div className="history-header-actions">
            <button className="btn-secondary" onClick={() => load(true)}>
              Refresh
            </button>
            <button className="btn-secondary" onClick={onClose}>
              Close
            </button>
          </div>
        </div>

        <div className="analytics-range-tabs" role="tablist" aria-label="Time range">
          {visibleRanges.map((opt) => (
            <button
              key={opt.value}
              role="tab"
              aria-selected={range === opt.value}
              className={
                "analytics-range-tab" +
                (range === opt.value ? " analytics-range-tab-active" : "")
              }
              onClick={() => setRange(opt.value)}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {loading && <p className="history-empty">Loading…</p>}
        {error && !loading && <p className="history-empty">Couldn't load analytics: {error}</p>}

        {bothEmpty && (
          <p className="history-empty">
            No completed sessions in this range yet — finish a session to start building your stats.
          </p>
        )}

        {data && !loading && !error && !bothEmpty && (
          <>
            <div className="analytics-totals">
              <div className="analytics-total-card analytics-cat-focused">
                <span className="analytics-total-label">Focus</span>
                <span className="analytics-total-value">{formatTime(data.total_focused_minutes)}</span>
                <span className="analytics-total-sub">of {formatTime(
                  data.total_focused_minutes + data.total_distracted_minutes +
                  data.total_sleeping_minutes + data.total_absent_minutes
                )} tracked</span>
              </div>
              <div className="analytics-total-card analytics-cat-distracted">
                <span className="analytics-total-label">Distracted</span>
                <span className="analytics-total-value">{formatTime(data.total_distracted_minutes)}</span>
                <span className="analytics-total-sub">looking away mid-task</span>
              </div>
              <div className="analytics-total-card analytics-cat-sleeping">
                <span className="analytics-total-label">Sleeping</span>
                <span className="analytics-total-value">{formatTime(data.total_sleeping_minutes)}</span>
                <span className="analytics-total-sub">eyes closed</span>
              </div>
              <div className="analytics-total-card analytics-cat-absent">
                <span className="analytics-total-label">Away from keyboard</span>
                <span className="analytics-total-value">{formatTime(data.total_absent_minutes)}</span>
                <span className="analytics-total-sub">face not detected</span>
              </div>
              <div className="analytics-total-card analytics-cat-nudges">
                <span className="analytics-total-label">Nudges</span>
                <span className="analytics-total-value">{data.total_interventions}</span>
                <span className="analytics-total-sub">{data.total_sessions} real sessions this range</span>
              </div>
            </div>

            <div className="analytics-performance">
              <div className="analytics-performance-copy">
                <span className="analytics-performance-label">Performance — focus at the desk</span>
                <span className="analytics-performance-value">{Math.round(data.avg_focus_pct)}%</span>
                <span className="analytics-performance-note">
                  Average share of your study-by-the-desk time that was actually focused, measured
                  straight from every focus tick. Time away from the keyboard is counted separately
                  — it doesn't water this number down.
                </span>
              </div>
              <div className="analytics-performance-bar">
                <div
                  className="analytics-performance-fill"
                  style={{ width: `${Math.max(0, Math.min(100, data.avg_focus_pct))}%` }}
                />
              </div>
            </div>

            <div className="analytics-section">
              <h3 className="analytics-section-label">Time each day (minutes)</h3>
              <div className="analytics-chart">
                <ResponsiveContainer width="100%" height={230}>
                  <BarChart data={chartData}>
                    <CartesianGrid vertical={false} stroke="var(--line-soft)" />
                    <XAxis
                      dataKey="day"
                      tick={{ fill: "var(--ink-soft)", fontSize: 11 }}
                      axisLine={{ stroke: "var(--line-soft)" }}
                      tickLine={false}
                      interval="preserveStartEnd"
                      minTickGap={16}
                    />
                    <YAxis
                      tick={{ fill: "var(--ink-soft)", fontSize: 11 }}
                      axisLine={false}
                      tickLine={false}
                      width={30}
                    />
                    <Tooltip
                      formatter={(value, name) => [formatMinutesPrecise(value), name]}
                      contentStyle={{
                        background: "var(--bg-panel-raised)",
                        border: "1px solid var(--line-soft)",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                      labelStyle={{ color: "var(--ink)" }}
                      cursor={{ fill: "var(--bg-panel-raised)" }}
                    />
                    <Legend
                      wrapperStyle={{ fontSize: 12, color: "var(--ink-soft)" }}
                      iconSize={10}
                    />
                    <Bar dataKey="Focused" stackId="day" fill="var(--state-focused)" />
                    <Bar
                      dataKey="Distracted"
                      stackId="day"
                      fill="var(--state-distracted)"
                    />
                    <Bar dataKey="Sleeping" stackId="day" fill="var(--state-sleeping)" />
                    <Bar
                      dataKey="Away from keyboard"
                      stackId="day"
                      fill="var(--state-absent)"
                      radius={[3, 3, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {acadError && (
              <p className="history-empty">Couldn't load academic progress: {acadError}</p>
            )}

            {acad && acad.total_sessions > 0 && (
              <div className="analytics-section analytics-academic">
                <h3 className="analytics-section-label">Academic progress</h3>
                {acad.note && <p className="analytics-academic-note">{acad.note}</p>}

                <div className="analytics-academic-stats">
                  <div className="analytics-academic-card">
                    <span className="analytics-academic-value">{acad.total_sessions}</span>
                    <span className="analytics-academic-label">sessions</span>
                  </div>
                  <div className="analytics-academic-card">
                    <span className="analytics-academic-value">
                      {Math.round(acad.avg_focus_pct)}%
                    </span>
                    <span className="analytics-academic-label">avg focus</span>
                  </div>
                  <div className="analytics-academic-card">
                    <span className="analytics-academic-value">
                      {acad.avg_quiz_score != null ? `${Math.round(acad.avg_quiz_score)}%` : "—"}
                    </span>
                    <span className="analytics-academic-label">
                      quiz avg{acad.quiz_attempts > 0 ? ` · ${acad.quiz_attempts} taken` : ""}
                    </span>
                  </div>
                  <div className="analytics-academic-card">
                    <span className="analytics-academic-value">{acad.total_interventions}</span>
                    <span className="analytics-academic-label">
                      nudges · {acad.interventions_per_hour}/hr
                    </span>
                  </div>
                </div>

                {acad.subjects.length > 0 && (
                  <>
                    <h4 className="analytics-subsection-label">By subject</h4>
                    <div className="analytics-subject-list">
                      {acad.subjects.map((s) => (
                        <div key={s.subject} className="analytics-subject-row">
                          <span className="analytics-subject-name">{s.subject}</span>
                          <span className="analytics-subject-stat">
                            <b>{s.session_count}</b> session{s.session_count === 1 ? "" : "s"}
                          </span>
                          <span className="analytics-subject-stat">
                            <b>{Math.round(s.avg_focus_pct)}%</b> focus
                          </span>
                          <span className="analytics-subject-stat">
                            <b>{s.avg_quiz_score != null ? `${Math.round(s.avg_quiz_score)}%` : "—"}</b>{" "}
                            quiz{s.quiz_attempts > 0 ? ` (${s.quiz_attempts})` : ""}
                          </span>
                          <span className="analytics-subject-stat">
                            <b>{s.total_interventions}</b> nudge{s.total_interventions === 1 ? "" : "s"}
                          </span>
                          <span className={`analytics-trend analytics-trend-${s.trend}`}>
                            {TREND_LABELS[s.trend] ?? s.trend}
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                )}

                {acad.recent_sessions.length > 0 && (
                  <>
                    <h4 className="analytics-subsection-label">Recent sessions</h4>
                    <div className="analytics-sessions-table">
                      <div className="analytics-sessions-head">
                        <span>Session</span>
                        <span>Focus</span>
                        <span>Nudges</span>
                        <span>Quiz</span>
                      </div>
                      {acad.recent_sessions.map((s) => (
                        <div key={s.session_id} className="analytics-sessions-row">
                          <span className="analytics-session-task">
                            <span className="analytics-session-date">
                              {formatShortDate(s.started_at)}
                            </span>
                            {s.task_description}
                            {s.subject && (
                              <span className="analytics-session-subject">{s.subject}</span>
                            )}
                          </span>
                          <span className="analytics-session-focus">
                            {Math.round(s.focus_pct)}%
                          </span>
                          <span>{s.intervention_count}</span>
                          <span className="analytics-session-quiz">
                            {s.quiz_score != null ? (
                              <>
                                <b>{Math.round(s.quiz_score)}%</b>
                                {s.quiz_difficulty && (
                                  <span className={`quiz-difficulty quiz-difficulty-${s.quiz_difficulty}`}>
                                    {s.quiz_difficulty}
                                  </span>
                                )}
                              </>
                            ) : (
                              <span className="analytics-session-noquiz">not taken</span>
                            )}
                          </span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            <div className="analytics-section">
              <h3 className="analytics-section-label">
                Nudges this range
                {hasNudges && <span className="analytics-nudge-total">{data.total_interventions} total</span>}
              </h3>
              {hasNudges ? (
                <div className="analytics-nudge-chips">
                  {sortedNudgeTypes.map((type) => (
                    <span key={type} className="analytics-nudge-chip">
                      <b>{nudgeTypes[type]}</b> {NUDGE_LABELS[type] ?? type}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="analytics-empty-line">
                  No nudges needed — you stayed on task.
                </p>
              )}
            </div>

            <div className="analytics-footer">
              <span>
                Streak <strong>{data.current_streak_days} day{data.current_streak_days === 1 ? "" : "s"}</strong>
              </span>
              <span>
                Active days <strong>{data.active_days}</strong>
              </span>
              {data.best_day && (
                <span>
                  Best focus{" "}
                  <strong>
                    {formatDayLabel(data.best_day.date)} — {Math.round(data.best_day.focus_pct)}%
                  </strong>
                </span>
              )}
              {data.best_session && (
                <span>
                  Best session{" "}
                  <strong>
                    {data.best_session.task_description} — {Math.round(data.best_session.focus_pct)}%
                  </strong>
                </span>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}