import { useCallback, useEffect, useRef, useState } from "react";
import { ShieldBan } from "lucide-react";
import { api, getWsUrl, recheckBaseUrls, getToken } from "../api/client";
import { useAlarmSound } from "../hooks/useAlarmSound";

const AUTO_DISMISS_MS = 8000;
// Same attempt can arrive twice (HTTP ?site= redirect + WS push). Collapse
// within this window so one visit doesn't double-alarm a tab that hasn't
// claimed the site yet.
const DEDUP_WINDOW_MS = 12000;
// ONE alarm per blocked site — EVER. The first attempt claims the site in
// localStorage (under navigator.locks so two Stubilly tabs can't both win);
// every later attempt, in any session, any tab, after any reload, is silent.
// The server keeps pushing every interceptor hit; this is the single gate.
const CLAIM_PREFIX = "stubilly:alarmed:";
const CLAIM_LOCK = "stubilly-blocked-alarm";
// App.jsx broadcasts these around the Start / End Session lifecycle.
const SESSION_STARTED_EVENT = "stubilly:session-started";
const SESSION_ENDED_EVENT = "stubilly:session-ended";
// Broadcast by BlockedNotifier when the server pushes {"type":"policy_refresh"}
// over /ws/notifications — an admin (or a session-level save) just rewrote
// this student's block/allow lists. App.jsx listens and calls refreshPolicy()
// immediately, so the ALLOWED list's student-visible effects (whitelist,
// on/off-task badge, alarm suppression) apply as fast as the blocked list's
// OS-side interception, instead of waiting out the 5s poll.
const POLICY_REFRESH_EVENT = "stubilly:policy-refresh";

function normalizeSite(site) {
  let s = String(site || "").trim().toLowerCase();
  if (s.startsWith("www.")) s = s.slice(4);
  return s;
}

/**
 * Blocked-site alarm + transport whenever a hosts-blocked domain is hit.
 *
 * Two arrival paths, both funnelled through notifyOnce():
 *  1. HTTP redirect — the interceptor 302s blocked plain-HTTP hits to
 *     /blocked?site=... ; on mount we pull that query, focus the window,
 *     alarm, then clean the URL back to /.
 *  2. WebSocket — /ws/notifications pushes {"type":"blocked_attempt"} for
 *     HTTPS/SNI attempts (and HTTP ones too) while Stubilly is already open.
 *
 * GATED to sessions: the alarm only fires for a signed-in student whose
 * session is actually running (open row in /sessions, or a Start/End event
 * from this tab). The sign-in screen, the setup screen before Start Session,
 * and the parent's Guardian view are never alarmed — hosts blocking is a
 * mid-session feature, so nobody else gets to see it go off.
 *
 * EXACTLY ONCE, EVER, per blocked site: the first eligible attempt claims
 * `stubilly:alarmed:<site>` in localStorage and only the winning tab plays
 * the beep + toast. Every subsequent hit — background tabs of the blocked
 * site still polling, the student revisiting and reopening it, WS replay,
 * page reloads, other Stubilly tabs, later sessions — is silent forever.
 * There is no per-session reset.
 *
 * A pending attempt captured before the session started (setup/sign-in
 * screen arrival) is discarded at Start Session: it predates the session
 * and must never burn a site's once-ever claim or fire a stray alarm.
 *
 * Mounted in main.jsx beside <App/> so App's phase returns never unmount it.
 */
export default function BlockedNotifier() {
  const [notice, setNotice] = useState(null);
  const [tokenTick, setTokenTick] = useState(0);
  const [eligible, setEligible] = useState(false);
  const eligibleRef = useRef(false);
  const pendingSiteRef = useRef(null);
  const playAlarm = useAlarmSound();
  const seenAtRef = useRef(new Set());
  const alarmedRef = useRef(new Set()); // fast path: sites already claimed
  const timerRef = useRef(null);

  const setSessionLive = useCallback((live) => {
    eligibleRef.current = live;
    setEligible(live);
  }, []);

  // Claim this site forever, then alarm only if we won. The claim lives in
  // localStorage (shared by every tab and every reload on this origin) and
  // is guarded by navigator.locks so two tabs receiving the same WS push in
  // the same tick cannot both fire. Older epoch-scoped claim keys from the
  // previous build are honored too, so the upgrade never re-alarms.
  const claimAndAlarm = useCallback(
    async (site, copy) => {
      try {
        if (alarmedRef.current.has(site)) return;
        const claimKey = `${CLAIM_PREFIX}${site}`;
        const claim = () => {
          try {
            for (let i = localStorage.length - 1; i >= 0; i--) {
              const key = localStorage.key(i);
              if (!key || !key.startsWith(CLAIM_PREFIX)) continue;
              const rest = key.slice(CLAIM_PREFIX.length);
              if (rest === site || rest.endsWith(`:${site}`)) return false;
            }
            localStorage.setItem(claimKey, String(Date.now()));
          } catch {
            // storage unavailable — the in-memory memo still covers this tab
          }
          if (alarmedRef.current.has(site)) return false;
          alarmedRef.current.add(site);
          return true;
        };
        let won = false;
        try {
          if (navigator.locks?.request) {
            won = await navigator.locks.request(CLAIM_LOCK, async () => claim());
          } else {
            won = claim();
          }
        } catch {
          // Locks unavailable/failed — the plain claim still writes the
          // persistent key, so revisits stay silent even after a reload.
          won = claim();
        }
        if (!won) return; // already alarmed once before — stay silent
        try {
          window.focus();
        } catch {
          // browser may refuse focus without a gesture
        }
        playAlarm();
        setNotice({ site, receivedAt: Date.now(), ...copy });
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => setNotice(null), AUTO_DISMISS_MS);
      } catch {
        // claiming is best-effort — never break the notifier
      }
    },
    [playAlarm]
  );

  // Eligibility: this account has a session open right now. Refreshed when
  // the login token appears/changes and whenever App broadcasts the session
  // lifecycle; Start is optimistic (the POST already succeeded), End and
  // logout re-verify (one open session per account, so End => not live).
  const syncEligibility = useCallback(async () => {
    if (!getToken()) {
      setSessionLive(false);
      return;
    }
    try {
      const rows = await api.listSessions();
      setSessionLive(Array.isArray(rows) && rows.some((s) => s && !s.ended_at));
    } catch {
      setSessionLive(false); // no token / unreachable — fail safe: never alarm
    }
  }, [setSessionLive]);

  useEffect(() => {
    syncEligibility();
    const onStarted = () => {
      // A pending attempt captured BEFORE this session (setup/sign-in screen
      // arrival) predates the session — it must not burn the site's
      // once-ever claim or fire a stray alarm at session start. The real
      // mid-session 302 arrives in its own document, after this.
      pendingSiteRef.current = null;
      setSessionLive(true);
    };
    const onEnded = () => {
      setSessionLive(false);
      syncEligibility();
    };
    const onStorage = () => {
      setTokenTick((t) => t + 1);
      syncEligibility();
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener(SESSION_STARTED_EVENT, onStarted);
    window.addEventListener(SESSION_ENDED_EVENT, onEnded);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener(SESSION_STARTED_EVENT, onStarted);
      window.removeEventListener(SESSION_ENDED_EVENT, onEnded);
    };
  }, [syncEligibility, setSessionLive]);

  const notifyOnce = useCallback(
    (rawSite, at) => {
      // Session gate: blocking is a mid-session feature — a sign-in screen,
      // a pre-start setup screen, or a parent's dashboard must never alarm
      // (the hosts file is machine-wide, so attempts can arrive anywhere).
      if (!eligibleRef.current) return;
      const site = normalizeSite(rawSite);
      if (!site) return;
      // Prefer the server's attempt timestamp so HTTP ?site= and WS push of
      // the same hit collapse in this tab even before the claim resolves.
      const stamp = Number.isFinite(at) && at > 0 ? at * 1000 : Date.now();
      const key = `${site}@${stamp}`;
      if (seenAtRef.current.has(key)) return;
      // Also collapse same-site attempts within the short window (double delivery).
      const lastKey = [...seenAtRef.current].find((k) => k.startsWith(`${site}@`));
      if (lastKey && stamp - Number(lastKey.split("@")[1]) < DEDUP_WINDOW_MS) {
        seenAtRef.current.add(key);
        return;
      }
      seenAtRef.current.add(key);
      // Bound memory: keep only the newest few hundred keys.
      if (seenAtRef.current.size > 400) {
        const arr = [...seenAtRef.current];
        seenAtRef.current = new Set(arr.slice(-200));
      }
      // The ONE and only alarm for this site, ever.
      claimAndAlarm(site);
    },
    [claimAndAlarm]
  );

  // Path 1a: capture /blocked?site=... arrival from the HTTP interceptor's
  // 302 immediately (the URL must be cleaned even when we end up NOT
  // eligible, so the redirect never sticks in history). Only a tab that is
  // already signed in can be a mid-session transport — a sign-in-screen
  // arrival is swallowed silently and never remembered (otherwise it would
  // alarm, and burn its claim, the moment someone logs in with a session).
  useEffect(() => {
    const path = window.location.pathname.replace(/\/+$/, "");
    if (path !== "/blocked") return undefined;
    const site = new URLSearchParams(window.location.search).get("site");
    if (site && getToken()) pendingSiteRef.current = site;
    if (site || window.location.search) {
      window.history.replaceState({}, "", "/");
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  // Path 1b: alarm for the captured attempt once eligibility is known —
  // a mid-session tab transported back here has an open session, so the
  // fetch on mount flips this on a beat later; a pre-start/sign-in/parent
  // tab never becomes eligible and swallows the attempt silently.
  useEffect(() => {
    if (!eligible || !pendingSiteRef.current) return;
    const site = pendingSiteRef.current;
    pendingSiteRef.current = null;
    notifyOnce(site);
  }, [eligible, notifyOnce]);

  // Poll lightly while unauthenticated so a same-tab login also connects
  // (storage events only fire across tabs).
  useEffect(() => {
    if (getToken()) return undefined;
    const id = setInterval(() => {
      if (getToken()) setTokenTick((t) => t + 1);
    }, 1000);
    return () => clearInterval(id);
  }, [tokenTick]);

  // Path 2: live pushes over /ws/notifications (HTTPS has no redirect).
  // Only opens while this account actually has a running session — no
  // socket (and no alarm) on the sign-in/setup screens or the parent view.
  useEffect(() => {
    if (!eligible) return undefined;
    if (!getToken()) return undefined;
    let active = true;
    let ws = null;
    let attempt = 0;
    let reconnectTimer = null;

    async function connect() {
      if (!active) return;
      try {
        // Authenticated channel: the server scopes every blocked_attempt
        // to the owning student, so this tab only ever hears ITS OWN hits.
        const tok = getToken();
        if (!tok) return;
        const url = await getWsUrl(
          `/ws/notifications?token=${encodeURIComponent(tok)}`
        );
        if (!active) return;
        ws = new WebSocket(url);
      } catch {
        scheduleReconnect();
        return;
      }
      ws.onopen = () => {
        if (active) attempt = 0;
      };
      ws.onmessage = (evt) => {
        if (!active) return;
        try {
          const msg = JSON.parse(evt.data);
          if (msg.type === "blocked_attempt") notifyOnce(msg.site, msg.at);
          else if (msg.type === "intervention") {
            // Smart intervention: the app/site was just blocked (auto mode or
            // an admin decision). Same once-ever alarm path, but the copy
            // explains WHY — label + reason — instead of only naming a site.
            if (!eligibleRef.current) return;
            const claim = msg.site || msg.label || "distraction";
            claimAndAlarm(claim, {
              detail: `Blocked: ${msg.label || "distraction"}`,
              sub: msg.reason
                ? `${msg.reason} — back to Stubilly.`
                : "Stay focused — back to Stubilly.",
            });
          } else if (msg.type === "policy_refresh") {
            // The admin just saved this student's block/allow lists — ask
            // App to re-apply them on the spot (realtime, like the blocked
            // interceptor). Fire-and-forget; App owns the actual fetch.
            window.dispatchEvent(new CustomEvent(POLICY_REFRESH_EVENT));
          }
        } catch {
          // ignore malformed frames
        }
      };
      ws.onclose = () => {
        if (!active) return;
        scheduleReconnect();
      };
      ws.onerror = () => ws?.close();
    }

    function scheduleReconnect() {
      const delay = Math.min(800 * 2 ** attempt, 10000);
      attempt += 1;
      reconnectTimer = setTimeout(() => {
        recheckBaseUrls();
        connect();
      }, delay);
    }

    connect();
    return () => {
      active = false;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      ws?.close();
    };
  }, [notifyOnce, tokenTick, eligible]);

  if (!notice) return null;

  return (
    <div className="hard-block-notice" role="alert">
      <ShieldBan size={22} />
      <div className="hard-block-notice-text">
        <strong>{notice.detail || `Blocked: ${notice.site}`}</strong>
        <span>
          {notice.sub ||
            "Stay focused — that site is on your blocklist. You're back on Stubilly."}
        </span>
      </div>
      <button
        type="button"
        className="hard-block-notice-dismiss"
        onClick={() => {
          if (timerRef.current) clearTimeout(timerRef.current);
          setNotice(null);
        }}
        aria-label="Dismiss"
      >
        &times;
      </button>
    </div>
  );
}
