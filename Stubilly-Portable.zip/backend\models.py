"""
ORM models. Tables, deliberately simple:

sessions        - one row per study session (start/end, task, summary stats)
focus_events    - one row per webcam classification tick (the raw dataset)
interventions   - one row per nudge/alarm/check-in the system triggered
tasks           - the AI-generated micro-task breakdown for a session
chat_messages   - the body-doubling companion chat transcript
study_notes     - things the companion quietly decided were worth remembering
quizzes         - auto-generated post-session quiz (difficulty from focus %)
quiz_questions  - the multiple-choice questions inside a quiz
users           - one row per account (student OR parent; serial + password)
login_events    - one row per login/logout (who is online and when)
consent_records - one row per age/consent verification (audit trail)
parent_alerts   - one row per focus alert pushed to a linked parent/guardian

This schema is the actual research dataset — keep focus_events granular
(don't pre-aggregate) so you can compute whatever metrics you need later
(time-to-first-distraction, distraction frequency, intervention efficacy, etc).
"""
from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text, Boolean, UniqueConstraint
from sqlalchemy.orm import relationship
from datetime import datetime, timezone
from database import Base


def now_utc():
    return datetime.now(timezone.utc)


class User(Base):
    """One row per account — a student OR a parent/guardian. The serial
    number is the public handle (what a student types at login, what the
    admin searches for); the administration hub manages these accounts and
    per-user policies.

    Role-based access (conceptual framework, step 1):
      "student" (default) - uses the focus system
      "parent"            - linked guardian; reads focus reports + alerts,
                            NEVER chat content (see ParentModule rules)
    """

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    serial_number = Column(String, unique=True, index=True, nullable=False)
    # Optional email — the primary handle for self-service registration, the
    # to-be-verified identifier for social sign-in, and the target for
    # password recovery. NULL for legacy admin-created accounts that predate
    # email (they keep logging in by serial number only).
    email = Column(String, nullable=True, index=True)
    full_name = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)

    # --- Role-based access (Admin lives in its own table) ---
    # "student" | "parent". Every column below is shared by both roles; a
    # parent simply never has sessions of their own. nullable=True so the
    # additive SQLite migration can ALTER an existing users table — the
    # Python-side default supplies "student" for every insert.
    role = Column(String, default="student", nullable=True)

    # --- Age & consent (conceptual framework, process step 2) ---
    # DOB is optional (legacy accounts have none) but when present it
    # decides minor status: anyone under 18 needs a parent/guardian consent
    # record before monitoring may start. is_minor is denormalized so the
    # startup gate doesn't recompute ages on every request.
    date_of_birth = Column(DateTime, nullable=True)
    is_minor = Column(Boolean, default=False)
    # The parent/guardian account that owns this student (NULL = self-managed
    # adult account, or a legacy account predating the parent module).
    parent_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    # Latest consent decision for this account: True = granted, False =
    # withheld/revoked, NULL = never asked. Consent is always attributable
    # (granted_by_user_id) so an auditor can see WHO authorised monitoring.
    consent_granted = Column(Boolean, nullable=True)
    consent_at = Column(DateTime, nullable=True)
    consent_granted_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    # Free-text scope captured with the consent ("webcam + window only", ...).
    consent_scope = Column(Text, nullable=True)

    # --- Per-account preferences (user settings input) ---
    # JSON: {"check_in_interval_sec": 300, "tone": "gentle|firm",
    #        "webcam_enabled": true, "voice_mode": false}
    # NULL = all defaults (see DEFAULT_SETTINGS in admin.py).
    settings = Column(Text, nullable=True)

    # pbkdf2-hashed password (see auth.py). Never stored in plaintext.
    password_hash = Column(Text, nullable=False)
    # Plaintext copy of the same password, kept so an administrator can see
    # and reset a student's credentials from the hub (which is exactly what
    # the hub is for in this tool). NULL for accounts created before plaintext
    # capture existed — the admin can reset such an account to set one.
    password_plain = Column(Text, nullable=True)
    created_at = Column(DateTime, default=now_utc)

    # Per-user enforcement policy — authoritatively managed by the admin hub.
    # The student app downloads these and applies them at session start and
    # while a session is running (see /policy/current). Secrets of a sort:
    # kept as JSON-array strings like blocked_sites on sessions.
    blocked_sites = Column(Text, nullable=True)
    allowed_sites = Column(Text, nullable=True)
    policy_updated_at = Column(DateTime, nullable=True)

    # Password recovery (no mail server exists, so a code is issued here and
    # surfaced to the requester). One-time, expires shortly after issue.
    reset_code = Column(String, nullable=True)
    reset_code_expires = Column(DateTime, nullable=True)

    # First-run coach-mark tutorial. False = still owed a one-time walkthrough
    # (set by the column default for every newly created account). True = the
    # user finished or skipped it. NULL = legacy row that predates this column
    # (accounts that already existed before the tutorial shipped) — treated as
    # already-seen so old accounts never see the coach marks.
    tutorial_seen = Column(Boolean, nullable=True, default=False)

    sessions = relationship(
        "StudySession", back_populates="user", foreign_keys="StudySession.user_id"
    )
    login_events = relationship("LoginEvent", back_populates="user", cascade="all, delete-orphan")
    # Students linked to this account when role="parent".
    children = relationship(
        "User", backref="parent", remote_side="User.id", foreign_keys="User.parent_id"
    )


class Admin(Base):
    """One row per administrator account, kept entirely separate from
    students. Every admin shares the same full access (they all govern every
    student); what differs is only the identity used to log into the hub.
    Passwords are stored as plain text intentionally — each administrator must
    be able to read their OWN password from the hub, while other admins' rows
    return no password (their names stay visible to everyone)."""

    __tablename__ = "admins"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    username = Column(String, unique=True, index=True, nullable=False)
    password = Column(Text, nullable=False)  # visible only to the owner
    created_at = Column(DateTime, default=now_utc)
    is_active = Column(Boolean, default=True)


class LoginEvent(Base):
    """One row per login. logout_at stays NULL while the user is online —
    that's exactly how the admin hub knows who is currently logged in."""

    __tablename__ = "login_events"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    login_at = Column(DateTime, default=now_utc, index=True)
    logout_at = Column(DateTime, nullable=True)
    device = Column(String, nullable=True)  # free-form device label sent by the client

    user = relationship("User", back_populates="login_events")


class StudySession(Base):
    __tablename__ = "sessions"

    id = Column(Integer, primary_key=True, index=True)
    task_description = Column(Text, nullable=False)
    started_at = Column(DateTime, default=now_utc)
    ended_at = Column(DateTime, nullable=True)

    # --- Declared academic task (INPUT: subject / deadline / priority) ---
    # Optional structured metadata the student declares at setup. The AI uses
    # subject + deadline to prioritise the breakdown; the dashboard groups and
    # sorts by it. Free-text task_description stays the primary description.
    subject = Column(String, nullable=True)       # e.g. "Thesis", "Math"
    deadline = Column(DateTime, nullable=True)    # when it's due
    priority = Column(String, nullable=True)      # "low" | "medium" | "high"

    # Chosen AI companion for this session (billy/fokus/shola/conan/akira).
    # NULL for legacy sessions that predate the companion feature — the
    # backend falls back to the default companion (Fokus) when resolving.
    companion_id = Column(String, nullable=True)

    # The account this session belongs to. NULL for the legacy single-user
    # (no login) mode; linked to a User when the session started behind a
    # login token so the admin hub can attribute sessions to accounts.
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    # Denormalized summary stats, filled in when the session ends.
    # Kept alongside the raw events table so the dashboard can query
    # session history fast without re-aggregating focus_events every time.
    total_focused_seconds = Column(Float, default=0.0)
    total_distracted_seconds = Column(Float, default=0.0)
    intervention_count = Column(Integer, default=0)

    # Adaptive check-ins: how many periodic progress check-ins were served
    # during this run (the interval comes from the student's settings).
    check_in_count = Column(Integer, default=0)
    # How many times the paralysis-vs-distraction classifier fired "paralysis"
    # (stuck, not merely distracted) during this run — evaluation data.
    paralysis_count = Column(Integer, default=0)

    # Domains that were auto-blocked during this session's block-list
    # enforcement (JSON array, e.g. '["youtube.com","reddit.com"]').
    # Kept as a permanent record of what was blocked so the SAME set can be
    # re-applied when the session is resumed (in-progress) or continued /
    # studied again (finished) — then lifted again once that run ends.
    blocked_sites = Column(Text, nullable=True)

    # Sites/apps explicitly allowed during this session (JSON array, e.g.
    # '["canvas.instructure.com","SoundCloud"]'). Mirror record to
    # blocked_sites: kept so the SAME allowances are re-applied when the
    # session is resumed / continued / studied again, then lifted once that
    # run ends. An allow wins over the blocklist and Live Shutdown for as
    # long as this session's run is in effect.
    allowed_sites = Column(Text, nullable=True)

    focus_events = relationship("FocusEvent", back_populates="session", cascade="all, delete-orphan")
    interventions = relationship("Intervention", back_populates="session", cascade="all, delete-orphan")
    tasks = relationship("MicroTask", back_populates="session", cascade="all, delete-orphan")
    chat_messages = relationship("ChatMessage", back_populates="session", cascade="all, delete-orphan")
    study_notes = relationship("StudyNote", back_populates="session", cascade="all, delete-orphan")
    quizzes = relationship("Quiz", back_populates="session", cascade="all, delete-orphan")
    user = relationship("User", back_populates="sessions")


class FocusEvent(Base):
    """One row per vision-model inference tick. This is the core dataset."""
    __tablename__ = "focus_events"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    timestamp = Column(DateTime, default=now_utc, index=True)

    # "focused" | "distracted" | "sleeping" | "absent"
    state = Column(String, nullable=False)
    confidence = Column(Float, nullable=False)

    # Raw metadata used to derive the state — kept for later re-analysis
    # (e.g. re-tuning thresholds) without needing to re-run vision inference.
    eye_aspect_ratio = Column(Float, nullable=True)
    head_pose_yaw = Column(Float, nullable=True)
    head_pose_pitch = Column(Float, nullable=True)
    face_detected = Column(Integer, default=1)  # 0/1, SQLite has no native bool

    # Background app/window monitoring, piggybacked onto the same tick.
    # "on_task" | "off_task" | null (monitoring unavailable, e.g. non-Electron/web)
    app_state = Column(String, nullable=True)
    active_app = Column(String, nullable=True)  # foreground app name at this tick
    # Foreground window title at this tick (the named window — e.g. the
    # browser tab title) for precise "what is the student actually on" insight.
    active_title = Column(String, nullable=True)

    # Base domain of the foreground site at this tick (extracted from the
    # active window's URL/title, or "stubilly" when the study tab itself is
    # focused in browser mode). Null when no site could be derived. This is
    # the presence signal the guardian dashboard shows ("where is my
    # student right now") — distinct from the blocked-site alarm.
    active_site = Column(String, nullable=True)

    # Keyboard/mouse idle seconds at this tick (INPUT: idle time). NULL when
    # the client can't measure it. Used by the paralysis-vs-distraction
    # classifier: a face on camera + a dead input device reads as "frozen /
    # stuck", not "browsing away".
    idle_seconds = Column(Float, nullable=True)

    # Coarse gaze proxy from head pose: "center" | "left" | "right" | "down"
    # | "up" | null. Derived client-side so gaze direction is queryable
    # without re-running the vision model over raw matrices.
    gaze_direction = Column(String, nullable=True)

    session = relationship("StudySession", back_populates="focus_events")


class Intervention(Base):
    """One row every time Stubilly actually does something (nudge, alarm,
    check-in, paralysis assist, link)."""
    __tablename__ = "interventions"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    timestamp = Column(DateTime, default=now_utc)

    # "alarm" (webcam: 30-Second Focus Alarm / sleeping) |
    # "app_alarm" (2-Minute Rule: first alarm on an off-task app/site) |
    # "off_task_block" (2-Minute Rule: forced transfer back to Stubilly) |
    # "check_in"      (adaptive periodic progress check-in) |
    # "paralysis"     (stuck-detected: task paralysis, not ordinary distraction) |
    # "study_link" | "break_suggestion"
    intervention_type = Column(String, nullable=False)
    trigger_state = Column(String, nullable=False)  # what focus state caused this
    message = Column(Text, nullable=True)  # what was shown/said to the student

    # Did the student respond / dismiss / act on it? Written by the feedback
    # UI ("helpful" / "dismissed") — this is the intervention-reliability
    # signal the evaluation output is built from.
    user_response = Column(String, nullable=True)

    # Delivery channel the client actually used: "text" | "voice". Recorded
    # so evaluation can separate voice-vs-text effectiveness.
    channel = Column(String, nullable=True)

    session = relationship("StudySession", back_populates="interventions")


class MicroTask(Base):
    """AI-generated task breakdown (Ollama output) for a session."""
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    description = Column(Text, nullable=False)
    estimated_minutes = Column(Integer, nullable=True)
    completed = Column(Integer, default=0)
    order_index = Column(Integer, default=0)
    # 1 = "your AI plan is still being written" stand-in step. Only set when the
    # breakdown was too slow to arrive before the session had to start (a whole
    # class pressing Start together); the real plan replaces this row in place
    # as soon as the model answers, so nothing downstream sees a swap.
    is_placeholder = Column(Integer, default=0)

    session = relationship("StudySession", back_populates="tasks")


class ChatMessage(Base):
    """One row per turn in the body-doubling companion chat (both sides)."""
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    timestamp = Column(DateTime, default=now_utc, index=True)

    role = Column(String, nullable=False)  # "user" | "companion"
    content = Column(Text, nullable=False)

    session = relationship("StudySession", back_populates="chat_messages")


class StudyNote(Base):
    """
    Auto-captured notes. The companion decides on its own, after each chat
    exchange, whether anything in it was worth remembering (a decision, a
    fact, a to-do, a blocker) — the student never has to hit "save note".
    """
    __tablename__ = "study_notes"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False)
    timestamp = Column(DateTime, default=now_utc, index=True)

    content = Column(Text, nullable=False)
    source = Column(String, default="chat")  # "chat" | "focus" (room to grow later)

    session = relationship("StudySession", back_populates="study_notes")


class Quiz(Base):
    """
    Post-session quiz, auto-generated from what the student studied in the
    session (task, subject, checklist steps, chat, captured notes).

    The difficulty is chosen fully automatically from the session's focus
    performance (strong focus -> hard, middling -> medium, weak -> easy) so
    no teacher/parent configuration is involved.
    """
    __tablename__ = "quizzes"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False, index=True)

    # "easy" | "medium" | "hard" — picked from focus_pct at generation time.
    difficulty = Column(String, default="medium")
    # The focus % the difficulty was derived from (snapshot for the UI badge).
    focus_pct = Column(Float, default=0.0)
    # "ollama" — authored by the local LLM from the session's material;
    # "fallback" — deterministic questions built from the checklist when the
    # LLM is unreachable (quiz flow never dead-ends).
    source = Column(String, default="ollama")
    # "pending" (generated, not yet submitted) | "completed"
    status = Column(String, default="pending")

    question_count = Column(Integer, default=0)
    score = Column(Integer, nullable=True)      # correct answers, once completed
    answers = Column(Text, nullable=True)       # JSON array of chosen option indexes
    created_at = Column(DateTime, default=now_utc)
    completed_at = Column(DateTime, nullable=True)

    questions = relationship("QuizQuestion", back_populates="quiz", cascade="all, delete-orphan")
    session = relationship("StudySession", back_populates="quizzes")


class QuizQuestion(Base):
    """One multiple-choice question inside a Quiz. options is a JSON array
    of strings; correct_index points into it. correct_index is served to the
    client only AFTER the quiz is graded (review mode)."""
    __tablename__ = "quiz_questions"

    id = Column(Integer, primary_key=True, index=True)
    quiz_id = Column(Integer, ForeignKey("quizzes.id"), nullable=False, index=True)
    order_index = Column(Integer, default=0)

    prompt = Column(Text, nullable=False)
    options = Column(Text, nullable=False)      # JSON array, e.g. '["a","b","c","d"]'
    correct_index = Column(Integer, nullable=False)

    quiz = relationship("Quiz", back_populates="questions")


class ConsentRecord(Base):
    """
    Append-only audit trail of age/consent verification (process step 2).
    One row every time consent is granted or withheld, WHO granted it, and
    for what scope. The users.consent_* columns hold the CURRENT state; this
    table keeps the history so an evaluator can report consent coverage.
    """
    __tablename__ = "consent_records"

    id = Column(Integer, primary_key=True, index=True)
    # The account being monitored (the student).
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    # Who granted it: a parent/guardian account, the student themselves when
    # 18+, or NULL when granted by an administrator.
    granted_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    granted_at = Column(DateTime, default=now_utc, index=True)
    granted = Column(Boolean, default=True)          # False = withheld/revoked
    # What was authorised, e.g. "webcam,window,site-blocking".
    scope = Column(Text, nullable=True)
    # Age band recorded at the time of the decision ("minor" | "adult" |
    # "unknown") so minor-consent coverage can be reported later.
    age_band = Column(String, nullable=True)
    note = Column(Text, nullable=True)

    user = relationship("User", foreign_keys=[user_id])
    grantor = relationship("User", foreign_keys=[granted_by])


class ParentAlert(Base):
    """
    OUTPUT: parent/guardian focus alerts. One row per alert pushed to a
    linked parent's dashboard + realtime channel. Deliberately carries NO
    chat content — the conceptual framework's parent module is
    "focus alerts + real-time notification + no chat content access".
    """
    __tablename__ = "parent_alerts"

    id = Column(Integer, primary_key=True, index=True)
    parent_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    student_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=True)
    # "focus_started" | "focus_ended" | "off_task" | "distraction_spike" |
    # "paralysis" | "session_report" | "absent" | "sleeping"
    kind = Column(String, nullable=False)
    # Human-readable one-liner. Never includes chat transcript text.
    message = Column(Text, nullable=False)
    # Key numbers behind the alert (JSON): focus_pct, off_task_minutes, etc.
    payload = Column(Text, nullable=True)
    read_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now_utc, index=True)

    parent = relationship("User", foreign_keys=[parent_id])
    student = relationship("User", foreign_keys=[student_id])


class AdminNotification(Base):
    """
    OUTPUT: Admin Hub feed of account-lifecycle events. One row per new
    account (self-registered, guardian-created, or administrator-created),
    pushed live over /ws/admin and replayed on hub open so the admin never
    misses who joined while the hub was closed.
    """
    __tablename__ = "admin_notifications"

    id = Column(Integer, primary_key=True, index=True)
    # "account_created" | "account_created_by_guardian" | ...
    kind = Column(String, nullable=False)
    # Human-readable one-liner, e.g. "New account: juan@student.edu".
    message = Column(Text, nullable=False)
    # JSON context: {user_id, email, role, created_by} — display only.
    payload = Column(Text, nullable=True)
    read_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now_utc, index=True)


class AdminNotificationDismissal(Base):
    """
    PER-ADMIN deletion marker: one row means "this admin removed that
    notification from THEIR bell". The shared admin_notifications row is
    never deleted, so one admin clearing their feed can never erase the
    notification content another admin still sees.
    """
    __tablename__ = "admin_notification_dismissals"
    __table_args__ = (
        UniqueConstraint("admin_id", "notification_id", name="uq_admin_notif_dismissal"),
    )

    id = Column(Integer, primary_key=True, index=True)
    # CASCADE both ways: SQLite runs with foreign_keys=ON, so hard-deleting a
    # notification (dangling-user cleanup) or an admin account must take its
    # dismissal markers with it instead of tripping the FK.
    admin_id = Column(Integer, ForeignKey("admins.id", ondelete="CASCADE"), nullable=False, index=True)
    notification_id = Column(Integer, ForeignKey("admin_notifications.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(DateTime, default=now_utc)


class AdminMessage(Base):
    """
    OUTPUT: One row per Admin Hub chat message — the shared realtime
    admin-to-admin room. Replayed on hub open, pushed live over /ws/admin.
    """
    __tablename__ = "admin_messages"

    id = Column(Integer, primary_key=True, index=True)
    # Sender's admins.id (nullable so a removed admin's words survive).
    admin_id = Column(Integer, nullable=True, index=True)
    sender_name = Column(String, nullable=False)
    body = Column(Text, nullable=False)
    created_at = Column(DateTime, default=now_utc, index=True)

    # --- Telegram-style message actions (all additive, all nullable so an
    # older database gets them through migrate.py's ALTER TABLE) -----------
    # The message this one replies to (Telegram's quoted reply).
    reply_to_id = Column(Integer, nullable=True, index=True)
    # Set when the author edits their own text; the bubble shows "edited".
    edited_at = Column(DateTime, nullable=True)
    # Soft delete: the row stays so every open hub can reconcile the same id
    # (a hard delete would leave the message on screen forever), but the body
    # is emptied and the bubble reads "message deleted".
    deleted_at = Column(DateTime, nullable=True)

    # --- Attachment (one picture OR one voice note per message) -------------
    # "image" | "audio" | None. attachment_path holds ONLY a generated file
    # name inside the media folder - never anything the browser supplied.
    attachment_kind = Column(String, nullable=True)
    attachment_path = Column(String, nullable=True)
    attachment_name = Column(String, nullable=True)
    attachment_mime = Column(String, nullable=True)
    attachment_size = Column(Integer, nullable=True)
    # Voice-note length in seconds (measured in the browser while recording).
    attachment_seconds = Column(Float, nullable=True)

    # --- Pin / label (all additive, nullable so migrate.py's ALTER adds them) -
    # Pinned messages float to the top of the chat's "Pinned" view so a room
    # can keep a few anchor messages visible regardless of chat scrolled away.
    # 1/0 (SQLite has no native bool; NULL = not pinned).
    pinned = Column(Integer, nullable=True)
    # Optional short label marking a message as IMPORTANT (e.g. "Important").
    # NULL = unlabelled. Kept as a string so future UIs can offer more labels
    # without a schema change.
    important_label = Column(String, nullable=True)


class UserSession(Base):
    """A durable record that a signed-in token exists, so a backend restart no
    longer signs every student and parent out.

    Only a SHA-256 HASH of the token is stored (never the token itself), which
    is all that is needed to recognise the same browser after a restart. Rows
    are written at sign-in and marked revoked at sign-out; there is no other
    write path, so the table never needs a heartbeat.
    """
    __tablename__ = "user_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    token_hash = Column(String, nullable=False, unique=True, index=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    revoked = Column(Integer, nullable=False, default=0)
    revoked_at = Column(DateTime, nullable=True)


class SiteVisit(Base):
    """
    Family-Link-style site presence: one row per (user, site, local day),
    with accumulated seconds and a live last_seen. Feeds the guardian
    dashboard's "currently on" card and the "most used today" ranking.
    Written from two signals: focus ticks carrying active_site (window
    monitor / study-tab focus) and hosts-file interceptor hits on blocked
    sites (browser-mode browsing). Presence only — never content.
    """
    __tablename__ = "site_visits"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    site = Column(String, nullable=False)
    # Local calendar day "YYYY-MM-DD" the seconds were accumulated on.
    day = Column(String, nullable=False, index=True)
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False, index=True)
    seconds = Column(Float, default=0.0, nullable=False)

    __table_args__ = (
        UniqueConstraint("user_id", "site", "day", name="uq_site_visit_user_site_day"),
    )

    user = relationship("User", foreign_keys=[user_id])


class AppVisit(Base):
    """
    Family-Link-style app presence: one row per (user, app, local day) —
    the app twin of SiteVisit. Written from the merged foreground reading
    (client window monitor or the backend's own Windows-API probe) on each
    focus tick. Feeds the guardian card's "using X" line and the app
    ranking; never window content.
    """
    __tablename__ = "app_visits"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    app = Column(String, nullable=False)
    day = Column(String, nullable=False, index=True)
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False, index=True)
    seconds = Column(Float, default=0.0, nullable=False)

    __table_args__ = (
        UniqueConstraint("user_id", "app", "day", name="uq_app_visit_user_app_day"),
    )

    user = relationship("User", foreign_keys=[user_id])


class ScreenTime(Base):
    """
    Total screen seconds per (user, local day) — the estimate the guardian
    sees and the number the parental screen-time limit enforces against.

    Deliberately a separate row with its OWN last_seen: site and app
    presence are written from the same tick, so summing them would
    double-count every second. This row accrues one delta per observation
    regardless of how many presence rows that observation touches.
    """
    __tablename__ = "screen_time"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    day = Column(String, nullable=False, index=True)
    last_seen = Column(DateTime, nullable=False, index=True)
    seconds = Column(Float, default=0.0, nullable=False)

    __table_args__ = (
        UniqueConstraint("user_id", "day", name="uq_screen_time_user_day"),
    )

    user = relationship("User", foreign_keys=[user_id])


class SessionActivity(Base):
    """
    Per-session activity rollup — one row per (session, kind, name), the
    session-scoped twin of SiteVisit/AppVisit/ScreenTime. Written from the
    same presence ticks: site rows ("youtube.com"), app rows ("chrome") and
    one screen row (name="") so a guardian can replay WHAT a session was
    made of and how much of it was screen time, per session and per day.
    """
    __tablename__ = "session_activity"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    # "site" | "app" | "screen"
    kind = Column(String, nullable=False)
    name = Column(String, nullable=False, default="")
    seconds = Column(Float, default=0.0, nullable=False)
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False, index=True)

    __table_args__ = (
        UniqueConstraint("session_id", "kind", "name", name="uq_session_activity_kind_name"),
    )

    user = relationship("User", foreign_keys=[user_id])


class WindowVisit(Base):
    """
    Foreground-window presence: one row per (user, session, app, title)
    with accumulated seconds and a live last_seen — session-scoped so each
    history entry shows exactly which windows were in front during THAT
    session. Written by the server-side window sampler while a session is
    open and monitoring_enabled: this is what lets a guardian see not just
    WHICH app, but WHICH window ("Document1 - Word", the page title in
    Chrome) was in front, and for how long. Presence only — never page
    content or keystrokes. (day column stays for the by-day rollup.)
    """
    __tablename__ = "window_visits"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=True, index=True)
    app = Column(String, nullable=False)
    title = Column(String, nullable=False)
    # Local calendar day "YYYY-MM-DD" the seconds were accumulated on.
    day = Column(String, nullable=False, index=True)
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False, index=True)
    seconds = Column(Float, default=0.0, nullable=False)

    __table_args__ = (
        UniqueConstraint(
            "user_id", "session_id", "app", "title",
            name="uq_window_visit_user_session_app_title",
        ),
    )

    user = relationship("User", foreign_keys=[user_id])


class ActivityEvent(Base):
    """
    Click/interaction breadcrumb from the student's own browser: one row
    per (user, at, kind, label) — the guardian's Activity timeline ("what
    did they click, what were they looking at"). Fed in small batches by
    the client's activity tracker while the account has monitoring on;
    labels are element text/aria only (no field values, no keys, no page
    HTML). at is naive UTC like sessions.start; rows age out at 30 days.
    """
    __tablename__ = "activity_events"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=True, index=True)
    at = Column(DateTime, nullable=False, index=True)
    # "click" | "view" (small client-defined set; free-form but capped).
    kind = Column(String, nullable=False)
    label = Column(String, nullable=False)

    user = relationship("User", foreign_keys=[user_id])


class AccountRequest(Base):
    """Closed-contact "request an account" loop: a visitor who cannot (or
    should not) self-sign-up submits name/email/role, a CHOSEN password,
    and a message. The admin's bell rings instantly; APPROVE mints the
    account with the exact password they chose; the requester polls status
    at the login screen and then signs in. Password is stored hashed only
    — approval reuses the hash, so the plaintext never exists server-side.
    """
    __tablename__ = "account_requests"

    id = Column(Integer, primary_key=True, index=True)
    full_name = Column(String, nullable=False)
    email = Column(String, nullable=False, index=True)
    # "parent" | "student" — parent is the blueprint's primary path.
    role = Column(String, nullable=False, default="parent")
    password_hash = Column(String, nullable=False)
    message = Column(Text, nullable=False, default="")
    # "pending" | "approved" | "denied"
    status = Column(String, nullable=False, default="pending", index=True)
    created_at = Column(DateTime, nullable=False, default=now_utc)
    decided_at = Column(DateTime, nullable=True)
    decided_by = Column(String, nullable=True)


class BlockSighting(Base):
    """Smart-intervention stream 1: how many times the SAME off-task app/site
    popped back into the foreground during ONE study session — the new
    "intervention counter". One row per (session, key). count increments when
    the target reappears after a gap (continuous presence = one sighting).
    Presence/app name only, never page content or keystrokes.
    """
    __tablename__ = "block_sightings"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    # Normalized target: site base ("youtube.com") or app basename ("roblox").
    key = Column(String, nullable=False)
    # "site" | "app"
    kind = Column(String, nullable=False, default="app")
    # AI label: "game" | "social_media" | "video" | "school_work" | "neutral"
    label = Column(String, nullable=False, default="neutral")
    confidence = Column(Float, nullable=False, default=0.0)
    count = Column(Integer, nullable=False, default=1)
    seconds = Column(Float, nullable=False, default=0.0)
    first_seen = Column(DateTime, nullable=False)
    last_seen = Column(DateTime, nullable=False)
    last_title = Column(String, nullable=True)

    __table_args__ = (
        UniqueConstraint("session_id", "key", name="uq_block_sighting_session_key"),
    )

    user = relationship("User", foreign_keys=[user_id])


class BlockTicket(Base):
    """Proposal ticket from the smart-intervention blueprint: created when a
    distraction is sighted 2+ times in a live session (or auto-approved for
    obvious high-confidence cases when the admin turns AUTO on). Admin gate:
    Block / Allow once / Deny / Defer. evidence JSON carries the whole case
    (sightings, minutes, label, confidence, task, quiz result, distraction
    minutes, paralysis) so the hub shows WHY, and every decision is logged.
    """
    __tablename__ = "block_tickets"

    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("sessions.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, index=True)
    key = Column(String, nullable=False)
    kind = Column(String, nullable=False, default="app")  # "site" | "app"
    app = Column(String, nullable=False, default="")
    site = Column(String, nullable=True)
    title = Column(String, nullable=True)
    label = Column(String, nullable=False, default="neutral")
    confidence = Column(Float, nullable=False, default=0.0)
    sighting_count = Column(Integer, nullable=False, default=0)
    seconds = Column(Float, nullable=False, default=0.0)
    task = Column(String, nullable=True)
    # "proposed" | "suggested" (strong evidence) | "blocked" | "allowed_once"
    # | "denied" | "deferred"
    status = Column(String, nullable=False, default="proposed", index=True)
    # "normal" | "strong" — strong = quiz fail + high distraction + 3+ sightings
    strength = Column(String, nullable=False, default="normal")
    evidence = Column(Text, nullable=True)  # JSON
    auto_blocked = Column(Boolean, nullable=False, default=False)
    created_at = Column(DateTime, nullable=False, default=now_utc, index=True)
    decided_at = Column(DateTime, nullable=True)
    decided_by = Column(String, nullable=True)

    user = relationship("User", foreign_keys=[user_id])


class AppSetting(Base):
    """Tiny key/value store for global feature toggles — the blueprint's
    optional AUTO branch ("auto-block high-confidence cases only if the
    admin turns that setting on"). Values are JSON text.
    """
    __tablename__ = "app_settings"

    key = Column(String, primary_key=True)
    value = Column(Text, nullable=True)
    updated_at = Column(DateTime, nullable=False, default=now_utc, onupdate=now_utc)
