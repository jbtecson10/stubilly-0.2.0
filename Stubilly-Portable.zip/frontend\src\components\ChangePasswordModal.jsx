import { useState } from "react";
import { api } from "../api/client";

// Lets a signed-in student change their own account password ("rechange my
// password"): proves the current one, then sets a new one via the backend.
export default function ChangePasswordModal({ onClose }) {
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [done, setDone] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!current || !next || busy) return;
    setError(null);
    if (next.length < 4) {
      setError("New password must be at least 4 characters");
      return;
    }
    if (next !== confirm) {
      setError("New passwords don't match");
      return;
    }
    setBusy(true);
    try {
      await api.changePassword(current, next);
      setDone(true);
    } catch (err) {
      setError(err.message || "Couldn't change your password.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="admin-gate-overlay" onClick={onClose}>
      <form
        className="admin-gate-card"
        onSubmit={handleSubmit}
        onClick={(e) => e.stopPropagation()}
      >
        <h2 className="admin-gate-title">Change password</h2>
        <p className="admin-gate-hint">
          {done
            ? "Your password has been updated."
            : "Enter your current password, then the new one."}
        </p>
        {!done && (
          <>
            <label className="admin-gate-label">
              <span>Current password</span>
              <input
                className="admin-gate-input"
                type="password"
                value={current}
                onChange={(e) => setCurrent(e.target.value)}
                autoComplete="current-password"
                autoFocus
              />
            </label>
            <label className="admin-gate-label">
              <span>New password</span>
              <input
                className="admin-gate-input"
                type="password"
                value={next}
                onChange={(e) => setNext(e.target.value)}
                placeholder="min 4 characters"
                autoComplete="new-password"
              />
            </label>
            <label className="admin-gate-label">
              <span>Confirm new password</span>
              <input
                className="admin-gate-input"
                type="password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                autoComplete="new-password"
              />
            </label>
          </>
        )}
        {error && <p className="login-error">{error}</p>}
        <div className="admin-gate-actions">
          {done ? (
            <button type="button" className="btn-primary" onClick={onClose}>
              Done
            </button>
          ) : (
            <>
              <button
                type="submit"
                className="btn-primary"
                disabled={!current || !next || !confirm || busy}
              >
                {busy ? "Updating…" : "Change password"}
              </button>
              <button type="button" className="btn-text" onClick={onClose}>
                Cancel
              </button>
            </>
          )}
        </div>
      </form>
    </div>
  );
}