# api/ — talking to the backend

`client.js` — the single place the frontend talks to the FastAPI backend.

- **Server resolution** (`resolveBaseUrls`): uses the remote URL passed by
  Electron (central-server mode), probes it once (1.5s), and falls back to
  `localhost:8420` if unreachable — zero config, never dead-ends.
- **`request()`** — one low-level helper (json, auth header, error throwing);
  every REST call is a method on the exported `api` object.
- **`wsChat(sessionId)` / `wsFocus(sessionId)`** — WebSocket URL builders.

Start reading: **`client.js`** (it's short — about 200 lines).