import { useCallback, useEffect, useRef, useState } from "react";
import { api, getWsUrl, recheckBaseUrls, isUsingLocalBackend, getToken } from "../api/client";

/**
 * Owns the WebSocket connection to /ws/{sessionId}/chat.
 *
 * - messages: full transcript, including the in-progress companion reply
 *   (its content grows token-by-token as chunks stream in — this is what
 *   makes the chat feel instant instead of "typing... then a wall of text").
 * - notes: auto-captured notes, newest first, populated as the companion
 *   quietly decides something in the conversation was worth remembering.
 * - tasks: the "Today's steps" checklist. Starts from `initialTasks`
 *   (the plan baked into the session) and is REPLACED live whenever the
 *   backend pushes a {"type":"tasks"} event — the checklist self-adjusts
 *   in real time as the chat reveals the plan should change.
 * - sendMessage(text): send a user turn. Guaranteed to never drop a message:
 *   the bubble appears immediately, and if the socket isn't open the message
 *   is queued and resent as soon as the connection comes back.
 * - companionTyping: true while a reply is actively streaming in.
 *
 * Loads chat + note history once on mount so reopening a session doesn't
 * start from a blank slate.
 */
export function useCompanionChat(sessionId, initialTasks) {
  const [messages, setMessages] = useState([]);
  const [notes, setNotes] = useState([]);
  const [tasks, setTasks] = useState(initialTasks || []);
  const [connected, setConnected] = useState(false);
  const [companionTyping, setCompanionTyping] = useState(false);
  // Live avatar emotion from the backend ("happy" | "excited" |
  // "concerned" | "thinking" | …). Auto-clears a few seconds after the
  // last frame so the face settles back to the ambient state.
  const [emotion, setEmotion] = useState(null);
  const emotionTimerRef = useRef(null);

  const wsRef = useRef(null);
  const streamingIdRef = useRef(null);
  const pendingRef = useRef([]);
  const replyAttemptRef = useRef(0);
  const replyTimeoutRef = useRef(null);
  const initialTasksRef = useRef(initialTasks);

  // Keep the ref in sync with the latest session plan. Runs before the
  // history-load effect below (declaration order), so when `sessionId`
  // changes the reset reads the freshest `initialTasks`.
  useEffect(() => {
    initialTasksRef.current = initialTasks;
  });

  const clearReplyTimeout = () => {
    if (replyTimeoutRef.current) {
      clearTimeout(replyTimeoutRef.current);
      replyTimeoutRef.current = null;
    }
  };

  // Load any existing history (e.g. session was reloaded mid-way).
  useEffect(() => {
    if (!sessionId) return;
    let cancelled = false;
    setTasks(initialTasksRef.current || []);

    Promise.all([api.getChatHistory(sessionId), api.getSessionNotes(sessionId)])
      .then(([history, existingNotes]) => {
        if (cancelled) return;
        setMessages(
          history.map((m) => ({
            id: `db-${m.id}`,
            role: m.role,
            content: m.content,
            at: m.timestamp ? Date.parse(m.timestamp) : null,
          }))
        );
        setNotes([...existingNotes].reverse());
      })
      .catch(() => {
        // First-ever session for this id, or backend briefly unreachable —
        // an empty chat/notes list is a fine starting state either way.
      });

    return () => {
      cancelled = true;
    };
  }, [sessionId]);

  useEffect(() => {
    if (!sessionId) return;

    // `active` is scoped to THIS effect run, not shared across remounts like
    // a ref would be. That matters because React 18 StrictMode intentionally
    // mounts → cleans up → remounts every effect once in dev, which opens a
    // socket, closes it, and opens a second one almost immediately. Without
    // this guard, the first socket's onclose handler doesn't know it was
    // closed on purpose and schedules its own reconnect — so you end up with
    // an extra orphaned socket in the mix, and wsRef can point at a
    // different connection than the one actually wired to the live one the
    // backend replies on. `active` lets each effect run cleanly disown its
    // own socket on cleanup, so exactly one real connection ever exists.
    let active = true;
    let reconnectTimer = null;
    let attempt = 0;
    let ws = null;

    const flushPending = () => {
      const queued = pendingRef.current;
      pendingRef.current = [];
      for (const item of queued) {
        try {
          wsRef.current?.send(JSON.stringify(item));
        } catch {
          pendingRef.current.unshift(item); // put it back; will retry next reconnect
        }
      }
    };

    async function connect() {
      if (!active) return;

      const userToken = getToken();
      const qs = userToken ? `?token=${encodeURIComponent(userToken)}` : "";
      const url = await getWsUrl(`/ws/${sessionId}/chat${qs}`);
      if (!active) return;
      ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        if (active) {
          setConnected(true);
          attempt = 0;
          flushPending();
        }
      };

      ws.onmessage = (evt) => {
        if (!active) return;
        let msg;
        try {
          msg = JSON.parse(evt.data);
        } catch {
          return; // ignore malformed frames
        }

        if (msg.type === "emotion") {
          setEmotion(msg.content || null);
          if (emotionTimerRef.current) clearTimeout(emotionTimerRef.current);
          emotionTimerRef.current = setTimeout(() => setEmotion(null), 6000);
        } else if (msg.type === "token") {
          clearReplyTimeout();
          setCompanionTyping(true);
          // `streamingIdRef.current` must be assigned HERE, in the event
          // handler, not inside the setState updater below. React StrictMode
          // double-invokes updater functions in dev and uses the second
          // result; a side effect inside the updater makes the first call
          // create the bubble and the second call (which maps over the same
          // original `prev`, still without the bubble) discard it — the
          // companion's reply would stream to the socket and never appear.
          if (!streamingIdRef.current) {
            streamingIdRef.current = `stream-${Date.now()}`;
            setMessages((prev) => [
              ...prev,
              {
                id: streamingIdRef.current,
                role: "companion",
                content: msg.content,
                streaming: true,
                at: Date.now(),
              },
            ]);
          } else {
            setMessages((prev) =>
              prev.map((m) =>
                m.id === streamingIdRef.current ? { ...m, content: m.content + msg.content } : m
              )
            );
          }
        } else if (msg.type === "message_done") {
          clearReplyTimeout();
          // Mark the bubble complete BEFORE clearing the ref: consumers
          // (TTS above all) must be able to tell a finished reply from a
          // growing one, or they read a single streamed token as the whole
          // message and speak one word.
          const doneId = streamingIdRef.current;
          streamingIdRef.current = null;
          if (doneId) {
            setMessages((prev) =>
              prev.map((m) => (m.id === doneId ? { ...m, streaming: false } : m))
            );
          }
          setCompanionTyping(false);
        } else if (msg.type === "note") {
          setNotes((prev) => [{ id: msg.id, content: msg.content }, ...prev]);
        } else if (msg.type === "tasks") {
          // Live checklist adjustment — the session's plan was rewritten by
          // the chat refiner; replace the panel's list wholesale.
          setTasks(Array.isArray(msg.tasks) ? msg.tasks : []);
        }
      };

      ws.onclose = () => {
        if (!active) return; // cleanup closed this on purpose — don't reconnect
        clearReplyTimeout();
        setCompanionTyping(false);
        setConnected(false);
        attempt++;
        const delay = Math.min(800 * 2 ** attempt, 10000);
        reconnectTimer = setTimeout(() => {
          // Occasionally re-probe so the chat follows the app onto a central
          // server that just came online (without re-pinging the network
          // stack on every single retry).
          if (attempt % 5 === 0) recheckBaseUrls();
          connect();
        }, delay);
      };

      // Bind the socket in the handler — a stale closure would close the
      // newly-assigned socket when an old one errors after reconnect.
      ws.onerror = () => {
        if (wsRef.current === ws) ws.close();
      };
    }

    connect();

    return () => {
      active = false;
      clearReplyTimeout();
      if (reconnectTimer) clearTimeout(reconnectTimer);
      ws?.close();
      if (wsRef.current === ws) wsRef.current = null;
    };
  }, [sessionId]);

  const sendMessage = useCallback((text, image = null, imageName = null) => {
    const trimmed = text.trim();
    if (!trimmed && !image) return;

    // Show the message immediately, regardless of socket state, so it is
    // never silently dropped — if we can't send it right now it's queued and
    // resent on reconnect.
    setCompanionTyping(true);
    const sentAt = Date.now();
    setMessages((prev) => [...prev, {
      id: `local-${sentAt}`,
      role: "user",
      content: trimmed ? `${trimmed}${image ? "\n[photo attached]" : ""}` : "[photo attached]",
      at: sentAt,
      // Keep the data-URL on the local message so the bubble can render a
      // thumbnail (the backend strips it from its echo; this is display-only).
      image: image || null,
    }]);

    // Running on the local fallback backend? Make sure the (embedded or
    // installed) Ollama is serving the companion model — auto-pulling it in
    // the background if this machine has never downloaded it — so local AI
    // works with zero manual install steps.
    if (isUsingLocalBackend()) window.stubilly?.ollamaEnsureModel?.();

    const payload = {
      content: trimmed,
      ...(image ? { image } : {}),
      // Original filename — the identification path in the backend uses it
      // as the primary web-search keyword (the canvas data-URL drops it).
      ...(image && imageName ? { image_name: imageName } : {}),
    };
    const ws = wsRef.current;
    if (ws?.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify(payload));
      } catch {
        pendingRef.current.push(payload);
      }
    } else {
      pendingRef.current.push(payload);
    }

    // Watchdog: if no token arrives within 40s (e.g. the socket is wedged in
    // an "open" state but the backend stopped answering), force a reconnect
    // instead of leaving the "typing..." dots up forever.
    const attempt = ++replyAttemptRef.current;
    clearReplyTimeout();
    replyTimeoutRef.current = setTimeout(() => {
      if (replyAttemptRef.current === attempt && pendingRef.current.length === 0) {
        setCompanionTyping(false);
        setConnected(false);
        try {
          wsRef.current?.close();
        } catch {
          /* already closed — reconnect timer will handle it */
        }
      }
    }, 40000);
  }, []);

  return { messages, notes, tasks, connected, companionTyping, emotion, sendMessage };
}