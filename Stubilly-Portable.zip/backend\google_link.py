"""Google Classroom / Drive link for the study companion.

One-click OAuth (auth-code flow + CSRF state) stores a refresh token per
user under %APPDATA%\\Stubilly\\google_tokens.json - never in the repo,
never in logs. Chat turns pull a small cached slice (active courses,
upcoming coursework, recent Drive files) so the companion can ground
advice in the student's actual schoolwork. Every failure path returns
None and chat proceeds without Google; the companion never depends on
Google being up.
"""
import json
import logging
import os
import secrets
import time
from pathlib import Path
from urllib.parse import urlencode

import httpx

logger = logging.getLogger("stubilly.google")

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo"
COURSES_URL = "https://classroom.googleapis.com/v1/courses"
COURSEWORK_URL = "https://classroom.googleapis.com/v1/courses/{course_id}/courseWork/me"
DRIVE_FILES_URL = "https://www.googleapis.com/drive/v3/files"

# Read-only scope set - the companion observes schoolwork, never writes.
SCOPES = (
    "openid email "
    "https://www.googleapis.com/auth/classroom.courses.readonly "
    "https://www.googleapis.com/auth/classroom.coursework.me.readonly "
    "https://www.googleapis.com/auth/drive.readonly "
    "https://www.googleapis.com/auth/documents.readonly"
)

# Fallback local redirect. The live redirect is derived per-request from the
# origin the student is actually browsing (loopback OR the Tailscale tunnel),
# because Google requires the auth-request redirect_uri to EXACTLY match a
# registered URI AND to match the token-exchange redirect_uri. Hardcoding
# 127.0.0.1 while the browser sits on https://…ts.net caused redirect_uri_mismatch.
# Override with GOOGLE_REDIRECT_URI to pin one URI regardless of origin.
REDIRECT_URI = os.getenv(
    "GOOGLE_REDIRECT_URI", "http://127.0.0.1:8422/api/google/callback"
).strip()

_STATE_TTL_SEC = 600
_CACHE_TTL_SEC = 300

# state -> (user_id, redirect_uri, expires_at). In-memory only: a restart
# just means the student clicks Connect again. The redirect is remembered
# per-state so the token exchange reuses the exact string Google approved.
_states: dict[str, tuple[int, str, int]] = {}
# user_id -> (fetched_at, context-dict)
_cache: dict[int, tuple[float, dict]] = {}


def configured() -> bool:
    return bool(_client_id() and _client_secret())


def _client_id() -> str:
    return os.getenv("GOOGLE_CLIENT_ID", "").strip()


def _client_secret() -> str:
    return os.getenv("GOOGLE_CLIENT_SECRET", "").strip()


def _token_path() -> Path:
    # A second local deployment gets its own token file (user ids from two
    # different databases can collide and clobber each other's refresh token).
    override = os.getenv("STUBILLY_GOOGLE_TOKENS_PATH", "").strip()
    if override:
        p = Path(override)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p
    base = os.getenv("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    d = Path(base) / "Stubilly"
    d.mkdir(parents=True, exist_ok=True)
    return d / "google_tokens.json"


def _load_tokens() -> dict:
    try:
        return json.loads(_token_path().read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_tokens(data: dict) -> None:
    p = _token_path()
    p.write_text(json.dumps(data), encoding="utf-8")
    try:
        os.chmod(p, 0o600)
    except Exception:
        pass


def redirect_uri_for(origin: str | None) -> str:
    """Resolve the OAuth redirect URI for a given browsing origin.

    Priority:
      1. GOOGLE_REDIRECT_URI env override (pins one URI regardless of origin)
      2. `{origin}/api/google/callback` when a usable http(s) origin is given
         (loopback or tunnel - matches whatever host the student is on)
      3. module REDIRECT_URI fallback
    """
    env = os.getenv("GOOGLE_REDIRECT_URI", "").strip()
    if env:
        return env
    o = (origin or "").strip().rstrip("/")
    if o.startswith("http://") or o.startswith("https://"):
        return o + "/api/google/callback"
    return REDIRECT_URI


def new_state(user_id: int, redirect_uri: str = "") -> str:
    state = secrets.token_urlsafe(24)
    now = int(time.time())
    _states[state] = (int(user_id), redirect_uri or REDIRECT_URI, now + _STATE_TTL_SEC)
    for k in [k for k, (_, _, exp) in _states.items() if exp < now]:
        _states.pop(k, None)
    return state


def pop_state(state: str) -> tuple[int, str] | None:
    hit = _states.pop(state, None)
    if not hit:
        return None
    user_id, redirect_uri, exp = hit
    if exp < time.time():
        return None
    return int(user_id), redirect_uri


def auth_url(state: str, redirect_uri: str = "") -> str:
    return AUTH_URL + "?" + urlencode(
        {
            "client_id": _client_id(),
            "redirect_uri": redirect_uri or REDIRECT_URI,
            "response_type": "code",
            "scope": SCOPES,
            "access_type": "offline",
            "prompt": "consent",
            "state": state,
        }
    )


async def _token_request(data: dict) -> dict | None:
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            r = await client.post(TOKEN_URL, data=data)
            if r.status_code >= 400:
                logger.warning("google token request failed: HTTP %s", r.status_code)
                return None
            return r.json()
    except Exception:
        logger.warning("google token request unreachable", exc_info=True)
        return None


async def exchange_code(code: str, redirect_uri: str = "") -> dict | None:
    return await _token_request(
        {
            "code": code,
            "client_id": _client_id(),
            "client_secret": _client_secret(),
            "redirect_uri": redirect_uri or REDIRECT_URI,
            "grant_type": "authorization_code",
        }
    )


async def _refresh(user_id: int, refresh_token: str) -> dict | None:
    tok = await _token_request(
        {
            "client_id": _client_id(),
            "client_secret": _client_secret(),
            "refresh_token": refresh_token,
            "grant_type": "refresh_token",
        }
    )
    if not tok or not tok.get("access_token"):
        return None
    data = _load_tokens()
    entry = data.get(str(user_id)) or {}
    entry["access_token"] = tok["access_token"]
    entry["refresh_token"] = tok.get("refresh_token") or refresh_token
    entry["expires_at"] = time.time() + int(tok.get("expires_in") or 3500)
    data[str(user_id)] = entry
    _save_tokens(data)
    return entry


async def _valid_access(user_id: int) -> str | None:
    entry = _load_tokens().get(str(user_id))
    if not entry:
        return None
    if float(entry.get("expires_at") or 0) - 60 < time.time():
        rt = entry.get("refresh_token")
        if not rt:
            return None
        entry = await _refresh(user_id, rt)
        if not entry:
            return None
    return entry.get("access_token")


async def fetch_email(access_token: str) -> str:
    try:
        async with httpx.AsyncClient(timeout=6.0) as client:
            r = await client.get(
                USERINFO_URL, headers={"Authorization": f"Bearer {access_token}"}
            )
            if r.status_code < 400:
                return (r.json().get("email") or "").strip()
    except Exception:
        pass
    return ""


def save_tokens(user_id: int, tok: dict, email: str = "") -> None:
    data = _load_tokens()
    data[str(int(user_id))] = {
        "access_token": tok.get("access_token"),
        "refresh_token": tok.get("refresh_token"),
        "expires_at": time.time() + int(tok.get("expires_in") or 3500),
        "email": email,
    }
    _save_tokens(data)
    _cache.pop(int(user_id), None)


def connected_email(user_id: int | None) -> str | None:
    """Linked-account email, or None when this user has no link."""
    if user_id is None:
        return None
    entry = _load_tokens().get(str(int(user_id)))
    if not entry:
        return None
    return entry.get("email") or ""


def forget(user_id: int) -> None:
    data = _load_tokens()
    data.pop(str(int(user_id)), None)
    _save_tokens(data)
    _cache.pop(int(user_id), None)


async def google_context(user_id: int | None) -> dict | None:
    """Cached slice for the chat prompt: courses, upcoming work, Drive files."""
    if user_id is None or not configured():
        return None
    uid = int(user_id)
    now = time.time()
    hit = _cache.get(uid)
    if hit and now - hit[0] < _CACHE_TTL_SEC:
        return hit[1]

    access = await _valid_access(uid)
    if not access:
        return None

    headers = {"Authorization": f"Bearer {access}"}
    out: dict = {}
    try:
        async with httpx.AsyncClient(timeout=6.0, headers=headers) as client:
            r = await client.get(
                COURSES_URL, params={"pageSize": 4, "courseStates": "ACTIVE"}
            )
            courses = (r.json().get("courses") if r.status_code < 400 else None) or []
            out["courses"] = [
                {
                    "name": c.get("name"),
                    "section": c.get("section") or "",
                    "id": c.get("id"),
                }
                for c in courses[:4]
            ]

            upcoming = []
            for c in out["courses"]:
                cid = c.get("id")
                if not cid:
                    continue
                cr = await client.get(
                    COURSEWORK_URL.format(course_id=cid), params={"pageSize": 3}
                )
                if cr.status_code >= 400:
                    continue
                for w in (cr.json().get("courseWork") or [])[:3]:
                    due = ""
                    if w.get("dueDate"):
                        d = w["dueDate"]
                        due = f"{d.get('year', '')}-{d.get('month', ''):02}-{d.get('day', ''):02}" if d.get("month") else ""
                    elif w.get("dueTime"):
                        due = str(w["dueTime"])
                    upcoming.append(
                        {
                            "title": w.get("title"),
                            "course": c.get("name"),
                            "due": due,
                        }
                    )
                if len(upcoming) >= 6:
                    break
            out["upcoming"] = upcoming[:6]

            dr = await client.get(
                DRIVE_FILES_URL,
                params={
                    "pageSize": 5,
                    "fields": "files(name,mimeType)",
                    "orderBy": "modifiedTime desc",
                    "q": "trashed = false",
                },
            )
            files = (dr.json().get("files") if dr.status_code < 400 else None) or []
            out["drive"] = [
                {"name": f.get("name"), "type": (f.get("mimeType") or "").split(".")[-1]}
                for f in files[:5]
            ]
    except Exception:
        logger.info("google context fetch failed", exc_info=True)
        return None

    if not (out.get("courses") or out.get("upcoming") or out.get("drive")):
        return None
    _cache[uid] = (now, out)
    return out
