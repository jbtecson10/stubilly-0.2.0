// Thin wrapper around the FastAPI backend. Connection resolution, in order:
//   remote candidates (probing /health in order) → localhost:8420 fallback.
//
// Remote candidates come from:
//   1. window.stubilly.backendUrls / backendUrl — the (list of) URLs main.cjs
//      passed in (remote central-server mode, set via STUBILLY_API_URL,
//      %APPDATA%/Stubilly/config.json or the bundled default-config.json).
//   2. VITE_STUBILLY_BACKEND_URL.
//
// The engine probes each candidate with a short /health GET and picks the
// first healthy one; if none respond it falls back to the app's own local
// backend, so an app pointed at a central server still works standalone.
// It does NOT decide once and forget: a background recheck (and every WS
// reconnect) re-probes, so the moment a server becomes reachable — e.g. the
// hosting PC finishes booting, or a friend's network comes up — the app
// auto-switches to it and the sockets reconnect there. No restart needed.
const LOCAL_HTTP = "http://localhost:8423";

// Web-mode detection: when a browser loads Stubilly straight from the backend
// (no Electron preload bridge injected), the app is hosted by the server
// itself — always target the same origin it was served from.
const IS_WEB = typeof window !== "undefined" && !window.stubilly;
const HEALTH_TIMEOUT_MS = 1500;
const RECHECK_INTERVAL_MS = 30000;

function readConfiguredUrls() {
  const winUrls =
    typeof window !== "undefined"
      ? (Array.isArray(window.stubilly?.backendUrls) && window.stubilly.backendUrls.length
          ? window.stubilly.backendUrls
          : window.stubilly?.backendUrl
            ? [window.stubilly.backendUrl]
            : window.__STUBILLY_BACKEND_URL
              ? [window.__STUBILLY_BACKEND_URL]
              : null)
      : null;
  // Web base may be mounted under a path: the funnel serves this prototype at
  // /proto2, and the proxy STRIPS that prefix before the request reaches this
  // server. The bare origin alone would drop the prefix and land on the other
  // prototype's backend at the site root, so the first path segment re-attaches
  // it. Served at "/" there is no segment and the base stays a bare origin.
  const webUrl =
    IS_WEB && typeof window !== "undefined"
      ? (() => {
          const { origin, pathname } = window.location;
          const seg = (pathname || "").split("/").filter(Boolean)[0];
          return origin + (seg && !seg.includes(".") ? `/${seg}` : "");
        })()
      : null;
  const envUrl = import.meta.env.VITE_STUBILLY_BACKEND_URL;
  const raw = (webUrl ? [webUrl] : []).concat(winUrls || [], envUrl ? [envUrl] : []);
  const seen = new Set();
  const urls = [];
  for (const u of raw) {
    const clean = (u || "").trim().replace(/\/+$/, "");
    if (clean && !seen.has(clean)) {
      seen.add(clean);
      urls.push(clean);
    }
  }
  return urls;
}

const CONFIG_HTTP = readConfiguredUrls();
const CONFIG_WS = CONFIG_HTTP.map((u) => u.replace(/^http/, "ws"));

let activeHttp = CONFIG_HTTP.length ? null : LOCAL_HTTP;
let activeWs = null;
let resolvePromise = null;
let lastProbeAt = 0;

async function probeCandidate(httpUrl) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), HEALTH_TIMEOUT_MS);
  try {
    const res = await fetch(`${httpUrl}/health`, { signal: ctrl.signal });
    clearTimeout(timer);
    return res.ok;
  } catch {
    clearTimeout(timer);
    return false;
  }
}

// Scans configured remotes (in order) then the local backend; the first one
// that answers /health becomes the active base.
async function probeAndSelect() {
  const candidates = [];
  for (let i = 0; i < CONFIG_HTTP.length; i++) {
    candidates.push([CONFIG_HTTP[i], CONFIG_WS[i]]);
  }
  // The desktop shell may also fall back to its own embedded local backend.
  // A browser-visited web base IS that backend: it must only ever talk to
  // the origin that served the page. Pointing a visitor's browser at
  // http://localhost:8420 would target THEIR machine, not the server — so
  // that fallback is desktop-only.
  if (!IS_WEB) {
    candidates.push([LOCAL_HTTP, LOCAL_HTTP.replace(/^http/, "ws")]);
  }

  for (const [httpUrl, wsUrl] of candidates) {
    const ok = await probeCandidate(httpUrl);
    if (ok) {
      activeHttp = httpUrl;
      activeWs = wsUrl;
      lastProbeAt = Date.now();
      return;
    }
  }
  // Nothing answered at all — leave whatever we had; the next recheck or WS
  // reconnect will try again.
}

async function resolveBaseUrls() {
  if (activeHttp) return { http: activeHttp, ws: activeWs || activeHttp.replace(/^http/, "ws") };
  if (!resolvePromise) {
    resolvePromise = (async () => {
      await probeAndSelect();
    })().finally(() => {
      resolvePromise = null;
    });
  }
  await resolvePromise;
  // Web base: the server that served the page is the only backend worth
  // talking to, even if it's momentarily unreachable. Desktop shell: local.
  const fallbackHttp = IS_WEB ? CONFIG_HTTP[0] || LOCAL_HTTP : LOCAL_HTTP;
  return {
    http: activeHttp || fallbackHttp,
    ws: activeWs || activeHttp?.replace(/^http/, "ws") || fallbackHttp.replace(/^http/, "ws"),
  };
}

// Re-probe now (used on WS drops so a server that just came online is picked
// up within seconds instead of waiting for the periodic tick). Fire-and-forget.
export function recheckBaseUrls() {
  if (resolvePromise) return;
  if (Date.now() - lastProbeAt < 2000) return; // don't hammer a healthy setup
  probeAndSelect();
}

// Background self-healing: periodically re-run the probe so the app follows a
// central server that was offline at launch, and drops it when it disappears.
if (typeof window !== "undefined") {
  setInterval(() => {
    if (resolvePromise) return;
    probeAndSelect();
  }, RECHECK_INTERVAL_MS);
}

// Start probing on load so the base is settled by the time any session UI
// needs to open a WebSocket.
resolveBaseUrls();

export function hasConfiguredRemote() {
  return CONFIG_HTTP.length > 0;
}

export function getConfiguredRemoteHost() {
  try {
    return CONFIG_HTTP.length ? new URL(CONFIG_HTTP[0]).host : null;
  } catch {
    return CONFIG_HTTP[0] || null;
  }
}

export function isUsingLocalBackend() {
  // In web mode the server that serves the page IS the backend — there is no
  // "stuck on localhost fallback" state, so the offline-server banner that
  // applies to the desktop shell must never appear for browser visitors.
  return !IS_WEB && activeHttp === LOCAL_HTTP;
}

export const USER_TOKEN_KEY = "stubilly.token";

// True once THIS document has logged in (or received a social token). Fresh
// tab load must NEVER auto-login with a session the document didn't create.
let sessionEstablished = false;
function markSessionEstablished() {
  sessionEstablished = true;
}

// Use sessionStorage instead of localStorage to ensure each browser tab
// has its own independent session. This prevents token collisions when
// multiple users log in from different tabs on the same browser.
// The clone guard below also blocks the one remaining leak: a new tab
// opened from a logged-in tab INHERITS that tab's sessionStorage. A fresh
// "navigate" therefore only keeps the token when this very document logged
// in; every other fresh navigation starts at the sign-in page.
export function getToken() {
  try {
    const t = sessionStorage.getItem(USER_TOKEN_KEY);
    if (!t) return null;
    let navType = "navigate";
    try {
      const nav = performance.getEntriesByType("navigation")[0];
      if (nav) navType = nav.type;
    } catch {
      /* keep default */
    }
    if (navType === "reload" || navType === "back_forward" || sessionEstablished) return t;
    // The HTTP interceptor redirects a logged-in tab to /blocked?site=... mid
    // study-session (BlockedNotifier then replaceState's back to "/"). That is
    // a fresh "navigate" document, but it is THIS tab's own live session — a
    // brand-new tab can't carry a sessionStorage token, so an arrival here with
    // a token is always a real student. Without this exception the guard below
    // would log the student out the moment the blocker pings them.
    try {
      if (window.location.pathname.replace(/\/+$/, "") === "/blocked") {
        sessionEstablished = true;
        return t;
      }
    } catch {
      /* keep the guard default */
    }
    try {
      sessionStorage.removeItem(USER_TOKEN_KEY);
    } catch {
      /* ignore */
    }
    return null;
  } catch {
    return localStorage.getItem(USER_TOKEN_KEY);
  }
}

export function setToken(token) {
  if (!token) {
    removeToken();
    return;
  }
  markSessionEstablished();
  try {
    sessionStorage.setItem(USER_TOKEN_KEY, token);
  } catch {
    localStorage.setItem(USER_TOKEN_KEY, token);
  }
}

export function removeToken() {
  sessionEstablished = false;
  try {
    sessionStorage.removeItem(USER_TOKEN_KEY);
  } catch {}
  try {
    localStorage.removeItem(USER_TOKEN_KEY);
  } catch {}
}

// The logged-out request core. Reads the user token (or an explicit
// override via options.token, used by the admin hub for admin tokens).
async function request(path, options = {}) {
  const { token, silent401, ...rest } = options;
  const isUserToken = token === undefined;
  const activeToken = isUserToken ? getToken() : token;
  // FormData (a picture or voice-note upload) must NOT be given a JSON
  // Content-Type: the browser has to add its own multipart boundary, and a
  // wrong type here makes the server reject the upload instead of reading it.
  const isForm = typeof FormData !== "undefined" && rest.body instanceof FormData;
  const headers = isForm ? { ...rest.headers } : { "Content-Type": "application/json", ...rest.headers };
  if (activeToken) headers.Authorization = `Bearer ${activeToken}`;

  const { http } = await resolveBaseUrls();
  // cache: "no-store" — admin re-reads hit the same URL repeatedly (e.g. the
  // consent re-read right after Grant/Revoke) and Chrome would otherwise serve
  // the earlier response from the HTTP cache, showing a stale consent state.
  const res = await fetch(`${http}${path}`, { ...rest, headers, cache: "no-store" });
  if (!res.ok) {
    // The signed-in user's token was rejected (server restarted, token
    // expired). Surface it so the UI signs back in instead of sitting
    // there looking "offline / monitoring unavailable" forever.
    // `silent401` is for background housekeeping (the keepalive ping): a
    // hiccup there must never sign anybody out on its own - the next real
    // request is what reports the dead session.
    if (res.status === 401 && isUserToken && activeToken && !silent401) {
      try {
        window.dispatchEvent(new CustomEvent("stubilly:session-expired"));
      } catch {
        /* non-browser context — ignore */
      }
    }
    const text = await res.text().catch(() => "");
    const err = new Error(`${res.status} ${res.statusText}: ${text}`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

export const api = {
  health: () => request("/health"),

  // --- auth / admin hub ---
  bootstrap: () => request("/auth/bootstrap"),
  login: (serialNumber, password, device) =>
    request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ serial_number: serialNumber, password, device }),
    }),
  logout: () => request("/auth/logout", { method: "POST" }),
  me: () => request("/auth/me"),
  // Marks the first-run tutorial as finished server-side so it never shows
  // again on any browser for this account.
  tutorialSeen: () => request("/auth/tutorial-seen", { method: "POST" }),
  // Keeps an idle-but-open tab signed in. Silent on failure by design: it
  // must never be the thing that signs a student or parent out.
  keepalive: () => request("/auth/keepalive", { method: "POST", silent401: true }),
  // Self-service registration — open to anyone, no admin token. `data` may
  // carry { email, full_name, password } and optionally a serial_number.
  registerUser: (data) =>
    request("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  // --- "Request an account" loop (public) ---------------------------------
  // The blueprint's closed-contact sign-up: anyone may ASK, the admin's
  // bell rings, APPROVE mints the account with the password they chose.
  requestAccount: (data) =>
    request("/auth/request-account", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  // Unauthenticated status poll for the requester at the login screen.
  accountRequestStatus: (email) =>
    request(`/auth/account-request?email=${encodeURIComponent(email)}`),
  adminAccountRequests: (adminToken, status = "pending") =>
    request(`/admin/account-requests?status=${encodeURIComponent(status)}`, {
      token: adminToken,
    }),
  approveAccountRequest: (adminToken, id) =>
    request(`/admin/account-requests/${id}/approve`, {
      method: "POST",
      token: adminToken,
    }),
  denyAccountRequest: (adminToken, id) =>
    request(`/admin/account-requests/${id}/deny`, {
      method: "POST",
      token: adminToken,
    }),
  // --- smart intervention: proposal tickets + AUTO toggle ----------------
  adminBlockTickets: (adminToken, status = "open") =>
    request(`/admin/block-tickets?status=${encodeURIComponent(status)}`, {
      token: adminToken,
    }),
  adminDecideBlockTicket: (adminToken, id, action) =>
    request(`/admin/block-tickets/${id}/decision`, {
      method: "POST",
      body: JSON.stringify({ action }),
      token: adminToken,
    }),
  adminInterventionSettings: (adminToken) =>
    request("/admin/intervention-settings", { token: adminToken }),
  adminUpdateInterventionSettings: (adminToken, autoBlock) =>
    request("/admin/intervention-settings", {
      method: "PUT",
      body: JSON.stringify({ auto_block: autoBlock }),
      token: adminToken,
    }),
  // --- ML on-task model (Option B: accuracy dashboard + threshold dial) ---
  adminMlModel: (adminToken) =>
    request("/admin/ml-model", { token: adminToken }),
  adminSetMlThreshold: (adminToken, threshold) =>
    request("/admin/ml-model/threshold", {
      method: "PUT",
      body: JSON.stringify({ threshold }),
      token: adminToken,
    }),
  // --- timed breaks (server timer is authoritative) -----------------------
  startSessionBreak: (sessionId, minutes = 5) =>
    request(`/sessions/${sessionId}/break`, {
      method: "POST",
      body: JSON.stringify({ minutes }),
    }),
  endSessionBreak: (sessionId) =>
    request(`/sessions/${sessionId}/break/end`, { method: "POST" }),
  adminStartSessionBreak: (adminToken, sessionId, minutes = 5) =>
    request(`/admin/sessions/${sessionId}/break`, {
      method: "POST",
      body: JSON.stringify({ minutes }),
      token: adminToken,
    }),
  adminEndSessionBreak: (adminToken, sessionId) =>
    request(`/admin/sessions/${sessionId}/break/end`, {
      method: "POST",
      token: adminToken,
    }),
  adminDiagnostics: (adminToken) =>
    request("/admin/diagnostics", { token: adminToken }),
  forgotPassword: (email) =>
    request("/auth/forgot-password", {
      method: "POST",
      body: JSON.stringify({ email }),
    }),
  resetPassword: (email, code, newPassword) =>
    request("/auth/reset-password", {
      method: "POST",
      body: JSON.stringify({ email, code, new_password: newPassword }),
    }),
  changePassword: (currentPassword, newPassword) =>
    request("/auth/change-password", {
      method: "POST",
      body: JSON.stringify({ current_password: currentPassword, new_password: newPassword }),
    }),
  socialProviders: () => request("/auth/social/status"),
  socialLoginUrl: async (provider) => {
    // Whole-page OAuth redirect: keep the browser on the app's own origin so
    // the callback returns here with the session token in the URL fragment.
    const { http } = await resolveBaseUrls();
    const origin =
      typeof window !== "undefined" && window.location?.origin
        ? window.location.origin
        : http;
    return `${http}/auth/social/login/${provider}?redirect_uri=${encodeURIComponent(origin)}`;
  },
  // Revoke an admin token server-side (used by the hub's account-card Sign out).
  adminLogout: (adminToken) =>
    request("/admin/logout", { method: "POST", token: adminToken }),
  adminLogin: (username, password) =>
    request("/admin/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    }),
  adminBootstrap: (name, username, password) =>
    request("/auth/admin-bootstrap", {
      method: "POST",
      body: JSON.stringify({ name, username, password }),
    }),
  adminAdmins: (adminToken) => request("/admin/admins", { token: adminToken }),
  adminCreateAdmin: (adminToken, { name, username, password }) =>
    request("/admin/admins", {
      method: "POST",
      body: JSON.stringify({ name, username, password }),
      token: adminToken,
    }),
  // Account factory: the ONLY way guardian accounts come to exist (and the
  // hub can create students — including minors linked to a guardian).
  adminCreateUser: (adminToken, data) =>
    request("/admin/users", {
      method: "POST",
      body: JSON.stringify(data),
      token: adminToken,
    }),
  adminUpdateUser: (adminToken, userId, data) =>
    request(`/admin/users/${userId}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token: adminToken,
    }),
  // Permanent account removal — guardian children are unlinked server-side.
  adminDeleteUser: (adminToken, userId) =>
    request(`/admin/users/${userId}`, { method: "DELETE", token: adminToken }),
  // New-account notification feed (replayed on open, pushed live over /ws/admin).
  // The hub's bell groups the feed by day and offers search + kind filters, so
  // it asks for the widest window the API allows (200, its own cap) instead of
  // the bare default of 50 - otherwise older days and other people's activity
  // are invisible no matter what you search for.
  adminNotifications: (adminToken, limit = 200) =>
    request(`/admin/notifications?limit=${limit}`, { token: adminToken }),
  adminReadNotification: (adminToken, id) =>
    request(`/admin/notifications/${id}/read`, { method: "POST", token: adminToken }),
  adminReadAllNotifications: (adminToken) =>
    request("/admin/notifications/read-all", { method: "POST", token: adminToken }),
  adminDeleteNotification: (adminToken, id) =>
    request(`/admin/notifications/${id}`, { method: "DELETE", token: adminToken }),
  // Select-mode bulk actions on the bell: dismiss keeps the rows (they stay
  // deletable/account-aware) and records per-admin dismissal instead of
  // destroying rows other admins may still need; clear empties the feed for
  // the calling admin only.
  adminDismissNotifications: (adminToken, ids) =>
    request("/admin/notifications/dismiss", {
      method: "POST",
      token: adminToken,
      body: JSON.stringify({ ids }),
    }),
  adminClearNotifications: (adminToken) =>
    request("/admin/notifications/clear", { method: "POST", token: adminToken }),
  // Admin-to-admin chat room (history replayed on open, live over /ws/admin).
  // Paging: pass { before_id } for older pages (scroll-up loading / reply
  // jumps into history deeper than the newest 200) or { after_id } for a
  // catch-up page. Everything comes back oldest-first like the default call.
  adminChatMessages: (adminToken, opts = {}) => {
    const q = new URLSearchParams();
    if (opts.limit != null) q.set("limit", String(opts.limit));
    if (opts.before_id != null) q.set("before_id", String(opts.before_id));
    if (opts.after_id != null) q.set("after_id", String(opts.after_id));
    const qs = q.toString();
    return request(`/admin/chat/messages${qs ? `?${qs}` : ""}`, { token: adminToken });
  },
  adminSendChat: (adminToken, body, extra = {}) =>
    request("/admin/chat/messages", {
      method: "POST",
      // extra carries { reply_to_id, attachment_token } for a quoted reply or
      // a picture/voice note. A plain text message sends exactly as before.
      body: JSON.stringify({ body, ...extra }),
      token: adminToken,
    }),
  // --- Telegram-style message actions -------------------------------------
  adminEditChat: (adminToken, id, body) =>
    request(`/admin/chat/messages/${id}`, {
      method: "PUT",
      body: JSON.stringify({ body }),
      token: adminToken,
    }),
  adminDeleteChat: (adminToken, id) =>
    request(`/admin/chat/messages/${id}`, { method: "DELETE", token: adminToken }),
  // Pin / important-label toggle. Any admin may set these; the field is
  // broadcast to every hub as "chat_message_updated" (edited_at untouched).
  adminSetChatFlags: (adminToken, id, flags) =>
    request(`/admin/chat/messages/${id}/flags`, {
      method: "PUT",
      body: JSON.stringify(flags),
      token: adminToken,
    }),
  // Upload a picture or voice note FIRST and send the returned token with the
  // message: one endpoint for uploads keeps the existing send contract (and
  // every existing probe) untouched.
  adminUploadChatMedia: (adminToken, file, seconds) => {
    const form = new FormData();
    form.append("file", file);
    if (seconds != null) form.append("seconds", String(seconds));
    return request("/admin/chat/media", { method: "POST", body: form, token: adminToken });
  },
  // Attachments are admin-only, so the browser fetches the bytes with the
  // admin token and shows them from an object URL (an <img src> cannot send
  // an Authorization header).
  adminChatMediaBlob: async (adminToken, token) => {
    const { http } = await resolveBaseUrls();
    const res = await fetch(`${http}/admin/chat/media/${encodeURIComponent(token)}`, {
      headers: { authorization: `Bearer ${adminToken}` },
    });
    if (!res.ok) throw new Error(`media ${res.status}`);
    return res.blob();
  },
  adminDeleteAdmin: (adminToken, id) =>
    request(`/admin/admins/${id}`, { method: "DELETE", token: adminToken }),
  adminChangeAdminPassword: (adminToken, password) =>
    request("/admin/admins/me/password", {
      method: "PUT",
      body: JSON.stringify({ password }),
      token: adminToken,
    }),
  adminSetUserPassword: (adminToken, userId, password) =>
    request(`/admin/users/${userId}/password`, {
      method: "PUT",
      body: JSON.stringify({ password }),
      token: adminToken,
    }),
  currentPolicy: () => request("/policy/current"),
  adminUsers: (adminToken) => request("/admin/users", { token: adminToken }),
  adminSearchUsers: (adminToken, q) =>
    request(`/admin/users/search?q=${encodeURIComponent(q)}`, { token: adminToken }),
  adminGetUser: (adminToken, userId) =>
    request(`/admin/users/${userId}`, { token: adminToken }),
  adminUpdatePolicy: (adminToken, userId, blockedSites, allowedSites) =>
    request(`/admin/users/${userId}/policy`, {
      method: "PUT",
      body: JSON.stringify({ blocked_sites: blockedSites, allowed_sites: allowedSites }),
      token: adminToken,
    }),
  adminSetConsent: (adminToken, userId, granted) =>
    request(`/admin/users/${userId}/consent`, {
      method: "PUT",
      body: JSON.stringify({ granted, scope: "webcam,window,site-blocking" }),
      token: adminToken,
    }),
  adminLoginHistory: (adminToken, userId) =>
    request(`/admin/users/${userId}/login-history`, { token: adminToken }),
  adminSessions: (adminToken) => request("/admin/sessions", { token: adminToken }),
  adminGetUserSessions: (adminToken, userId) =>
    request(`/admin/users/${userId}/sessions`, { token: adminToken }),
  adminAnalyticsOverview: (adminToken, userId, range = "week") =>
    request(
      `/analytics/overview?range=${encodeURIComponent(range)}&user_id=${userId}`,
      { token: adminToken }
    ),

  // --- sessions ---
  // `meta` carries the declared academic task (INPUT layer): { subject,
  // deadline, priority } plus the chosen companion_id. Optional — old
  // callers passing only the description keep working.
  startSession: (taskDescription, microtasksFromSessionId, meta = {}) =>
    request("/sessions/start", {
      method: "POST",
      body: JSON.stringify({
        task_description: taskDescription,
        ...(microtasksFromSessionId ? { microtasks_from_session_id: microtasksFromSessionId } : {}),
        ...(meta.subject ? { subject: meta.subject } : {}),
        ...(meta.deadline ? { deadline: meta.deadline } : {}),
        ...(meta.priority ? { priority: meta.priority } : {}),
        ...(meta.companionId ? { companion_id: meta.companionId } : {}),
      }),
    }),

  // --- companions ---
  listCompanions: () => request("/companions"),
  // The OAuth redirect must be served by THIS prototype's backend. Under the
  // funnel the app lives at /proto2 and the proxy strips that prefix, so the
  // bare origin would drop it and land the Google callback on the other
  // prototype at the site root. Send the resolved base (origin + /proto2),
  // which is exactly where request() routes every other call.
  googleStatus: async () => {
    const { http } = await resolveBaseUrls();
    const origin = encodeURIComponent(http);
    return request(`/api/google/status?origin=${origin}`);
  },
  googleConnect: async () => {
    const { http } = await resolveBaseUrls();
    const origin = encodeURIComponent(http);
    return request(`/api/google/connect?origin=${origin}`);
  },
  googleDisconnect: () => request("/api/google/disconnect", { method: "POST" }),

  // Per-account learning profile (the companion's memory of this student).
  // Empty object for a brand-new account or in legacy single-user mode.
  getLearningProfile: () => request("/companions/learning"),

  endSession: (sessionId) =>
    request(`/sessions/${sessionId}/end`, { method: "POST" }),

  listSessions: () => request("/sessions"),

  getSession: (sessionId) => request(`/sessions/${sessionId}`),

  updateSessionBlockedSites: (sessionId, sites) =>
    request(`/sessions/${sessionId}/blocked-sites`, {
      method: "PUT",
      body: JSON.stringify({ blocked_sites: sites }),
    }),

  updateSessionAllowedSites: (sessionId, sites) =>
    request(`/sessions/${sessionId}/allowed-sites`, {
      method: "PUT",
      body: JSON.stringify({ allowed_sites: sites }),
    }),

  getSessionEvents: (sessionId) => request(`/sessions/${sessionId}/events`),

  getSessionStats: (sessionId) => request(`/sessions/${sessionId}/stats`),

  getStudyLinks: (sessionId) => request(`/sessions/${sessionId}/study-links`),

  getAnalyticsOverview: (range = "month") =>
    request(`/analytics/overview?range=${encodeURIComponent(range)}`),

  // Academic progress: subjects x quiz scores x nudges, computed server-side
  // for THIS account only (no user_id parameter exists on purpose).
  getAcademicProgress: (range = "month") =>
    request(`/analytics/academic?range=${encodeURIComponent(range)}`),

  // --- post-session quiz (auto-generated from the session's study content) ---
  getSessionQuiz: (sessionId) => request(`/sessions/${sessionId}/quiz`),

  generateSessionQuiz: (sessionId) =>
    request(`/sessions/${sessionId}/quiz/generate`, { method: "POST" }),

  submitSessionQuiz: (sessionId, answers) =>
    request(`/sessions/${sessionId}/quiz/submit`, {
      method: "POST",
      body: JSON.stringify({ answers }),
    }),

  // Checklist persistence — the server-side record of what was worked on
  // (matched by description; ids change when the AI rewrites the list).
  updateSessionTasks: (sessionId, tasks) =>
    request(`/sessions/${sessionId}/tasks`, {
      method: "PUT",
      body: JSON.stringify({ tasks }),
    }),

  getChatHistory: (sessionId) => request(`/sessions/${sessionId}/chat`),

  getSessionNotes: (sessionId) => request(`/sessions/${sessionId}/notes`),

  // --- user settings (check-in cadence / tone / webcam / voice) ---
  getSettings: () => request("/me/settings"),
  updateSettings: (patch) =>
    request("/me/settings", { method: "PUT", body: JSON.stringify(patch) }),

  // --- age / consent (minors need a guardian grant) ---
  recordConsent: (granted, scope, note) =>
    request("/me/consent", {
      method: "POST",
      body: JSON.stringify({ granted, scope, note }),
    }),
  consentRecords: () => request("/me/consent/records"),

  // Backend's own foreground-window snapshot — the browser-mode bridge for
  // window monitoring (badge, on/off-task, presence) in any browser.
  liveWindow: () => request("/me/live-window"),
  // Click/view breadcrumb batch for the guardian's Activity timeline.
  // keepalive lets the last flush survive a page unload.
  postActivity: (events, keepalive = false) =>
    request("/me/activity", {
      method: "POST",
      body: JSON.stringify({ events }),
      keepalive,
    }),

  // --- parent / guardian module (focus alerts + site presence, no chat) ---
  parentStudents: () => request("/parent/students"),
  parentOverview: () => request("/parent/overview"),
  parentAlerts: (unreadOnly = false) =>
    request(`/parent/alerts${unreadOnly ? "?unread=1" : ""}`),
  parentMarkAlertRead: (alertId) =>
    request(`/parent/alerts/${alertId}/read`, { method: "POST" }),
  // Bulk read for the feed (one call instead of a per-row click storm).
  parentMarkAllAlertsRead: (studentId) =>
    request(
      `/parent/alerts/read-all${studentId ? `?student_id=${studentId}` : ""}`,
      { method: "POST" }
    ),
  // Server clock for skew-corrected relative timestamps ("2m ago").
  serverTime: () => request("/meta/time"),
  parentSites: () => request("/parent/sites"),
  parentConsent: (userId, granted, scope, note) =>
    request("/parent/consent", {
      method: "POST",
      body: JSON.stringify({ user_id: userId, granted, scope, note }),
    }),
  parentCreateStudent: (payload) =>
    request("/parent/students", { method: "POST", body: JSON.stringify(payload) }),
  // Parental controls (Family-Link style): block/allow lists + screen rules.
  parentStudentPolicy: (studentId, body) =>
    request(`/parent/students/${studentId}/policy`, {
      method: "PUT",
      body: JSON.stringify(body),
    }),
  parentStudentLimits: (studentId, body) =>
    request(`/parent/students/${studentId}/limits`, {
      method: "PUT",
      body: JSON.stringify(body),
    }),
  // Link an EXISTING student account (already registered / already using
  // the app) to this guardian, by email or serial number.
  parentLinkStudent: (identifier) =>
    request("/parent/students/link", {
      method: "POST",
      body: JSON.stringify({ identifier }),
    }),
  // Per-session history + per-day activity for one linked student.
  parentStudentSessions: (studentId, limit = 30) =>
    request(`/parent/students/${studentId}/sessions?limit=${limit}`),
  parentStudentActivity: (studentId, date) =>
    request(
      `/parent/students/${studentId}/activity${date ? `?date=${encodeURIComponent(date)}` : ""}`
    ),

  // --- intervention feedback + evaluation (theoretical framework) ---
  respondToIntervention: (interventionId, response) =>
    request(`/interventions/${interventionId}/respond`, {
      method: "POST",
      body: JSON.stringify({ intervention_id: interventionId, response }),
    }),
  getPatterns: (days = 14) => request(`/analytics/patterns?days=${days}`),
  getSessionEvaluation: (sessionId) => request(`/sessions/${sessionId}/evaluation`),
};

function wsUrl(path) {
  // Mirror resolveBaseUrls(): web base stays on its serving origin, never
  // silently pointing a browser at localhost:8420.
  const fallbackHttp = IS_WEB ? CONFIG_HTTP[0] || LOCAL_HTTP : LOCAL_HTTP;
  const wsBase =
    activeWs || CONFIG_WS[0] || (activeHttp || fallbackHttp).replace(/^http/, "ws");
  return `${wsBase}${path}`;
}

// Async WebSocket URL builder: waits for the base to be resolved, then
// returns a URL on the CURRENT active backend. Socket hooks call this on
// every (re)connect so they follow server switches automatically.
export async function getWsUrl(path) {
  const { ws } = await resolveBaseUrls();
  return `${ws}${path}`;
}

export const WS_BASE_URL = wsUrl("");
export const wsChat = (sessionId) => wsUrl(`/ws/${sessionId}/chat`);
export const wsFocus = (sessionId) => wsUrl(`/ws/${sessionId}`);
// Guardian realtime channel — pass ?token=<user token> (WS can't send headers).
export const wsParent = () => wsUrl("/ws/parent");