import { useEffect, useState } from "react";
import { api } from "../../../api/client";
import { HistSession, ActivityTimeline, fmtDur } from "../shared.jsx";

// "Maria Cruz" -> "Maria" for the friendly empty-state line.
function firstNameOf(name) {
  const first = String(name || "").trim().split(/\s+/)[0];
  return first || name;
}

/**
 * History section — presentation for BOTH entry points:
 *
 * - All-students view (opened from the rail with no student picked): every
 *   linked student gets a clearly labeled subsection — big name header,
 *   status chip, then their recent sessions itemized under it. The lists
 *   are fetched per student (api.parentStudentSessions(id, 30)) lazily when
 *   this view mounts and refreshed on the dashboard's 15s cadence, with one
 *   try/catch per student so a single failure never blanks the page.
 * - Single-student view (a chip here, or a deep link from an Overview
 *   card): the tabbed panel — Sessions / By day (date picker) / Activity —
 *   exactly as before.
 *
 * The student chips filter works in both: picking one opens only that
 * student's view; "All students" returns to the grouped view (re-selecting
 * the open student closes their panel — the same toggle the Overview card's
 * History button uses, so no new handler is introduced).
 */
export default function HistorySection({
  students,
  student,
  tab,
  sessions,
  day,
  date,
  onSwitchTab,
  onSetDay,
  onOpenStudent,
}) {
  const allView = !student;
  const [byStudent, setByStudent] = useState({});

  // Per-student session lists for the All-students view: lazy on first
  // open, then the same 15s cadence the open panel uses.
  useEffect(() => {
    if (!allView) return undefined;
    let alive = true;
    const load = async () => {
      await Promise.all(
        students.map(async (s) => {
          try {
            const list = await api.parentStudentSessions(s.id, 30);
            if (alive) setByStudent((prev) => ({ ...prev, [s.id]: list }));
          } catch {
            // Keep the last known list; a first-load failure falls back to
            // an empty one so the subsection shows its empty state instead
            // of loading forever.
            if (alive) {
              setByStudent((prev) => (prev[s.id] ? prev : { ...prev, [s.id]: [] }));
            }
          }
        })
      );
    };
    load();
    const timer = setInterval(load, 15000);
    return () => {
      alive = false;
      clearInterval(timer);
    };
  }, [allView, students]);

  // Closing the open student returns to the All-students view: the panel's
  // toggle (toggleHistory) closes when its own student id is re-selected.
  const showAll = () => {
    if (student) onOpenStudent(student.id);
  };

  const chipsRow = students.length > 0 && (
    <div className="parent-alert-bar parent-focus-bar">
      <span className="parent-focus-label">Students</span>
      <div
        className="parent-alert-filter parent-alert-chips"
        aria-label="Choose a student"
      >
        <button
          type="button"
          className={`parent-alert-chip${allView ? " is-active" : ""}`}
          aria-pressed={allView}
          onClick={showAll}
        >
          All students
        </button>
        {students.map((s) => (
          <button
            key={s.id}
            type="button"
            className={`parent-alert-chip${
              !allView && student.id === s.id ? " is-active" : ""
            }`}
            aria-pressed={!allView && student.id === s.id}
            onClick={() => onOpenStudent(s.id)}
          >
            {s.full_name || s.serial_number}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <>
      <h1 className="setup-title">History</h1>
      <p className="setup-subtitle">
        {allView
          ? "Recent focus sessions for every linked student — grouped by student, newest first."
          : "See what they studied, how long they studied and how focused they were."}
      </p>
      <p className="parent-instruction">
        {allView ? (
          <>
            Tap a student to open their full history — <strong>Sessions</strong>,{" "}
            <strong>By day</strong> with a date picker and the{" "}
            <strong>Activity</strong> timeline.
          </>
        ) : (
          <>
            <strong>Sessions</strong> = every session · <strong>By day</strong> = one
            day at a time · <strong>Activity</strong> = what they clicked.
          </>
        )}
      </p>

      {chipsRow}

      {!allView ? (
        <>
          <span className="parent-history-who">
            {student.full_name || student.serial_number}
          </span>
          <div className="parent-history">
            <div className="parent-history-tabs">
              <button
                type="button"
                className={`parent-history-tab${
                  tab !== "day" && tab !== "activity" ? " is-active" : ""
                }`}
                onClick={() => onSwitchTab("sessions")}
              >
                Sessions
              </button>
              <button
                type="button"
                className={`parent-history-tab${tab === "day" ? " is-active" : ""}`}
                onClick={() => onSwitchTab("day")}
              >
                By day
              </button>
              <button
                type="button"
                className={`parent-history-tab${
                  tab === "activity" ? " is-active" : ""
                }`}
                onClick={() => onSwitchTab("activity")}
              >
                Activity
              </button>
              {(tab === "day" || tab === "activity") && (
                <input
                  type="date"
                  className="parent-history-date"
                  value={date || new Date().toISOString().slice(0, 10)}
                  max={new Date().toISOString().slice(0, 10)}
                  onChange={(e) => onSetDay(e.target.value)}
                />
              )}
            </div>
            {tab === "activity" ? (
              day ? (
                <ActivityTimeline data={day} />
              ) : (
                <p className="parent-history-empty">Loading…</p>
              )
            ) : tab === "day" ? (
              day ? (
                <div className="parent-hist-day">
                  <div className="parent-hist-meta">
                    <span>
                      Screen time <strong>{fmtDur(day.screen_seconds)}</strong>
                    </span>
                    <span>{day.sessions?.length || 0} session(s)</span>
                  </div>
                  {(day.top_sites?.length || 0) > 0 && (
                    <div className="parent-site-top">
                      <span className="parent-site-top-label">Sites that day</span>
                      {day.top_sites.slice(0, 8).map((t) => (
                        <div className="parent-site-row" key={t.site}>
                          <span className="parent-site-name">{t.site}</span>
                          <span className="parent-site-track">
                            <span
                              className="parent-site-fill"
                              style={{
                                width: `${Math.max(
                                  6,
                                  Math.round(
                                    (t.seconds / (day.top_sites[0]?.seconds || 1)) *
                                      100
                                  )
                                )}%`,
                              }}
                            />
                          </span>
                          <span className="parent-site-time">{fmtDur(t.seconds)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {(day.top_apps?.length || 0) > 0 && (
                    <div className="parent-site-top">
                      <span className="parent-site-top-label">Apps that day</span>
                      {day.top_apps.slice(0, 8).map((t) => (
                        <div className="parent-site-row" key={t.app}>
                          <span className="parent-site-name">{t.app}</span>
                          <span className="parent-site-track">
                            <span
                              className="parent-site-fill parent-app-fill"
                              style={{
                                width: `${Math.max(
                                  6,
                                  Math.round(
                                    (t.seconds / (day.top_apps[0]?.seconds || 1)) * 100
                                  )
                                )}%`,
                              }}
                            />
                          </span>
                          <span className="parent-site-time">{fmtDur(t.seconds)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {(day.sessions?.length || 0) === 0 ? (
                    <p className="parent-history-empty">
                      No sessions this day — try another date, or open the Sessions
                      tab.
                    </p>
                  ) : (
                    day.sessions.map((sess) => (
                      <HistSession key={sess.id} sess={sess} />
                    ))
                  )}
                </div>
              ) : (
                <p className="parent-history-empty">Loading…</p>
              )
            ) : (sessions || []).length === 0 ? (
              <p className="parent-history-empty">
                No sessions yet — when{" "}
                {firstNameOf(student.full_name || student.serial_number)} starts a
                focus session, it will show up here.
              </p>
            ) : (
              sessions.map((sess) => <HistSession key={sess.id} sess={sess} />)
            )}
          </div>
        </>
      ) : students.length === 0 ? (
        <p className="setup-notice">
          No students linked yet — open Family and use Add student to create or link
          your child's account.
        </p>
      ) : (
        <div className="parent-hist-all">
          {students.map((s) => {
            const name = s.full_name || s.serial_number;
            const list = byStudent[s.id];
            return (
              <section key={s.id} className="parent-hist-student">
                <div className="parent-hist-student-head">
                  <h2 className="parent-hist-student-name">{name}</h2>
                  {s.status ? (
                    <span className={`parent-status parent-status-${s.status}`}>
                      {String(s.status).replace(/_/g, " ")}
                    </span>
                  ) : null}
                </div>
                {list == null ? (
                  <p className="parent-history-empty">Loading…</p>
                ) : list.length === 0 ? (
                  <p className="parent-history-empty">
                    No sessions yet — when {firstNameOf(name)} starts a focus
                    session, it will show up here.
                  </p>
                ) : (
                  <>
                    <p className="parent-hist-student-count">
                      {list.length} recent session{list.length === 1 ? "" : "s"}
                    </p>
                    <div className="parent-hist-list">
                      {list.map((sess) => (
                        <HistSession key={sess.id} sess={sess} />
                      ))}
                    </div>
                  </>
                )}
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}
