import { useState } from "react";
import { Lock, LockOpen, Loader2, Settings2 } from "lucide-react";
import WhitelistSettings from "./WhitelistSettings";

export default function BlockingBadge({ blocking, onAdd, onRemove, readOnly = false }) {
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { blocklist, active, pending, error, available, addBlocklistEntry, removeBlocklistEntry } =
    blocking;

  if (!available) return null; // not on Electron (e.g. a plain web build) — nothing to show

  const Icon = pending ? Loader2 : active ? Lock : LockOpen;
  const label = pending ? "Applying…" : active ? "Sites blocked" : "Blocking off";

  return (
    <div className="app-monitor">
      <button
        className={`app-monitor-pill${active ? " app-monitor-pill-blocking" : ""}${error ? " app-monitor-pill-alert" : ""}`}
        onClick={() => !readOnly && setSettingsOpen((v) => !v)}
        title={
          readOnly
            ? "Blocked sites are managed by your administrator"
            : error || "Click to edit the blocked sites list"
        }
      >
        <Icon size={14} className={pending ? "app-monitor-spin" : ""} />
        <span className="app-monitor-label">{error ? "Blocking error" : label}</span>
        {!readOnly && <Settings2 size={13} className="app-monitor-gear" />}
      </button>

      {settingsOpen && (
        <WhitelistSettings
          title="Blocked sites"
          hint="During focus time, these domains are redirected system-wide — in every browser, not just Stubilly — until your next break. Changes apply immediately if blocking is already on."
          placeholder="e.g. reddit.com"
          entries={blocklist}
          onAdd={onAdd || addBlocklistEntry}
          onRemove={onRemove || removeBlocklistEntry}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
}
