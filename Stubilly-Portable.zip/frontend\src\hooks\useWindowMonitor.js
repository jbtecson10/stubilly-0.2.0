import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, getToken } from "../api/client";

const STORAGE_KEY = "stubilly.whitelist";

export function extractDomain(url) {
  try {
    let host = new URL(url).hostname.toLowerCase();
    if (host.startsWith("www.")) host = host.slice(4);
    return host || null;
  } catch {
    return null;
  }
}

// active-win reports the browser URL on macOS but almost never on Windows
// (Chrome/Edge/Firefox all return null there), so a window that IS a
// browser still carries only its title. When a title embeds the literal
// domain ("SoundCloud — soundcloud.com"), we can still pull a site out of
// it; when it's just a brand name ("SoundCloud", "Facebook"), we stay
// conservative and return null — the main process's live title-matching
// still enforces already-blocked sites by name either way.
export function extractDomainFromTitle(title) {
  if (!title) return null;
  const m = title.toLowerCase().match(/(?:^|[\s(['"(])([a-z0-9-]+\.[a-z]{2,})(?:[\s)'.'"\](!]|$)/);
  return m ? m[1] : null;
}

// Where to get the live site for a reading: an explicit site (the backend
// probe's own domain extraction), else URL when the platform hands it to us,
// else the best title-derived domain we can be sure about.
export function extractSiteFromReading(win) {
  if (win?.site) return String(win.site).toLowerCase();
  return extractDomain(win?.url) || extractDomainFromTitle(win?.title);
}

// Reasonable out-of-the-box whitelist so the feature isn't useless before
// the student has configured anything. Matched as case-insensitive
// substrings against the app name, window title, and (browser-reported) URL.
export const DEFAULT_WHITELIST = [
  "Stubilly",
  "classroom.google.com",
  "docs.google.com",
  "drive.google.com",
  "scholar.google.com",
  "wikipedia.org",
];

function loadWhitelist() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // An explicitly saved empty whitelist is valid (student cleared it) —
      // only fall back to defaults when nothing has ever been stored.
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // corrupt/blocked storage — fall back to defaults
  }
  return DEFAULT_WHITELIST;
}

// The whitelist is authored as domains ("canvas.instructure.com") but on
// Windows the foreground reading almost always carries only the app name and
// the *page title* — never the URL. A title like "Algebra 1 - Google
// Classroom" therefore never contains the literal entry, so a student sitting
// on an allowed site was wrongly flagged off-task. Bridge the two: keep the
// raw substring match, then, for a domain-style entry, also match when the
// window's site shares the host, or when the domain's leading label appears as
// a whole word in the app/title (classroom, docs, drive, scholar, canvas, ...).
function matchesWhitelistEntry(entry, haystack, site) {
  const needle = String(entry).trim().toLowerCase();
  if (!needle) return false;
  if (haystack.includes(needle)) return true;
  // Domain-style only: no spaces, at least one dot.
  if (!needle.includes(".") || /\s/.test(needle)) return false;
  if (site) {
    const host = site.toLowerCase();
    if (host === needle || host.endsWith(`.${needle}`) || needle.endsWith(`.${host}`)) {
      return true;
    }
  }
  const label = needle.split(".")[0];
  if (label.length >= 4) {
    const word = new RegExp(`(^|[^a-z0-9])${label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([^a-z0-9]|$)`);
    if (word.test(haystack)) return true;
  }
  return false;
}

function isWhitelisted(win, whitelist) {
  if (!win) return true; // no reading yet — don't flag a false alarm
  const haystack = `${win.appName ?? ""} ${win.title ?? ""} ${win.url ?? ""}`.toLowerCase();
  const site = extractSiteFromReading(win);
  return whitelist.some((entry) => matchesWhitelistEntry(entry, haystack, site));
}

// Terminals are always exempt from off-task detection, no matter what the
// student does to their editable whitelist above — this is fixed, not a
// setting. Reasoning: (1) system-level tasks (installing deps, running
// the launcher, debugging) shouldn't ever trip the alarm or get the
// window yanked out from under them, and (2) unlike site blocking (hosts
// file, only touches browsers) or the forced-transfer behavior (only
// pulls Stubilly's own window forward), Stubilly has no way to tell a
// legitimate terminal task from a distracting one anyway — so the safe
// default is to never flag it.
const ALWAYS_EXEMPT_APPS = [
  "cmd.exe",
  "powershell.exe",
  "pwsh.exe",
  "windowsterminal.exe",
  "wt.exe",
  "conhost.exe",
  "terminal.app",
  "iterm",
  "iterm2",
  "gnome-terminal",
  "konsole",
  "xterm",
  "alacritty",
];

function isExemptTerminal(win) {
  if (!win?.appName) return false;
  const name = win.appName.toLowerCase();
  return ALWAYS_EXEMPT_APPS.some((exempt) => name.includes(exempt));
}

// Off-task debounce — the "precise" guard on the realtime window-read. A
// single foreground event (a quick alt-tab, an accidental click into another
// window for a second) must NOT flip the student to off_task and back every
// couple of seconds (that flaps the badge, the intervention alarm, and Live
// Kill). Commit to off_task only after 3 consecutive off readings OR ~4s of
// sustained disengagement, whichever comes first; recovery stays instant.
// The browser bridge polls every second, so 3 readings ~= 3s — precise without
// the old multi-second dead time.
const OFF_TASK_DEBOUNCE_READINGS = 3;
const OFF_TASK_DEBOUNCE_MS = 4000;
// A foreground reading can fail for a single tick (a UAC prompt, a fullscreen
// switch, a locked screen). One miss must not flip the badge to "unavailable"
// or count as off-task — require a short streak before believing the probe is
// really gone, and never let "no reading" masquerade as "distracted".
const UNAVAILABLE_STREAK_TOLERANCE = 3;

/**
 * Tracks the system-wide foreground app/window (pushed from the Electron
 * main process via `active-win`) and classifies it on/off-task against a
 * whitelist persisted in localStorage. Mirrors useFocusDetector's shape —
 * a live reading in, a derived state out — but for the "what's on screen"
 * signal instead of the webcam.
 *
 * `sessionAllowed` is the CURRENT session's temporary allowances (typed in
 * mid-session or carried from a resumed/continued session, stored on the
 * backend record). They are merged with the persistent global whitelist into
 * `effectiveWhitelist` — the list the renderer syncs to the main process and
 * uses for classification — so a session allowance overrides the blocklist
 * and Live Shutdown exactly like a permanent one does, but drops the moment
 * the session ends. The persistent whitelist itself is untouched.
 */
export function useWindowMonitor(sessionAllowed = []) {
  const [whitelist, setWhitelist] = useState(loadWhitelist);
  const [activeWindow, setActiveWindow] = useState(null);
  const [available, setAvailable] = useState(Boolean(window.stubilly?.onActiveWindow));
  const [onTask, setOnTask] = useState(true);
  const [offTaskSeconds, setOffTaskSeconds] = useState(0);
  const offTaskSinceRef = useRef(null);
  // Debounce bookkeeping: consecutive off readings + when the current off
  // stretch began, so a single accidental glance away never commits off_task.
  const offTaskStreakRef = useRef(0);

  const effectiveWhitelist = useMemo(() => {
    const seen = new Set();
    const out = [];
    for (const entry of [...whitelist, ...sessionAllowed]) {
      const key = String(entry).toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(entry);
    }
    return out;
  }, [whitelist, sessionAllowed]);

  useEffect(() => {
    if (window.stubilly?.onActiveWindow) {
      const unsubscribeWindow = window.stubilly.onActiveWindow(setActiveWindow);
      const unsubscribeError = window.stubilly.onActiveWindowError?.(() => setAvailable(false));
      return () => {
        unsubscribeWindow?.();
        unsubscribeError?.();
      };
    }
    // Browser mode: no Electron bridge exists, so poll the backend's own
    // Windows-API snapshot instead (/me/live-window — one ctypes read on
    // the student's machine). This is what makes the badge, on/off-task
    // classification and presence work in ANY browser/profile instead of
    // showing "Monitoring unavailable".
    let stop = false;
    let timer = null;
    let misses = 0;
    const poll = async () => {
      if (stop) return;
      // Signed out (or token gone): nothing to authenticate against —
      // keep the interval warm so monitoring resumes right after login.
      if (getToken()) {
        try {
          const reading = await api.liveWindow();
          if (stop) return;
          if (reading?.available) {
            misses = 0;
            // `site` is the probe's own conservative domain extraction from
            // the title; carry it as the URL so classification reads it the
            // same way an Electron reading's real URL would.
            setActiveWindow({
              appName: reading.app,
              title: reading.title,
              url: reading.site ?? null,
              site: reading.site ?? null,
            });
            setAvailable(true);
          } else if (++misses >= UNAVAILABLE_STREAK_TOLERANCE) {
            // Only after a sustained miss streak: a lone failed read keeps the
            // last known window (and on/off-task state) instead of blanking.
            setActiveWindow(null);
            setAvailable(false);
          }
        } catch {
          if (!stop && ++misses >= UNAVAILABLE_STREAK_TOLERANCE) setAvailable(false);
        }
      } else {
        misses = 0;
        setActiveWindow(null);
        setAvailable(false);
      }
      if (!stop) timer = setTimeout(poll, 1000);
    };
    poll();
    return () => {
      stop = true;
      if (timer) clearTimeout(timer);
    };
  }, []);

  useEffect(() => {
    // No reading (or signed out) is NOT evidence of distraction — leave the
    // last committed on/off-task state untouched so a transient probe miss
    // never flashes the badge or the off-task alarm.
    if (!available) return;
    // Stubilly itself is ALWAYS on-task — the student is studying inside it.
    // Never flag the study app as a distraction, no matter what the
    // whitelist says (a missing "Stubilly" entry must not fire the 2-min
    // alarm or the hard-block path).
    const inStubilly = /stubilly/i.test(
      `${activeWindow?.appName ?? ""} ${activeWindow?.title ?? ""} ${activeWindow?.url ?? ""}`
    );
    if (inStubilly) {
      offTaskStreakRef.current = 0;
      offTaskSinceRef.current = null;
      setOffTaskSeconds(0);
      setOnTask(true);
      return;
    }
    const matched = isExemptTerminal(activeWindow) || isWhitelisted(activeWindow, effectiveWhitelist);
    if (matched) {
      // Instantly back on-task — recovery is never delayed by the debounce.
      offTaskStreakRef.current = 0;
      offTaskSinceRef.current = null;
      setOffTaskSeconds(0);
      setOnTask(true);
      return;
    }
    // Off-task candidate. Debounce before COMMITTING: track the streak and
    // the elapsed time of this off stretch, flip to false only when either
    // crosses its threshold. A single stray reading resets nothing (it is
    // still "off"), but when the student returns we recover instantly above.
    const nowMs = Date.now();
    if (!offTaskSinceRef.current) {
      offTaskSinceRef.current = nowMs;
      offTaskStreakRef.current = 1;
    } else {
      offTaskStreakRef.current += 1;
    }
    const elapsedSec = (nowMs - offTaskSinceRef.current) / 1000;
    if (
      offTaskStreakRef.current >= OFF_TASK_DEBOUNCE_READINGS ||
      elapsedSec >= OFF_TASK_DEBOUNCE_MS / 1000
    ) {
      setOnTask(false);
    }
  }, [activeWindow, effectiveWhitelist, available]);

  useEffect(() => {
    if (onTask) return undefined;
    const id = setInterval(() => {
      if (offTaskSinceRef.current) {
        setOffTaskSeconds(Math.floor((Date.now() - offTaskSinceRef.current) / 1000));
      }
    }, 1000);
    return () => clearInterval(id);
  }, [onTask]);

  const persist = useCallback((next) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // best-effort — an unsaved whitelist still works for this session
    }
    return next;
  }, []);

  const addWhitelistEntry = useCallback(
    (raw) => {
      const value = raw.trim();
      if (!value) return;
      setWhitelist((prev) => {
        if (prev.some((e) => e.toLowerCase() === value.toLowerCase())) return prev;
        return persist([...prev, value]);
      });
    },
    [persist]
  );

  const removeWhitelistEntry = useCallback(
    (value) => {
      setWhitelist((prev) => persist(prev.filter((e) => e !== value)));
    },
    [persist]
  );

  // Admin-managed mode: the server policy wholesale-replaces the persistent
  // allow-list. Persists locally so enforcement survives offline, but from
  // now on the ADMIN owns the content — the student UI no longer edits it.
  const replaceWhitelist = useCallback(
    (list) => {
      const cleaned = (Array.isArray(list) ? list : [])
        .map((s) => String(s).trim())
        .filter(Boolean);
      setWhitelist(persist(cleaned));
    },
    [persist]
  );

  return {
    activeWindow,
    available,
    onTask,
    offTaskSeconds,
    whitelist,
    effectiveWhitelist,
    addWhitelistEntry,
    removeWhitelistEntry,
    replaceWhitelist,
  };
}
