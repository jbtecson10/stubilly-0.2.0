"""
Best-effort SQLite migrations for Stubilly.

Why this exists: SQLAlchemy's create_all() only creates missing TABLES — it
never adds columns to tables that already exist. So a database created by an
older build of the app is missing any columns that were added to the models
later (e.g. focus_events.app_state / active_app), and every query against
those tables blows up with "no such column". Fresh test databases hide this;
long-lived user DBs surface it.

The migration derives what to add directly from the ORM metadata, so any
column that exists in the models but not in the on-disk table gets added
automatically. All such columns are nullable (a requirement for SQLite's
ALTER TABLE ... ADD COLUMN).
"""
import logging

from sqlalchemy import text
from sqlalchemy.schema import CreateIndex, CreateTable

import models  # noqa: F401  — registers every ORM table on Base.metadata
from database import engine, Base

logger = logging.getLogger("stubilly.migrate")


def run_migrations() -> None:
    with engine.begin() as conn:
        existing_tables = {
            row[0]
            for row in conn.execute(
                text("SELECT name FROM sqlite_master WHERE type='table'")
            )
        }

        # Constraint/table-shape changes must land BEFORE the column loop
        # (they rebuild the table, which would otherwise discard per-column
        # fixes applied moments earlier).
        _rebuild_window_visits(conn, existing_tables)

        for table_name, table in Base.metadata.tables.items():
            if table_name not in existing_tables:
                continue
            db_columns = {
                row[1]
                for row in conn.execute(
                    text(f"PRAGMA table_info('{table_name}')")
                )
            }
            for column_name, column in table.columns.items():
                if column_name in db_columns:
                    continue
                col_type = str(column.type.compile(dialect=engine.dialect))
                logger.info(
                    "Migrating: adding column %s.%s (%s)",
                    table_name, column_name, col_type,
                )
                conn.execute(
                    text(
                        f"ALTER TABLE \"{table_name}\" "
                        f"ADD COLUMN \"{column_name}\" {col_type}"
                    )
                )

        # Backfill: columns added by the ALTER above (or by older builds) are
        # nullable, so rows that predate them hold SQL NULL. The response
        # models treat these as non-optional numbers, so a NULL would surface
        # as a 500 (e.g. GET /sessions). Give legacy rows a real 0.
        _backfill_nulls(conn, existing_tables)


def _rebuild_window_visits(conn, existing_tables) -> None:
    """window_visits started life keyed (user, day, app, title), which
    pinned every window of a day to the FIRST session that saw it. The
    history view needs per-session rows, so the unique key became
    (user, session, app, title). SQLite can't alter a constraint —
    rebuild the table from the ORM's current shape and carry the rows
    over. Fresh databases already match and are left alone."""
    table = Base.metadata.tables.get("window_visits")
    if table is None or "window_visits" not in existing_tables:
        return
    row = conn.execute(
        text("SELECT sql FROM sqlite_master WHERE type='table' "
             "AND name='window_visits'")
    ).fetchone()
    ddl = (row[0] or "") if row else ""
    if "uq_window_visit_user_session_app_title" in ddl:
        return  # already current
    if "window_visits" not in ddl:
        return  # unrecognised shape — don't guess
    logger.info("Migrating: rebuilding window_visits with session-scoped key")
    conn.execute(text('DROP TABLE IF EXISTS "window_visits_new"'))
    create = str(CreateTable(table).compile(dialect=engine.dialect)).strip()
    create_new = create.replace(
        "CREATE TABLE window_visits (", "CREATE TABLE window_visits_new (", 1
    )
    if create_new == create:
        logger.warning("Migrating: window_visits DDL shape unexpected — skipping rebuild")
        return
    conn.execute(text(create_new))
    cols = ", ".join(f'"{c.name}"' for c in table.columns)
    conn.execute(text(
        f'INSERT INTO "window_visits_new" ({cols}) '
        f'SELECT {cols} FROM "window_visits"'
    ))
    conn.execute(text('DROP TABLE "window_visits"'))
    conn.execute(text('ALTER TABLE "window_visits_new" RENAME TO "window_visits"'))
    for idx in sorted(table.indexes, key=lambda i: i.name or ""):
        idx_ddl = str(CreateIndex(idx).compile(dialect=engine.dialect)).strip()
        if idx_ddl:
            conn.execute(text(idx_ddl))
    existing_tables.add("window_visits")


def _backfill_nulls(conn, existing_tables) -> None:
    backfills = {
        "sessions": {
            "total_focused_seconds": "0.0",
            "total_distracted_seconds": "0.0",
            "intervention_count": "0",
            "check_in_count": "0",
            "paralysis_count": "0",
        },
        # tasks.is_placeholder / completed / order_index are added columns;
        # pre-existing rows hold NULL and would 500 the SessionOut serializer.
        "tasks": {
            "is_placeholder": "0",
            "completed": "0",
            "order_index": "0",
        },
        # admin_messages.pinned is an added column; NULL would serialize as
        # False anyway, but backfilling keeps the raw table honest.
        "admin_messages": {
            "pinned": "0",
        },
    }
    for table_name, columns in backfills.items():
        if table_name not in existing_tables:
            continue
        db_columns = {
            row[1]
            for row in conn.execute(
                text(f"PRAGMA table_info('{table_name}')")
            )
        }
        for column_name, default in columns.items():
            if column_name not in db_columns:
                continue
            result = conn.execute(
                text(
                    f"UPDATE \"{table_name}\" SET \"{column_name}\" = {default} "
                    f"WHERE \"{column_name}\" IS NULL"
                )
            )
            if result.rowcount:
                logger.info(
                    "Migrating: backfilled %s.%s NULL -> %s on %d row(s)",
                    table_name, column_name, default, result.rowcount,
                )