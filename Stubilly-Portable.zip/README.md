# Stubilly — Portable Build

A self-contained copy of **Stubilly Prototype 2** that runs locally with either
**Ollama** or **llama.cpp** as the AI backend. Share it, clone it, run it.

---

## What you need first

| Requirement | Why | Get it |
|---|---|---|
| **Python 3.10+** | Runs the backend | [python.org](https://www.python.org/downloads/) — tick *Add to PATH* |
| **Ollama *or* llama.cpp** | Local AI model | See below |

You only need **one** of the two LLM backends. Pick whichever you prefer.

### Ollama (easiest)

1. Install from [ollama.com](https://ollama.com)
2. Open a terminal and pull a model:  `ollama pull llama3.2`
3. Make sure Ollama is running (`ollama serve` — the installer usually does this)

### llama.cpp (more control)

1. Download a GGUF model (e.g. [Qwen2.5-7B](https://huggingface.co/Qwen/Qwen2.5-7B-Instruct-GGUF))
2. Start the server:

   ```
   llama-server -m path\to\your-model.gguf --port 8080
   ```

3. Leave that terminal window open.

---

## Quick start (3 steps)

```
1. Double-click  setup.bat          ← do this once
2. Double-click  run-ollama.bat     ← or run-llamacpp.bat
3. Open the URL it prints           ← usually http://localhost:8422
```

That's it. The first account you create becomes the administrator.

---

## Ports

| Launcher | Port | LLM backend |
|---|---|---|
| `run-ollama.bat` | **8422** | Ollama |
| `run-llamacpp.bat` | **8423** | llama.cpp |

Both can run at the same time — they use separate ports and separate databases.

---

## Configuration

Edit the `.env` file in this folder. Everything has a working default; the
only things you might want to change:

- `OLLAMA_MODEL` — which Ollama model to use (default: `llama3.2`)
- `STUBILLY_LLAMACPP_MODEL` — which llama.cpp model name to send
- `GEMINI_API_KEY` — optional; enables cloud AI features

---

## Folder layout

```
Stubilly-Portable/
├── setup.bat              ← run once to install Python deps
├── run-ollama.bat         ← start Ollama mode  (:8422)
├── run-llamacpp.bat       ← start llama.cpp mode (:8423)
├── .env                   ← configuration (edit as needed)
├── backend/               ← Python source (FastAPI + SQLite)
└── frontend/
    ├── dist/              ← pre-built web UI (served automatically)
    └── src/               ← web UI source (rebuild with: npm install && npm run build)
```

---

## Troubleshooting

**"Python is not installed"** — install Python from python.org and make sure
to tick *Add Python to PATH* during setup, then run `setup.bat` again.

**"Address already in use"** — something else is on port 8422/8423. Either
close it or change `STUBILLY_PORT` in `.env`.

**AI replies are slow / empty** — make sure your LLM backend is actually
running (`ollama list` or check the llama-server terminal).

**Face-cam / focus detection doesn't load** — it fetches MediaPipe models from
a CDN on first use. An internet connection is needed once; after that they're
cached.

---

## Security notes

- This binds to `127.0.0.1` by default — only your machine can reach it.
- To allow other devices on your network, change `STUBILLY_HOST` to `0.0.0.0`
  in `.env` and allow the port through your firewall.
- No data leaves your machine unless you configure a cloud API key.

---

## License / credits

Prototype 2 — Stubilly study companion. For personal / educational use.
