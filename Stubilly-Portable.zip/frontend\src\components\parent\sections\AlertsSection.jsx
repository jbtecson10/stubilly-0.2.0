import { CheckCheck, Filter, Users } from "lucide-react";
import { dayLabel, timeAgo, KIND_LABELS } from "../shared.jsx";

/**
 * Alert feed section: per-student stream chips, unread-only toggle,
 * mark-all-read, day-grouped timeline, Block buttons and relative time
 * labels — moved verbatim from the old single-page dashboard. Rendered
 * standalone (rail → Alerts) or embedded under the Overview (where the
 * focus switcher above the cards already drives it).
 */
export default function AlertsSection({
  students,
  alerts,
  shownAlerts,
  feedItems,
  alertStudent,
  setAlertStudent,
  focusMatch,
  unread,
  unreadOnly,
  setUnreadOnly,
  markAllRead,
  markRead,
  blockSiteFromAlert,
  blockState,
  standalone,
}) {
  return (
    <>
      {standalone ? (
        <h1 className="setup-title">
          Alerts
          {unread > 0 && <span className="parent-alert-badge">{unread}</span>}
        </h1>
      ) : (
        <h2 className="parent-section-title">
          Alerts
          {unread > 0 && <span className="parent-alert-badge">{unread}</span>}
        </h2>
      )}
      {standalone && (
        <p className="setup-subtitle">
          Get notified the moment something important happens — tap an alert to act
          on it.
        </p>
      )}
      {standalone && students.length > 0 && (
        <div className="parent-alert-bar parent-focus-bar">
          <span className="parent-focus-label">Students</span>
          <div
            className="parent-alert-filter parent-alert-chips"
            aria-label="Focus on a student"
          >
            <button
              type="button"
              className={`parent-alert-chip${alertStudent === "all" ? " is-active" : ""}`}
              onClick={() => setAlertStudent("all")}
            >
              All students
              <span className="parent-alert-chip-n">{alerts.length}</span>
            </button>
            {students.map((s) => {
              const total = alerts.filter((a) => a.student_id === s.id).length;
              const fresh = alerts.filter(
                (a) => a.student_id === s.id && !a.read_at
              ).length;
              return (
                <button
                  key={s.id}
                  type="button"
                  className={`parent-alert-chip${
                    alertStudent === String(s.id) ? " is-active" : ""
                  }`}
                  onClick={() => setAlertStudent(String(s.id))}
                >
                  {s.full_name || s.serial_number}
                  <span className="parent-alert-chip-n">{total}</span>
                  {fresh > 0 && (
                    <span className="parent-alert-chip-new">{fresh} new</span>
                  )}
                </button>
              );
            })}
          </div>
          {focusMatch && (
            <button
              type="button"
              className="btn-secondary"
              onClick={() => setAlertStudent("all")}
            >
              <Users size={15} aria-hidden="true" />
              Show everyone
            </button>
          )}
        </div>
      )}
      {alerts.length === 0 ? (
        <p className="setup-notice">No alerts yet — you'll see them here as they happen.</p>
      ) : (
        <>
          <div className="parent-alert-bar parent-feed-bar">
            <button
              type="button"
              className={`btn-secondary parent-feed-btn${unreadOnly ? " is-active" : ""}`}
              onClick={() => setUnreadOnly((v) => !v)}
              aria-pressed={unreadOnly}
            >
              <Filter size={15} aria-hidden="true" />
              {unreadOnly ? "Unread only · on" : "Unread only"}
            </button>
            <button
              type="button"
              className="btn-secondary parent-feed-btn"
              disabled={unread === 0}
              onClick={markAllRead}
            >
              <CheckCheck size={15} aria-hidden="true" />
              Mark all read{unread > 0 ? ` (${unread})` : ""}
            </button>
          </div>
          <p className="parent-instruction">
            <strong>Unread only</strong> hides alerts you've already seen.{" "}
            <strong>Mark all read</strong> clears them all at once.
          </p>
          {shownAlerts.length === 0 ? (
            <p className="setup-notice">Nothing here — all caught up.</p>
          ) : (
            <ul className="parent-alerts">
              {feedItems.map((item) => {
                if (!item.alert) {
                  return (
                    <li key={item.key} className="parent-alert-day">
                      {dayLabel(item.day)}
                    </li>
                  );
                }
                const a = item.alert;
                const site = a.kind === "site_visit" ? a.payload?.site || null : null;
                const s = students.find((x) => x.id === a.student_id);
                const isBlocked = !!(site && (s?.blocked_sites || []).includes(site));
                const busy = blockState[a.id] === "busy";
                const failed = blockState[a.id] === "error";
                return (
                  <li
                    key={item.key}
                    className={`parent-alert${a.read_at ? "" : " parent-alert-unread"}`}
                    onClick={() => !a.read_at && markRead(a.id)}
                  >
                    <span className={`parent-alert-kind parent-alert-${a.kind}`}>
                      {KIND_LABELS[a.kind] || a.kind}
                    </span>
                    <span className="parent-alert-body">
                      <strong>{a.student_name || "Student"}</strong> — {a.message}
                    </span>
                    {site ? (
                      <button
                        type="button"
                        className={`parent-alert-action${isBlocked ? " is-done" : ""}${
                          failed && !isBlocked ? " is-error" : ""
                        }`}
                        disabled={busy || isBlocked}
                        onClick={(e) => {
                          e.stopPropagation();
                          blockSiteFromAlert(a);
                        }}
                      >
                        {isBlocked
                          ? "Blocked ✓"
                          : busy
                            ? "Blocking…"
                            : failed
                              ? "Failed — retry"
                              : `Block ${site}`}
                      </button>
                    ) : (
                      <span className="parent-alert-action-slot" aria-hidden="true" />
                    )}
                    <span className="parent-alert-time">{timeAgo(a.created_at)}</span>
                  </li>
                );
              })}
            </ul>
          )}
          {shownAlerts.length > 60 && (
            <p className="parent-alerts-note">
              Showing the newest 60 of {shownAlerts.length} — focus a student above to
              see the rest.
            </p>
          )}
        </>
      )}
    </>
  );
}
