#!/usr/bin/env node
/**
 * Downloads the MediaPipe wasm runtime + face_landmarker model into
 * public/models/ so Vite bundles them into dist/ and the packaged Electron
 * app works fully offline (no CDN fetch at runtime).
 *
 * Run once during development setup, or as a prebuild step before
 * `npm run electron:build`:
 *   node scripts/download-models.mjs
 *
 * After running this, useFocusDetector.js will pick up the local files
 * automatically (see the LOCAL_MODELS_AVAILABLE check in that file).
 */
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const MODELS_DIR = path.join(__dirname, "..", "public", "models");

const WASM_FILES = [
  "vision_wasm_internal.js",
  "vision_wasm_internal.wasm",
  "vision_wasm_nosimd_internal.js",
  "vision_wasm_nosimd_internal.wasm",
];
const WASM_BASE = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/wasm";
const MODEL_URL =
  "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task";

async function download(url, destPath) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Failed to fetch ${url}: ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  await writeFile(destPath, buf);
  console.log(`  ✓ ${path.basename(destPath)} (${(buf.length / 1024).toFixed(0)} KB)`);
}

async function main() {
  await mkdir(path.join(MODELS_DIR, "wasm"), { recursive: true });

  console.log("Downloading MediaPipe wasm runtime...");
  for (const file of WASM_FILES) {
    await download(`${WASM_BASE}/${file}`, path.join(MODELS_DIR, "wasm", file));
  }

  console.log("Downloading face_landmarker model...");
  await download(MODEL_URL, path.join(MODELS_DIR, "face_landmarker.task"));

  console.log(`\nDone. Models saved to ${MODELS_DIR}`);
  console.log("These are picked up automatically by useFocusDetector.js at build time.");
}

main().catch((err) => {
  console.error("Model download failed:", err.message);
  console.error("The app will still work using the CDN fallback while online.");
  process.exit(1);
});
