import { CheckCheck, Pause, Play, Plus, ShieldCheck, ShieldOff } from "lucide-react";

/**
 * Parental controls section: screen limits, downtime, pause, monitoring
 * switch and the blocked-sites list (the content that used to live in
 * the Controls modal) for the student chosen via panel state. With no
 * student chosen yet, shows a picker. Every group carries a plain helper
 * line so a non-technical parent knows exactly what each rule does.
 */
export default function ControlsSection({
  students,
  student,
  draft,
  ctlMsg,
  updateDraft,
  addSite,
  removeSite,
  saveLimits,
  savePolicy,
  togglePause,
  toggleMonitoring,
  onOpenStudent,
}) {
  const s = student;
  const d = draft;
  return (
    <>
      <h1 className="setup-title">Parental controls</h1>
      <p className="setup-subtitle">
        Set the rules for your child's device. Changes apply immediately.
      </p>
      {!s || !d ? (
        <>
          <p className="parent-instruction">Pick a student below to get started.</p>
          {students.length === 0 ? (
            <p className="setup-notice">
              No students linked yet — open Family and use Add student to create or
              link your child's account.
            </p>
          ) : (
            <div className="parent-alert-bar parent-focus-bar">
              <span className="parent-focus-label">Students</span>
              <div
                className="parent-alert-filter parent-alert-chips"
                aria-label="Choose a student"
              >
                {students.map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    className="parent-alert-chip"
                    onClick={() => onOpenStudent(st.id)}
                  >
                    {st.full_name || st.serial_number}
                  </button>
                ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="parent-controls-panel">
          {/* --- Screen time: daily limit + downtime window --- */}
          <div className="parent-ctl-group">
            <span className="parent-ctl-title">Screen time</span>
            <div className="parent-controls-row">
              <label className="parent-controls-label">
                Daily limit (min)
                <input
                  type="number"
                  min="0"
                  max="1440"
                  placeholder="unlimited"
                  value={d.limit}
                  onChange={(e) => updateDraft(s.id, { limit: e.target.value })}
                />
              </label>
              <label className="parent-controls-label">
                Downtime from
                <input
                  type="time"
                  value={d.ds}
                  onChange={(e) => updateDraft(s.id, { ds: e.target.value })}
                />
              </label>
              <label className="parent-controls-label">
                to
                <input
                  type="time"
                  value={d.de}
                  onChange={(e) => updateDraft(s.id, { de: e.target.value })}
                />
              </label>
              <button type="button" className="btn-secondary" onClick={() => saveLimits(s)}>
                <CheckCheck size={15} aria-hidden="true" />
                Save rules
              </button>
            </div>
            <p className="parent-ctl-help">
              <strong>Daily limit</strong> — Max screen time per day, in minutes —
              leave empty for unlimited.
              <br />
              <strong>Downtime</strong> — Device locks down between these times, e.g.
              9 PM–7 AM.
            </p>
          </div>

          {/* --- Blocked sites --- */}
          <div className="parent-ctl-group">
            <span className="parent-ctl-title">Blocked sites</span>
            <div className="parent-controls-row parent-controls-sites">
              <span className="parent-chips">
                {d.sites.map((site) => (
                  <span className="parent-chip" key={site}>
                    {site}
                    <button
                      type="button"
                      aria-label={`Remove ${site}`}
                      onClick={() => removeSite(s.id, site)}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </span>
              <input
                type="text"
                placeholder="example.com"
                value={d.newSite}
                onChange={(e) => updateDraft(s.id, { newSite: e.target.value })}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    addSite(s.id);
                  }
                }}
              />
              <button type="button" className="btn-secondary" onClick={() => addSite(s.id)}>
                <Plus size={15} aria-hidden="true" />
                Add
              </button>
              <button type="button" className="btn-secondary" onClick={() => savePolicy(s)}>
                <CheckCheck size={15} aria-hidden="true" />
                Save sites
              </button>
            </div>
            <p className="parent-ctl-help">
              <strong>Blocked sites</strong> — Type a site and press Add — your child
              can't open it while studying.
            </p>
          </div>

          {/* --- Pause + activity monitoring --- */}
          <div className="parent-ctl-group">
            <span className="parent-ctl-title">Pause &amp; monitoring</span>
            <div className="parent-controls-row">
              <button
                type="button"
                className={`btn-secondary ${s.device_paused ? "btn-resume" : "btn-pause"}`}
                onClick={() => togglePause(s)}
              >
                {s.device_paused ? (
                  <Play size={15} aria-hidden="true" />
                ) : (
                  <Pause size={15} aria-hidden="true" />
                )}
                {s.device_paused ? "Resume device" : "Pause device"}
              </button>
              <button
                type="button"
                className={`btn-secondary ${
                  s.monitoring_enabled === false ? "btn-pause" : "btn-resume"
                }`}
                onClick={() => toggleMonitoring(s)}
              >
                {s.monitoring_enabled === false ? (
                  <ShieldCheck size={15} aria-hidden="true" />
                ) : (
                  <ShieldOff size={15} aria-hidden="true" />
                )}
                {s.monitoring_enabled === false ? "Turn on monitoring" : "Turn off monitoring"}
              </button>
            </div>
            <p className="parent-ctl-help">
              <strong>Pause button</strong> — Instantly stops any new session; the one
              already running finishes.
              <br />
              <strong>Monitoring</strong> — Records window titles (never content) and
              clicks for the Activity timeline while a session runs.
            </p>
          </div>

          {ctlMsg[s.id] && <div className="parent-controls-msg">{ctlMsg[s.id]}</div>}
        </div>
      )}
    </>
  );
}
