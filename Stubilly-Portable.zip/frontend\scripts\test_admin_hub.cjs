const http = require('http');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

async function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

async function main() {
  const electronPath = path.join(__dirname, '..', 'node_modules', 'electron', 'dist', 'electron.exe');
  const tempProfile = path.join(process.env.TEMP || 'C:\\temp', 'stubilly_admin_test_profile');
  
  console.log('Launching Electron with remote debugging on port 9223...');
  const child = spawn(electronPath, [
    path.join(__dirname, '..'),
    '--remote-debugging-port=9223',
    `--user-data-dir=${tempProfile}`,
  ], {
    stdio: 'ignore',
  });

  // Wait for remote debugging endpoint to become available
  let version = null;
  for (let i = 0; i < 20; i++) {
    await new Promise((r) => setTimeout(r, 600));
    try {
      version = await getJson('http://127.0.0.1:9223/json/version');
      if (version) break;
    } catch {}
  }

  if (!version) {
    console.error('Failed to connect to Electron remote debugging.');
    child.kill();
    process.exit(1);
  }

  console.log('Connected to Electron CDP:', version.Browser);

  // Find page target
  const targets = await getJson('http://127.0.0.1:9223/json');
  const pageTarget = targets.find((t) => t.type === 'page');
  if (!pageTarget) {
    console.error('No page target found');
    child.kill();
    process.exit(1);
  }

  const WS = globalThis.WebSocket || require('ws');
  const ws = new WS(pageTarget.webSocketDebuggerUrl);

  let msgId = 1;
  const pending = new Map();

  function send(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = msgId++;
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, method, params }));
    });
  }

  const errors = [];
  ws.addEventListener('message', (evt) => {
    const data = evt.data;
    const msg = JSON.parse(data);
    if (msg.method === 'Runtime.consoleAPICalled') {
      if (msg.params.type === 'error') {
        const text = msg.params.args.map((a) => a.value || a.description || JSON.stringify(a)).join(' ');
        console.error('Console ERROR:', text);
        errors.push(text);
      }
    }
    if (msg.method === 'Runtime.exceptionThrown') {
      console.error('JS EXCEPTION:', msg.params.exceptionDetails);
      errors.push(JSON.stringify(msg.params.exceptionDetails));
    }
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(msg.error);
      else resolve(msg.result);
    }
  });

  if (ws.readyState !== 1) {
    await new Promise((r) => ws.addEventListener('open', r));
  }
  await send('Runtime.enable');
  await send('Page.enable');

  console.log('Waiting for Vite page to settle...');
  await new Promise((r) => setTimeout(r, 2000));

  // Dispatch custom event to open admin hub: window.dispatchEvent(new CustomEvent('stubilly:open-admin'))
  console.log('Dispatching stubilly:open-admin event...');
  await send('Runtime.evaluate', {
    expression: "window.dispatchEvent(new CustomEvent('stubilly:open-admin'))",
  });

  await new Promise((r) => setTimeout(r, 1200));

  // Check what screen is visible (create admin vs login vs hub)
  let evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const gate = document.querySelector('.admin-gate-overlay') || document.querySelector('.admin-hub-overlay');
      return {
        hasGate: Boolean(gate),
        html: gate ? gate.innerHTML.substring(0, 300) : null,
        title: gate ? gate.querySelector('h2, h1')?.innerText : null
      };
    })()`,
    returnByValue: true,
  });

  console.log('Gate state:', evalRes.result.value);

  // If first admin create form or login form is present, fill it and submit
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      function setReactVal(el, val) {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
        setter.call(el, val);
        el.dispatchEvent(new Event('input', { bubbles: true }));
      }

      const inputs = Array.from(document.querySelectorAll('.admin-gate-card input'));
      if (inputs.length > 0) {
        for (const input of inputs) {
          if (input.placeholder && input.placeholder.includes('Reyes')) {
            setReactVal(input, 'Administrator');
          } else if (input.type === 'password') {
            setReactVal(input, 'password123');
          } else if (input.type === 'text') {
            setReactVal(input, 'admin');
          }
        }
        const submitBtn = document.querySelector('.admin-gate-card button[type="submit"]');
        if (submitBtn) {
          submitBtn.click();
          return 'submitted_form';
        }
      }
      return 'no_form_or_already_hub';
    })()`,
    returnByValue: true,
  });

  console.log('Submit result:', evalRes.result.value);
  await new Promise((r) => setTimeout(r, 2000));

  // Now inspect the Admin Hub
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const hub = document.querySelector('.admin-hub');
      if (!hub) return { open: false };
      const title = hub.querySelector('.admin-hub-title')?.innerText;
      const tabs = Array.from(hub.querySelectorAll('.admin-hub-tab')).map(t => t.innerText.trim());
      const households = Array.from(hub.querySelectorAll('.admin-household-card')).length;
      const students = Array.from(hub.querySelectorAll('.admin-student-item')).length;
      const detail = Boolean(hub.querySelector('.admin-detail-panel'));
      return {
        open: true,
        title,
        tabs,
        households,
        students,
        hasDetail: detail
      };
    })()`,
    returnByValue: true,
  });

  console.log('Admin Hub Status:', evalRes.result.value);

  // Test selecting the first student or guardian
  console.log('Selecting first person in list...');
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const item = document.querySelector('.admin-student-item') || document.querySelector('.admin-guardian-row');
      if (item) {
        item.click();
        return 'clicked';
      }
      return 'not_found';
    })()`,
    returnByValue: true,
  });
  console.log('Select person result:', evalRes.result.value);

  await new Promise((r) => setTimeout(r, 1200));

  // Verify detail panel opened
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const detail = document.querySelector('.admin-detail-panel');
      if (!detail) return { hasDetail: false };
      const name = detail.querySelector('.admin-header-title h2')?.innerText;
      const metrics = Array.from(detail.querySelectorAll('.admin-metric-card')).map(m => ({
        label: m.querySelector('.admin-metric-label')?.innerText,
        val: m.querySelector('.admin-metric-val')?.innerText
      }));
      const subtabs = Array.from(detail.querySelectorAll('.admin-detail-tab')).map(t => t.innerText.trim());
      return {
        hasDetail: true,
        name,
        metrics,
        subtabs
      };
    })()`,
    returnByValue: true,
  });
  console.log('Student Process Detail Panel:', evalRes.result.value);

  // Now switch to Sessions Hub Tab
  console.log('Switching to Sessions Hub tab...');
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const tabBtn = Array.from(document.querySelectorAll('.admin-hub-tab')).find(t => t.innerText.includes('Sessions'));
      if (tabBtn) {
        tabBtn.click();
        return 'clicked';
      }
      return 'tab_not_found';
    })()`,
    returnByValue: true,
  });

  await new Promise((r) => setTimeout(r, 1200));

  // Verify Sessions Hub
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const layout = document.querySelector('.admin-sess-layout');
      if (!layout) return { hasSessionsHub: false };
      const peopleCount = document.querySelectorAll('.admin-sess-person-card').length;
      const banner = document.querySelector('.admin-sess-banner h2')?.innerText;
      const sessionCards = document.querySelectorAll('.admin-session-card').length;
      return {
        hasSessionsHub: true,
        peopleCount,
        revealedPersonName: banner,
        sessionCardsCount: sessionCards
      };
    })()`,
    returnByValue: true,
  });
  console.log('Sessions Hub State:', evalRes.result.value);

  // Test notification bell
  console.log('Testing notification bell...');
  evalRes = await send('Runtime.evaluate', {
    expression: `(() => {
      const bell = document.querySelector('.admin-notif-wrap button');
      if (bell) {
        bell.click();
        const panel = document.querySelector('.admin-notif-panel');
        return { bellClicked: true, panelOpened: Boolean(panel) };
      }
      return { bellClicked: false };
    })()`,
    returnByValue: true,
  });
  console.log('Notification Bell Test:', evalRes.result.value);

  // Switch back to Accounts & Families to screenshot Ready to Assist
  await send('Runtime.evaluate', {
    expression: `(() => {
      const tabBtn = Array.from(document.querySelectorAll('.admin-hub-tab')).find(t => t.innerText.includes('Accounts'));
      if (tabBtn) tabBtn.click();
    })()`,
  });

  await new Promise((r) => setTimeout(r, 600));

  // Select student jin
  await send('Runtime.evaluate', {
    expression: `(() => {
      const item = document.querySelector('.admin-student-item');
      if (item) item.click();
    })()`,
  });

  await new Promise((r) => setTimeout(r, 800));

  const ssAccounts = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('admin_accounts_assist.png', Buffer.from(ssAccounts.data, 'base64'));
  console.log('Saved screenshot to admin_accounts_assist.png');

  // Switch to Sessions Hub tab and screenshot
  await send('Runtime.evaluate', {
    expression: `(() => {
      const tabBtn = Array.from(document.querySelectorAll('.admin-hub-tab')).find(t => t.innerText.includes('Sessions'));
      if (tabBtn) tabBtn.click();
    })()`,
  });

  await new Promise((r) => setTimeout(r, 800));

  const ssSessions = await send('Page.captureScreenshot', { format: 'png' });
  fs.writeFileSync('admin_sessions_hub.png', Buffer.from(ssSessions.data, 'base64'));
  console.log('Saved screenshot to admin_sessions_hub.png');

  console.log('Total console/runtime errors captured:', errors.length);
  if (errors.length > 0) {
    console.error('Errors encountered:', errors);
  }

  // Cleanup
  ws.close();
  child.kill();
  process.exit(errors.length === 0 ? 0 : 1);
}

main().catch((err) => {
  console.error('Test script error:', err);
  process.exit(1);
});
