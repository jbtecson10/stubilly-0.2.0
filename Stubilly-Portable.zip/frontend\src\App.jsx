import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { api, hasConfiguredRemote, getConfiguredRemoteHost, isUsingLocalBackend, getToken, setToken, removeToken } from "./api/client";
import { useFocusSocket } from "./hooks/useFocusSocket";
import { useFocusDetector } from "./hooks/useFocusDetector";
import { useWindowMonitor, extractSiteFromReading } from "./hooks/useWindowMonitor";
import { useActivityTracker } from "./hooks/useActivityTracker";
import { useTabBlocking, normalizeSiteInput } from "./hooks/useTabBlocking";
import { useAlarmSound } from "./hooks/useAlarmSound";
import { usePomodoro } from "./hooks/usePomodoro";
import { useCompanionChat } from "./hooks/useCompanionChat";
import { useServerPolicy } from "./hooks/useServerPolicy";
import { useIdleTracker } from "./hooks/useIdleTracker";
import WebcamPanel from "./components/WebcamPanel";
import AppMonitorBadge from "./components/AppMonitorBadge";
import BlockingBadge from "./components/BlockingBadge";
import HardBlockBadge from "./components/HardBlockBadge";
import HardBlockNotice from "./components/HardBlockNotice";
import CompanionNote from "./components/CompanionNote";
import TaskChecklist from "./components/TaskChecklist";
import SessionSetup from "./components/SessionSetup";
import SessionHistory from "./components/SessionHistory";
import SessionTimer from "./components/SessionTimer";
import SessionSummary from "./components/SessionSummary";
import PomodoroBar from "./components/PomodoroBar";
import AICompanionPanel from "./components/AICompanionPanel";
import NotesPanel from "./components/NotesPanel";
import AuthScreen from "./components/AuthScreen";
import AdminHub from "./components/AdminHub";
import SettingsModal from "./components/SettingsModal";
import ParentDashboard from "./components/ParentDashboard";
import BlockedPage from "./components/BlockedPage";
import "./App.css";

const DEFAULT_POMODORO = { workMinutes: 25, breakMinutes: 5, maxBreaks: 4 };

// "setup" -> "active" -> "summary"
function StudyApp() {
  const [phase, setPhase] = useState("setup");
  const [session, setSession] = useState(null);
  const [finishedSession, setFinishedSession] = useState(null);
  const [starting, setStarting] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [ollamaOnline, setOllamaOnline] = useState(true);
  const [pomodoroConfig, setPomodoroConfig] = useState(DEFAULT_POMODORO);
  const [strictBlockingEnabled, setStrictBlockingEnabled] = useState(false);
  // "No break exceptions"  Esee SessionSetup. When true, the blocklist stays
  // active through breaks too, not just focus blocks.
  const [blockThroughBreaksEnabled, setBlockThroughBreaksEnabled] = useState(false);
  // Auto-block: the first time a site trips the 2-Minute Rule, its domain
  // gets permanently added to the blocklist  Enot just alarmed-and-forgotten.
  const [autoBlockEnabled, setAutoBlockEnabled] = useState(false);
  // Live shutdown: force-closes the offending app/browser outright the
  // moment the off-task timer trips, instead of just alarming/redirecting.
  const [liveKillEnabled, setLiveKillEnabled] = useState(false);
  // The Central Admin Hub is currently open on this machine. While it is,
  // every blocking/enforcement path is suspended so the administrator is
  // never blocked, force-closed, or redirected by the features they govern.
  const [adminActive, setAdminActive] = useState(false);
  // An administrator signed in through the same sign-in form as students (the
  // backend matched their username in the separate administrator table). This
  // never carries a student token  Ethe two account types stay distinct.
  const [adminSession, setAdminSession] = useState(null); // { token, admin }
  useEffect(() => {
    setAdminActive(!!adminSession);
  }, [adminSession]);

  // --- Central admin-hub auth -------------------------------------------
  // authStatus drives the boot gate:
  //   "loading"   -> checking bootstrap / any social sign-in result, briefly
  //   "firstUser" -> server reachable, no accounts yet: registration screen
  //   "legacy"    -> server unreachable: plain local mode
  //   "login"     -> hub exists, no user signed in: show the AuthScreen
  //   "ready"     -> user signed in: run in admin-managed mode
  const [authStatus, setAuthStatus] = useState("loading");
  const [user, setUser] = useState(null);
  // NOTE: the imported client "setToken" (not a React one) persists the
  // session token  Eit must never be shadowed by a useState setter here.
  // Cross-tab social sign-in feedback (from the URL fragment set by the
  // /auth/social callback before the page reloaded).
  const [authError, setAuthError] = useState(null);
  const managed = authStatus === "ready";

  // Signed-in student's preferences (check-in cadence, tone, voice, webcam).
  // Loaded with the account; the Settings modal edits them.
  const [userSettings, setUserSettings] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [tutorialRect, setTutorialRect] = useState(null);

  const TUTORIAL_STEPS = useMemo(() => ([
    {
      selector: '[data-tutorial="task"]',
      title: "Tell Stubilly your task",
      desc: "Type what you are studying (e.g. Algebra II, Biology chapter 5). Stubilly breaks it into small steps.",
    },
    {
      selector: '[data-tutorial="companion"]',
      title: "Pick your study buddy",
      desc: "Choose a companion: Billy (hype coach), Fokus (deep-work guardian), or Shola (patient mentor).",
    },
    {
      selector: '[data-tutorial="start"]',
      title: "Start your session",
      desc: "Stubilly watches your focus and blocks distractions. Use Break anytime: blocks lift while you rest.",
    },
    {
      selector: '[data-tutorial="nav-history"]',
      title: "History & Progress",
      desc: "Under Insights, review your past sessions and see focus analytics, streaks and trends over time.",
    },
    {
      selector: '[data-tutorial="nav-guards"]',
      title: "Focus guards & Companions",
      desc: "Under Manage, tune site blocking rules and switch your AI study buddy anytime.",
    },
    {
      selector: '[data-tutorial="nav-settings"]',
      title: "Settings & Help",
      desc: "Adjust your preferences at the bottom of the sidebar. Need answers? Open Help.",
    },
  ]), []);

  // Companion registry (loaded once) + the active voice-reply toggle.
  const [companions, setCompanions] = useState([]);
  // Voice replies ON by default  Ethe companion should talk by default;
  // the speaker toggle in the chat header still silences it.
  const [voiceRepliesOn, setVoiceRepliesOn] = useState(true);

  // The companion's memory of this student (per-account, server-side).
  // Empty until the student has finished at least one session.
  const [learningProfile, setLearningProfile] = useState(null);

  useEffect(() => {
    let cancelled = false;
    api.listCompanions().then((data) => {
      if (!cancelled && Array.isArray(data?.companions)) setCompanions(data.companions);
    }).catch(() => {});
    return () => { cancelled = true; };
  }, []);

  // Load (and reload on account change) the learning profile so the
  // companion can greet the returning student by name and history.
  useEffect(() => {
    if (!user) {
      setLearningProfile(null);
      return undefined;
    }
    let cancelled = false;
    api.getLearningProfile()
      .then((data) => {
        if (!cancelled) setLearningProfile(data?.learning_profile || null);
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [user]);

  const activeCompanion = useMemo(() => {
    if (!session?.companion_id) return null;
    return companions.find((c) => c.id === session.companion_id) || null;
  }, [session?.companion_id, companions]);

  // Keyboard/mouse idle seconds for the paralysis classifier  Eattached to
  // every focus tick below.
  const getIdleSeconds = useIdleTracker();

  // Decide the mode the moment the app boots: drain any social sign-in result
  // from the URL, then ask the server whether any accounts exist yet.
  useEffect(() => {
    let cancelled = false;

    // Social sign-in returns here as  #social/token=...  (success) or
    // #social/error=... (cancelled / failed). Picked up before anything else
    // and scrubbed from the URL so a plain reload doesn't re-trigger it.
    const hash = window.location.hash || "";
    let m = hash.match(/^#social\/token=([^]*)$/);
    if (m) {
      const tok = decodeURIComponent(m[1]);
      try {
        window.history.replaceState(null, "", window.location.pathname + window.location.search);
      } catch {
        /* replaceState unsupported (file://)  Eharmless */
      }
      setToken(tok);
    } else {
      m = hash.match(/^#social\/error=([^]*)$/);
      if (m) {
        const reason = decodeURIComponent(m[1]);
        setAuthError(
          reason === "cancelled" ? "Sign-in was cancelled." : "Social sign-in didn't complete  Etry again."
        );
        try {
          window.history.replaceState(null, "", window.location.pathname + window.location.search);
        } catch {
          /* harmless */
        }
      }
    }

    api
      .bootstrap()
      .then(async (b) => {
        if (cancelled) return;
        // A stored (or just-arrived) session token always wins: verify it and
        // go straight to "ready". This also covers the social sign-up case on
        // a fresh server  Ebootstrap may still say "no accounts" but the user
        // just made the first one and is holding a valid token for it.
        const stored = getToken();
        if (stored) {
          setToken(stored);
          try {
            const u = await api.me();
            if (cancelled) return;
            setUser(u);
            setAuthStatus("ready");
            return;
          } catch {
            removeToken();
          }
        }
        if (!b.requires_login) {
          // Anything pointed at a central server goes straight to the sign-in
          // screen when there are still no accounts  Eregistration is open to
          // everyone now, so "Set up Stubilly" is just this screen in its
          // create-account-first mode. A true standalone install (no server
          // configured) shows the same registration-first door.
          setAuthStatus(hasConfiguredRemote() ? "login" : "firstUser");
          return;
        }
        setAuthStatus("login");
      })
      .catch(() => {
        if (!cancelled) setAuthStatus("legacy");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  // Live admin policy for the signed-in user. Declared BEFORE useFocusSocket
  // below so a policy_refresh push over the live session can call refresh()
  // without hitting a temporal-dead-zone error on first render.
  const handlePolicyUnauthorized = useCallback(() => {
    // Token vanished mid-session (server restart / forced logout): return
    // to login instead of polling forever on a dead token. Also drop the
    // live session/blocklist so nothing keeps enforcing a policy we can no
    // longer refresh.
    removeToken();
    setToken(null);
    setUser(null);
    setAuthStatus("login");
    setSession(null);
    setFinishedSession(null);
    setPhase("setup");
    setSessionAllowed([]);
    // Clear hosts/tab blocking state that belonged to the old session.
    window.dispatchEvent(new CustomEvent("stubilly:session-ended"));
  }, []);
  const { policy: serverPolicy, refresh: refreshPolicy } = useServerPolicy(
    managed,
    handlePolicyUnauthorized
  );

  // Global 401 from ANY signed-in request (server restarted while a tab
  // sat on the home screen, token expired): sign back in instead of the
  // UI sitting there looking "offline / monitoring unavailable" forever.
  useEffect(() => {
    const onExpired = () => {
      if (!getToken()) return;
      handlePolicyUnauthorized();
      setAuthError("Your session expired  Eplease sign in again.");
    };
    window.addEventListener("stubilly:session-expired", onExpired);
    return () => window.removeEventListener("stubilly:session-expired", onExpired);
  }, [handlePolicyUnauthorized]);

  // Realtime admin policy saves: BlockedNotifier hears the server's
  // {"type":"policy_refresh"} frame on /ws/notifications and rebroadcasts it
  // here. Re-fetch NOW so the block/allow lists  Eincluding the owner's
  // "allowed must be as fast as blocked" ask  Eapply on the spot, not on the
  // next 5s poll. The 5s poll stays as the fallback for a socket that's down.
  useEffect(() => {
    const onPolicy = () => {
      if (managed) refreshPolicy();
    };
    window.addEventListener("stubilly:policy-refresh", onPolicy);
    return () => window.removeEventListener("stubilly:policy-refresh", onPolicy);
  }, [managed, refreshPolicy]);

  // Keep an idle-but-open tab signed in. A student or parent who signs in
  // and then simply leaves the app alone makes no other authenticated
  // request, so the server-side presence window (75s) used to lapse and the
  // next call answered 401 - "Your session expired - please sign in again"
  // - with nobody having signed out. Ping well inside that window, and
  // again the moment the tab is looked at, because a hidden tab has its
  // timers throttled to roughly once a minute. Failures are ignored here;
  // a genuinely dead session is still reported by the next real request.
  useEffect(() => {
    if (!user) return undefined;
    let cancelled = false;
    const ping = () => {
      if (cancelled) return;
      api.keepalive().catch(() => {});
    };
    const onWake = () => {
      if (document.visibilityState === "visible") ping();
    };
    const id = setInterval(ping, 30_000);
    ping();
    document.addEventListener("visibilitychange", onWake);
    window.addEventListener("focus", onWake);
    window.addEventListener("online", ping);
    return () => {
      cancelled = true;
      clearInterval(id);
      document.removeEventListener("visibilitychange", onWake);
      window.removeEventListener("focus", onWake);
      window.removeEventListener("online", ping);
    };
  }, [user]);
  const videoRef = useRef(null);
  const { liveState, lastIntervention, breakInfo, sendFocusEvent, connected } = useFocusSocket(
    session?.id,
    managed ? refreshPolicy : undefined,
    // Backend force-ended this session (parental screen rules  Epause,
    // downtime or a spent daily limit): run the standard end flow. The
    // server already finalized the row, so api.endSession is idempotent.
    (reason) => handleSessionEndByRules(reason)
  );
  const [sessionAllowed, setSessionAllowed] = useState([]);
  const windowMonitor = useWindowMonitor(sessionAllowed);
  // Guardian activity timeline: click/view breadcrumbs while the account
  // has monitoring on (userSettings is null before login ↁEtreated as on,
  // and the server still enforces the real switch on every flush).
  useActivityTracker({
    enabled: managed && userSettings?.monitoring_enabled !== false,
    sessionId: session?.id ?? null,
  });
  const blocking = useTabBlocking();
  const playAlarm = useAlarmSound();
  const pomodoro = usePomodoro(pomodoroConfig);
  // Server-timed breaks: the pomodoro's own timer drives the UI, but every
  // phase change ALSO arms the backend timer. Conversely the backend's
  // break_started / break_ended pushes flip the UI back  Ean admin-granted
  // break, or the server timer expiring while this tab was asleep.
  const prevPomodoroPhaseRef = useRef("work");
  useEffect(() => {
    const prev = prevPomodoroPhaseRef.current;
    const next = pomodoro.phase;
    prevPomodoroPhaseRef.current = next;
    if (!session?.id || prev === next) return;
    if (next === "break") {
      api.startSessionBreak(session.id, pomodoroConfig.breakMinutes ?? 5).catch(() => {
        // Best-effort: the WS on_break tick still arms the fallback timer.
      });
    } else {
      api.endSessionBreak(session.id).catch(() => {
        // Best-effort: server timer expiry still ends it server-side.
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pomodoro.phase, session?.id]);
  useEffect(() => {
    if (!breakInfo) return;
    if (breakInfo.active && pomodoro.phase === "work") pomodoro.takeBreakNow();
    if (!breakInfo.active && pomodoro.phase === "break") pomodoro.endBreakNow();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [breakInfo?.at]);
  // useFocusDetector's interval captures onTick once per startDetection call,
  // not once per render  Eso read live values through refs rather than
  // closing over `windowMonitor`/`pomodoro` directly, or every tick would
  // ship whatever was true when the webcam loop last (re)started.
  const windowMonitorRef = useRef(windowMonitor);
  const pomodoroPhaseRef = useRef(pomodoro.phase);
  useEffect(() => {
    windowMonitorRef.current = windowMonitor;
  }, [windowMonitor]);
  useEffect(() => {
    pomodoroPhaseRef.current = pomodoro.phase;
  }, [pomodoro.phase]);
  const { ready: detectorReady, error: detectorError, startDetection, stopDetection } =
    useFocusDetector(videoRef, {
      // Piggyback the current app/window classification onto the same tick
      // cadence as the webcam reading, so it's one event per row rather than
      // a second independent stream to throttle.
      onTick: (event) => {
        const wm = windowMonitorRef.current;
        sendFocusEvent({
          session_id: session.id,
          ...event,
          // Input-device idle seconds  Ethe paralysis classifier's signal
          // for "stuck" vs "actively doing something else".
          idle_seconds: getIdleSeconds(),
          app_state: wm.available ? (wm.onTask ? "on_task" : "off_task") : null,
          active_app: wm.activeWindow?.appName ?? null,
          // Foreground site for the guardian's "where is my student" card:
          // the window-derived domain in desktop/browser-with-reading mode;
          // the study tab itself when its title says Stubilly (any mode);
          // otherwise the study tab in browser fallback. Other tabs' URLs
          // are unreadable from here  Eblocked-site hits and the backend's
          // own window probe are tracked server-side instead.
          active_site: wm.available
            ? extractSiteFromReading(wm.activeWindow) ||
              (/stubilly/i.test(wm.activeWindow?.title || "") ? "stubilly" : null)
            : document.hasFocus()
              ? "stubilly"
              : null,
          // Named window the student is on right now (precision for parents
          // and the session export  Ewhich window", not just which app/site).
          active_title: wm.available ? (wm.activeWindow?.title ?? null) : null,
          on_break: pomodoroPhaseRef.current === "break",
        });
      },
    });

  // Live admin policy: when the hub controls this machine, keep the
  // block/allow lists in sync with the server, including mid-session.
  // Declared after `windowMonitor`/`blocking`/`stopDetection` above so the
  // hooks below (whose dependency arrays read those values) don't hit a
  // temporal-dead-zone error at first render. The hook itself lives further
  // up (before useFocusSocket) so the WS policy_refresh push can refresh().
  useEffect(() => {
    if (!managed || !serverPolicy) return;
    blocking.replaceBlocklist(serverPolicy.blocked_sites || []);
    windowMonitor.replaceWhitelist(serverPolicy.allowed_sites || []);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [managed, serverPolicy]);

  const handleLogin = useCallback(
    (newToken, u) => {
      setToken(newToken);
      setUser(u);
      setAuthStatus("ready");
      refreshPolicy();
    },
    [refreshPolicy]
  );

  // An administrator signed in through the unified sign-in form. Store the
  // admin token (distinct from any student token) and surface the hub.
  const handleAdminLogin = useCallback((adminToken, adminInfo) => {
    setAdminSession({ token: adminToken, admin: adminInfo });
  }, []);

  // Closing or signing out of the hub just drops the admin session. The token
  // itself is revoked server-side by the hub's Sign out action before this.
  const handleAdminLock = useCallback(() => {
    setAdminSession(null);
  }, []);

  // Re-read the account after a guardian says they've granted consent  E  // /auth/me carries the fresh consent flag, so the waiting screen lifts.
  const recheckConsent = useCallback(async () => {
    try {
      const me = await api.me();
      setUser(me);
    } catch {
      // Token expired etc.  Ethe policy poll handles that case.
    }
    refreshPolicy();
  }, [refreshPolicy]);

  // While a minor waits on guardian consent, poll every few seconds so the
  // screen lifts by itself the moment a guardian  Eor the admin, for an
  // independent (unlinked) account  Egrants monitoring approval.
  useEffect(() => {
    if (!(managed && user?.is_minor && user?.consent_granted !== true)) return undefined;
    const t = setInterval(recheckConsent, 8000);
    return () => clearInterval(t);
  }, [managed, user, recheckConsent]);

  const handleLogout = useCallback(async () => {
    // Close the live session first so the backend logs an accurate logout.
    if (session) {
      stopDetection();
      try {
        await api.endSession(session.id);
      } catch {
        // Best-effort  Elocal teardown below still clears state.
      }
    }
    blocking.clearSessionBlocklistEntries();
    sessionAutoAddedRef.current = new Set();
    setSessionAllowed([]);
    try {
      await api.logout();
    } catch {
      // Best-effort  Etoken is cleared regardless.
    }
    removeToken();
    setToken(null);
    setUser(null);
    setAuthStatus("login");
    setSession(null);
    setFinishedSession(null);
    setPhase("setup");
    // Signed out => no session of ours is live: silence blocked-site alarms
    // on the sign-in screen (the session above was ended just before this).
    window.dispatchEvent(new CustomEvent("stubilly:session-ended"));
  }, [session, blocking, stopDetection]);

  const { messages, notes, tasks: liveTasks, connected: chatConnected, companionTyping, emotion, sendMessage } =
    useCompanionChat(session?.id, session?.tasks);

  // Play a short alarm tone whenever a new urgent intervention comes in
  // (webcam "alarm", or the app-monitoring "app_alarm"/"off_task_block")  E  // but never during a break, since off-task/eyes-closed is expected and
  // allowed there.
  const lastAlarmAtRef = useRef(null);
  useEffect(() => {
    if (!lastIntervention) return;
    const isUrgent = ["alarm", "app_alarm", "off_task_block", "game_warn", "full_block"].includes(lastIntervention.interventionType);
    if (!isUrgent) return;
    if (pomodoro.phase === "break") return;
    if (lastAlarmAtRef.current === lastIntervention.at) return;
    lastAlarmAtRef.current = lastIntervention.at;
    playAlarm();
    // "off_task_block" means repeated nudges didn't work  Eforce Stubilly's
    // window to the front instead of just sounding another alarm the
    // student can keep tabbing past.
    if (lastIntervention.interventionType === "off_task_block") {
      window.stubilly?.bringToFront?.();
    }
    // "full_block" is the 5-minute escalation: close the offending app
    // outright and pull Stubilly forward  Eopening it again just re-triggers
    // the backend's re-close.
    if (lastIntervention.interventionType === "full_block") {
      const aw = windowMonitorRef.current?.activeWindow;
      if (aw && (aw.pid || aw.execPath || aw.appName)) {
        window.stubilly?.forceCloseApp?.({ pid: aw.pid, execPath: aw.execPath, appName: aw.appName });
      }
      window.stubilly?.bringToFront?.();
    }
  }, [lastIntervention, pomodoro.phase, playAlarm]);

  // Auto-block: the moment an off-task site trips the 2-Minute Rule
  // (the "app_alarm" intervention, which fires exactly once per continuous
  // off-task stretch), its domain gets pushed straight into the permanent
  // blocklist  Enot just alarmed once and left reachable. Only meaningful
  // for browser tabs (active-win only reports `url` for supported
  // browsers)  Ea non-browser app has no domain to add. Because
  // useTabBlocking's blocklist effect re-applies to the hosts file
  // immediately whenever it changes and blocking is already on, this
  // takes effect within the same tick the alarm fires  Eno waiting for
  // the next focus block. Once added it's in localStorage like any other
  // blocklist entry, so it stays blocked in every future session too,
  // not just this one.
  const autoBlockedRef = useRef(new Set());
  // Domains auto-added (not manually blocked) during the CURRENT session.
  // Cleared at session end so getting caught on a site once never bans it
  // forever  Eit's only blocked for as long as the session is running.
  const sessionAutoAddedRef = useRef(new Set());
  // Mirrors the active session id so the auto-block effects (whose dep arrays
  // intentionally don't include `session`) can report blocked domains to the
  // right session without stale-closing over it.
  const sessionIdRef = useRef(null);
  useEffect(() => {
    sessionIdRef.current = session?.id ?? null;
  }, [session?.id]);

  // Persists the current session's auto-blocked domains to the backend as
  // they're added. That record is what lets a session (in-progress or
  // finished) re-apply its block-list enforcement when resumed or continued
  // later  Ethe enforcement itself lives in this Electron window, so without
  // this the block set would be lost the moment the app restarts.
  const persistSessionBlockedSites = useCallback((idOverride) => {
    const id = idOverride ?? sessionIdRef.current;
    if (!id) return;
    const sites = [...sessionAutoAddedRef.current];
    api.updateSessionBlockedSites(id, sites).catch(() => {
      // Best-effort  Ethe live blocklist already enforces these right now;
      // this only makes them restorable next time.
    });
  }, []);

  // Same deal for allowances: the current session's temporary allowed sites
  // are recorded on the session so a resumed/continued run re-applies them
  // (the enforcement itself is the live whitelist merge above  Ethis just
  // makes it restorable after an app restart or a later session). `entries`
  // is passed explicitly whenever the caller already knows the post-change
  // list, so the DB never gets a stale snapshot from a pending re-render.
  const persistSessionAllowedSites = useCallback((idOverride, entries) => {
    const id = idOverride ?? sessionIdRef.current;
    if (!id) return;
    const sites = entries ?? [...sessionAllowedRef.current];
    api.updateSessionAllowedSites(id, sites).catch(() => {
      // Best-effort  Esame reasoning as blocked sites.
    });
  }, []);
  // Mirrors `sessionAllowed` state so persist can read the latest list from
  // any callback without closing over a stale render.
  const sessionAllowedRef = useRef([]);
  useEffect(() => {
    sessionAllowedRef.current = sessionAllowed;
  }, [sessionAllowed]);
  useEffect(() => {
    if (!lastIntervention) return;
    if (lastIntervention.interventionType !== "app_alarm") return;
    if (adminActive) return;
    if (!strictBlockingEnabled || (!autoBlockEnabled && !liveKillEnabled)) return;
    // URL is the reliable source, but on Windows active-win reports none  E    // fall back to a domain embedded in the window title when available.
    const domain = extractSiteFromReading(windowMonitorRef.current?.activeWindow);
    if (!domain || autoBlockedRef.current.has(domain)) return;
    // Allowed sites are never auto-blocked  Ean explicit allow wins
    // (it also stays as the way to un-block a site that did get added).
    if (isDomainWhitelisted(domain, windowMonitorRef.current?.effectiveWhitelist)) return;
    addSessionBan(domain);
  }, [lastIntervention, adminActive, autoBlockEnabled, liveKillEnabled, strictBlockingEnabled]); // eslint-disable-line react-hooks/exhaustive-deps

  // Real-time auto-block: while a session is active with strict blocking +
  // auto-block on, the moment the foreground window is an off-task browser
  // (not whitelisted/exempt) on an extractable site, its domain is pushed
  // into the blocklist immediately  Eno 2-minute grace period, no double
  // confirmation poll. useTabBlocking re-applies that to the hosts file at
  // once, and main.cjs's instant blocked-domain path (armed below)
  // force-closes just that site's window so established connections can't
  // keep it alive. It's a session ban: enforced for the rest of this
  // session, then released automatically when the session ends.
  const offTaskSeenRef = useRef({ domain: null, count: 0 });
  useEffect(() => {
    if (phase !== "active" || adminActive || !strictBlockingEnabled || !autoBlockEnabled) return;
    if (pomodoro.phase === "break" && !blockThroughBreaksEnabled) return;
    const wm = windowMonitor;
    if (!wm?.activeWindow || wm.onTask) {
      offTaskSeenRef.current = { domain: null, count: 0 };
      return;
    }
    const domain = extractSiteFromReading(wm.activeWindow);
    if (!domain) {
      offTaskSeenRef.current = { domain: null, count: 0 };
      return;
    }
    const prev = offTaskSeenRef.current;
    if (prev.domain === domain) prev.count += 1;
    else offTaskSeenRef.current = { domain, count: 1 };
    // Single off-task reading is enough: the window monitor already polls
    // living-fast (800ms), and every blocked/whitelisted window is filtered
    // before this ever sees a domain. Auto-block is opt-in and a site that
    // gets added is removable  Espeed is the point, so we don't make the
    // student wait a second confirmation poll.
    if (offTaskSeenRef.current.count < 1) return;
    const alreadyInList = (blocking.blocklist || []).some((e) => e.toLowerCase() === domain);
    if (!alreadyInList) addSessionBan(domain);
    offTaskSeenRef.current = { domain, count: 0 };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [windowMonitor.activeWindow, windowMonitor.onTask, phase, pomodoro.phase, adminActive, strictBlockingEnabled, autoBlockEnabled, blockThroughBreaksEnabled]);

  // Arms the main-process auto-kill: once a domain is in the active blocked
  // set, the first poll where it's the foreground browser URL closes that
  // window/app outright (PID tree kill)  Ethe only thing that defeats the
  // hosts-file's blind spot (already-open connections + browser DNS cache).
  // Armed whenever strict blocking is on (not gated on auto-block), so a
  // site added to the blocklist manually mid-session is also enforced live.
  useEffect(() => {
    const armed =
      phase === "active" &&
      !adminActive &&
      strictBlockingEnabled &&
      (pomodoro.phase === "work" || blockThroughBreaksEnabled);
    window.stubilly?.setAutoKill?.(armed);
  }, [phase, pomodoro.phase, adminActive, strictBlockingEnabled, blockThroughBreaksEnabled]); // eslint-disable-line react-hooks/exhaustive-deps

  // Live shutdown: the moment the 2-minute off-task timer trips
  // ("app_alarm"), force-close the offending app/browser outright instead
  // of just alarming and redirecting. This is a real `taskkill`  Esee
  // main.cjs for the hardcoded protected-process list (terminals,
  // Explorer, Stubilly itself always refused there regardless of what's
  // sent). Runs alongside auto-block/bring-to-front, not instead of them  E  // closing the app also handles anything bring-to-front alone couldn't
  // (a fullscreen game, a second monitor) since there's simply nothing
  // left running to compete for focus.
  const liveKilledRef = useRef(new Set());
  useEffect(() => {
    if (!lastIntervention) return;
    const killType = lastIntervention.interventionType;
    if (killType !== "app_alarm" && killType !== "full_block") return;
    if (adminActive) return;
    // full_block is the backend's 5-minute hard escalation  Ealways closes,
    // even when the opt-in Live Kill toggle is off.
    if (killType === "app_alarm" && (!liveKillEnabled || !strictBlockingEnabled)) return;
    const aw = windowMonitorRef.current?.activeWindow;
    if (!aw || (!aw.pid && !aw.execPath)) return;
    const key = aw.execPath || aw.pid;
    if (liveKilledRef.current.has(key)) return;
    liveKilledRef.current.add(key);
    window.stubilly?.forceCloseApp?.({ pid: aw.pid, execPath: aw.execPath, appName: aw.appName });
    // Live shutdown must do exactly what the spec says: the moment a blocked
    // site/app is detected, transport the student back to Stubilly and put a
    // "focus" notification on screen  Enot just silently close the app.
    window.stubilly?.bringToFront?.();
    setHardBlockEvent({ label: aw.appName || "that app", receivedAt: Date.now() });
  }, [lastIntervention, adminActive, liveKillEnabled, strictBlockingEnabled]); // eslint-disable-line react-hooks/exhaustive-deps

  // Fresh Pomodoro cycle each time a new session starts (config may repeat
  // the same defaults, so this can't rely on the config object changing).
  useEffect(() => {
    if (session?.id) pomodoro.resetCycle();
  }, [session?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // Pause the countdown outside of an active session.
  useEffect(() => {
    pomodoro.setRunning(phase === "active");
  }, [phase]); // eslint-disable-line react-hooks/exhaustive-deps

  // Strict site blocking tracks work/break automatically: on during focus
  // blocks (if the student opted in at setup), off on break or once the
  // session ends  Eunless "no break exceptions" was also enabled, in which
  // case it stays on for the whole session, breaks included, and only
  // lifts once the session actually ends. Guarded against firing
  // repeatedly for the same target, since each call can trigger a real OS
  // permission prompt.
  const blockTargetRef = useRef(false);
  useEffect(() => {
    const shouldBlock =
      phase === "active" &&
      !adminActive &&
      strictBlockingEnabled &&
      (pomodoro.phase === "work" || blockThroughBreaksEnabled);
    if (shouldBlock === blockTargetRef.current) return;
    blockTargetRef.current = shouldBlock;
    if (shouldBlock) blocking.enable();
    else blocking.disable();
  }, [phase, pomodoro.phase, adminActive, strictBlockingEnabled, blockThroughBreaksEnabled]); // eslint-disable-line react-hooks/exhaustive-deps

  // Fixed hard-block policy  ESteam, Facebook, Instagram,
  // Twitter/X, Snapchat, WhatsApp, Telegram (see
  // electron/hard-block.cjs). Messenger is intentionally NOT on this fixed
  // list  Eit stays accessible unless a student/admin adds it to the
  // editable blocklist. Always on whenever a session is active, on
  // the SAME work/break timing as the custom blocklist above, but NOT
  // gated on strictBlockingEnabled or liveKillEnabled  Ethis fixed list
  // applies automatically whether or not the student opted into either of
  // those. This is what makes it "realtime automatic": no checkbox, no
  // 2-minute grace period, live from the moment the session starts.
  const hardBlockTargetRef = useRef(false);
  const [hardBlockActive, setHardBlockActiveState] = useState(false);
  useEffect(() => {
    const shouldHardBlock =
      phase === "active" && !adminActive && (pomodoro.phase === "work" || blockThroughBreaksEnabled);
    if (shouldHardBlock === hardBlockTargetRef.current) return;
    hardBlockTargetRef.current = shouldHardBlock;
    window.stubilly?.setHardBlockActive?.(shouldHardBlock).then((result) => {
      setHardBlockActiveState(Boolean(result?.active));
    });
  }, [phase, pomodoro.phase, adminActive, blockThroughBreaksEnabled]);

  // Keep the main process's allow-list in sync with the whitelist whenever
  // it changes (including the default list on first load). Sends the merged
  // "effective" view  Ethe global whitelist PLUS the current session's
  // temporary allowances  Eso a site allowed mid-session is excluded from
  // the blocklist, the hosts file, and the instant blocked-domain/kill path
  // on the same tick. Whitelisted domains are genuinely safe to access even
  // if they're also in the blocklist.
  useEffect(() => {
    window.stubilly?.setWhitelist?.(windowMonitor.effectiveWhitelist);
  }, [windowMonitor.effectiveWhitelist]); // eslint-disable-line react-hooks/exhaustive-deps

  // Bans a site for the CURRENT session: added to the live blocklist (so it's
  // enforced right now), recorded on the session (so a resume re-applies it),
  // and  Ebecause it goes in as a session ban, not a persistent entry  Eit
  // lifts automatically when the session ends and never shows up in future
  // sessions or after an app restart.
  function addSessionBan(raw) {
    const value = normalizeSiteInput(raw);
    if (!value) return;
    sessionAutoAddedRef.current.add(value);
    autoBlockedRef.current.add(value);
    blocking.addSessionBlocklistEntry(value);
    persistSessionBlockedSites();
  }

  // Blocking a site mid-session must actually block it: if the domain is
  // ALSO on the allow-list, drop it there first  Ethe allow-list winning
  // over the blocklist is by design, but it must never silently swallow an
  // explicit "block this" from the student. Exact normalized matches only,
  // so a broad "google.com" allow entry is left alone (docs/drive/etc stay
  // allowed); leaving that broader entry intact means the block still can't
  // beat it, which is the expected "allow wins" behavior.
  function handleAddBlockedSite(raw) {
    const value = normalizeSiteInput(raw);
    if (!value) return;
    const exact = windowMonitor.whitelist.find(
      (entry) => entry.toLowerCase() === value.toLowerCase()
    );
    if (exact) windowMonitor.removeWhitelistEntry(exact);
    // An exact session allowance is dropped too, so "block this" always wins
    // over a same-session "allow this"  Enever silently swallowed.
    if (sessionAllowed.some((entry) => entry.toLowerCase() === value.toLowerCase())) {
      const next = sessionAllowed.filter((entry) => entry.toLowerCase() !== value.toLowerCase());
      setSessionAllowed(next);
      persistSessionAllowedSites(undefined, next);
    }
    addSessionBan(value);
  }

  // Matches main.cjs's exclusion rule so "allow" stays consistent across
  // the renderer and the hosts/instant-kill paths: a domain is allowed when
  // it IS a whitelist entry or lives under one (docs.google.com under
  // google.com stays allowed).
  function isDomainWhitelisted(domain, whitelist) {
    return (whitelist || []).some((raw) => {
      const w = normalizeSiteInput(raw);
      return w && (domain === w || domain.endsWith("." + w));
    });
  }

  // Instant reaction to a hard-block hit. By the time this fires, the main
  // process has already force-closed the app (if it's a native one like
  // Steam/WhatsApp) and pulled Stubilly's window to the front  E  // this just makes that moment visible and audible: an alarm, plus the
  // actual on-screen "stay focused" notification (HardBlockNotice below),
  // not just a silent redirect.
  const [hardBlockEvent, setHardBlockEvent] = useState(null);
  useEffect(() => {
    if (!window.stubilly?.onHardBlockTriggered) return;
    return window.stubilly.onHardBlockTriggered((data) => {
      playAlarm();
      setHardBlockEvent({ ...data, receivedAt: Date.now() });
    });
  }, [playAlarm]);

  useEffect(() => {
    api.health().then((h) => setOllamaOnline(h.ollama)).catch(() => setOllamaOnline(false));
  }, []);

  // Student settings (check-in interval / tone / voice / webcam)  Ethe
  // INPUT-preferences layer. Fetched with the signed-in account; failures
  // just leave the server defaults in place.
  useEffect(() => {
    if (!managed) {
      setUserSettings(null);
      return;
    }
    let cancelled = false;
    api
      .getSettings()
      .then((s) => {
        if (!cancelled) setUserSettings(s);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [managed]);

  // First-time user tutorial: only NEWLY created accounts (tutorial_seen=false
  // from the server) get the coach-marks, and only once. Finishing or skipping
  // flips the flag server-side so it never reappears on any browser. Legacy
  // accounts that predate the column arrive with tutorial_seen=true and never
  // see it.
  useEffect(() => {
    if (!managed || !user) return;
    if (user.tutorial_seen === false) {
      setShowTutorial(true);
      setTutorialStep(0);
    }
  }, [managed, user]);

  // Track the highlighted element's viewport rect for the coach-mark spotlight.
  useEffect(() => {
    if (!showTutorial) { setTutorialRect(null); return undefined; }
    const step = TUTORIAL_STEPS[tutorialStep];
    if (!step) { setTutorialRect(null); return undefined; }
    let raf;
    const measure = () => {
      const el = document.querySelector(step.selector);
      if (!el) { setTutorialRect(null); return; }
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      raf = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect();
        setTutorialRect({ top: r.top, left: r.left, width: r.width, height: r.height });
      });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", measure); };
  }, [showTutorial, tutorialStep, TUTORIAL_STEPS]);

  useEffect(() => {
    if (phase === "active" && detectorReady && connected) {
      startDetection();
      return stopDetection;
    }
  }, [phase, detectorReady, connected]); // eslint-disable-line react-hooks/exhaustive-deps

  // Webcam-free focus line: if the camera never initialised (denied or no
  // device) but a window monitor is available, keep the ENTIRE focus stream
  // alive with derived ticks  Esame leaderboard/guardian/progress output as
  // the webcam path, just sourced from the active window instead of a face.
  // "precise + realtime" holds with or without a camera: on/off-task commits
  // within a couple of window-readings (~2-8s, see useWindowMonitor's
  // debounce) and parents still see which window/site the student is on.
  useEffect(() => {
    if (
      phase !== "active" ||
      !connected ||
      detectorReady ||
      !windowMonitorRef.current.available
    ) {
      return undefined;
    }
    const t = setInterval(() => {
      const wm = windowMonitorRef.current;
      if (phase !== "active") return;
      sendFocusEvent({
        session_id: session.id,
        state: wm.onTask ? "focused" : "distracted",
        confidence: 0.5,
        face_detected: false,
        idle_seconds: getIdleSeconds(),
        app_state: wm.available ? (wm.onTask ? "on_task" : "off_task") : null,
        active_app: wm.activeWindow?.appName ?? null,
        active_site: wm.available
          ? extractSiteFromReading(wm.activeWindow) ||
            (/stubilly/i.test(wm.activeWindow?.title || "") ? "stubilly" : null)
          : document.hasFocus()
            ? "stubilly"
            : null,
        active_title: wm.available ? (wm.activeWindow?.title ?? null) : null,
        on_break: pomodoroPhaseRef.current === "break",
      });
    }, 1200);
    return () => clearInterval(t);
  }, [phase, connected, detectorReady, session, sendFocusEvent]);

  async function handleStart(taskDescription, config, microtasksFromSessionId, carriedBlockedSites = [], carriedAllowedSites = [], meta = null) {
    setStarting(true);
    try {
      // In managed mode, grab the latest published policy right before the
      // timer starts so enforcement begins on the freshest admin-approved
      // list (the ongoing poll keeps it fresh mid-session afterwards).
      if (managed) await refreshPolicy();
      // Declared academic task (INPUT): subject / deadline / priority. Setup
      // hands it inside `config.taskMeta`; resume/continue/study-again pass
      // `meta` explicitly (carried over from the source session).
      const taskMeta = meta ?? config?.taskMeta ?? null;
      const newSession = await api.startSession(taskDescription, microtasksFromSessionId, taskMeta || {});
      setPomodoroConfig(config ?? DEFAULT_POMODORO);
      setStrictBlockingEnabled(Boolean(config?.strictBlocking));
      setBlockThroughBreaksEnabled(Boolean(config?.strictBlocking && config?.blockThroughBreaks));
      setAutoBlockEnabled(Boolean(config?.strictBlocking && config?.autoBlock));
      setLiveKillEnabled(Boolean(config?.strictBlocking && config?.liveKill));
      autoBlockedRef.current = new Set();
      liveKilledRef.current = new Set();
      offTaskSeenRef.current = { domain: null, count: 0 };
      blocking.clearSessionBlocklistEntries();
      // Re-apply the source session's block-list enforcement to this run:
      // the domains that were blocked during the continued/re-studied session
      // stay blocked here too, and are lifted when THIS session ends.
      sessionAutoAddedRef.current = new Set(carriedBlockedSites);
      carriedBlockedSites.forEach((domain) => blocking.addSessionBlocklistEntry(domain));
      if (carriedBlockedSites.length > 0) persistSessionBlockedSites(newSession.id);
      // Re-apply the source session's allowances the same way: they stream
      // into the whitelist the main process enforces (overriding the
      // blocklist + Live Shutdown), and lift when THIS session ends.
      setSessionAllowed(carriedAllowedSites);
      sessionAllowedRef.current = carriedAllowedSites;
      if (carriedAllowedSites.length > 0) persistSessionAllowedSites(newSession.id, carriedAllowedSites);
      setSession(newSession);
      setPhase("active");
      // A student who lost the race for the AI (a whole class pressing Start in
      // the same second) started on a stand-in step so they were not left
      // watching a spinner. The server rewrites that step with the real
      // breakdown in place a moment later - fetch it here so the task list
      // fills itself in without the student doing anything.
      if (newSession.tasks?.some((t) => t.is_placeholder)) pollForRealPlan(newSession.id);
      // Blocking/intervention is a mid-session feature: tell BlockedNotifier
      // (mounted outside App) that this account now runs a live session, so
      // blocked-site alarms are allowed from here until End Session.
      window.dispatchEvent(new CustomEvent("stubilly:session-started"));
    } catch (e) {
      alert(`Couldn't start session  Eis the backend running? (${e.message})`);
    } finally {
      setStarting(false);
    }
  }

  // Pick up the AI task breakdown that was still being written when the
  // session started. Only ever runs for the stand-in-step path, gives up
  // after ~24s (the server gives up writing it long before that), and never
  // touches anything but the task list of the still-running session.
  async function pollForRealPlan(sessionId, attempt = 0) {
    if (attempt >= 6) return;
    await new Promise((r) => setTimeout(r, 4000));
    try {
      const full = await api.getSession(sessionId);
      const waiting = full?.tasks?.some((t) => t.is_placeholder);
      if (waiting) {
        pollForRealPlan(sessionId, attempt + 1);
        return;
      }
      setSession((cur) => (cur && cur.id === full.id ? { ...cur, ...full } : cur));
    } catch {
      /* offline: the next ordinary refresh shows the real plan */
    }
  }

  // Force-ended by the backend's parental screen rules (guardian pause,
  // downtime window or daily limit reached). The intervention frame that
  // precedes this one already showed WHY on screen; here we run the
  // standard end flow  Eapi.endSession is idempotent when the row is
  // already finalized, and the summary then shows the server's totals.
  async function handleSessionEndByRules(reason) {
    if (!session || phase !== "active") return; // already ending/ended
    stopDetection();
    let ended = null;
    try {
      ended = await api.endSession(session.id);
    } catch {
      /* server just finalized it  Efall through and keep the UI honest */
    }
    blocking.clearSessionBlocklistEntries();
    sessionAutoAddedRef.current = new Set();
    try {
      await window.stubilly?.liftBlocking?.();
    } catch {
      /* desktop-only lift; hosts were already re-asserted server-side */
    }
    setSessionAllowed([]);
    if (!ended) {
      // Can't reach the backend at all: leave the phase alone so the
      // student can hit End Session manually  Ethe reason still shows.
      alert(reason || "Session ended by parental controls.");
      return;
    }
    setFinishedSession(ended);
    setPhase("summary");
    window.dispatchEvent(new CustomEvent("stubilly:session-ended"));
  }

  async function handleEnd() {
    stopDetection();
    // The backend occasionally blips (e.g. it was just (re)started)  Eone
    // short retry makes "end session" survive that instead of showing
    // "Failed to fetch".
    let ended = null;
    for (let attempt = 0; attempt < 2 && !ended; attempt++) {
      try {
        ended = await api.endSession(session.id);
      } catch (e) {
        if (attempt === 1) {
          alert(`Couldn't end session cleanly: ${e.message}`);
          return;
        }
        await new Promise((r) => setTimeout(r, 1200));
      }
    }
    // Release every session-scoped ban: sites added during THIS session
    // (manually, by auto-block, or carried in from a continued/resumed
    // session) drop out of the blocklist now. They're not written to
    // storage, so they won't be enforced again in a future session or
    // after a restart. The persistent base list is untouched.
    blocking.clearSessionBlocklistEntries();
    sessionAutoAddedRef.current = new Set();
    // Definitive lift of EVERYTHING at the OS level (hosts file + hard-block
    // process killer + custom list), verified. This is what guarantees the
    // banned/blocked apps open again the moment the session ends  Enothing
    // persists outside a session. If the admin approval for the hosts
    // restore was declined or timed out, say so plainly instead of leaving
    // the student silently blocked.
    try {
      const lift = await window.stubilly?.liftBlocking?.();
      if (lift && lift.stillBlocked) {
        alert(
          "Sites are still blocked because the Windows admin prompt for lifting " +
            "the block wasn't approved. Click Yes when it appears, then reopen " +
            "whatever was blocked  Enothing stays blocked outside a session."
        );
      }
    } catch {
      // lift failed entirely (IPC error)  Ethe reconciler's disable below
      // still runs and the on-screen banner will match whatever it found.
    }
    // Lift the session's temporary allowances too  Ethey only ever apply to
    // one run, never to future sessions or after a restart.
    setSessionAllowed([]);
    setFinishedSession(ended);
    setPhase("summary");
    // The session is over: blocking/intervention switches off with it  E    // BlockedNotifier drops its alarm gate immediately (re-verified against
    // /sessions, which now reports no open row).
    window.dispatchEvent(new CustomEvent("stubilly:session-ended"));
  }

  function handleNewSession() {
    setSession(null);
    setFinishedSession(null);
    setPhase("setup");
  }

  // "Study again" from the past-sessions view: if a session is somehow still
  // active, finalize it first (so no orphaned "In progress" sessions), then
  // start a fresh session on the same task with default Pomodoro settings.
  // Everything about the previous run (its chat transcript, notes, microtasks)
  // stays stored under its own session, so both are kept side by side. The
  // source session's blocked domains are carried over so revisiting a
  // finished session keeps the same sites enforced during the new run.
  async function handleStudyAgain(sourceSession) {
    setShowHistory(false);
    if (session) {
      stopDetection();
      try {
        await api.endSession(session.id);
      } catch {
        // Backend auto-finalizes any open session on the next /start anyway.
      }
    }
    await handleStart(sourceSession.task_description, undefined, undefined, sourceSession.blocked_sites || [], sourceSession.allowed_sites || [], {
      subject: sourceSession.subject || null,
      deadline: sourceSession.deadline || null,
      priority: sourceSession.priority || null,
    });
  }

  // "Continue with saved steps" from the history view: starts a NEW session
  // on the same task but reuses the saved micro-task checklist (with its
  // completion flags) from the previous run, so the student picks up their
  // saved process instead of getting a brand-new breakdown. The original
  // session stays untouched in history as a permanent reference. The source
  // session's blocked domains are carried over to the new run.
  async function handleContinueSession(contSession) {
    setShowHistory(false);
    if (session) {
      stopDetection();
      try {
        await api.endSession(session.id);
      } catch {
        // Backend auto-finalizes any open session on the next /start anyway.
      }
    }
    await handleStart(contSession.task_description, undefined, contSession.id, contSession.blocked_sites || [], contSession.allowed_sites || [], {
      subject: contSession.subject || null,
      deadline: contSession.deadline || null,
      priority: contSession.priority || null,
    });
  }

  // "Resume session" from the history view: reopens an In-Progress session
  // as-is  Esame saved task checklist, same chat/notes, and the same
  // block-list enforcement that was in effect when it was interrupted
  // (recorded on the session, so it survives an app restart). If the backend
  // finalized it meanwhile (e.g. another session was started in between),
  // fall back to continuing it with its saved steps instead.
  async function handleResumeInProgress(sessionId) {
    setShowHistory(false);
    if (session) {
      stopDetection();
      try {
        await api.endSession(session.id);
      } catch {
        // Backend auto-finalizes any open session on the next /start anyway.
      }
    }
    let full;
    try {
      full = await api.getSession(sessionId);
    } catch (e) {
      alert(`Couldn't resume session: ${e.message}`);
      return;
    }
    if (full.ended_at) {
      await handleContinueSession(full);
      return;
    }
    setPomodoroConfig(DEFAULT_POMODORO);
    setStrictBlockingEnabled(true);
    setBlockThroughBreaksEnabled(false);
    // Managed mode: the admin owns the block/allow lists  Ethe student's
    // auto-block behavior (which edits the permanent list) stays off.
    setAutoBlockEnabled(!managed);
    autoBlockedRef.current = new Set();
    liveKilledRef.current = new Set();
    offTaskSeenRef.current = { domain: null, count: 0 };
    blocking.clearSessionBlocklistEntries();
    // Re-apply this session's recorded block-list enforcement.
    sessionAutoAddedRef.current = new Set(full.blocked_sites || []);
    sessionAutoAddedRef.current.forEach((domain) => blocking.addSessionBlocklistEntry(domain));
    // Re-apply this session's recorded allowances the same way.
    setSessionAllowed(full.allowed_sites || []);
    sessionAllowedRef.current = full.allowed_sites || [];
    if ((full.allowed_sites || []).length > 0) persistSessionAllowedSites(full.id, full.allowed_sites);
    setSession(full);
    setPhase("active");
  }

  // The administration hub renders on top of the sign-in screens once an
  // administrator has signed in through the unified form.
  const adminHub = adminSession ? (
    <AdminHub
      adminToken={adminSession.token}
      admin={adminSession.admin}
      onLock={handleAdminLock}
      onClose={handleAdminLock}
    />
  ) : null;

  // Clear self-healing status while the app is pointed at a central server
  // but currently stuck on its own local backend (server offline, rebooting,
  // or not on the network yet)  Eshown over the sign-in screens.
  const serverNotice = hasConfiguredRemote() && isUsingLocalBackend() ? (
    <div className="app-banner">
      Can't reach the Stubilly server ({getConfiguredRemoteHost()}) yet  Eretrying automatically…
    </div>
  ) : null;

  // Boot gate: briefly ask the server whether this deployment has accounts.
  if (authStatus === "loading") {
    return (
      <>
        <div className="setup-screen">
          <div className="setup-card">
            <p className="setup-subtitle">Checking Stubilly…</p>
          </div>
        </div>
      </>
    );
  }

  // Admin-managed deployment, not signed in yet.
  if (authStatus === "login") {
    return (
      <>
        {authError && <div className="app-banner">{authError}</div>}
        <AuthScreen
          onLogin={handleLogin}
          onAdminLogin={handleAdminLogin}
          backendLabel={isUsingLocalBackend() ? null : getConfiguredRemoteHost()}
        />
        {serverNotice}
        {adminHub}
      </>
    );
  }

  // Fresh deployment  Eno accounts exist yet, so land on the registration
  // screen (create-account tab selected). Registration is always open, so
  // this is the same AuthScreen with a different default tab.
  if (authStatus === "firstUser") {
    return (
      <>
        {authError && <div className="app-banner">{authError}</div>}
        <AuthScreen
          onLogin={handleLogin}
          onAdminLogin={handleAdminLogin}
          backendLabel={isUsingLocalBackend() ? null : getConfiguredRemoteHost()}
          firstRun
        />
        {serverNotice}
        {adminHub}
      </>
    );
  }

  // Guardian accounts land on the parent dashboard  Ethey never run a focus
  // session of their own (role boundary is enforced server-side too).
  if (managed && user?.role === "parent") {
    return (
      <>
        <ParentDashboard user={user} setUser={setUser} onLogout={handleLogout} />
      </>
    );
  }

  // Fallback: if somehow a non-parent user lands on parent dashboard (e.g. role
  // mismatch after a role change), treat them as a student by default and
  // surface a one-line notice  Ederived during render, never setState-in-render.
  const unknownRoleNotice =
    managed && user?.role !== "parent" && user?.role !== "student"
      ? "Your account role is not set correctly. Please contact an administrator."
      : null;

  // Minor without a guardian's monitoring consent: the server would reject
  // the session anyway  Esay so up front instead of failing at Start.
  const needsConsent = managed && user?.is_minor && user?.consent_granted !== true;

  if (phase === "setup") {
    return (
      <>
        {unknownRoleNotice && <div className="app-banner">{unknownRoleNotice}</div>}
        {needsConsent ? (
          <div className="setup-screen">
            <div className="setup-card">
              <h1 className="setup-title">Waiting for guardian approval</h1>
              <p className="setup-subtitle">
                Stubilly needs a parent or guardian to approve monitoring before a session can
                start on this account. Ask them to sign in and grant consent  Eor, if this is an
                independent account with no guardian, ask an administrator to grant consent in the
                Admin Hub. You'll be able to focus as soon as it's granted.
              </p>
              <div className="setup-actions">
                <button className="btn-secondary" onClick={recheckConsent}>
                  I've been approved  Ere-check
                </button>
                <button className="btn-text" onClick={handleLogout}>
                  Sign out
                </button>
              </div>
            </div>
          </div>
        ) : (
          <SessionSetup
            onStart={handleStart}
            starting={starting}
            ollamaOnline={ollamaOnline}
            managed={managed}
            user={user}
            policy={serverPolicy}
            onLogout={handleLogout}
            onStudyAgain={handleStudyAgain}
            onContinue={handleContinueSession}
            onResumeInProgress={handleResumeInProgress}
            onOpenSettings={() => setShowSettings(true)}
            settings={userSettings}
            onSettingsSaved={setUserSettings}
          />
        )}
        {showHistory && (
          <SessionHistory onClose={() => setShowHistory(false)} onStudyAgain={handleStudyAgain} onContinue={handleContinueSession} onResumeInProgress={handleResumeInProgress} />
        )}
        {showSettings && (
          <SettingsModal
            settings={userSettings}
            onClose={() => setShowSettings(false)}
            onSaved={setUserSettings}
          />
        )}
                {showTutorial && (() => {
          const step = TUTORIAL_STEPS[tutorialStep];
          const isLast = tutorialStep >= TUTORIAL_STEPS.length - 1;
          const isFirst = tutorialStep <= 0;
          const finish = () => {
            setShowTutorial(false);
            // Flip the server flag so this account never sees the tutorial
            // again on any browser. Best-effort: if the call fails the local
            // user state still hides it for this session.
            api.tutorialSeen().catch(() => {});
            setUser((u) => (u ? { ...u, tutorial_seen: true } : u));
          };
          const advance = () => { if (isLast) finish(); else setTutorialStep((v) => v + 1); };
          const goBack = () => { if (!isFirst) setTutorialStep((v) => v - 1); };
          // Popup position: below the target by default, above if near bottom.
          let popTop = 0, popLeft = 0, popPos = "bottom", arrowLeft = 0;
          if (tutorialRect) {
            const POP_W = 320, GAP = 16, POP_H = 175;
            popLeft = Math.max(16, Math.min(tutorialRect.left, window.innerWidth - POP_W - 16));
            if (tutorialRect.top + tutorialRect.height + GAP + POP_H < window.innerHeight) {
              popTop = tutorialRect.top + tutorialRect.height + GAP;
              popPos = "bottom";
            } else {
              popTop = Math.max(16, tutorialRect.top - GAP - POP_H);
              popPos = "top";
            }
            // Arrow points at the target's horizontal center, clamped inside the popup.
            const targetCx = tutorialRect.left + tutorialRect.width / 2;
            arrowLeft = Math.max(18, Math.min(targetCx - popLeft - 7, POP_W - 36));
          }
          return (
            <>
              {/* Dimmed backdrop (click-through) */}
              <div style={{ position: "fixed", inset: 0, zIndex: 999, background: "rgba(15,23,42,0.55)" }} />
              {/* Spotlight ring around the active target */}
              {tutorialRect && (
                <div
                  style={{
                    position: "fixed", zIndex: 1001, pointerEvents: "none",
                    top: tutorialRect.top - 5, left: tutorialRect.left - 5,
                    width: tutorialRect.width + 10, height: tutorialRect.height + 10,
                    borderRadius: 10,
                    boxShadow: "0 0 0 4px #f59e0b, 0 0 24px rgba(245,158,11,0.45)",
                    transition: "top 0.3s ease, left 0.3s ease, width 0.3s ease, height 0.3s ease",
                  }}
                />
              )}
              {/* Small opaque coach-mark card */}
              <div
                style={{
                  position: "fixed", zIndex: 1002,
                  top: tutorialRect ? popTop : "40%", left: tutorialRect ? popLeft : "50%",
                  transform: tutorialRect ? "none" : "translateX(-50%)",
                  width: 320, maxWidth: "calc(100vw - 32px)",
                  background: "#fef9ee", borderRadius: 14,
                  boxShadow: "0 12px 40px rgba(0,0,0,0.35)",
                  padding: "18px 20px 16px", fontFamily: "inherit",
                }}
              >
                {/* Arrow pointing at the target */}
                {tutorialRect && (
                  <div
                    style={{
                      position: "absolute", width: 14, height: 14,
                      background: "#fef9ee", transform: "rotate(45deg)",
                      ...(popPos === "bottom"
                        ? { top: -7, left: arrowLeft }
                        : { bottom: -7, left: arrowLeft }),
                    }}
                  />
                )}
                {/* Close / Skip */}
                <button
                  aria-label="Skip tutorial"
                  onClick={finish}
                  style={{
                    position: "absolute", top: 8, right: 8, width: 28, height: 28,
                    border: "none", background: "transparent", cursor: "pointer",
                    fontSize: 18, color: "#92400e", borderRadius: "50%", lineHeight: 1,
                  }}
                >&#10005;</button>

                {/* Step dots */}
                <div style={{ display: "flex", gap: 6, marginBottom: 10 }}>
                  {TUTORIAL_STEPS.map((_, i) => (
                    <span
                      key={i}
                      style={{
                        width: i === tutorialStep ? 18 : 8, height: 8, borderRadius: 4,
                        background: i === tutorialStep ? "#f59e0b" : "#fcd34d",
                        transition: "width 0.25s ease, background 0.25s ease",
                      }}
                    />
                  ))}
                </div>

                <h3 style={{ margin: "0 0 6px", fontSize: 15, fontWeight: 700, color: "#78350f" }}>
                  {step?.title}
                </h3>
                <p style={{ margin: "0 0 14px", fontSize: 13, lineHeight: 1.55, color: "#92400e" }}>
                  {step?.desc}
                </p>

                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
                    <button
                      onClick={finish}
                      style={{
                        border: "none", background: "transparent", cursor: "pointer",
                        fontSize: 12.5, color: "#b45309", fontWeight: 600, padding: "4px 0",
                      }}
                    >Skip</button>
                    {!isFirst && (
                      <button
                        onClick={goBack}
                        style={{
                          border: "none", background: "transparent", cursor: "pointer",
                          fontSize: 12.5, color: "#b45309", fontWeight: 600, padding: "4px 0",
                        }}
                      >Back</button>
                    )}
                  </div>
                  <button
                    onClick={advance}
                    style={{
                      border: "none", background: "#92400e", color: "#fef9ee",
                      borderRadius: 8, padding: "7px 18px", cursor: "pointer",
                      fontSize: 13, fontWeight: 700,
                    }}
                  >{isLast ? "Got it" : "Next"}</button>
                </div>
              </div>
            </>
          );
        })()}
      </>
    );
  }

  if (phase === "summary") {
    return (
      <>
        <SessionSummary
          session={finishedSession}
          onNewSession={handleNewSession}
          onShowHistory={() => setShowHistory(true)}
        />
        {showHistory && (
          <SessionHistory onClose={() => setShowHistory(false)} onStudyAgain={handleStudyAgain} onContinue={handleContinueSession} onResumeInProgress={handleResumeInProgress} />
        )}
      </>
    );
  }

  return (
    <>
      {unknownRoleNotice && <div className="app-banner">{unknownRoleNotice}</div>}
      <div className="app-shell">
        <header className="app-header">
          <span className="app-brand">
            <span className="setup-lamp" aria-hidden="true" />
            <span className="app-logo">Stubilly{managed ? " · " + (user?.full_name || user?.serial_number) : ""}</span>
          </span>
          <PomodoroBar pomodoro={pomodoro} />
          <div className="app-header-status">
            <AppMonitorBadge
              monitor={windowMonitor}
              readOnly={managed}
              monitoringEnabled={managed ? userSettings?.monitoring_enabled : undefined}
            />
            {strictBlockingEnabled && <BlockingBadge blocking={blocking} onAdd={handleAddBlockedSite} readOnly={managed} />}
            <HardBlockBadge active={hardBlockActive} />
            <SessionTimer startedAt={session.started_at} />
          </div>
          <div className="app-header-actions">
            {managed && (
              <button className="btn-secondary" onClick={handleLogout}>
                Sign out
              </button>
            )}
            <button className="btn-secondary" onClick={() => setShowHistory(true)}>
              History
            </button>
            <button className="btn-secondary" onClick={() => setShowSettings(true)}>
              Settings
            </button>
            <button className="btn-secondary" onClick={handleEnd}>
              End session
            </button>
          </div>
        </header>

        <main className="app-desk">
          <div className="app-stage">
            <WebcamPanel videoRef={videoRef} state={emotion || liveState.state} companion={activeCompanion} />
            <CompanionNote
              state={liveState.state}
              intervention={lastIntervention}
              voiceMode={Boolean(userSettings?.voice_mode)}
            />
          </div>
          <div className="app-side">
            <AICompanionPanel
              companion={activeCompanion}
              messages={messages}
              companionTyping={companionTyping}
              connected={chatConnected}
              onSend={sendMessage}
              voiceMode={voiceRepliesOn}
              onToggleVoiceMode={() => setVoiceRepliesOn((v) => !v)}
              learningProfile={learningProfile}
              focusState={liveState.state}
              emotion={emotion}
              onOpenSettings={() => setShowSettings(true)}
            />
            <div className="side-panels">
              <TaskChecklist tasks={liveTasks?.length ? liveTasks : session.tasks} sessionId={session.id} />
              <NotesPanel notes={notes} />
            </div>
          </div>
        </main>

        {detectorError && (
          <div className="app-banner app-banner-error">Vision model failed to load: {detectorError}</div>
        )}
        {blocking.error && (
          <div className="app-banner app-banner-error">Site blocking issue: {blocking.error}</div>
        )}
        {!connected && (
          <div className="app-banner">
            {hasConfiguredRemote()
              ? `Can't reach the Stubilly server (${getConfiguredRemoteHost()}) yet  Eretrying automatically…`
              : "Reconnecting to Stubilly…"}
          </div>
        )}
        <HardBlockNotice event={hardBlockEvent} />
        {showHistory && (
          <SessionHistory onClose={() => setShowHistory(false)} onStudyAgain={handleStudyAgain} onContinue={handleContinueSession} onResumeInProgress={handleResumeInProgress} />
        )}
        {showSettings && (
          <SettingsModal
            settings={userSettings}
            onClose={() => setShowSettings(false)}
            onSaved={setUserSettings}
          />
        )}
        
      </div>
    </>
  );
}

export default function App() {
  // /blocked is what the HTTP interceptor 302s blocked sites to  Erender
  // the guided blocked page instead of booting the whole study app in that
  // tab. BlockedNotifier's capture/replaceState path only runs inside the
  // app itself, so the page stays visible until the student acts on it.
  const isBlockedRoute =
    typeof window !== "undefined" &&
    window.location.pathname.replace(/\/+$/, "") === "/blocked";
  if (isBlockedRoute) return <BlockedPage />;
  return <StudyApp />;
}
