import { useCallback, useEffect, useRef, useState } from "react";
import { getWsUrl, recheckBaseUrls, getToken } from "../api/client";

/**
 * Owns the WebSocket connection to /ws/{sessionId}.
 * - sendFocusEvent(event): push one webcam classification tick to the backend
 * - liveState: latest {state, seconds_in_state} reflected back by the state machine
 * - lastIntervention: most recent nudge/alarm the backend fired, or null
 * - onPolicyRefresh (optional): invoked when the backend pushes
 *   {"type": "policy_refresh"} after an admin saves the block/allow policy —
 *   the instant path for admin changes; the /policy/current poll is fallback.
 *
 * Reconnects with backoff on drop (webcam apps run for 25+ min sessions, a
 * dropped wifi/localhost hiccup shouldn't kill the session), re-resolving the
 * active backend first so it also self-heals onto a central server that just
 * came online.
 */
export function useFocusSocket(sessionId, onPolicyRefresh, onSessionEnd) {
  const [connected, setConnected] = useState(false);
  const [liveState, setLiveState] = useState({ state: "focused", seconds_in_state: 0 });
  const [lastIntervention, setLastIntervention] = useState(null);
  // Server-timed break state: {active, endsAt} pushed by break_started /
  // break_ended frames (timer expiry, REST start/end, admin grant).
  const [breakInfo, setBreakInfo] = useState(null);
  const wsRef = useRef(null);
  const policyCbRef = useRef(onPolicyRefresh);
  const sessionEndCbRef = useRef(onSessionEnd);

  useEffect(() => {
    policyCbRef.current = onPolicyRefresh;
  }, [onPolicyRefresh]);
  useEffect(() => {
    sessionEndCbRef.current = onSessionEnd;
  }, [onSessionEnd]);

  useEffect(() => {
    if (!sessionId) return;

    let active = true;
    let reconnectTimer = null;
    let attempt = 0;
    let ws = null;

    async function connect() {
      if (!active) return;
      // Pass the student token so every focus frame keeps presence alive
      // (Admin Hub "online") even when the 5s HTTP poll is throttled.
      const userToken = getToken();
      const qs = userToken ? `?token=${encodeURIComponent(userToken)}` : "";
      const url = await getWsUrl(`/ws/${sessionId}${qs}`);
      if (!active) return;
      ws = new WebSocket(url);
      wsRef.current = ws;

      ws.onopen = () => {
        if (active) {
          setConnected(true);
          attempt = 0;
        }
      };

      ws.onmessage = (evt) => {
        if (!active) return;
        let msg;
        try {
          msg = JSON.parse(evt.data);
        } catch {
          return; // ignore malformed frames
        }
        if (msg.type === "state_update") {
          setLiveState({ state: msg.state, seconds_in_state: msg.seconds_in_state });
        } else if (msg.type === "intervention") {
          setLastIntervention({
            interventionType: msg.intervention_type,
            message: msg.message,
            // Feedback + delivery metadata (theoretical-framework loop):
            // id lets the UI record "helpful/dismissed", voice/tone tell it
            // whether to speak the line and how.
            id: msg.id ?? null,
            voice: !!msg.voice,
            tone: msg.tone || "gentle",
            respondable: !!msg.respondable,
            at: Date.now(),
          });
        } else if (msg.type === "intervention_update") {
          // The alarm was already shown instantly with a fixed line; when the
          // model's wording arrives the backend sends this update for the SAME
          // intervention, so the student just sees the nicer sentence. No new
          // alarm, no second sound.
          setLastIntervention((prev) => {
            if (!prev || (msg.id != null && prev.id != null && prev.id !== msg.id)) {
              return prev;
            }
            return { ...prev, message: msg.message };
          });
        } else if (msg.type === "policy_refresh") {
          policyCbRef.current?.();
        } else if (msg.type === "break_started") {
          setBreakInfo({ active: true, endsAt: msg.ends_at || null, at: Date.now() });
        } else if (msg.type === "break_ended") {
          setBreakInfo({ active: false, endsAt: null, at: Date.now() });
        } else if (msg.type === "session_end") {
          // The backend force-ended this session (parental screen rules).
          // The row is finalized — stop reconnecting and let the app run
          // its end/summary flow with the reason.
          active = false;
          if (reconnectTimer) clearTimeout(reconnectTimer);
          setConnected(false);
          try {
            ws.close();
          } catch {
            /* already closing */
          }
          sessionEndCbRef.current?.(msg.reason || "Session ended");
        }
      };

      ws.onclose = () => {
        if (!active) return;
        setConnected(false);
        const delay = Math.min(800 * 2 ** attempt, 10000);
        attempt++;
        reconnectTimer = setTimeout(() => {
          // The server may have just come online — let the base re-resolve.
          recheckBaseUrls();
          connect();
        }, delay);
      };

      // Bind the socket in the handler — a stale closure would close the
      // newly-assigned socket when an old one errors after reconnect.
      ws.onerror = () => {
        if (wsRef.current === ws) ws.close();
      };
    }

    connect();
    return () => {
      active = false;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      ws?.close();
      if (wsRef.current === ws) wsRef.current = null;
    };
  }, [sessionId]);

  const sendFocusEvent = useCallback((event) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(event));
    }
  }, []);

  return { connected, liveState, lastIntervention, breakInfo, sendFocusEvent };
}
