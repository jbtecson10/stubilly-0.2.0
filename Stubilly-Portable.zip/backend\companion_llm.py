"""
Hybrid provider for the "Chat with Stubilly" companion.

Tries providers in priority order and falls through to the next one if a
provider isn't configured or fails to even start responding:

    1. Gemini  (GEMINI_API_KEY)
    2. Grok    (GROK_API_KEY)
    3. Ollama  (local — always available, needs no key, this is what the
                rest of the app already used before)

Copilot is deliberately not in this chain: it doesn't expose a public
completions API a third-party app can call the way Gemini/Grok do, so
there's nothing to integrate against.

The fallback only kicks in for a "hard" failure — no key set, an auth
error, a network error, or a non-2xx response — all of which happen
*before* any text has been streamed back to the student. If a provider
fails *mid-reply* (rare, but possible on a flaky connection), we don't
restart from scratch with a different provider — that would either
duplicate or contradict what the student already saw start appearing. We
just stop cleanly there instead.

Task breakdown, nudges, and the background note-extractor all stay on the
local Ollama client (ollama_client.py) — those are cheap, non-interactive
calls where local-first still makes sense; only the interactive chat that
the student is actually looking at needs the extra speed/quality of a
frontier cloud model.
"""
import asyncio
import json
import logging
import os
from typing import AsyncIterator

import httpx

from llm_backend import (
    DEFAULT_MODEL as OLLAMA_DEFAULT_MODEL,
    build_companion_system_prompt,
    stream_companion_reply as _stream_ollama_companion,
)
# Vision always routes through Ollama directly (moondream), regardless of
# which text backend is active: the llama.cpp text model can't read images,
# and Ollama is the multimodal engine for BOTH deployments.
import ollama_client as _vision_backend

logger = logging.getLogger("stubilly.companion_llm")

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
# New Google AI Studio keys can't use the older 2.x model IDs — Google's own
# 404 message points at the 3.8 line, which is what this key is provisioned for.
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:streamGenerateContent?alt=sse"

GROK_API_KEY = os.getenv("GROK_API_KEY", "").strip()
GROK_MODEL = os.getenv("GROK_MODEL", "grok-4.3")
GROK_URL = "https://api.x.ai/v1/chat/completions"

# Local multimodal model used when a photo must be read without cloud
# vision (e.g. both cloud providers failed). Picked up from env so a
# different vision model can be dropped in without a rebuild.
VISION_MODEL = os.getenv("STUBILLY_VISION_MODEL", "moondream")

# Companion chat should feel instant and stay short — this caps output
# length for both cloud providers the same way ollama_client.CHAT_OPTIONS
# does for the local model.
MAX_OUTPUT_TOKENS = 250

# Time-to-first-token budget. If a configured provider hasn't produced a
# single token by now, it's treated as unusable and we fail over — a student
# staring at a blank bubble is the worst failure mode, worse than a slightly
# slower fallback.
FIRST_TOKEN_BUDGET_SECONDS = 4.0


class ProviderUnavailable(Exception):
    """Raised when a provider can't even start responding (no key, auth/network error)."""


async def _fast_start(messages: list[dict], provider) -> tuple[AsyncIterator[str], str]:
    """
    Cheap fail-fast gate: build the provider's stream, wait up to
    FIRST_TOKEN_BUDGET_SECONDS for the very first token, and only then hand
    it back to the caller. If the first token never arrives (hung network,
    cold cloud endpoint), the stream is closed and ProviderUnavailable is
    raised so the hybrid chain falls through to the next provider instead of
    making the student wait.
    """
    stream = provider(messages)  # async generator — body doesn't run until __anext__
    try:
        try:
            first = await asyncio.wait_for(stream.__anext__(), FIRST_TOKEN_BUDGET_SECONDS)
        except asyncio.TimeoutError:
            raise ProviderUnavailable(f"no first token within {FIRST_TOKEN_BUDGET_SECONDS}s")
        except StopAsyncIteration:
            raise ProviderUnavailable("provider ended without any tokens")
        return stream, first
    except Exception:
        await stream.aclose()
        raise


def _to_gemini_parts(content) -> list[dict]:
    """Text (+ optional attached photo) -> Gemini parts.

    Content is either a plain string or a list of parts where
    {"type": "image", "data": <b64>, "mime": ...} carries a photo the
    student attached in chat.
    """
    if isinstance(content, str):
        return [{"text": content}]
    parts: list[dict] = []
    for p in content:
        if p.get("type") == "image" and p.get("data"):
            parts.append(
                {
                    "inline_data": {
                        "mime_type": p.get("mime") or "image/jpeg",
                        "data": p["data"],
                    }
                }
            )
        elif p.get("text"):
            parts.append({"text": p["text"]})
    return parts or [{"text": ""}]


def _to_openai_messages(messages: list[dict], allow_images: bool = True) -> list[dict]:
    """Normalize messages for OpenAI-shaped APIs (Grok) and text-only
    models (local Ollama). Photos become data-URL image parts when the
    provider supports vision; otherwise they collapse to a note so the
    text model at least knows a photo was shared."""
    out: list[dict] = []
    for m in messages:
        c = m["content"]
        if isinstance(c, list):
            has_image = any(p.get("type") == "image" and p.get("data") for p in c)
            if allow_images and has_image:
                content: list | str = []
                for p in c:
                    if p.get("type") == "image" and p.get("data"):
                        url = f"data:{p.get('mime') or 'image/jpeg'};base64,{p['data']}"
                        content.append({"type": "image_url", "image_url": {"url": url}})
                    elif p.get("text"):
                        content.append({"type": "text", "text": p["text"]})
                if not any(x.get("type") == "text" for x in content):
                    content.append({"type": "text", "text": "[the student attached a photo]"})
            else:
                texts = [p.get("text", "") for p in c if p.get("text")]
                content = "\n".join(t for t in texts if t)
                if has_image:
                    content = f"{content}\n[the student attached a photo]".strip()
                content = content or "[the student attached a photo]"
        else:
            content = c
        out.append({"role": m["role"], "content": content})
    return out


def _to_gemini_contents(messages: list[dict]) -> tuple[str, list[dict]]:
    """Split the OpenAI-style messages list into Gemini's (system, contents) shape."""
    system_text = ""
    contents = []
    for m in messages:
        if m["role"] == "system":
            system_text = m["content"]
        else:
            contents.append({
                "role": "model" if m["role"] == "assistant" else "user",
                "parts": _to_gemini_parts(m["content"]),
            })
    return system_text, contents


async def _stream_gemini(messages: list[dict]) -> AsyncIterator[str]:
    if not GEMINI_API_KEY:
        raise ProviderUnavailable("no GEMINI_API_KEY set")

    system_text, contents = _to_gemini_contents(messages)
    body = {
        "contents": contents,
        "systemInstruction": {"parts": [{"text": system_text}]},
        "generationConfig": {"maxOutputTokens": MAX_OUTPUT_TOKENS},
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            async with client.stream(
                "POST",
                GEMINI_URL,
                headers={"x-goog-api-key": GEMINI_API_KEY, "Content-Type": "application/json"},
                json=body,
            ) as resp:
                resp.raise_for_status()  # raises before any tokens are read — safe to fall back on
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    payload = line[len("data:"):].strip()
                    if not payload or payload == "[DONE]":
                        continue
                    try:
                        chunk = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    for cand in chunk.get("candidates", []):
                        for part in cand.get("content", {}).get("parts", []):
                            text = part.get("text", "")
                            if text:
                                yield text
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException, httpx.HTTPStatusError) as e:
        raise ProviderUnavailable(f"Gemini unreachable: {e}") from e


async def _stream_grok(messages: list[dict]) -> AsyncIterator[str]:
    if not GROK_API_KEY:
        raise ProviderUnavailable("no GROK_API_KEY set")

    body = {
        "model": GROK_MODEL,
        # Multimodal-aware copy: photos ride along as data-URL image parts
        # so Grok sees the same picture Gemini sees.
        "messages": _to_openai_messages(messages),
        "stream": True,
        "max_tokens": MAX_OUTPUT_TOKENS,
        # Slightly creative but grounded — matches the Gemini path so a
        # Grok fallback doesn't feel like a different product.
        "temperature": 0.7,
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            async with client.stream(
                "POST",
                GROK_URL,
                headers={"Authorization": f"Bearer {GROK_API_KEY}", "Content-Type": "application/json"},
                json=body,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    payload = line[len("data:"):].strip()
                    if not payload or payload == "[DONE]":
                        continue
                    try:
                        chunk = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    for choice in chunk.get("choices", []):
                        delta = choice.get("delta", {}).get("content", "")
                        if delta:
                            yield delta
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException, httpx.HTTPStatusError) as e:
        raise ProviderUnavailable(f"Grok unreachable: {e}") from e


def _messages_have_image(messages: list[dict]) -> bool:
    for m in messages:
        c = m.get("content")
        if isinstance(c, list) and any(
            p.get("type") == "image" and p.get("data") for p in c
        ):
            return True
    return False


def _to_ollama_messages(messages: list[dict]) -> list[dict]:
    """Ollama /api/chat shape: flat string content plus an optional
    base64 `images` list on the message (native multimodal)."""
    out: list[dict] = []
    for m in messages:
        c = m["content"]
        if isinstance(c, list):
            texts = [p.get("text", "") for p in c if p.get("text")]
            images = [
                p["data"] for p in c if p.get("type") == "image" and p.get("data")
            ]
            msg: dict = {
                "role": m["role"],
                "content": "\n".join(t for t in texts if t)
                or "[the student attached a photo]",
            }
            if images:
                msg["images"] = images
            out.append(msg)
        else:
            out.append({"role": m["role"], "content": c})
    return out


def _pick_local_model(ollama_msgs: list[dict]) -> str:
    if any(m.get("images") for m in ollama_msgs):
        return VISION_MODEL
    return OLLAMA_DEFAULT_MODEL


async def stream_companion_reply_hybrid(messages: list[dict]) -> AsyncIterator[str]:
    """
    Provider order by need:
      - Text chat: warm local Ollama first (fastest first token), then
        Gemini, then Grok. Each provider must produce a first token within
        FIRST_TOKEN_BUDGET_SECONDS or it's skipped.
      - Photos: Gemini (vision) first, then Grok, then local Ollama with
        the native `images` payload so a local vision model can still read
        the picture.
    Falls through only on pre-first-token failures; mid-reply failures stop
    cleanly instead of restarting under the student.
    """
    has_image = _messages_have_image(messages)
    cloud_chain = (("Gemini", _stream_gemini), ("Grok", _stream_grok))
    if not has_image:
        # Local first: fail-fast on a dead daemon, otherwise the warm model
        # answers in a few hundred ms.
        ollama_msgs = _to_ollama_messages(messages)
        model = _pick_local_model(ollama_msgs)
        try:
            stream = _stream_ollama_companion(ollama_msgs, model=model, fail_fast=True)
            first = await asyncio.wait_for(stream.__anext__(), FIRST_TOKEN_BUDGET_SECONDS)
        except Exception as e:
            logger.info(f"Ollama unavailable, falling back: {e}")
        else:
            try:
                yield first
                async for piece in stream:
                    yield piece
                return
            except Exception as e:
                logger.warning(f"Ollama failed mid-reply, stopping: {e}")
                return
            finally:
                await stream.aclose()

    for name, provider in cloud_chain:
        try:
            stream, first = await _fast_start(messages, provider)
        except ProviderUnavailable as e:
            logger.info(f"{name} unavailable, falling back: {e}")
            continue
        # Provider produced a first token — its reply owns the response now.
        try:
            yield first
            async for piece in stream:
                yield piece
            return  # provider finished its reply successfully
        except ProviderUnavailable as e:
            # Already showed the student partial text — don't restart with a
            # different provider on top of it, just stop here.
            logger.warning(f"{name} failed mid-reply, stopping: {e}")
            return
        finally:
            await stream.aclose()

    # Nothing cloud-side worked - last resort: the local model (with native
    # images when a photo was attached, so a local vision model can read it).
    # Image fallback always goes straight to Ollama: the llama.cpp text model
    # is not multimodal, so routing a photo there would silently lose it.
    ollama_msgs = _to_ollama_messages(messages)
    if has_image:
        async for piece in _vision_backend.stream_companion_reply(
            ollama_msgs, model=VISION_MODEL
        ):
            yield piece
        return
    model = _pick_local_model(ollama_msgs)
    async for piece in _stream_ollama_companion(ollama_msgs, model=model):
        yield piece
