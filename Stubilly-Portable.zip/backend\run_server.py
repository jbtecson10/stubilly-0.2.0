"""
Entry point for the PyInstaller-bundled backend (see build.sh).

Not used in normal `uvicorn main:app --reload` development — this exists so
Electron can spawn a single self-contained executable in production instead
of requiring Python to be installed on the user's machine.
"""
import os
import sys
from pathlib import Path


def user_data_dir() -> Path:
    """Cross-platform per-user app-data folder, so the DB survives app updates
    and isn't stuck inside a read-only packaged install directory."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home()))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    path = base / "Stubilly"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _seed_admins_if_empty() -> None:
    """Populate an empty admins table from the primary deployment's admins.

    A second local deployment (llamacpp\\run.bat) boots a brand-new database:
    with zero administrators, every admin login 401s forever and no account
    request can ever be approved. Copy ONLY the administrators - never student
    or user data, which stays separate per deployment - so the same admin
    credentials work on both. A machine with no primary database falls back to
    the prototype's original owner account so the instance is never
    unadministrable.
    """
    import sqlite3

    from database import SessionLocal
    from sqlalchemy import func

    import models

    db = SessionLocal()
    try:
        if db.query(models.Admin).count() > 0:
            return
        own = os.path.abspath(os.environ.get("STUBILLY_DB_PATH", "./stubilly.db"))
        primary = os.path.abspath(
            os.path.join(os.environ.get("APPDATA", str(Path.home())), "Stubilly", "stubilly.db")
        )
        rows = []
        if primary != own and os.path.exists(primary):
            try:
                con = sqlite3.connect(primary, timeout=5)
                try:
                    rows = con.execute(
                        "select name, username, password, is_active from admins"
                    ).fetchall()
                finally:
                    con.close()
            except Exception as exc:
                print(f"admin seed: cannot read primary {primary}: {exc}", flush=True)
        if not rows:
            rows = [("Dr. Reyes", "reyes", "reyes123", 1)]
        added = 0
        for name, username, password, is_active in rows:
            taken = (
                db.query(models.Admin)
                .filter(func.lower(models.Admin.username) == str(username).lower())
                .first()
            )
            if taken is not None:
                continue
            db.add(
                models.Admin(
                    name=name,
                    username=username,
                    password=password,
                    is_active=bool(is_active),
                )
            )
            added += 1
        db.commit()
        print(f"admin seed: fresh database populated with {added} administrator(s)", flush=True)
    finally:
        db.close()


if __name__ == "__main__":
    # Default to the shared per-user database; a second local deployment
    # (llamacpp\run.bat) passes its own STUBILLY_DB_PATH and must win.
    os.environ.setdefault("STUBILLY_DB_PATH", str(user_data_dir() / "stubilly.db"))

    import uvicorn
    from main import app  # direct import, not the "main:app" string form —
    # PyInstaller's frozen bundle can't resolve that string import at runtime.
    _seed_admins_if_empty()

    # Central-server deployments bind to a LAN/external host via
    # STUBILLY_HOST (default is loopback-only, the safe local default).
    # Port via STUBILLY_PORT (default 8420). The web-base launcher sets
    # 8421 so it can coexist with any other Stubilly backend already on
    # localhost:8420 (e.g. the installed desktop app's embedded server).
    host = os.environ.get("STUBILLY_HOST", "127.0.0.1")
    port = int(os.environ.get("STUBILLY_PORT", "8420"))
    uvicorn.run(app, host=host, port=port, reload=False)
