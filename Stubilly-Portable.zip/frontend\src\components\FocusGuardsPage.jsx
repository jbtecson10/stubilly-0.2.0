import { Shield, Globe, Timer, Power, Info } from "lucide-react";
import StudentPage from "./StudentPage";

/*
 * Focus guards page. Explains each protection mode and lets the student turn
 * them on/off. The four toggles are bound to the same state the Study setup
 * uses, so changes here carry straight into the next session.
 */
const GUARDS = [
  {
    key: "strictBlocking",
    icon: Shield,
    tint: "blue",
    title: "Strict blocking",
    short: "Locks blocking settings for the whole session.",
    body: "When strict blocking is on, the block list is fixed for the session and the per-guard options below are applied consistently. Leave it off to stay flexible.",
  },
  {
    key: "blockThroughBreaks",
    icon: Globe,
    tint: "amber",
    title: "Block through breaks",
    short: "Keep sites blocked even during break time.",
    body: "By default blocking is lifted on breaks so you can stretch. Turn this on to keep distracting sites blocked for the entire session, breaks included.",
  },
  {
    key: "autoBlock",
    icon: Timer,
    tint: "green",
    title: "Automatic blocking",
    short: "Start blocking as soon as the session begins.",
    body: "With automatic blocking the block list is applied the moment a session starts, so you never have a window of open distractions before it kicks in.",
  },
  {
    key: "liveKill",
    icon: Power,
    tint: "red",
    title: "Live shutdown",
    short: "Force-close off-task apps after prolonged distraction.",
    body: "Off-task applications can be closed automatically after you drift for too long. Unsaved work in those apps may be lost — only enable this if you accept that.",
  },
];

const TINT_CLASS = {
  blue: "spage-guards-ic--blue",
  amber: "spage-guards-ic--amber",
  green: "spage-guards-ic--green",
  red: "spage-guards-ic--red",
};

export default function FocusGuardsPage({ onBack, guards, setGuard }) {
  return (
    <StudentPage
      title="Focus guards"
      subtitle="Choose how strictly Stubilly protects your study time."
      onBack={onBack}
      wide
    >
      <div className="spage-guards-note">
        <Info size={16} />
        <span>
          Guards apply to the next session you start. You can also adjust them on the Study page.
          Site blocking needs administrator rights and lifts automatically during breaks unless
          “block through breaks” is on.
        </span>
      </div>

      <div className="spage-guards-grid">
        {GUARDS.map((g) => {
          const Icon = g.icon;
          const on = !!guards[g.key];
          return (
            <div className={`spage-guard${on ? " is-on" : ""}`} key={g.key}>
              <div className="spage-guard-top">
                <span className={`spage-guards-ic ${TINT_CLASS[g.tint]}`}>
                  <Icon size={20} />
                </span>
                <label className="spage-guard-switch">
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={(e) => setGuard(g.key, e.target.checked)}
                    aria-label={g.title}
                  />
                  <span className="spage-guard-slider" />
                </label>
              </div>
              <h3 className="spage-guard-title">{g.title}</h3>
              <p className="spage-guard-short">{g.short}</p>
              <p className="spage-guard-body">{g.body}</p>
            </div>
          );
        })}
      </div>
    </StudentPage>
  );
}
