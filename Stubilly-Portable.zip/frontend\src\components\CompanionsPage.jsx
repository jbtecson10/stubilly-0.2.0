import { useEffect, useState } from "react";
import { Check } from "lucide-react";
import { api } from "../api/client";
import { FALLBACK_COMPANIONS } from "./CompanionPicker";
import StudentPage from "./StudentPage";

/*
 * Companions page. A full gallery of every study buddy with its personality,
 * so the student can read up and pick one. Selection writes to the same
 * companionId the Study setup uses, so the chosen buddy carries into the
 * next session.
 */
export default function CompanionsPage({ onBack, value, onChange }) {
  const [companions, setCompanions] = useState(FALLBACK_COMPANIONS);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await api.listCompanions();
        if (!cancelled && Array.isArray(data?.companions) && data.companions.length) {
          setCompanions(data.companions);
        }
      } catch {
        // Backend briefly down — the fallback list keeps the page usable.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const selected = value || "fokus";

  return (
    <StudentPage
      title="Companions"
      subtitle="Meet every study buddy and pick the one that fits your vibe."
      onBack={onBack}
      wide
    >
      <div className="spage-comp-grid">
        {companions.map((c) => {
          const isActive = c.id === selected;
          return (
            <button
              type="button"
              key={c.id}
              className={`spage-comp${isActive ? " is-active" : ""}`}
              onClick={() => onChange?.(c.id)}
              aria-pressed={isActive}
            >
              <span className="spage-comp-top">
                <span className="spage-comp-avatar" style={{ background: `${c.color}22`, borderColor: c.color }}>
                  <span className="spage-comp-emoji">{c.emoji}</span>
                </span>
                {isActive && (
                  <span className="spage-comp-check" style={{ background: c.color }}>
                    <Check size={14} color="#fff" />
                  </span>
                )}
              </span>
              <span className="spage-comp-name">{c.name}</span>
              <span className="spage-comp-tag" style={{ color: c.color }}>
                {c.tagline}
              </span>
              <span className="spage-comp-desc">{c.personality}</span>
              <span className={`spage-comp-cta${isActive ? " is-active" : ""}`}>
                {isActive ? "Selected" : "Choose companion"}
              </span>
            </button>
          );
        })}
      </div>
    </StudentPage>
  );
}
