import { useState } from "react";
import {
  GraduationCap,
  History,
  BarChart3,
  Settings,
  Shield,
  Users,
  CircleHelp,
  PanelLeftClose,
  PanelLeftOpen,
  UserRound,
  ChevronRight,
  LogOut,
} from "lucide-react";

/*
 * Student-home sidebar (compact, reference: ValSNED admin rail). A fixed left
 * rail that does NOT scroll with the page: brand + collapse on top, grouped
 * nav with an active blue pill, Settings + Help near the bottom, and an
 * ACCOUNT card pinned at the bottom. The account card reveals a Sign out
 * popover. Navigation is controlled — the parent owns the active `view`.
 */
const NAV_GROUPS = [
  {
    label: null,
    items: [{ id: "study", label: "Study", icon: GraduationCap }],
  },
  {
    label: "Insights",
    items: [
      { id: "history", label: "History", icon: History },
      { id: "progress", label: "Progress", icon: BarChart3 },
    ],
  },
  {
    label: "Manage",
    items: [
      { id: "guards", label: "Focus guards", icon: Shield },
      { id: "companions", label: "Companions", icon: Users },
    ],
  },
];

export default function StudentNav({
  view = "study",
  onNavigate,
  user,
  managed,
  onLogout,
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);

  const go = (id) => {
    setAccountOpen(false);
    onNavigate?.(id);
  };

  const name = user?.full_name || user?.email || user?.serial_number || "Student";
  const role = managed ? "Managed access" : "Local access";

  return (
    <aside className={`snav ${collapsed ? "snav--collapsed" : ""}`} aria-label="Primary">
      {/* Brand + collapse */}
      <div className="snav-top">
        <span className="snav-lamp" aria-hidden="true" />
        {!collapsed && (
          <span className="snav-brand">
            <strong>Stubilly</strong>
            <small>Study companion</small>
          </span>
        )}
        <button
          type="button"
          className="snav-collapse"
          onClick={() => setCollapsed((c) => !c)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
        </button>
      </div>

      {/* Scrollable nav */}
      <nav className="snav-scroll">
        {NAV_GROUPS.map((group) => (
          <div className="snav-group" key={group.label || "top"}>
            {group.label && !collapsed && <span className="snav-group-label">{group.label}</span>}
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  className={`snav-item ${isActive ? "snav-item--active" : ""}`}
                  data-tutorial={`nav-${item.id}`}
                  onClick={() => go(item.id)}
                  aria-current={isActive ? "page" : undefined}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon size={17} className="snav-item-icon" />
                  {!collapsed && <span className="snav-item-label">{item.label}</span>}
                </button>
              );
            })}
          </div>
        ))}

        {/* Settings + Help sit just above the account card */}
        <div className="snav-group snav-group--footer">
          <button
            type="button"
            className={`snav-item ${view === "settings" ? "snav-item--active" : ""}`}
            data-tutorial="nav-settings"
            onClick={() => go("settings")}
            title={collapsed ? "Settings" : undefined}
          >
            <Settings size={17} className="snav-item-icon" />
            {!collapsed && <span className="snav-item-label">Settings</span>}
          </button>
          <button
            type="button"
            className={`snav-item ${view === "help" ? "snav-item--active" : ""}`}
            data-tutorial="nav-help"
            onClick={() => go("help")}
            title={collapsed ? "Help" : undefined}
          >
            <CircleHelp size={17} className="snav-item-icon" />
            {!collapsed && <span className="snav-item-label">Help</span>}
          </button>
        </div>
      </nav>

      {/* Account card pinned to the bottom */}
      <div className="snav-account-wrap">
        {accountOpen && (
          <div className="snav-account-menu" role="menu">
            <button
              type="button"
              className="snav-account-menu-item"
              role="menuitem"
              onClick={() => {
                setAccountOpen(false);
                onLogout?.();
              }}
            >
              <LogOut size={15} />
              <span>Sign out</span>
            </button>
            <span className="snav-account-menu-note">
              {managed ? "Ends your session on the server." : "Clears the current session from this device."}
            </span>
          </div>
        )}
        <button
          type="button"
          className="snav-account"
          onClick={() => setAccountOpen((o) => !o)}
          aria-expanded={accountOpen}
          aria-haspopup="menu"
          title={collapsed ? name : undefined}
        >
          <span className="snav-account-avatar" aria-hidden="true">
            <UserRound size={18} />
          </span>
          {!collapsed && (
            <span className="snav-account-text">
              <small>Account</small>
              <strong>{name}</strong>
              <em>{role}</em>
            </span>
          )}
          {!collapsed && <ChevronRight size={16} className="snav-account-chevron" />}
        </button>
      </div>
    </aside>
  );
}
