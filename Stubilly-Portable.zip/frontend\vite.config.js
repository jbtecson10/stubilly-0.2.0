import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  // Packaged Electron builds load index.html via file://, where absolute
  // asset paths ("/assets/...") resolve against the OS filesystem root
  // instead of the dist folder and 404. Relative paths fix that for the
  // packaged build without changing anything in dev (Vite's dev server
  // still serves "./" and "/" the same way).
  base: './',
})
