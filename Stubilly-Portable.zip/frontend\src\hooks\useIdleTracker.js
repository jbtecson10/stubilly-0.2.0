import { useCallback, useEffect, useRef } from "react";

const INPUT_EVENTS = [
  "mousemove",
  "mousedown",
  "keydown",
  "wheel",
  "touchstart",
  "pointermove",
  "scroll",
];

/**
 * Keyboard/mouse idle tracker (INPUT layer for the paralysis classifier).
 *
 * Returns a stable `idleSeconds()` function: seconds since the last input
 * event seen by THIS page. The backend treats a long idle with the face
 * still on camera as "stuck on the task" (task paralysis) rather than
 * "browsing away" — the latter keeps the ordinary distraction alarm.
 *
 * Deliberately page-scoped: input typed in another window doesn't reset it,
 * which is what lets the classifier tell "frozen, not typing" apart from
 * "actively doing something else".
 */
export function useIdleTracker() {
  const lastInputRef = useRef(Date.now());

  useEffect(() => {
    const mark = () => {
      lastInputRef.current = Date.now();
    };
    for (const name of INPUT_EVENTS) {
      window.addEventListener(name, mark, { passive: true });
    }
    return () => {
      for (const name of INPUT_EVENTS) {
        window.removeEventListener(name, mark);
      }
    };
  }, []);

  return useCallback(() => {
    const ms = Date.now() - lastInputRef.current;
    return Math.max(0, Math.round((ms / 1000) * 10) / 10);
  }, []);
}
