import { useState } from "react";
import { X, Trash2 } from "lucide-react";

export default function WhitelistSettings({
  title = "Allowed apps & sites",
  hint = "Stubilly checks the active window's app name, title, and URL against this list. A match keeps you marked on-task; anything else starts the off-task timer.",
  placeholder = "e.g. canvas.instructure.com",
  entries,
  onAdd,
  onRemove,
  onClose,
}) {
  const [draft, setDraft] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    onAdd(draft);
    setDraft("");
  }

  return (
    <div className="whitelist-popover">
      <div className="whitelist-popover-header">
        <span>{title}</span>
        <button className="btn-icon" onClick={onClose} aria-label="Close">
          <X size={14} />
        </button>
      </div>

      <p className="whitelist-popover-hint">{hint}</p>

      <ul className="whitelist-list">
        {entries.map((entry) => (
          <li key={entry} className="whitelist-item">
            <span>{entry}</span>
            <button
              className="btn-icon"
              onClick={() => onRemove(entry)}
              aria-label={`Remove ${entry}`}
            >
              <Trash2 size={13} />
            </button>
          </li>
        ))}
      </ul>

      <form className="whitelist-add-form" onSubmit={handleSubmit}>
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder={placeholder}
        />
        <button type="submit" className="btn-text" disabled={!draft.trim()}>
          Add
        </button>
      </form>
    </div>
  );
}

