import { ArrowLeft } from "lucide-react";

/*
 * Shared page shell for the student-home views (History, Progress, Focus
 * guards, Companions, Help). Gives every page a consistent header — title,
 * subtitle and a "Back to Study" action — and a scrollable body. `wide`
 * lets a page use the full width instead of the centered reading column.
 */
export default function StudentPage({ title, subtitle, onBack, wide, children }) {
  return (
    <div className={`spage${wide ? " spage--wide" : ""}`}>
      <div className="spage-head">
        <div className="spage-head-text">
          <h1 className="spage-title">{title}</h1>
          {subtitle && <p className="spage-sub">{subtitle}</p>}
        </div>
        <button type="button" className="spage-back" onClick={onBack}>
          <ArrowLeft size={16} />
          <span>Back to Study</span>
        </button>
      </div>
      <div className="spage-body">{children}</div>
    </div>
  );
}
