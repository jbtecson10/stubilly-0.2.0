import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import BlockedNotifier from './components/BlockedNotifier.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
    <BlockedNotifier />
  </StrictMode>,
)

