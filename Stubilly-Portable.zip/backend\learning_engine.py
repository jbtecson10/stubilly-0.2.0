"""Online learning engine for smart interventions.

Two engines, both pure Python (no numpy/sklearn on this box):

1. Supervised - online logistic regression trained by SGD / mini-batch
   with L1 (sparsifying) + L2 (weight-decay) regularization. It predicts
   P(stay focused) from lightweight context features (hour, recent focus
   ratio, current off-task signal, intervention pressure). The prediction
   feeds intervention timing: high drift-risk -> act earlier / guide,
   low risk -> stay quiet. Updated once per decision window from the
   observed outcome (focused vs drifted), so it learns each student's
   rhythm without a big batch.

2. Unsupervised - k-means over the same feature vectors to surface usage
   clusters (e.g. "morning learner", "deadline cruncher"). Clusters are
   read-only insights for Smart Ops and the companion, never gating.

The model is tiny (a weight vector + bias) and is persisted as JSON inside
the user's learning profile (users.settings["companion_learning"]["model"]).
Every function here is deterministic and side-effect free so it is trivially
unit-testable; the DB I/O lives in learning.py.
"""
from __future__ import annotations

import math
import random
from typing import Iterable, Sequence

# --- feature schema -------------------------------------------------------
# Order is the contract: a model vector is only valid against the same order.
FEATURE_NAMES = (
    "hour_norm",            # hour of day / 24
    "weekend",              # 1 Sat/Sun else 0
    "focused_recent",       # recent focused ratio 0..1
    "distracted_recent",    # recent distracted ratio 0..1
    "intervention_pressure",# interventions this session, capped/scaled 0..1
    "off_task_now",         # foreground currently off-task 0/1
)
N_FEATURES = len(FEATURE_NAMES)

# L1/L2 defaults: light L2 keeps weights sane, light L1 prunes noise.
DEFAULT_L2 = 1e-3
DEFAULT_L1 = 1e-4
DEFAULT_LR = 0.05
MINIBATCH = 8
CLUSTER_K = 3
CLUSTER_ITERS = 25


def _sigmoid(z: float) -> float:
    # Numerically stable sigmoid.
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    ez = math.exp(z)
    return ez / (1.0 + ez)


def new_model(n: int = N_FEATURES) -> dict:
    """A fresh, untrained model: zero weights, zero bias, sample count 0."""
    return {"weights": [0.0] * n, "bias": 0.0, "n": 0}


def _dot(w: Sequence[float], x: Sequence[float]) -> float:
    return sum(wi * xi for wi, xi in zip(w, x))


def predict_proba(x: Sequence[float], model: dict) -> float:
    """P(stay focused) for feature vector x under the current model."""
    w = model.get("weights") or [0.0] * len(x)
    b = float(model.get("bias") or 0.0)
    return _sigmoid(_dot(w, x) + b)


def update(
    x: Sequence[float],
    y: float,
    model: dict,
    lr: float = DEFAULT_LR,
    l1: float = DEFAULT_L1,
    l2: float = DEFAULT_L2,
) -> dict:
    """One SGD step on a single sample (y in {0,1} = stayed focused).

    Gradient of logistic loss + L2 decay, then a proximal soft-threshold for
    L1 (the standard proximal-gradient update that actually drives small
    weights to exactly zero). Returns a NEW model dict (immutable in, out).
    """
    w = list(model.get("weights") or [0.0] * len(x))
    b = float(model.get("bias") or 0.0)
    p = _sigmoid(_dot(w, x) + b)
    err = p - y  # dL/dz
    scale = lr * err
    for i in range(len(w)):
        grad = scale * x[i] + lr * l2 * w[i]
        new_w = w[i] - grad
        # Proximal L1: soft-threshold toward zero.
        if new_w > lr * l1:
            new_w -= lr * l1
        elif new_w < -lr * l1:
            new_w += lr * l1
        else:
            new_w = 0.0
        w[i] = new_w
    b = b - scale
    return {"weights": w, "bias": b, "n": int(model.get("n") or 0) + 1}


def update_minibatch(
    batch: Sequence[tuple[Sequence[float], float]],
    model: dict,
    lr: float = DEFAULT_LR,
    l1: float = DEFAULT_L1,
    l2: float = DEFAULT_L2,
) -> dict:
    """Mini-batch SGD: average the per-sample gradients over the batch, then
    take one regularized step. More stable than pure SGD on noisy focus data.
    """
    if not batch:
        return model
    n = len(batch)
    w = list(model.get("weights") or [0.0] * len(batch[0][0]))
    b = float(model.get("bias") or 0.0)
    gw = [0.0] * len(w)
    gb = 0.0
    for x, y in batch:
        err = _sigmoid(_dot(w, x) + b) - y
        for i in range(len(w)):
            gw[i] += err * x[i]
        gb += err
    lr_eff = lr / n
    for i in range(len(w)):
        grad = lr_eff * gw[i] + lr * l2 * w[i]
        new_w = w[i] - grad
        if new_w > lr * l1:
            new_w -= lr * l1
        elif new_w < -lr * l1:
            new_w += lr * l1
        else:
            new_w = 0.0
        w[i] = new_w
    b = b - lr_eff * gb
    total_n = int(model.get("n") or 0) + n
    return {"weights": w, "bias": b, "n": total_n}


# --- unsupervised: k-means ------------------------------------------------

def _dist2(a: Sequence[float], b: Sequence[float]) -> float:
    return sum((ai - bi) ** 2 for ai, bi in zip(a, b))


def kmeans(
    vectors: Sequence[Sequence[float]],
    k: int = CLUSTER_K,
    iters: int = CLUSTER_ITERS,
    seed: int = 42,
) -> dict:
    """Lloyd's k-means, pure Python, deterministic given `seed`.

    Returns {"centers": [...], "assign": [cluster index per vector]}.
    Fewer vectors than k -> degenerate: every point its own cluster center.
    """
    pts = [list(v) for v in vectors]
    if not pts:
        return {"centers": [], "assign": []}
    k = max(1, min(k, len(pts)))
    rng = random.Random(seed)
    # k-means++ style seeding (few rounds, deterministic).
    centers = [list(rng.choice(pts))]
    while len(centers) < k:
        d2 = [min(_dist2(p, c) for c in centers) for p in pts]
        total = sum(d2)
        if total <= 0:
            centers.append(list(rng.choice(pts)))
            continue
        r = rng.random() * total
        acc = 0.0
        for p, d in zip(pts, d2):
            acc += d
            if acc >= r:
                centers.append(list(p))
                break
    assign = [0] * len(pts)
    for _ in range(iters):
        changed = False
        for idx, p in enumerate(pts):
            best = 0
            best_d = _dist2(p, centers[0])
            for c in range(1, len(centers)):
                d = _dist2(p, centers[c])
                if d < best_d:
                    best_d = d
                    best = c
            if assign[idx] != best:
                assign[idx] = best
                changed = True
        # Recompute centers as the mean of assigned points.
        dim = len(centers[0])
        for c in range(len(centers)):
            members = [pts[i] for i in range(len(pts)) if assign[i] == c]
            if members:
                centers[c] = [sum(m[d] for m in members) / len(members) for d in range(dim)]
        if not changed:
            break
    return {"centers": centers, "assign": assign}


def cluster_label(center: Sequence[float], names: Sequence[str] = FEATURE_NAMES) -> str:
    """Human-readable tag for a cluster from its dominant feature."""
    if not center:
        return "unknown"
    # Map a few interpretable heuristics onto the feature means.
    hour = center[0] * 24 if len(center) > 0 else 12
    focused = center[2] if len(center) > 2 else 0.5
    off = center[5] if len(center) > 5 else 0.0
    if hour < 11:
        part = "morning"
    elif hour < 17:
        part = "afternoon"
    else:
        part = "evening"
    if focused >= 0.65:
        mood = "focused"
    elif off >= 0.5:
        mood = "easily-distracted"
    else:
        mood = "steady"
    return f"{part}-{mood}"


def drift_risk(x: Sequence[float], model: dict) -> float:
    """1 - P(stay focused): the number interventions react to. High risk means
    the student is predicted to drift soon -> guide earlier / act."""
    return 1.0 - predict_proba(x, model)


def should_intervene_early(risk: float, threshold: float = 0.6) -> bool:
    """Gate used by the live loop: nudge sooner when predicted risk is high."""
    return risk >= threshold
