import { useCallback, useRef } from "react";

/**
 * Synthesizes a short two-tone beep with the Web Audio API — no asset file
 * to bundle/ship. Reuses one AudioContext across calls (browsers cap how
 * many can exist, and creating one on mount would need a user gesture).
 */
export function useAlarmSound() {
  const ctxRef = useRef(null);

  return useCallback(function playAlarm() {
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!ctxRef.current) ctxRef.current = new Ctx();
      const ctx = ctxRef.current;
      if (ctx.state === "suspended") ctx.resume();

      const now = ctx.currentTime;
      const PEAK_GAIN = 0.5;   // was 0.15 — clearly audible over typical speaker/room volume, not max-loud
      const TONE_LEN = 0.32;   // was 0.18 — longer hold so it actually registers as a tone, not a click
      // Two-tone pattern repeated twice back to back reads as "an alarm"
      // rather than a single quiet blip that's easy to miss or mistake
      // for a notification sound.
      const sequence = [880, 660, 880, 660];
      sequence.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        const start = now + i * (TONE_LEN + 0.03);
        gain.gain.setValueAtTime(0, start);
        gain.gain.linearRampToValueAtTime(PEAK_GAIN, start + 0.03);
        gain.gain.setValueAtTime(PEAK_GAIN, start + TONE_LEN - 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, start + TONE_LEN);
        osc.connect(gain).connect(ctx.destination);
        osc.start(start);
        osc.stop(start + TONE_LEN);
      });
    } catch {
      // audio isn't essential — the visual alert still shows
    }
  }, []);
}
