"""
Smart-intervention decision core (pure, dependency-free, unit-testable).

Blueprint: three streams combine at the DECISION step —
  1. Sightings  (block_sightings, window probe)  -> WHAT keeps disturbing them
  2. Quiz data  (quizzes, already in the build)  -> are they learning the task
  3. Distraction metrics (focus_events, already) -> how much time was lost
Sightings alone trigger a PROPOSAL at >= 2 appearances; quiz + distraction
data decide how STRONG the case is. No Ollama, DB, or OS calls here — the
window monitor wires these functions into the live loop.
"""
import re
from datetime import datetime, timedelta
from typing import Optional

# Off-task labels that earn sightings/proposals. school_work/neutral -> do
# nothing (the blueprint's decision table).
OFF_TASK_LABELS = frozenset({"game", "social_media", "video"})

ALL_LABELS = frozenset({"school_work", "neutral", "social_media", "video", "game"})

# Game keywords shared by the title heuristic (heuristic_label) and the
# background process scan (match_game_process). Word-boundary matching on
# title text; process names are camel-split first (see match_game_process).
GAME_PROCESS_TERMS = (
    "roblox", "fortnite", "minecraft", "steam", "epic games", "league of legends",
    "valorant", "apex legends", "genshin", "call of duty", "counter-strike",
    "csgo", "counter strike", "dota", "overwatch", "rocket league", "among us",
    "gta", "grand theft auto", "fifa", "ea sports fc", "balatro", "terraria",
    "starcraft", "starcraft ii", "brawlhalla", "rocket", "pubg", "battlegrounds",
    "dead by daylight", "fall guys", "stardew", "hollow knight", "celeste",
    "undertale", "deltarune", "cuphead", "hades", "portal", "half life",
    "left 4 dead", "team fortress", "world of warcraft", "wow", "runescape",
    "osrs", "old school runescape", "rust", "ark", "ark survival", "no man's sky",
    "skyrim", "skyrim special", "fallout", "elder scrolls", "starfield",
    "cyberpunk", "witcher", "baldur's gate", "baldurs gate", "elden ring",
    "dark souls", "sekiro", "monster hunter", "palworld", "lethal company",
    "content warning", "helldivers", "minecraft dungeons", "minecraft legends",
    "roblox player", "roblox studio", "epicgameslauncher", "steamwebhelper",
    "steam error", "battle.net", "blizzard", "riot client", "valorant champions",
    "sim", "the sims", "sims 4", "animal crossing", "mario", "zelda",
    "pokemon", "smash", "kirby", "metroid", "splatoon", "fire emblem",
    "nintendo", "xbox", "playstation", "gamebar", "game dvr", "xbox game bar",
    "razer", "razer synapse", "wallpaper engine", "osu", "osu!",
    "trackmania", "counter-strike 2", "cs2", "escape from tarkov", "tarkov",
    "world of tanks", "war thunder", "warframe", "destiny", "destiny 2",
    "diablo", "overwatch 2", "league", "smite", "heroes of the storm",
    "hearthstone", "gwent", "runeterra", "minecraft launcher", "tlauncher",
    "hypixel", "wynncraft", "min club", "club penguin", "fnaf",
    "five nights", "poppy playtime", "granny", "amnesia", "outlast",
    "resident evil", "silent hill", "fatal frame", "dead space", "doom",
    "quake", "unreal tournament", "halo", "gears of war", "forza",
    "forza horizon", "need for speed", "burnout", "project cars", "f1 20",
    "mafia", "just cause", " saints row", "borderlands", "bioshock",
    "dishonored", "prey", "deathloop", "star wars", "jedi fallen", "jedi survivor",
    "batman arkham", "spider-man", "spiderman", "marvel's", "guardians",
    "hogwarts", "legacy", "suicide squad", "gotham knights", "injustice",
    "mortal kombat", "street fighter", "tekken", "guilty gear", "dragon ball",
    "naruto", "my hero", "jujutsu", "demon slayer", "genshin impact",
    "honkai", "zenless", "wuthering", "tower of fantasy", "lost ark",
    "new world", "albion", "eve online", "elite dangerous", "star citizen",
    "kerbal", "factorio", "satisfactory", "dwarf fortress", "rimworld",
    "prison architect", "cities skylines", "planet coaster", "planet zoo",
    "the tycoon", "rollercoaster", "simulator", "farming simulator",
    "mudrunner", "snowrunner", "euro truck", "american truck", "beamng",
    "assetto", "iracing", "rFactor", "dirt rally", "wreckfest",
)

# How long a matched game process gets a fair warning before the scanner
# WM_CLOSEs it (two scan passes at the default 15s cadence).
GAME_WARN_GRACE_SEC = 30.0

# Apps that must NEVER be app-blocked: the browser (the study session itself
# lives in a tab), the OS shell, and the tooling a student writes code in.
# Blocking these kills the session or the machine's ability to function.
NEVER_BLOCK_APPS = frozenset({
    "chrome", "msedge", "edge", "firefox", "brave", "opera", "vivaldi", "safari",
    "iexplore", "explorer", "windows explorer", "searchui", "searchhost",
    "shellExperienceHost", "shellexperiencehost", "startmenuexperiencehost",
    "applicationframehost", "runtimebroker", "dwm", "csrss", "sihost",
    "code", "codium", "pycharm", "intellij", "idea64", "webstorm",
    "notepad", "notepad++", "sublime_text", "windowsterminal", "windowsterminal",
    "powershell", "pwsh", "cmd", "wt", "stubilly",
})

# School / work domains that are educational by default: never auto-blocked.
# YouTube is intentionally NOT here - it is allowed only when task-relevant
# (see task_relevance), otherwise it is a distraction.
SCHOOL_ALLOWLIST = frozenset({
    "classroom.google.com", "drive.google.com", "docs.google.com",
    "sheets.google.com", "slides.google.com", "forms.google.com",
    "calendar.google.com", "meet.google.com", "scholar.google.com",
    "word.office.com", "excel.office.com", "powerpoint.office.com",
    "office.com", "office365.com", "outlook.office.com", "onedrive.live.com",
    "sharepoint.com", "teams.microsoft.com", "msteams",
    "canva.com", "www.canva.com", "desmos.com", "geogebra.org",
    "khanacademy.org", "www.khanacademy.org", "quizlet.com", "www.quizlet.com",
    "canvas.instructure.com", "instructure.com", "blackboard.com",
    "overleaf.com", "mendeley.com", "zotero.org", "notion.so", "www.notion.so",
    "github.com", "gitlab.com", "stackoverflow.com", "stackexchange.com",
    "wikipedia.org", "en.wikipedia.org", "wikimedia.org",
})

# Domains that are only allowed when the task makes them relevant (a research
# video, a cited talk). Otherwise they are classic time-sinks.
CONDITIONAL_ALLOWLIST = frozenset({
    "youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
})


# Proposal rules.
PROPOSAL_MIN_SIGHTINGS = 2       # >= 2 appearances -> proposal ticket
ALLOW_ONCE_COOLDOWN_SEC = 600    # after Allow once, don't re-propose for 10 min
SIGHTING_GAP_SEC = 30            # re-appearance after this gap = new sighting

# Evidence combo ("the smarter part"): all three together promote a ticket
# to "suggested" (strong case -> parent alert as well as admin bell).
QUIZ_FAIL_RATIO = 0.60           # score/total below this = failed the quiz
STRONG_DISTRACTION_SEC = 600     # >= 12 min distracted/sleeping in session
STRONG_SIGHTINGS = 3             # and the target came back 3+ times

# AUTO branch: admin-only toggle, high-confidence obvious cases only.
AUTO_BLOCK_MIN_CONFIDENCE = 0.90
AUTO_BLOCK_LABEL = "game"


def normalize_key(app: str, site: str) -> tuple[str, str]:
    """Pick the sighting identity: a real domain from the window title beats
    the process name (blocking youtube.com is more precise than blocking
    chrome). Returns (kind, key) with kind in {"site", "app"}."""
    clean_site = (site or "").strip().lower().split(":")[0].strip(".")
    clean_app = (app or "").strip().lower()
    if clean_site and clean_site not in ("stubilly", "localhost"):
        return "site", clean_site[:160]
    if not clean_app:
        return "app", ""
    if clean_app.endswith(".exe"):
        clean_app = clean_app[:-4]
    return "app", clean_app[:64]


def heuristic_label(app: str, title: str, site: str) -> dict:
    """Deterministic fallback classifier used when Ollama is unreachable —
    keyword tables for the obvious cases, neutral otherwise. Returns the
    same shape as classify_window(): {label, confidence, source}.

    Matching is word-boundary whole-term: bare substring matching misfires
    on short words ("word" hits "password"/"wordle", "gta" hits "gtalk").
    """
    blob = " ".join(filter(None, [app, site, title])).lower()

    game_terms = GAME_PROCESS_TERMS

    video_terms = (
        "youtube", "netflix", "twitch", "disney+", "hulu", "prime video",
        "disney plus", "video player", "vlc",
    )
    social_terms = (
        "facebook", "instagram", "tiktok", "twitter", "snapchat", "reddit",
        "discord", "whatsapp", "telegram", "messenger", "pinterest", "threads",
        "x.com",
    )
    school_terms = (
        "word", "excel", "powerpoint", "outlook", "onedrive", "google docs",
        "google sheets", "google classroom", "classroom", "canvas", "blackboard",
        "khan academy", "quizlet", "docs.google", "sheets.slides", "libreoffice",
        "notepad", "visual studio", "vscode", "zoom", "teams", "mendeley",
        "zotero", "overleaf", "desmos", "geogebra",
    )
    for terms, label, confidence in (
        (game_terms, "game", 0.9),
        (video_terms, "video", 0.85),
        (social_terms, "social_media", 0.85),
        (school_terms, "school_work", 0.8),
    ):
        for term in terms:
            if re.search(rf"\b{re.escape(term)}\b", blob):
                return {"label": label, "confidence": confidence, "source": "heuristic"}
    return {"label": "neutral", "confidence": 0.6, "source": "heuristic"}


def match_game_process(name: Optional[str]) -> bool:
    """True when a running process basename looks like a game or game
    launcher (Steam-based or standalone). camelCase/digit runs are split
    first so "RobloxPlayerBeta" matches the term "roblox"; long terms also
    match inside glued launcher names ("steamwebhelper"). Callers must
    still screen never-block apps (browser/terminal) before acting."""
    if not name:
        return False
    base = str(name).strip()
    if base.lower().endswith(".exe"):
        base = base[:-4]
    spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", base)
    blob = spaced.lower()
    compact = blob.replace(" ", "")
    for term in GAME_PROCESS_TERMS:
        if " " in term or "'" in term or "." in term:
            if term in blob:
                return True
            continue
        if re.search(rf"\b{re.escape(term)}\b", blob):
            return True
        if len(term) >= 7 and term in compact:
            return True
    return False


def next_sighting_state(
    prev_count: int,
    prev_last_seen: Optional[datetime],
    now: datetime,
    gap_cap_sec: float = 30.0,
) -> tuple[int, float]:
    """Apply one foreground observation to a sighting row.
    Returns (new_count, seconds_to_credit).
    - First sighting: count 1, credit 0 (row opens at 0s, like window_visits).
    - Continuous presence (gap <= SIGHTING_GAP_SEC): same sighting, credit gap.
    - Re-appearance after a gap: NEW sighting, credit only the capped head of
      the gap so a stalled loop/laptop resume can't dump a huge jump."""
    if prev_last_seen is None or prev_count <= 0:
        return 1, 0.0
    gap = (now - prev_last_seen).total_seconds()
    if gap <= 0:
        return max(1, prev_count), 0.0
    if gap <= SIGHTING_GAP_SEC:
        return max(1, prev_count), min(gap, gap_cap_sec)
    return max(1, prev_count) + 1, min(gap, gap_cap_sec)


def should_propose(
    count: int,
    existing_status: Optional[str],
    denied_before: bool,
    allow_once_at: Optional[datetime],
    now: datetime,
) -> tuple[bool, str]:
    """Whether sighting `count` should (re)create a proposal ticket for this
    session+key. Returns (should_propose, reason). Tickets in an open state
    already exist; a user-level Deny is final; Allow once cools down."""
    if denied_before:
        return False, "denied_earlier"
    if count < PROPOSAL_MIN_SIGHTINGS:
        return False, "below_threshold"
    if existing_status in ("proposed", "suggested", "deferred", "blocked"):
        return False, f"ticket_{existing_status}"
    if existing_status == "allowed_once" and allow_once_at is not None:
        if (now - allow_once_at).total_seconds() < ALLOW_ONCE_COOLDOWN_SEC:
            return False, "allow_once_cooldown"
    return True, "ok"


def compute_strength(
    quiz_fail: bool,
    distraction_seconds: float,
    count: int,
) -> str:
    """The combined-evidence rule: quiz fail AND high distraction AND 3+
    sightings => 'strong' (promoted to 'suggested' + parent alert)."""
    if (
        quiz_fail
        and distraction_seconds >= STRONG_DISTRACTION_SEC
        and count >= STRONG_SIGHTINGS
    ):
        return "strong"
    return "normal"


def latest_quiz_failed(score: Optional[int], question_count: Optional[int]) -> bool:
    """Pass/fail rule for the session's completed quiz (the build had a score
    but no threshold): below QUIZ_FAIL_RATIO = the student didn't know the
    step. No quiz or no questions => not a failure signal."""
    if score is None or not question_count or question_count <= 0:
        return False
    return (score / question_count) < QUIZ_FAIL_RATIO


def auto_block_decision(
    enabled: bool,
    label: str,
    confidence: float,
) -> bool:
    """Optional AUTO branch: only obvious, high-confidence cases."""
    return bool(enabled) and label == AUTO_BLOCK_LABEL and confidence >= AUTO_BLOCK_MIN_CONFIDENCE


# --- task relevance + block-vs-guide (the smarter intervention) -----------

_STOPWORDS = frozenset({
    "a", "an", "the", "and", "or", "of", "to", "in", "on", "for", "with",
    "is", "are", "am", "be", "my", "me", "i", "we", "you", "it", "at", "by",
    "from", "as", "that", "this", "these", "those", "do", "does", "did",
    "will", "would", "can", "could", "should", "about", "into", "over",
    "under", "up", "down", "out", "so", "not", "no", "yes", "how", "what",
    "when", "where", "who", "why", "which", "than", "then", "there", "here",
    "finish", "complete", "work", "homework", "assignment", "task", "study",
    "session", "project", "essay", "paper", "report", "class", "school",
    "page", "pages", "read", "reading", "write", "writing", "review",
    "notes", "note", "study", "prepare", "prep", "复习",
})


def task_keywords(task: Optional[str]) -> set[str]:
    """Content-bearing keywords from a task description (stopwords stripped)."""
    if not task:
        return set()
    words = re.findall(r"[a-z0-9']+", str(task).lower())
    return {w for w in words if len(w) >= 3 and w not in _STOPWORDS}


def task_relevance(
    title: Optional[str],
    site: Optional[str],
    app: Optional[str],
    task: Optional[str],
) -> float:
    """How relevant the current window is to the study task, 0..1.

    Compares the window title/site/app against the task's keywords. A high
    score means this target is probably ON the task even if it looks like a
    classic distraction (e.g. a YouTube video whose title matches the topic,
    or a Google Doc named after the assignment). Used to choose guide vs
    block for conditional-allowlist domains (YouTube) and to soften the
    off-task call."""
    keys = task_keywords(task)
    if not keys:
        return 0.0
    blob = " ".join(filter(None, [title, site, app])).lower()
    if not blob.strip():
        return 0.0
    hits = sum(1 for k in keys if k in blob)
    # Saturate: 3+ keyword hits is about as relevant as it gets.
    return min(1.0, hits / 3.0)


def extract_search_query(title, site=None):
    """Pull the user's search query out of a search-engine results page title.

    "photosynthesis - Google Search" -> "photosynthesis"
    Returns empty string when no query can be extracted.
    """
    t = (title or "").strip()
    if not t:
        return ""
    for suffix in (" - Google Search", " - Google", " | Google Search",
                   " - Google News", " - Search - Bing", " - Bing",
                   " | Bing", " - Yahoo Search", " - Yahoo",
                   " - DuckDuckGo", " at DuckDuckGo"):
        if t.endswith(suffix):
            return t[: -len(suffix)].strip()
    return ""


def should_never_block(app, site):
    """True for the browser/OS/tooling we must never app-block, and for
    school-allowlisted domains (which are educational by default)."""
    clean_app = (app or "").strip().lower()
    if clean_app.endswith(".exe"):
        clean_app = clean_app[:-4]
    if clean_app in NEVER_BLOCK_APPS:
        return True
    host = (site or "").strip().lower().split(":")[0].strip(".")
    if _is_stubilly_host(host):
        return True
    return host in SCHOOL_ALLOWLIST


def _is_stubilly_host(host: str) -> bool:
    """True for the study app's own identity: bare 'stubilly' or any
    subdomain of it (e.g. stubilly.tail9266d1.ts.net). Lookalikes like
    notstubilly.com are NOT the app."""
    if not host:
        return False
    return host == "stubilly" or host.split(".")[0] == "stubilly"


def decide_block_vs_guide(
    label: str,
    confidence: float,
    app: Optional[str],
    site: Optional[str],
    title: Optional[str],
    task: Optional[str],
    min_relevance: float = 0.0,
) -> str:
    """The smarter-intervention decision: 'block', 'guide', or 'ignore'.

    Site-level and app-level decisions are kept independent: a sighting of
    youtube.com is judged on the SITE (block/guide by task-relevance) even
    though the foreground app is chrome, because the browser itself is never
    app-blocked but the site can still be hosts-blocked.

    Rules, in order:
      1. Conditional-allowlist domains (YouTube) -> guide when task-relevant,
         block otherwise.
      2. School-allowlisted domains -> ignore (educational by default).
      3. Off-task label that is task-relevant (research video, related doc)
         -> GUIDE (nudge back), never hard-block.
      4. High-confidence off-task (game/social/video) that is NOT relevant
         -> BLOCK (unless the target is the browser/OS/tooling itself).
      5. Low-confidence or neutral/school_work -> IGNORE."""
    host = (site or "").strip().lower().split(":")[0].strip(".")
    # The study app itself is never a block/guide target - alerting on
    # Stubilly would interrupt the very tab the student studies in.
    if _is_stubilly_host(host):
        return "ignore"

    # Google search: the search query (in the title) determines relevance.
    # A search for the task topic is fine; an unrelated search is a nudge
    # (guide), not a hard block - Google is a school tool, but off-topic
    # searches still pull the student away from the task.
    _is_google = (host == "google.com" or host == "www.google.com"
                  or host.endswith(".google.com"))
    if _is_google:
        q = extract_search_query(title, site)
        if q:
            qrel = task_relevance(q, host, app, task)
            if qrel > 0:
                return "ignore"
            return "guide"
    # External signals (screen OCR, deep URL intel) can FLOOR the local
    # keyword score  Ethey raise relevance, never lower it.
    rel = max(task_relevance(title, site, app, task), float(min_relevance or 0.0))

    if host in CONDITIONAL_ALLOWLIST:
        # YouTube etc.: on-task research is fine; otherwise it's a distraction.
        return "guide" if rel > 0 else "block"

    if host in SCHOOL_ALLOWLIST:
        return "ignore"

    if label not in OFF_TASK_LABELS:
        return "ignore"

    # Off-task by label, but the title/domain actually matches the assignment:
    # they are probably researching. Guide, don't kill the window.
    if rel > 0:
        return "guide"

    # A pure app sighting (no site) of the browser/OS/tooling is never a
    # block target - the session lives in a browser tab.
    if not host and should_never_block(app, None):
        return "ignore"

    if confidence >= AUTO_BLOCK_MIN_CONFIDENCE:
        return "block"
    if confidence >= 0.6:
        return "guide"
    return "ignore"
