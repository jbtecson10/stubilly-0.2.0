import { useEffect, useState } from "react";
import { ShieldBan } from "lucide-react";

const AUTO_DISMISS_MS = 5000;

/**
 * The visible half of a hard-block hit. main.cjs already force-closed the
 * app (if native) and pulled Stubilly's window to the front by the time
 * this shows up — this is what makes that moment legible to the student
 * instead of the window just mysteriously popping to the front with an
 * alarm sound and no explanation.
 *
 * `event` is the raw payload from onHardBlockTriggered (or null/undefined
 * when nothing has fired yet). Each new event re-triggers the banner and
 * resets its own auto-dismiss timer, even if one was already showing.
 */
export default function HardBlockNotice({ event }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!event) return undefined;
    setVisible(true);
    const timer = setTimeout(() => setVisible(false), AUTO_DISMISS_MS);
    return () => clearTimeout(timer);
  }, [event]);

  if (!visible || !event) return null;

  return (
    <div className="hard-block-notice" role="alert">
      <ShieldBan size={22} />
      <div className="hard-block-notice-text">
        <strong>Blocked: {event.label || "that app"}</strong>
        <span>Stay focused — you've been brought back to Stubilly.</span>
      </div>
      <button
        type="button"
        className="hard-block-notice-dismiss"
        onClick={() => setVisible(false)}
        aria-label="Dismiss"
      >
        &times;
      </button>
    </div>
  );
}
