import { useCallback, useEffect, useMemo, useRef, useState } from "react";

const STORAGE_KEY = "stubilly.blocklist";

// A reasonable starting set of commonly distracting sites. Fully
// user-editable — this is a default, not a fixed policy.
export const DEFAULT_BLOCKLIST = [
  "facebook.com",
  "instagram.com",
  "tiktok.com",
  "twitter.com",
  "x.com",
  "youtube.com",
  "reddit.com",
  "netflix.com",
  "twitch.tv",
  "9gag.com",
];

// Takes whatever site shape a user typed — a full URL
// ("https://www.facebook.com/profile"), a short one ("facebook.com/friends"),
// or a bare site name ("facebook") — and reduces it to a single normalized
// host (or bare name) so all three become the same blocklist entry. A bare
// name is kept as-is: it can't be written to the hosts file, but it's still
// matched live against window titles by the main process.
export function normalizeSiteInput(raw) {
  let value = String(raw ?? "").trim().toLowerCase();
  if (!value) return null;
  if (value.startsWith("http://")) value = value.slice(7);
  else if (value.startsWith("https://")) value = value.slice(8);
  const cut = [value.indexOf("/"), value.indexOf("?"), value.indexOf("#")].filter(
    (i) => i >= 0
  );
  if (cut.length) value = value.slice(0, Math.min(...cut));
  value = value.replace(/:\d+$/, ""); // drop any :port
  if (value.startsWith("www.")) value = value.slice(4);
  value = value.replace(/\.+$/g, "").trim();
  if (!value) return null;
  if (/\s/.test(value)) {
    // Multi-word input ("new facebook", "youtube videos") — pull out an
    // embedded host when there is one, otherwise reject it rather than
    // letting a useless phrase into the blocklist.
    const embedded = value.match(/(?:^|[\s(['"(])([a-z0-9-]+\.[a-z]{2,})(?:[\s)'.'"\](!]|$)/);
    if (embedded) return embedded[1];
    if (/\s/.test(value)) return null;
  }
  return value;
}

function loadBlocklist() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {
    // corrupt/blocked storage — fall back to defaults
  }
  return DEFAULT_BLOCKLIST;
}

/**
 * Owns the site blocklist and the on/off state of real, system-wide
 * enforcement (redirects blocked domains to 127.0.0.1 in the OS hosts
 * file — see electron/hosts-blocker.cjs). This blocks every browser on
 * the machine, not just what's visible inside Stubilly, and needs a
 * one-time OS admin permission the first time it's turned on.
 *
 * Two layers:
 *  - `blocklist`   — the student's persistent base list (localStorage).
 *                    Survives restarts, is enforced in every session.
 *  - session bans  — every site added DURING a session (manual "block this",
 *                    auto-block of off-task sites, carried-over from a
 *                    resumed/continued session). Enforced for the whole
 *                    session but NOT persisted: they drop out the moment the
 *                    session ends (clearSessionBlocklistEntries) and don't
 *                    come back even if the app restarts.
 *
 * The UI reads `blocklist` (the merged view). `active` only ever reflects a
 * successful, confirmed toggle — never assume it's on just because
 * `enable()` was called, since the OS permission prompt can be cancelled.
 */
export function useTabBlocking() {
  const [blocklist, setBlocklist] = useState(loadBlocklist);
  const [sessionEntries, setSessionEntries] = useState([]);
  const [wanted, setWanted] = useState(false);
  const [active, setActive] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState(null);
  const available = Boolean(window.stubilly?.setStrictBlocking);
  const mountedRef = useRef(true);

  useEffect(
    () => () => {
      mountedRef.current = false;
    },
    []
  );

  const merged = useMemo(() => {
    const seen = new Set();
    const out = [];
    for (const entry of [...blocklist, ...sessionEntries]) {
      const key = String(entry).toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(entry);
    }
    return out;
  }, [blocklist, sessionEntries]);

  // Enable/disable are now just "what SHOULD the OS be doing right now".
  // The reconciler effect below is the single place that pushes state to the
  // main process, and it always pushes on every change — including a site
  // added while blocking happens to be off at that instant. That closes the
  // old gap where adding a site while `active` was false silently did
  // NOTHING until the next phase transition.
  const enable = useCallback(() => setWanted(true), []);
  const disable = useCallback(() => setWanted(false), []);

  const persist = useCallback((next) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // best-effort — an unsaved blocklist still works for this session
    }
    return next;
  }, []);

  // Persistent base entry (setup-time editing, the default list, or an
  // explicit "keep this permanently" add).
  const addBlocklistEntry = useCallback(
    (raw) => {
      const value = normalizeSiteInput(raw);
      if (!value) return;
      setBlocklist((prev) => {
        if (prev.some((e) => e.toLowerCase() === value.toLowerCase())) return prev;
        return persist([...prev, value]);
      });
    },
    [persist]
  );

  // Session-scoped "ban this site now": enforced while the session runs,
  // dropped at session end, never written to storage.
  const addSessionBlocklistEntry = useCallback(
    (raw) => {
      const value = normalizeSiteInput(raw);
      if (!value) return;
      setSessionEntries((prev) => {
        const exists =
          prev.some((e) => e.toLowerCase() === value.toLowerCase()) ||
          blocklist.some((e) => e.toLowerCase() === value.toLowerCase());
        return exists ? prev : [...prev, value];
      });
    },
    [blocklist]
  );

  // Admin-managed mode: the server policy wholesale-replaces the base list.
  // Persists locally too so offline restarts still enforce the same list,
  // but from now on the ADMIN owns the content — the student UI no longer
  // edits it. Session-scoped bans are untouched.
  const replaceBlocklist = useCallback(
    (list) => {
      const cleaned = (Array.isArray(list) ? list : [])
        .map((s) => String(s).trim())
        .filter(Boolean);
      setBlocklist(persist(cleaned));
    },
    [persist]
  );

  const removeBlocklistEntry = useCallback(
    (value) => {
      const v = String(value || "").toLowerCase();
      setBlocklist((prev) => persist(prev.filter((e) => e.toLowerCase() !== v)));
      setSessionEntries((prev) => prev.filter((e) => e.toLowerCase() !== v));
    },
    [persist]
  );

  // Session is over — release every session-scoped ban at once.
  const clearSessionBlocklistEntries = useCallback(() => setSessionEntries([]), []);

  // Single reconciler: on EVERY change to the desired state (wanted) or the
  // enforced list (merged), the OS is brought to exactly that state — on
  // when a session wants blocking and there's something to block, off
  // otherwise. Because it fires on every merged change too, a site added
  // mid-session is pushed live immediately, even if the previous push had
  // failed (e.g. a declined admin prompt) and `active` had gone false.
  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      const push = window.stubilly?.setStrictBlocking;
      if (!push) {
        // Web mode: system-level enforcement lives on the SERVER (its hosts
        // file, refreshed from the admin policy + break state — see
        // backend/site_blocking.py). The browser has nothing to push here;
        // without this guard the reconciler used to throw on every mount and
        // leave `pending` stuck true.
        setPending(false);
        setActive(false);
        setError(null);
        return;
      }
      const shouldEnforce = wanted && merged.length > 0;
      setPending(true);
      setError(null);
      const result = await push(shouldEnforce ? merged : []);
      if (cancelled || !mountedRef.current) return;
      setPending(false);
      if (shouldEnforce) {
        setActive(Boolean(result?.ok));
        if (!result?.ok) setError(result?.error || "Couldn't enable site blocking");
      } else {
        setActive(false); // treat as off either way
        if (!result?.ok) setError(result?.error || "Couldn't fully disable site blocking");
      }
    };
    run();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wanted, merged]);

  return {
    blocklist: merged,
    active,
    pending,
    error,
    available,
    enable,
    disable,
    addBlocklistEntry,
    addSessionBlocklistEntry,
    removeBlocklistEntry,
    replaceBlocklist,
    clearSessionBlocklistEntries,
  };
}