"""
User/admin authentication for the Stubilly administration hub.

Deliberately dependency-free (stdlib only) so it survives the PyInstaller
bundle: passwords are hashed with PBKDF2-HMAC-SHA256 + a per-user salt,
tokens are secrets.token_urlsafe strings kept in an in-memory map, and
administrators are the admins table (username + password, stored plainly so
each admin can read their own from the hub) — there is no shared PIN anymore.
"""

import hashlib
import hmac
import os
import secrets
import time
from datetime import datetime

ADMIN_TOKEN_TTL_SEC = 12 * 60 * 60  # admin session lasts 12h

# token -> (user_id, last_seen epoch). The student app calls an
# authenticated endpoint roughly every 5s while signed in (its policy
# poll), which "touches" the entry — so a user counts as online exactly
# while their app is alive. When the app closes (or crashes), the touch
# stops and they flip to offline once the window below is exceeded. The
# admin hub polls the user list every few seconds and reflects that in
# real time without any manual refresh.
_USER_TOKENS: dict[str, tuple[int, float]] = {}
# Tokens that went quiet on their own (tab frozen/discarded by the browser,
# machine asleep, laptop lid closed) are parked here instead of being thrown
# away, so that tab can pick its session back up rather than being told the
# session expired while it was simply sitting there. Explicit sign-out and
# account deletion remove the token from here too, so those remain final.
_IDLE_LAPSED_TOKENS: dict[str, tuple[int, float]] = {}
# admin_token -> admin_id (so /admin/admins knows who "me" is)
_ADMIN_TOKENS: dict[str, int] = {}

# How long a user's app can go without any authenticated request before the
# token is treated as stale (and the user shown offline). Must exceed the
# app's poll interval (5s) AND browser intensive throttling on hidden tabs
# (~once per minute) so a healthy student never flickers offline while the
# admin tab is focused. Focus-WS frames also touch the token (timer-free).
USER_TOKEN_TTL_SEC = 75

# How long a token that merely went idle may be resumed (reactivate_user_token).
# Long enough to cover a whole school day of a laptop that was asleep or a tab
# the browser discarded; it never resurrects a signed-out or deleted session.
USER_TOKEN_IDLE_GRACE_SEC = 12 * 60 * 60

# How long a signed-in token stays usable across a backend restart. The token
# is remembered (as a hash) in the usersessions table, so a restart no longer
# ends anybody's session; this is the outer bound on that. Signing out still
# revokes it immediately, so a student who really logged out stays logged out.
SESSION_MAX_AGE_DAYS = 30


# ---------------------------------------------------------------------------
# Brute-force throttling (in-memory, per-process)
#
# Every failed login / failed recovery-code attempt is recorded against a
# key (identifier, admin username, client IP, recovery email). Once a key
# burns through its cap inside the sliding window the endpoint answers 429
# instead of even looking at credentials — a 6-digit code or a wordlist can
# no longer be ground down at leisure. Successful attempts clear the key.
# Counts live in process memory: a restart forgets them (acceptable — the
# caps exist to stop online grinding, and the recovery code itself is
# TTL-bound in the database either way). Caps/window are env-tunable so the
# test batteries can widen them if a suite ever needs more slack:
#   STUBILLY_LOGIN_MAX_FAILS      (default 15 per identifier / 5 min)
#   STUBILLY_LOGIN_MAX_FAILS_IP   (default 300 per client IP  / 5 min)
#   STUBILLY_RESET_MAX_FAILS      (default 5 per recovery email / 5 min)
#   STUBILLY_FAIL_WINDOW_SEC      (default 300)
# ---------------------------------------------------------------------------
_FAILS: dict[str, list[float]] = {}
_FAILS_SWEEP_LIMIT = 8192


def _env_int(name: str, default: int) -> int:
    try:
        return max(1, int(os.environ.get(name, str(default))))
    except ValueError:
        return default


def _fail_window() -> float:
    try:
        return max(30.0, float(os.environ.get("STUBILLY_FAIL_WINDOW_SEC", "300")))
    except ValueError:
        return 300.0


def _window(key: str) -> list[float]:
    """Key's attempt timestamps still inside the sliding window (also prunes)."""
    now = time.time()
    hits = [t for t in _FAILS.get(key, ()) if now - t < _fail_window()]
    if hits:
        _FAILS[key] = hits
    else:
        _FAILS.pop(key, None)
    return hits


def is_locked(key: str, max_fails: int) -> bool:
    """True when `key` has already burned `max_fails` attempts in the window."""
    return len(_window(key)) >= max_fails


def note_fail(key: str) -> None:
    hits = _window(key)
    hits.append(time.time())
    _FAILS[key] = hits
    if len(_FAILS) > _FAILS_SWEEP_LIMIT:
        # Identifier spray would otherwise grow this map without bound.
        now = time.time()
        for stale in [k for k, v in _FAILS.items() if not v or now - v[-1] >= _fail_window()]:
            _FAILS.pop(stale, None)


def clear_fails(key: str) -> None:
    _FAILS.pop(key, None)


def login_max_fails() -> int:
    return _env_int("STUBILLY_LOGIN_MAX_FAILS", 15)


def login_max_fails_ip() -> int:
    return _env_int("STUBILLY_LOGIN_MAX_FAILS_IP", 300)


def reset_max_fails() -> int:
    return _env_int("STUBILLY_RESET_MAX_FAILS", 5)


# ---------------------------------------------------------------------------
# Password hashing (PBKDF2-HMAC-SHA256, stdlib)
# ---------------------------------------------------------------------------

def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120_000)
    return f"{salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, dk_hex = stored.split("$")
        salt = bytes.fromhex(salt_hex)
        dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 120_000)
        return hmac.compare_digest(dk.hex().lower(), dk_hex.lower())
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------------------
# User tokens
# ---------------------------------------------------------------------------

def _hash_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def issue_user_token(user_id: int) -> str:
    token = secrets.token_urlsafe(32)
    _USER_TOKENS[token] = (user_id, time.time())
    _persist_token(user_id, token, revoke=False)
    return token


def _persist_token(user_id: int, token: str, revoke: bool) -> None:
    """Record (or revoke) a token in the database.

    The registry above lives in memory, so before this existed a backend restart
    silently logged every signed-in student and parent out - and since
    run-web.bat now restarts a crashed backend by itself, that could happen
    mid-lesson. A restart should be invisible: the browser keeps its token and
    keeps working. Only the HASH is stored, and only at sign-in / sign-out, so
    this is never a hot path.
    """
    try:
        import models
        from database import SessionLocal
        db = SessionLocal()
        try:
            row = (db.query(models.UserSession)
                   .filter(models.UserSession.token_hash == _hash_token(token))
                   .first())
            if row is None:
                if revoke:
                    return
                db.add(models.UserSession(
                    user_id=user_id, token_hash=_hash_token(token),
                    created_at=datetime.now(), revoked=0))
            else:
                row.revoked = 1 if revoke else 0
                row.revoked_at = datetime.now() if revoke else None
                if not revoke:
                    row.user_id = user_id
            db.commit()
        finally:
            db.close()
    except Exception:
        # Never let bookkeeping break an actual sign-in/sign-out.
        pass


def _user_id_from_database(token: str) -> int | None:
    """Accept a token this process has never seen, if the database still calls
    the session live.

    This is what makes a backend restart invisible. The browser still holds a
    perfectly good token; the in-memory registry is simply empty after the
    restart, so the first request the student makes resolves their account from
    the hashed session row and carries on instead of being told the session
    expired mid-lesson.

    Everything a sign-out must still guarantee is enforced here: a revoked
    token fails, a deleted or deactivated account fails, and a token older than
    SESSION_MAX_AGE_DAYS fails. Costs one indexed lookup, and only for tokens
    that are NOT already in memory - a normal request never comes through here.
    """
    try:
        import models
        from database import SessionLocal
        db = SessionLocal()
        try:
            row = (db.query(models.UserSession)
                   .filter(models.UserSession.token_hash == _hash_token(token))
                   .filter(models.UserSession.revoked == 0)
                   .first())
            if row is None:
                return None
            created = row.created_at or datetime.now()
            if (datetime.now() - created).days > SESSION_MAX_AGE_DAYS:
                return None
            account = (db.query(models.User)
                       .filter(models.User.id == row.user_id)
                       .filter(models.User.is_active == 1)
                       .first())
            if account is None:
                return None
            return row.user_id
        finally:
            db.close()
    except Exception:
        # A database hiccup must never silently authenticate anybody.
        return None


def restore_user_token(token: str | None) -> int | None:
    """Put a still-valid, unknown token back into the live registry.

    Used when a request presents a token this process does not know, which in
    practice means the backend restarted while the student was signed in.
    """
    if not token:
        return None
    user_id = _user_id_from_database(token)
    if user_id is not None:
        _USER_TOKENS[token] = (user_id, time.time())
        _IDLE_LAPSED_TOKENS.pop(token, None)
    return user_id


def get_user_from_token(token: str | None, touch: bool = True):
    """Resolves a user token to a user id. `touch=True` (the default) bumps
    the token's last-seen timestamp — used by every authenticated student
    request so presence stays accurate. Pass `touch=False` for pure reads
    that shouldn't extend a session (e.g. logout's own lookups).

    A token resolves three ways, in this order:
      1. it is live in this process's registry (the normal case);
      2. it was parked by user_ids_online() after going quiet on its own, so
         the tab comes back and is revived (within USER_TOKEN_IDLE_GRACE_SEC);
      3. this process has never seen it because the backend restarted while
         the student was signed in - the usersessions table still calls it
         live, so it is accepted (restore_user_token).

    Steps 2 and 3 are what stop "Your session expired - please sign in again"
    from appearing for somebody who never signed out. Explicit sign-out and
    account deletion revoke the stored session, so they still fail all three.
    """
    if not token:
        return None
    entry = _USER_TOKENS.get(token)
    if entry is not None:
        user_id, _ = entry
        if touch:
            _USER_TOKENS[token] = (user_id, time.time())
        return user_id

    # (2) Resuming a tab that went quiet: frozen, discarded, laptop asleep, or
    # just backgrounded long enough that even the keepalive ping was throttled.
    parked = _IDLE_LAPSED_TOKENS.get(token)
    if parked is not None:
        user_id, when = parked
        if time.time() - when <= USER_TOKEN_IDLE_GRACE_SEC:
            _IDLE_LAPSED_TOKENS.pop(token, None)
            _USER_TOKENS[token] = (user_id, time.time())
            return user_id
        _IDLE_LAPSED_TOKENS.pop(token, None)

    # (3) Unknown here: the backend restarted under a signed-in student.
    return restore_user_token(token)


def user_ids_online() -> set[int]:
    """Who currently holds a live (recently-touched) token — used by the
    admin hub to show who is signed in right now (independent of open
    login_events).

    A token that merely went quiet is MOVED to the idle-lapse map instead of
    being destroyed, so a tab that was frozen/discarded by the browser (its
    timers stopped entirely, so even the keepalive ping could not run) can
    pick its session back up instead of being told it expired. Signing out
    and deleting an account erase the token from both maps, so those stay
    final."""
    now = time.time()
    stale = [t for t, (_, last) in _USER_TOKENS.items() if now - last > USER_TOKEN_TTL_SEC]
    for t in stale:
        uid, _ = _USER_TOKENS.pop(t)
        _IDLE_LAPSED_TOKENS[t] = (uid, now)
    # Drop grace-expired entries so the map cannot grow without bound.
    for t, (_, when) in list(_IDLE_LAPSED_TOKENS.items()):
        if now - when > USER_TOKEN_IDLE_GRACE_SEC:
            _IDLE_LAPSED_TOKENS.pop(t, None)
    return {uid for (uid, last) in _USER_TOKENS.values() if now - last <= USER_TOKEN_TTL_SEC}


def revoke_user_token(token: str):
    """Explicit sign-out: final. Forgets the idle-lapsed copy and the stored
    session too, so this token can never be accepted again."""
    _USER_TOKENS.pop(token, None)
    _IDLE_LAPSED_TOKENS.pop(token, None)
    _persist_token(0, token, revoke=True)


def touch_user_token(token: str | None) -> int | None:
    """Keep an existing token alive and return its user id, or None if the
    token is unknown.

    An idle but open app (a student sitting on the home screen, a parent
    leaving the dashboard open) makes no authenticated request at all, so its
    token used to age past USER_TOKEN_TTL_SEC and the next call came back
    401 - "Your session expired - please sign in again" - even though nobody
    had signed out. Live sockets touch the token from the server side and the
    app pings /auth/keepalive, so a genuinely idle tab stays signed in for as
    long as it is open."""
    return get_user_from_token(token, touch=True)


def reactivate_user_token(token: str | None) -> int | None:
    """Bring an idle-LAPSED token back to life and return its user id.

    Only tokens that went quiet on their own qualify, and only within
    USER_TOKEN_IDLE_GRACE_SEC. A token revoked by an explicit sign-out, or by
    the deletion of the account, is not in this map at all - so "sign out"
    and "remove this account" still end the session for good.

    The caller must still confirm the account exists and is active (a
    deleted account must never come back this way)."""
    if not token:
        return None
    user_id = get_user_from_token(token, touch=True)
    if user_id is not None:
        return user_id
    entry = _IDLE_LAPSED_TOKENS.get(token)
    if entry is None:
        return None
    user_id, when = entry
    if time.time() - when > USER_TOKEN_IDLE_GRACE_SEC:
        _IDLE_LAPSED_TOKENS.pop(token, None)
        return None
    _USER_TOKENS[token] = (user_id, time.time())
    return user_id


def revoke_all_user_tokens(user_id: int):
    """Revoke ALL tokens for a given user (logout from all devices/sessions,
    or the account being deleted). Also revokes the stored sessions, so a
    restart can never bring one of them back."""
    to_remove = [t for t, (uid, _) in _USER_TOKENS.items() if uid == user_id]
    for t in to_remove:
        _USER_TOKENS.pop(t, None)
    for t, (uid, _) in list(_IDLE_LAPSED_TOKENS.items()):
        if uid == user_id:
            _IDLE_LAPSED_TOKENS.pop(t, None)
    for t in to_remove:
        _persist_token(user_id, t, revoke=True)
    try:
        import models
        from database import SessionLocal
        from sqlalchemy import update
        db = SessionLocal()
        try:
            gone = db.query(models.User.id).filter(
                models.User.id == user_id).first() is None
            if gone:
                # The account was deleted (SQLite runs with foreign_keys=ON, so
                # its session rows have to go with it or the DELETE 500s).
                db.query(models.UserSession).filter(
                    models.UserSession.user_id == user_id).delete(
                        synchronize_session=False)
            else:
                db.execute(
                    update(models.UserSession)
                    .where(models.UserSession.user_id == user_id)
                    .values(revoked=1, revoked_at=datetime.now())
                )
            db.commit()
        finally:
            db.close()
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Admin tokens (unlock the hidden hub)
# ---------------------------------------------------------------------------

def issue_admin_token(admin_id: int) -> str:
    token = secrets.token_urlsafe(32)
    _ADMIN_TOKENS[token] = admin_id
    return token


def get_admin_id(token: str | None):
    if not token:
        return None
    admin_id = _ADMIN_TOKENS.get(token)
    if admin_id is None:
        return None
    return admin_id


def is_admin_token(token: str | None) -> bool:
    return get_admin_id(token) is not None


def revoke_admin_token(token: str):
    _ADMIN_TOKENS.pop(token, None)


def revoke_all_admin_tokens(admin_id: int):
    """Revoke ALL tokens for a given admin (logout from all devices/sessions)."""
    to_remove = [t for t, aid in _ADMIN_TOKENS.items() if aid == admin_id]
    for t in to_remove:
        _ADMIN_TOKENS.pop(t, None)