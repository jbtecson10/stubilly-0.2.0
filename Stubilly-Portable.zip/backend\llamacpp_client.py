"""
Thin wrapper around llama.cpp's llama-server OpenAI-compatible REST API.

Same public interface as ollama_client.py so the rest of the app can swap
between Ollama and llama.cpp via the STUBILLY_LLM_BACKEND env var without
touching any call site. llama-server exposes POST /v1/chat/completions
(OpenAI format) and GET /health.
"""
import httpx
import json
import logging
import os
from typing import AsyncIterator, Optional

from ollama_client import OllamaUnavailableError, _extract_json_docs

logger = logging.getLogger("stubilly.llamacpp")

LLAMACPP_BASE_URL = os.getenv("STUBILLY_LLAMACPP_URL", "http://localhost:8080").strip().rstrip("/")
DEFAULT_MODEL = os.getenv("STUBILLY_LLAMACPP_MODEL", "qwen2.5-7b").strip()

# Same knobs as ollama_client — translated to OpenAI format below.
# num_ctx is a server-level setting in llama.cpp (-c flag), not per-request,
# so it is omitted from the payload.
CHAT_OPTIONS = {"num_predict": 300, "temperature": 0.7}
TASK_OPTIONS = {"num_predict": 320, "temperature": 0}
QUIZ_OPTIONS = {"num_predict": 900, "temperature": 0.3}
CLASSIFY_OPTIONS = {"num_predict": 40, "temperature": 0}
CLASSIFY_TIMEOUT = 4.0


def _to_openai_payload(messages: list[dict], options: dict | None, stream: bool) -> dict:
    opts = options or {}
    payload: dict = {
        "messages": messages,
        "stream": stream,
    }
    if "temperature" in opts:
        payload["temperature"] = opts["temperature"]
    if "num_predict" in opts:
        payload["max_tokens"] = opts["num_predict"]
    return payload


async def _chat(
    messages: list[dict],
    model: str = DEFAULT_MODEL,
    timeout: float = 30.0,
    options: dict | None = None,
) -> str:
    """Low-level call to /v1/chat/completions (non-streaming)."""
    payload = _to_openai_payload(messages, options, stream=False)
    payload["model"] = model
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                f"{LLAMACPP_BASE_URL}/v1/chat/completions", json=payload
            )
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException) as e:
        raise OllamaUnavailableError(
            f"Can't reach llama.cpp at {LLAMACPP_BASE_URL} — is llama-server running?"
        ) from e
    except httpx.HTTPStatusError as e:
        raise OllamaUnavailableError(f"llama.cpp returned an error: {e}") from e


async def generate_microtasks(task_description: str, model: str = DEFAULT_MODEL) -> list[dict]:
    system_prompt = (
        "You create the 'Today's steps' checklist for a student, based ONLY on the exact "
        "topic they typed for this session (it is quoted below). Every step must be "
        "directly about THAT topic — concrete, specific, startable within ~10 minutes, "
        "and written so a reader can tell which topic it serves. Steps that could apply "
        "to any subject ('review notes', 'practice problems', 'stay focused') are "
        "forbidden unless they name precisely what to review or practice, drawn from the "
        "topic itself.\n"
        "Produce the MINIMUM number of crucial, high-impact steps (usually 2-4) that "
        "move this topic forward the most right now. Respond with ONLY a JSON array, "
        "no preamble, no markdown fences, no explanation.\n"
        'Format: [{"description": "...", "estimated_minutes": 8}, ...]'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": f'Topic: "{task_description}"'},
            ],
            model=model,
            options=TASK_OPTIONS,
        )
        docs = _extract_json_docs(raw)
        candidates = []
        for d in docs:
            if isinstance(d, list):
                candidates.extend(d)
            elif isinstance(d, dict) and isinstance(d.get("tasks"), list):
                candidates.extend(d["tasks"])
        if candidates and all("description" in t for t in candidates):
            seen = set()
            deduped = []
            for t in candidates[:8]:
                desc = str(t["description"]).strip()
                key = desc.lower()
                if not desc or key in seen:
                    continue
                seen.add(key)
                deduped.append({
                    "description": desc,
                    "estimated_minutes": t.get("estimated_minutes") if isinstance(t.get("estimated_minutes"), int) else 10,
                })
            if deduped:
                return deduped[:4]
        raise ValueError("Malformed task list from model")
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Falling back to generic task breakdown: {e}")
        return [{"description": task_description, "estimated_minutes": 25}]


async def generate_quiz(
    task_description: str,
    subject: str | None = None,
    steps: list[str] | None = None,
    notes: list[str] | None = None,
    chat_excerpt: list[str] | None = None,
    difficulty: str = "medium",
    num_questions: int = 5,
    model: str = DEFAULT_MODEL,
) -> list[dict]:
    steps = [s for s in (steps or []) if s][:8]
    notes = [n for n in (notes or []) if n][:6]
    chat_excerpt = [m for m in (chat_excerpt or []) if m][:6]

    level = {
        "easy": "recall — remember or recognise facts explicitly present in the material",
        "medium": "application — apply the material to a short, concrete situation",
        "hard": "analysis and synthesis — connect ideas, compare approaches, or "
                "reason through a multi-step scenario from the material",
    }.get(difficulty, "application")

    material_parts = [f"Session task: {task_description}"]
    if subject:
        material_parts.append(f"Declared subject: {subject}")
    if steps:
        material_parts.append("Study plan steps:\n" + "\n".join(f"- {s}" for s in steps))
    if notes:
        material_parts.append("Notes captured during the session:\n" + "\n".join(f"- {n}" for n in notes))
    if chat_excerpt:
        material_parts.append("Chat excerpt:\n" + "\n".join(chat_excerpt))
    material = "\n\n".join(material_parts)

    system_prompt = (
        "You write a short multiple-choice quiz for a student, testing what they "
        "studied in ONE study session. Use ONLY the material provided — never "
        "invent facts that are not in it, and make every question answerable "
        "from that material alone.\n"
        f"Difficulty: {difficulty} ({level}).\n"
        f"Produce exactly {num_questions} distinct questions, each with "
        "2-4 plausible options and exactly ONE correct option. Options must be "
        "short. Vary which option is correct. Do not reference 'the material "
        "above' — embed what's needed in the question text.\n"
        "Respond with ONLY a JSON array, no preamble, no markdown fences, no "
        "explanation.\n"
        'Format: [{"prompt": "...", "options": ["...", "..."], "correct_index": 0}, ...]'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": material},
            ],
            model=model,
            options=QUIZ_OPTIONS,
        )
        docs = _extract_json_docs(raw)
        candidates: list = []
        for d in docs:
            if isinstance(d, list):
                candidates.extend(d)
            elif isinstance(d, dict) and isinstance(d.get("questions"), list):
                candidates.extend(d["questions"])
        validated = []
        seen = set()
        for q in candidates:
            if not isinstance(q, dict):
                continue
            prompt = str(q.get("prompt") or "").strip()
            opts = q.get("options")
            if not prompt or not isinstance(opts, list):
                continue
            options = [str(o).strip() for o in opts if str(o).strip()]
            try:
                correct = int(q.get("correct_index"))
            except (TypeError, ValueError):
                continue
            if len(options) < 2 or len(options) > 4 or not (0 <= correct < len(options)):
                continue
            key = prompt.lower()
            if key in seen:
                continue
            seen.add(key)
            validated.append({
                "prompt": prompt,
                "options": options,
                "correct_index": correct,
            })
            if len(validated) >= num_questions:
                break
        if not validated:
            raise ValueError("No usable questions in model output")
        return validated
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError) as e:
        logger.warning(f"Quiz generation falling back to checklist questions: {e}")
        return []


async def refine_tasks(
    task_description: str,
    current_tasks: list[str],
    transcript: str,
    model: str = DEFAULT_MODEL,
) -> list[dict] | None:
    current_bullets = "\n".join(f"- {t}" for t in current_tasks) or "- (empty)"
    system_prompt = (
        "You keep a student's live focus-session checklist. It holds ONLY the crucial, "
        "highest-impact steps needed right now — 2-4 sharp items, no filler, no busywork. "
        "Given the student's task, their CURRENT checklist, and the most recent conversation, "
        "say the plan CHANGED when the conversation reveals any of these concrete signals:\n"
        "  - a new assignment or deliverable is due (e.g. 'worksheet on X due today');\n"
        "  - the professor/exam specified a subtopic or skill that must be added;\n"
        "  - the student reports a blocker, a mistake, or a discovered gap in what they planned;\n"
        "  - the student explicitly re-prioritizes ('I need to finish X first').\n"
        "When changed, the target checklist is the FULL new plan (2-4 items, importance order), "
        "keeping whatever is still relevant verbatim-ish and swapping in what the chat proved must "
        "change. If the student has clearly switched to a different subject than the session task, "
        "the new checklist follows THEIR stated subject, not the old one. DO NOT change the plan for "
        "small talk, thanks, generic encouragement, or "
        "explanations of what is already on the checklist — those return changed:false. "
        "When unsure, keep the plan as-is.\n"
        'Respond with ONLY JSON, no markdown fences: {"changed": true/false}. When true, include '
        '"tasks": [{"description": "...", "estimated_minutes": int}, ...], descriptions short, '
        "action-first, each startable within ~10 minutes."
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"Task: {task_description}\n\n"
                        f"Current checklist:\n{current_bullets}\n\n"
                        f"Recent conversation:\n{transcript}"
                    ),
                },
            ],
            model=model,
            timeout=20.0,
            options=TASK_OPTIONS,
        )
        docs = _extract_json_docs(raw)
        changed = any(d.get("changed") if isinstance(d, dict) else False for d in docs)
        if not changed:
            return None
        tasks = None
        for d in docs:
            if isinstance(d, dict) and isinstance(d.get("tasks"), list):
                tasks = d["tasks"]
                break
        valid = isinstance(tasks, list) and tasks and all(
            isinstance(t.get("description"), str) and t["description"].strip() for t in tasks
        )
        return tasks if valid else None
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError, TypeError) as e:
        logger.info(f"Checklist refine skipped: {e}")
        return None


async def generate_nudge_message(task_description: str, distracted_seconds: int, model: str = DEFAULT_MODEL) -> str:
    system_prompt = (
        "You are Stubilly, a warm, non-judgmental study companion. The student has been "
        "distracted for a bit. Write ONE short sentence (under 20 words) gently nudging them "
        "back to their task. No preamble, just the sentence."
    )
    try:
        return await _chat(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": f"Task: {task_description}. Distracted for {distracted_seconds} seconds.",
                },
            ],
            model=model,
        )
    except OllamaUnavailableError:
        return "Hey — still with me? Let's get back to it."


async def generate_check_in_prompt(
    task_description: str,
    minutes_in: int,
    tone: str = "gentle",
    focus_pct: Optional[float] = None,
    model: str = DEFAULT_MODEL,
) -> str:
    focus_note = (
        f"Their measured focus so far is about {int(focus_pct)}% (lower = distracted). "
        if focus_pct is not None
        else "No focus readings yet this run. "
    )
    if tone == "firm":
        sys = (
            "You are Stubilly, a direct, action-oriented study coach. Write ONE short "
            "sentence (under 18 words) for a periodic progress check-in. Ask the student "
            "where they stand on their task or what the next concrete step is — "
            "straight to the point, no fluff, never accusatory."
        )
    else:
        sys = (
            "You are Stubilly, a warm, non-judgmental study companion. Write ONE short, "
            "encouraging sentence (under 18 words) for a periodic progress check-in. "
            "Ask how the student is doing on their task or what they need to keep going — "
            "supportive, no preamble."
        )
    try:
        text = await _chat(
            [
                {"role": "system", "content": sys},
                {
                    "role": "user",
                    "content": (
                        f"Task: {task_description}. Minutes in so far: {minutes_in}. "
                        f"{focus_note}Write just the check-in question."
                    ),
                },
            ],
            model=model,
        )
    except OllamaUnavailableError:
        return (
            f"Check-in — about {minutes_in} min on \"{task_description[:60]}\". "
            "How's it going?"
        )
    if not text or not str(text).strip():
        return (
            f"Check-in — about {minutes_in} min on \"{task_description[:60]}\". "
            "How's it going?"
        )
    return str(text).strip()


async def generate_study_links(task_description: str, model: str = DEFAULT_MODEL) -> list[str]:
    system_prompt = (
        "Given a student's task, suggest 2-3 short, specific search queries or documentation "
        "topics that would help them. Respond with ONLY a JSON array of strings, no explanation. "
        'Format: ["query 1", "query 2"]'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": task_description},
            ],
            model=model,
        )
        cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        links = json.loads(cleaned)
        if isinstance(links, list):
            return links
        raise ValueError
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError):
        return []


def build_companion_system_prompt(task_description: str, focus_state: str = "", seconds_in_state: int = 0) -> str:
    return (
        "You are Stubilly, a friendly and supportive study assistant.\n"
        f"The student's current task: {task_description}\n\n"
        "Keep replies short and practical — usually 1-3 sentences. Answer questions "
        "directly. If they seem off-task or discouraged, give a brief, warm reminder "
        "to refocus. Never lecture, never repeat yourself. If they ask for detail, "
        "give a bit more; otherwise stay brief."
    )


async def warm_model(model: str = DEFAULT_MODEL) -> None:
    """No-op: llama-server loads the model at startup and keeps it resident."""
    pass


async def stream_companion_reply(
    messages: list[dict],
    model: str = DEFAULT_MODEL,
    fail_fast: bool = False,
) -> AsyncIterator[str]:
    payload = _to_openai_payload(messages, CHAT_OPTIONS, stream=True)
    payload["model"] = model
    try:
        stream_timeout = httpx.Timeout(connect=10.0, read=45.0, write=10.0, pool=10.0)
        async with httpx.AsyncClient(timeout=stream_timeout) as client:
            async with client.stream(
                "POST",
                f"{LLAMACPP_BASE_URL}/v1/chat/completions",
                json=payload,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line or not line.startswith("data: "):
                        continue
                    data = line[len("data: "):].strip()
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                    except json.JSONDecodeError:
                        continue
                    piece = chunk.get("choices", [{}])[0].get("delta", {}).get("content", "")
                    if piece:
                        yield piece
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException):
        if fail_fast:
            raise OllamaUnavailableError("llama.cpp unreachable") from None
        yield "I can't reach my brain right now (llama.cpp is offline) — but I'm still here with you."
    except httpx.HTTPStatusError:
        if fail_fast:
            raise OllamaUnavailableError("llama.cpp HTTP error") from None
        yield "Something glitched on my end — mind trying that again?"


async def extract_note(
    task_description: str,
    user_text: str,
    companion_reply: str,
    model: str = DEFAULT_MODEL,
    existing_notes: list[str] | None = None,
) -> Optional[str]:
    existing = existing_notes or []
    existing_bullets = "\n".join(f"- {n}" for n in existing[:8]) or "- (none yet)"
    system_prompt = (
        "You capture selective study notes from ONE turn of a conversation. Given the "
        "student's task, decide if what was just said contains something crucial worth "
        "saving. A note is worth saving ONLY if ALL of: "
        "(1) it is a key fact, definition, method, decision, blocker, or precise next action "
        "directly tied to the student's task/lecture topic; "
        "(2) it is specific enough to be useful on its own later; "
        "(3) it is NOT already covered by the notes already captured this session.\n"
        "Most turns produce nothing — chit-chat, generic encouragement, re-explaining the task, "
        "and near-duplicates are NOT captured. Be strict.\n"
        'Respond with ONLY JSON, no markdown fences: {"worth_saving": true or false, '
        '"note": "short note, or empty string"}. If worth_saving, the note must be under 18 '
        'words, written as a standalone fact (not "the student said...").'
    )
    try:
        raw = await _chat(
            [
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"Task: {task_description}\n"
                        f"Student said: {user_text}\n"
                        f"Companion replied: {companion_reply}\n"
                        f"Already captured this session:\n{existing_bullets}"
                    ),
                },
            ],
            model=model,
            timeout=15.0,
        )
        cleaned = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        result = json.loads(cleaned)
        if result.get("worth_saving") and result.get("note"):
            return str(result["note"]).strip()
        return None
    except (OllamaUnavailableError, json.JSONDecodeError, ValueError, KeyError, TypeError) as e:
        logger.info(f"Note extraction skipped: {e}")
        return None


async def check_llamacpp_health() -> bool:
    """Health probe for the /health endpoint."""
    try:
        async with httpx.AsyncClient(timeout=3.0) as client:
            resp = await client.get(f"{LLAMACPP_BASE_URL}/health")
            return resp.status_code == 200
    except (httpx.ConnectError, httpx.ConnectTimeout, httpx.TimeoutException, httpx.HTTPStatusError):
        return False


def _heuristic(app: str, title: str, site: str) -> dict:
    import intervention
    return intervention.heuristic_label(app, title, site)


def classify_window(
    app: str, title: str, site: str, model: str = DEFAULT_MODEL
) -> dict:
    blob = " | ".join(str(x) for x in (app, site, title) if x)
    if not blob.strip():
        return {"label": "neutral", "confidence": 0.6, "source": "heuristic"}
    prompt = (
        "Classify what a student's foreground window is doing. "
        "Labels: school_work, social_media, video, game, neutral.\n"
        'Respond with ONLY JSON: {"label": "...", "confidence": 0.0-1.0}\n'
        f"Window: {blob[:400]}"
    )
    try:
        with httpx.Client(timeout=CLASSIFY_TIMEOUT) as client:
            resp = client.post(
                f"{LLAMACPP_BASE_URL}/v1/chat/completions",
                json=_to_openai_payload(
                    [{"role": "user", "content": prompt}], CLASSIFY_OPTIONS, stream=False
                ) | {"model": model},
            )
            resp.raise_for_status()
            raw = resp.json()["choices"][0]["message"]["content"]
        import intervention
        for doc in _extract_json_docs(raw):
            if isinstance(doc, dict):
                label = str(doc.get("label") or "").strip().lower()
                if label in intervention.ALL_LABELS:
                    try:
                        conf = float(doc.get("confidence") or 0)
                    except (TypeError, ValueError):
                        conf = 0.5
                    conf = max(0.0, min(1.0, conf))
                    return {"label": label, "confidence": conf, "source": "llama"}
        return _heuristic(app, title, site)
    except Exception as e:
        logger.debug(f"classify_window fallback: {e}")
        return _heuristic(app, title, site)
