"""
LLM backend switcher.

Set STUBILLY_LLM_BACKEND=ollama (default) or llamacpp in .env to choose
which local LLM provider powers every AI call. Re-exports the active
provider's functions so all call sites (main.py, companion_llm.py) stay
unchanged — they just import from this module instead of ollama_client.
"""
import os

BACKEND = os.getenv("STUBILLY_LLM_BACKEND", "ollama").strip().lower()

if BACKEND == "llamacpp":
    from llamacpp_client import (  # noqa: F401
        DEFAULT_MODEL,
        OllamaUnavailableError,
        build_companion_system_prompt,
        check_llamacpp_health as check_ollama_health,
        classify_window,
        extract_note,
        generate_check_in_prompt,
        generate_microtasks,
        generate_nudge_message,
        generate_quiz,
        generate_study_links,
        refine_tasks,
        stream_companion_reply,
        warm_model,
    )
else:
    from ollama_client import (  # noqa: F401
        DEFAULT_MODEL,
        OllamaUnavailableError,
        build_companion_system_prompt,
        check_ollama_health,
        classify_window,
        extract_note,
        generate_check_in_prompt,
        generate_microtasks,
        generate_nudge_message,
        generate_quiz,
        generate_study_links,
        refine_tasks,
        stream_companion_reply,
        warm_model,
    )

BACKEND_NAME = BACKEND  # "ollama" or "llamacpp"
