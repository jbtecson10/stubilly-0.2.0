import { useCallback, useEffect, useState } from "react";
import { api } from "../api/client";

const POLL_MS = 5000;

/**
 * Owns the admin-published block/allow policy for the logged-in user.
 *
 * - Fetches once immediately when `enabled` (i.e. a user is signed in) and
 *   then polls every POLL_MS — that polling is what makes an admin's change
 *   apply MID-SESSION, not just at the next session start.
 * - `refresh()` forces an immediate fetch (used at session start so the
 *   policy is applied before any focus time begins).
 *
 * The caller applies `policy` to the live blocklist / whitelist.
 */
export function useServerPolicy(enabled, onUnauthorized) {
  const [policy, setPolicy] = useState(null);
  const [error, setError] = useState(null);
  const [revision, setRevision] = useState(0);

  const fetch = useCallback(async () => {
    try {
      const p = await api.currentPolicy();
      setPolicy(p);
      setError(null);
    } catch (e) {
      setError(e);
      // Token gone (server restart, forced logout) — hand control back to
      // App so the student returns to login instead of polling forever.
      if (e?.status === 401 && typeof onUnauthorized === "function") {
        onUnauthorized();
      }
    }
  }, [onUnauthorized]);

  const refresh = useCallback(() => {
    setRevision((r) => r + 1);
    // Return the in-flight fetch so callers that need the fresh policy before
    // acting (e.g. handleStart awaiting blocklist apply) can await it.
    return fetch();
  }, [fetch]);

  useEffect(() => {
    if (!enabled) return undefined;
    let cancelled = false;
    let timer = null;

    const run = () => {
      if (cancelled) return;
      fetch().finally(() => {
        if (!cancelled) timer = setTimeout(run, POLL_MS);
      });
    };
    run();

    return () => {
      cancelled = true;
      if (timer) clearTimeout(timer);
    };
  }, [enabled, fetch, revision]);

  return { policy, error, refresh };
}