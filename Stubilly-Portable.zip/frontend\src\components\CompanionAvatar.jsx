/**
 * Animated SVG avatars for the five AI companions — soft "3D blob" style
 * (OpenHuman-inspired): one chubby floating body with a glossy gradient,
 * soft highlight, blush cheeks and simple eyes, plus a small floating
 * accent above the head that keeps each companion's identity:
 *   billy = flame · fokus = target ring · shola = leaf · conan = bolt · akira = wave
 *
 * Pure CSS/SVG — no image assets, no external deps. Same component renders
 * the picker grid, the chat header and the big session-desk stage via
 * the `size` prop (default 48px).
 *
 * `state` drives both the chat mood ("talking" | "thinking" | "listening"
 * | "happy" | "excited" | "concerned" | "surprised") and the focus mood on
 * the companion stage ("focused" | "distracted" | "sleeping" | "absent").
 * "sleeping" swaps to closed eyes (CSS in App.css). Unknown states fall
 * back to "idle".
 */
import { useId } from "react";

// Lighten (amt > 0) or darken (amt < 0) a #rrggbb color for the body
// gradient — keeps every companion's real accent color as the mid tone.
function shade(hex, amt) {
  const h = String(hex || "").replace("#", "");
  const full = h.length === 3 ? h.split("").map((ch) => ch + ch).join("") : h;
  let r = parseInt(full.slice(0, 2), 16);
  let g = parseInt(full.slice(2, 4), 16);
  let b = parseInt(full.slice(4, 6), 16);
  if ([r, g, b].some(Number.isNaN)) return hex;
  const t = amt < 0 ? 0 : 255;
  const p = Math.min(1, Math.abs(amt));
  r = Math.round(r + (t - r) * p);
  g = Math.round(g + (t - g) * p);
  b = Math.round(b + (t - b) * p);
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

// Chubby floating blob: dome body with a soft two-lobe bottom, centered
// face, sized to leave room for the floating accent above the head.
const BODY_PATH =
  "M32 18 C46 18 54 27 54 39 C54 47 50 53 44 57 " +
  "C40 59 36 57.5 34 54.5 C33 53 31 53 30 54.5 " +
  "C28 57.5 24 59 20 57 C14 53 10 47 10 39 C10 27 18 18 32 18 Z";

const ACCENTS = {
  billy: (c) => (
    <path
      d="M32 2 C33.5 6 37 7.5 37 11 C37 14 34.8 16 32 16 C29.2 16 27 14 27 11 C27 7.5 30.5 6 32 2 Z"
      fill={c}
      opacity="0.95"
    />
  ),
  fokus: (c) => (
    <g>
      <circle cx="32" cy="9" r="6.5" fill="none" stroke={c} strokeWidth="2.6" opacity="0.9" />
      <circle cx="32" cy="9" r="2.4" fill={c} />
    </g>
  ),
  shola: (c) => (
    <g transform="rotate(14 32 9)">
      <path
        d="M32 3 C37.5 5.5 39.5 10 37.5 13.5 C35.5 16.5 32 16 30 13 C28 10 29 5.5 32 3 Z"
        fill={c}
        opacity="0.92"
      />
      <path
        d="M31 5 Q33 9 33.5 13"
        stroke="#fff"
        strokeOpacity="0.5"
        strokeWidth="0.9"
        fill="none"
      />
    </g>
  ),
  conan: (c) => (
    <path d="M34.5 2 L26 10.5 L31 10.5 L29.5 17 L38 8 L33 8 Z" fill={c} opacity="0.95" />
  ),
  akira: (c) => (
    <g>
      <path
        d="M21 10 Q26.5 3.5 32 10 Q37.5 16.5 43 10"
        stroke={c}
        strokeWidth="2.6"
        fill="none"
        strokeLinecap="round"
        opacity="0.9"
      />
      <circle cx="32" cy="10" r="1.8" fill={c} />
    </g>
  ),
  tien: (c) => (
    <g>
      <path
        d="M32 1.5 L34.6 7.4 L40.5 10 L34.6 12.6 L32 18.5 L29.4 12.6 L23.5 10 L29.4 7.4 Z"
        fill={c}
        opacity="0.95"
      />
      <circle cx="32" cy="10" r="1.6" fill="#fff" opacity="0.85" />
    </g>
  ),
};

// Map a mood/state name to its CSS animation class. Shared by the chat
// header (idle/talking/thinking/listening) and the companion stage
// (focused/distracted/sleeping/absent).
const AVATAR_STATES = {
  idle: "avatar-idle",
  talking: "avatar-talking",
  thinking: "avatar-thinking",
  listening: "avatar-listening",
  focused: "avatar-focused",
  distracted: "avatar-distracted",
  sleeping: "avatar-sleeping",
  absent: "avatar-absent",
  happy: "avatar-happy",
  excited: "avatar-excited",
  concerned: "avatar-concerned",
  surprised: "avatar-surprised",
};

function BlobBody({ uid, color, accent }) {
  const light = shade(color, 0.5);
  const dark = shade(color, -0.5);
  return (
    <>
      <defs>
        <radialGradient id={`ab-${uid}`} cx="38%" cy="24%" r="80%">
          <stop offset="0%" stopColor={light} />
          <stop offset="52%" stopColor={color} />
          <stop offset="100%" stopColor={dark} />
        </radialGradient>
        <linearGradient id={`as-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="45%" stopColor="#000" stopOpacity="0" />
          <stop offset="100%" stopColor="#000" stopOpacity="0.26" />
        </linearGradient>
        <radialGradient id={`ah-${uid}`}>
          <stop offset="0%" stopColor="#fff" stopOpacity="0.55" />
          <stop offset="100%" stopColor="#fff" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={`ac-${uid}`}>
          <stop offset="0%" stopColor="#ff7aa2" stopOpacity="0.5" />
          <stop offset="100%" stopColor="#ff7aa2" stopOpacity="0" />
        </radialGradient>
      </defs>
      <g className="av-accent">{accent}</g>
      <path d={BODY_PATH} fill={`url(#ab-${uid})`} />
      <path d={BODY_PATH} fill={`url(#as-${uid})`} />
      <ellipse cx="23" cy="28" rx="10" ry="7.5" fill={`url(#ah-${uid})`} />
      <ellipse className="av-blush" cx="21" cy="43" rx="4.5" ry="2.6" fill={`url(#ac-${uid})`} />
      <ellipse className="av-blush" cx="43" cy="43" rx="4.5" ry="2.6" fill={`url(#ac-${uid})`} />
      <g className="av-eyes-open">
        <ellipse cx="25" cy="37" rx="3" ry="3.8" fill="#1c1c2e" />
        <ellipse cx="39" cy="37" rx="3" ry="3.8" fill="#1c1c2e" />
        <circle cx="23.8" cy="35.6" r="1.05" fill="#fff" />
        <circle cx="37.8" cy="35.6" r="1.05" fill="#fff" />
      </g>
      <g className="av-eyes-closed">
        <path
          d="M22 37 Q25 40.2 28 37"
          stroke="#1c1c2e"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
        />
        <path
          d="M36 37 Q39 40.2 42 37"
          stroke="#1c1c2e"
          strokeWidth="2"
          fill="none"
          strokeLinecap="round"
        />
      </g>
      {/* Mouth: a clean cartoon smile. No eyebrows — expression lives in the
          mouth shape + eyes + whole-face motion so it reads friendly, not
          angry. The single crescent stretches (scaleY) into an open mouth
          when talking or surprised. */}
      <g className="av-mouth-group">
        <path
          className="av-mouth"
          d="M24.8 44.9 Q32 53.6 39.2 44.9 Q32 48.7 24.8 44.9 Z"
          fill="#1c1c2e"
        />
      </g>
    </>
  );
}

export default function CompanionAvatar({
  companionId = "fokus",
  color = "#3b82f6",
  size = 48,
  state = "idle",
  className = "",
}) {
  const raw = useId();
  const uid = `${companionId}-${raw.replace(/:/g, "")}`;
  const animClass = AVATAR_STATES[state] || "avatar-idle";
  const accent = (ACCENTS[companionId] || ACCENTS.fokus)(color);

  return (
    <div
      className={`companion-avatar ${animClass} ${className}`}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      <svg viewBox="0 0 64 64" width={size} height={size}>
        <BlobBody uid={uid} color={color} accent={accent} />
      </svg>
    </div>
  );
}
