import { useEffect, useRef, useState } from "react";
import { api } from "../api/client";

/**
 * Today's steps — the session's crucial checklist. `tasks` can be replaced
 * live by the chat-driven refiner (backend pushes {"type":"tasks"}); the
 * checkmarks are keyed by description so items that survive a plan rewrite
 * keep their ✓, and a transient "adjusted" tag signals the real-time update
 * instead of the change happening invisibly.
 *
 * Every toggle is also persisted to the server (matched by description), so
 * the session permanently records what the student actually worked through —
 * that record is what the post-session quiz is built from.
 */
export default function TaskChecklist({ tasks, sessionId }) {
  const [checked, setChecked] = useState({});
  const [adjusted, setAdjusted] = useState(false);
  const [open, setOpen] = useState(false);
  const prevSigRef = useRef(null);
  const firstRenderRef = useRef(true);
  const clearTimerRef = useRef(null);
  const seededRef = useRef(false);

  const signature = (tasks || []).map((t) => `${t.id}:${t.description}`).join("|");

  // Seed checkmarks from the server's completed flags on first load (and
  // when a resumed session's tasks replace the list) so reopening a session
  // doesn't lose the ✓ marks the student already set.
  useEffect(() => {
    if (seededRef.current || !tasks?.length) return;
    seededRef.current = true;
    const seeded = {};
    for (const t of tasks) {
      if (t.completed) seeded[t.description] = true;
    }
    if (Object.keys(seeded).length) setChecked(seeded);
  }, [tasks]);

  useEffect(() => {
    if (firstRenderRef.current) {
      firstRenderRef.current = false;
    } else if (prevSigRef.current !== null && signature !== prevSigRef.current) {
      setAdjusted(true);
      clearTimeout(clearTimerRef.current);
      clearTimerRef.current = setTimeout(() => setAdjusted(false), 6000);
    }
    prevSigRef.current = signature;
  }, [signature]);

  useEffect(() => () => clearTimeout(clearTimerRef.current), []);

  if (!tasks?.length) {
    return (
      <div className="task-checklist task-checklist-empty">
        <h3 className="panel-heading">Today's steps</h3>
        <p>No task plan yet.</p>
      </div>
    );
  }

  const toggle = (description) =>
    setChecked((c) => {
      const next = { ...c, [description]: !c[description] };
      // Fire-and-forget: a dropped write only loses one ✓, but the session's
      // study-content record stays accurate for the quiz + progress views.
      if (sessionId) {
        api
          .updateSessionTasks(
            sessionId,
            (tasks || []).map((t) => ({
              description: t.description,
              completed: !!next[t.description],
            }))
          )
          .catch(() => {});
      }
      return next;
    });

  const doneCount = tasks.filter((t) => checked[t.description]).length;

  return (
    <div className="task-checklist">
      <button
        type="button"
        className="task-checklist-head side-panel-toggle"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <h3 className="panel-heading">Today's steps</h3>
        {adjusted && <span className="task-plan-tag">Adjusted as you chatted</span>}
        <span className="side-panel-badge">
          {doneCount}/{tasks.length}
        </span>
        <span className="side-panel-caret">{open ? "▾" : "▸"}</span>
      </button>
      {open && (
        <ul className="side-panel-body">
          {tasks.map((t) => (
            <li key={t.id} className={checked[t.description] ? "task-done" : ""}>
              <button
                className="task-checkbox"
                onClick={() => toggle(t.description)}
                aria-label={checked[t.description] ? "Mark incomplete" : "Mark complete"}
              >
                {checked[t.description] ? "✓" : ""}
              </button>
              <span className="task-description">{t.description}</span>
              {t.estimated_minutes && <span className="task-minutes">{t.estimated_minutes}m</span>}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}