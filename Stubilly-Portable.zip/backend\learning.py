"""Per-account companion learning profile.

Derives a small, durable profile from a finished study session and merges it
into the user's settings JSON (``users.settings["companion_learning"]``). No
new tables: the profile travels with the account and is rebuilt from focus
events / interventions as sessions complete.
"""
from datetime import datetime, timezone
from typing import Any, Dict, Optional
import json

from sqlalchemy.orm import Session

from models import StudySession, FocusEvent, Intervention, User
import learning_engine


def _feature_vector(summary: Dict[str, Any]) -> list[float]:
    """Build the learning-engine feature vector for one finished session.

    Label (supervised): did the student stay focused? focused_pct >= 50 = 1
    (stayed), else 0 (drifted). The vector encodes the context that
    predicted it: hour of day, weekend, recent focus/ distraction ratios,
    and how many interventions fired."""
    ended = summary.get("ended_at") or summary.get("ts")
    hour = 12.0
    weekend = 0.0
    if ended:
        try:
            dt = datetime.fromisoformat(str(ended))
            hour = dt.hour + dt.minute / 60.0
            weekend = 1.0 if dt.weekday() >= 5 else 0.0
        except ValueError:
            pass
    fp = float(summary.get("focused_pct") or 0.0) / 100.0
    dur = float(summary.get("duration_sec") or 0.0)
    distracted = float(summary.get("distracted_sec") or 0.0)
    at_desk = fp * dur + distracted if dur > 0 else 0.0
    distracted_ratio = (distracted / at_desk) if at_desk > 0 else 0.0
    iv = summary.get("intervention_counts") or {}
    iv_total = sum(int(v) for v in iv.values()) if isinstance(iv, dict) else int(iv or 0)
    pressure = min(1.0, iv_total / 5.0)
    return [
        hour / 24.0,
        weekend,
        fp,                       # focused_recent
        min(1.0, distracted_ratio),
        pressure,
        0.0,                      # off_task_now (not known at session end)
    ]


def train_model(profile: Dict[str, Any], summary: Dict[str, Any]) -> Dict[str, Any]:
    """One online SGD update of the drift model from a finished session.

    The model lives under profile["model"]; a fresh one is created on the
    first session. Returns the updated profile (immutable in/out)."""
    if not summary:
        return profile or {}
    prof = dict(profile or {})
    model = prof.get("model") or learning_engine.new_model()
    x = _feature_vector(summary)
    fp = float(summary.get("focused_pct") or 0.0)
    y = 1.0 if fp >= 50.0 else 0.0
    model = learning_engine.update(x, y, model)
    prof["model"] = model
    prof["model_updated_at"] = _iso(None)
    return prof


def cluster_history(profile: Dict[str, Any]) -> Dict[str, Any]:
    """Run unsupervised k-means over the stored history to surface usage
    clusters (read-only insight). Adds profile["clusters"]; safe to call
    any time, cheap for the 20-session history cap."""
    prof = dict(profile or {})
    hist = prof.get("history") or []
    if len(hist) < 3:
        prof["clusters"] = []
        return prof
    vectors = []
    for h in hist:
        # Rebuild a minimal feature vector from the stored summary.
        fp = float(h.get("focused_pct") or 0.0) / 100.0
        dur = float(h.get("duration_sec") or 0.0)
        iv = h.get("intervention_counts") or {}
        iv_total = sum(int(v) for v in iv.values()) if isinstance(iv, dict) else 0
        vectors.append([0.5, 0.0, fp, 1.0 - fp, min(1.0, iv_total / 5.0), 0.0])
    result = learning_engine.kmeans(vectors, k=min(3, len(vectors)))
    centers = result.get("centers") or []
    prof["clusters"] = [
        {"center": [round(c, 3) for c in center], "label": learning_engine.cluster_label(center)}
        for center in centers
    ]
    return prof


def _naive_utc(dt: Optional[datetime]) -> Optional[datetime]:
    """Normalize any datetime to a timezone-naive UTC value for arithmetic
    and SQLite comparison (SQLite stores datetimes without tzinfo)."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def _compute_durations(events) -> Dict[str, float]:
    focused = distracted = sleeping = absent = 0.0
    if not events:
        return {"focused": focused, "distracted": distracted, "sleeping": sleeping, "absent": absent}
    prev = events[0]
    for ev in events[1:]:
        d = (ev.timestamp - prev.timestamp).total_seconds()
        if d < 0:
            d = 0
        if prev.state == "focused":
            focused += d
        elif prev.state == "distracted":
            distracted += d
        elif prev.state == "sleeping":
            sleeping += d
        elif prev.state == "absent":
            absent += d
        prev = ev
    return {"focused": focused, "distracted": distracted, "sleeping": sleeping, "absent": absent}


def _iso(dt: Optional[datetime]) -> str:
    base = dt or datetime.now(timezone.utc)
    return base.isoformat()[:-7]


def summarize_session(db: Session, session_id: int) -> Dict[str, Any]:
    """Reduce one session into the scalar summary the profile consumes."""
    s = db.query(StudySession).filter(StudySession.id == session_id).first()
    if s is None:
        return {}

    events = (
        db.query(FocusEvent)
        .filter(FocusEvent.session_id == session_id)
        .order_by(FocusEvent.timestamp)
        .all()
    )
    ivs = db.query(Intervention).filter(Intervention.session_id == session_id).all()

    end_bound = _naive_utc(s.ended_at) or _naive_utc(datetime.now(timezone.utc))
    start = _naive_utc(s.started_at) or end_bound
    dur = max(0.0, (end_bound - start).total_seconds())

    d = _compute_durations(events)
    focused = d["focused"]
    at_desk = d["focused"] + d["distracted"] + d["sleeping"]
    focused_pct = round(100.0 * focused / at_desk, 1) if at_desk > 0 else 0.0

    iv_counts: Dict[str, int] = {}
    for iv in ivs:
        k = iv.intervention_type or "other"
        iv_counts[k] = iv_counts.get(k, 0) + 1

    return {
        "session_id": session_id,
        "task_description": s.task_description,
        "duration_sec": round(dur, 1),
        "focused_sec": round(d["focused"], 1),
        "distracted_sec": round(d["distracted"], 1),
        "sleeping_sec": round(d["sleeping"], 1),
        "absent_sec": round(d["absent"], 1),
        "focused_pct": focused_pct,
        "intervention_counts": iv_counts,
        "ended_at": _iso(end_bound),
        "ts": _iso(None),
    }


def merge_profile(existing: Dict[str, Any] | None, summary: Dict[str, Any]) -> Dict[str, Any]:
    """Fold a session summary into the running profile (cumulative mean)."""
    if not summary:
        return existing or {}

    prof = dict(existing or {})
    n = int(prof.get("sessions_count") or 0)
    prev_avg = float(prof.get("avg_focused_pct") or 0.0)
    fp = float(summary.get("focused_pct") or 0.0)

    prof["version"] = 1
    prof["sessions_count"] = n + 1
    prof["avg_focused_pct"] = round((prev_avg * n + fp) / (n + 1), 1)
    prof["last_session_id"] = summary.get("session_id")
    prof["last_task"] = summary.get("task_description") or ""
    prof["last_session_at"] = summary.get("ended_at") or summary.get("ts")
    prof["last_focused_pct"] = fp

    hist = list(prof.get("history") or [])
    hist.append({
        k: summary.get(k)
        for k in ["session_id", "focused_pct", "duration_sec", "intervention_counts", "ended_at", "ts", "task_description"]
    })
    prof["history"] = hist[-20:]
    prof["updated_at"] = _iso(None)
    return prof


def _load_settings(raw) -> Dict[str, Any]:
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str) and raw:
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
        except (ValueError, TypeError):
            return {}
    return {}


def load_profile(db: Session, user_id: int) -> Dict[str, Any]:
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        return {}
    settings = _load_settings(u.settings)
    lp = settings.get("companion_learning") or settings.get("learning_profile") or {}
    return lp if isinstance(lp, dict) else {}


def save_profile(db: Session, user_id: int, profile: Dict[str, Any]) -> None:
    u = db.query(User).filter(User.id == user_id).first()
    if not u:
        return
    settings = _load_settings(u.settings)
    settings["companion_learning"] = profile
    u.settings = json.dumps(settings)
    db.add(u)
    db.commit()
