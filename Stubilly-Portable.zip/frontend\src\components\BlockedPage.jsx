import { useMemo } from "react";

/**
 * Rendered when a blocked site 302s the tab here (/blocked?site=...).
 * Replaces the old blank-flash + silent replaceState with a guided page:
 * what got blocked, why, and the two ways out (back to the task, or take a
 * break — breaks lift the hosts-file ban for their duration).
 */
export default function BlockedPage() {
  const site = useMemo(() => {
    try {
      const raw = new URLSearchParams(window.location.search).get("site");
      return (raw || "").trim().toLowerCase().replace(/^www\./, "");
    } catch {
      return "";
    }
  }, []);

  const goBack = () => {
    window.location.replace("/");
  };

  return (
    <div className="blocked-page">
      <div className="blocked-card">
        <div className="blocked-icon" aria-hidden="true">
          🚧
        </div>
        <h1>Site blocked during study time</h1>
        {site && (
          <p className="blocked-site">
            <strong>{site}</strong>
          </p>
        )}
        <p className="blocked-why">
          Your study session is still running, so this site is closed until
          you finish — or until the next break.
        </p>
        <ul className="blocked-suggestions">
          <li>Switch back to Stubilly and keep working on your task.</li>
          <li>Stuck on the work itself? Ask your AI companion for help.</li>
          <li>
            Need a real pause? Take a break — breaks lift site blocks while
            they last.
          </li>
        </ul>
        <div className="blocked-actions">
          <button type="button" className="blocked-btn primary" onClick={goBack}>
            Back to my session
          </button>
        </div>
        <p className="blocked-hint">
          Opening this site again during the session will bring you right
          back here.
        </p>
      </div>
    </div>
  );
}
