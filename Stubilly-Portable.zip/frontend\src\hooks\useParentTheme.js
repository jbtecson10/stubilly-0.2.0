import { useCallback, useState } from "react";

const STORAGE_KEY = "stubilly-parent-theme";

function readInitialTheme() {
  if (typeof window === "undefined") return "light";
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved === "light" || saved === "dark") return saved;
  } catch {
    // localStorage can throw in private/blocked contexts — ignore.
  }
  // No saved choice: default the guardian view to the calm light skin.
  return "light";
}

/**
 * Parent/guardian dashboard ONLY. Separate key from the student-home and
 * admin themes so flipping one never repaints the others. The consuming
 * dashboard applies ".parent-skin" plus ".parent-theme-dark" when dark,
 * which re-declares the color tokens locally (see parent.css) so just the
 * guardian subtree flips.
 */
export default function useParentTheme() {
  const [theme, setTheme] = useState(readInitialTheme);

  const toggleTheme = useCallback(() => {
    setTheme((t) => {
      const next = t === "light" ? "dark" : "light";
      try {
        window.localStorage.setItem(STORAGE_KEY, next);
      } catch {
        // Ignore storage failures — the choice still holds this session.
      }
      return next;
    });
  }, []);

  return { theme, toggleTheme };
}
