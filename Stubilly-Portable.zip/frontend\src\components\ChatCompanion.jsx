import { useEffect, useRef, useState } from "react";
import { hasConfiguredRemote, getConfiguredRemoteHost } from "../api/client";

/**
 * The body-doubling companion chat. Replies stream in token-by-token (the
 * `messages` prop already reflects that — a companion bubble's content
 * grows as tokens arrive), so this component just has to render whatever
 * it's given and auto-scroll to keep up.
 */
export default function ChatCompanion({ messages, companionTyping, connected, onSend }) {
  const [draft, setDraft] = useState("");
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  function handleSubmit(e) {
    e.preventDefault();
    if (!draft.trim()) return;
    onSend(draft);
    setDraft("");
  }

  return (
    <div className="chat-companion">
      <h3 className="panel-heading">Chat with Stubilly</h3>

      <div className="chat-thread" ref={scrollRef}>
        {messages.length === 0 && (
          <p className="chat-empty">
            Hi! I'm Stubilly — I'm here to help. Ask me anything about your task, and
            I'll answer and help you stay on track.
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`chat-bubble chat-bubble-${m.role}`}>
            {m.content || (m.role === "companion" ? "\u00A0" : "")}
          </div>
        ))}
        {companionTyping && (
          <div className="chat-bubble chat-bubble-companion chat-bubble-typing">
            <span className="chat-typing-dot" />
            <span className="chat-typing-dot" />
            <span className="chat-typing-dot" />
          </div>
        )}
      </div>

      <form className="chat-input-row" onSubmit={handleSubmit}>
        <input
          className="chat-input"
          type="text"
          placeholder={connected ? "Type a message…" : "Reconnecting…"}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
        />
        <button type="submit" className="chat-send" disabled={!draft.trim()}>
          Send
        </button>
      </form>
      {!connected && (
        <p className="chat-status-note">
          {hasConfiguredRemote
            ? `Can't reach the study server (${getConfiguredRemoteHost()}) — retrying in the background. Your message will send once it reconnects.`
            : "Connection lost — trying to reconnect. Your message will send automatically when it's back."}
        </p>
      )}
    </div>
  );
}
