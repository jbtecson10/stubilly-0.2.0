import { useCallback, useState } from "react";

const STORAGE_KEY = "stubilly-home-theme";

function readInitialTheme() {
  if (typeof window === "undefined") return "light";
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    if (saved === "light" || saved === "dark") return saved;
  } catch {
    // localStorage can throw in private/blocked contexts — ignore.
  }
  // No saved choice: default the student home to the light admin skin.
  return "light";
}

/**
 * Student-home theme ONLY. Returns the current theme and a toggle. The
 * consuming screen applies a "theme-light" class when theme === "light",
 * which re-declares the color tokens locally (see index.css) so just that
 * subtree flips — sign-in, admin, active session and parent stay dark.
 */
export default function useTheme() {
  const [theme, setTheme] = useState(readInitialTheme);

  const toggleTheme = useCallback(() => {
    setTheme((t) => {
      const next = t === "light" ? "dark" : "light";
      try {
        window.localStorage.setItem(STORAGE_KEY, next);
      } catch {
        // Ignore storage failures — the choice still holds this session.
      }
      return next;
    });
  }, []);

  return { theme, toggleTheme };
}
