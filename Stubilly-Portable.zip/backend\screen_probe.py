"""Screen-content OCR probe: captures what is actually ON the student's
screen and scores it against the session task, so an off-task-looking
window that really shows assignment material (PDF viewer, lecture slides
in a generic app) is not judged by its window title alone.

Pipeline (all Windows-native, no cloud OCR):
  Pillow ImageGrab  -> full-screen PNG bytes in memory
  WinRT BitmapDecoder -> SoftwareBitmap
  Windows.Media.Ocr  -> extracted text
  intervention.task_keywords -> relevance score vs the session task

Privacy contract (deliberate):
  - Screenshots never leave process memory and are NEVER written to disk,
    DB, logs, or sent to the admin UI.
  - Only the relevance score + up to 5 matched keywords are exposed via
    latest()/ticket evidence. Raw OCR text stays in a single capped
    in-memory buffer used for the next score comparison, and is dropped
    by clear().

Threading: request_capture is fire-and-forget from the window-monitor
thread; OCR runs on a short-lived daemon thread with its own event loop
(WinRT async has no sync API). Throttled — one capture per
MIN_GAP_SEC. Never raises; any failure reports available=False."""
from __future__ import annotations

import io
import logging
import threading
import time
from typing import Optional

import intervention

logger = logging.getLogger("stubilly.screen_probe")

MIN_GAP_SEC = 8.0          # capture cadence; OCR of 1080p ~0.5-2s
MAX_TEXT_CHARS = 3000      # in-memory OCR buffer cap
MATCH_THRESHOLD = 0.4      # latest() reports a score only above this

_lock = threading.Lock()
_busy = False
_last_at = 0.0
_last_result: dict = {
    "available": False,
    "relevance": 0.0,
    "matched": [],
    "chars": 0,
    "at": 0.0,
}
_last_text = ""            # capped raw OCR, memory-only


def _score_text(text: str, task: Optional[str]) -> tuple[float, list]:
    """Keyword-overlap relevance (same /3 saturation as task_relevance)
    plus the matched keywords for evidence. Returns (score, matched)."""
    keys = intervention.task_keywords(task)
    if not keys or not text:
        return 0.0, []
    low = text.lower()
    matched = sorted(k for k in keys if k in low)
    return min(1.0, len(matched) / 3.0), matched


def _capture_sync() -> Optional[str]:
    """Screenshot + OCR, fully synchronous. Only called on the worker
    thread (WinRT needs an event loop, which the worker owns). None on
    any failure. Never raises to the caller."""
    try:
        from PIL import ImageGrab
        from winrt.windows.globalization import Language
        from winrt.windows.graphics.imaging import BitmapDecoder
        from winrt.windows.media.ocr import OcrEngine
        from winrt.windows.storage.streams import DataWriter, InMemoryRandomAccessStream
    except Exception as e:
        logger.debug(f"OCR deps unavailable: {e}")
        return None
    try:
        import asyncio

        async def _run() -> str:
            img = ImageGrab.grab()
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            stream = InMemoryRandomAccessStream()
            writer = DataWriter(stream)
            writer.write_bytes(buf.getvalue())
            await writer.store_async()
            writer.detach_stream()
            stream.seek(0)
            decoder = await BitmapDecoder.create_async(stream)
            bmp = await decoder.get_software_bitmap_async()
            engine = OcrEngine.try_create_from_language(Language("en-US"))
            if engine is None:
                engine = OcrEngine.try_create_from_user_profiles_languages()
            if engine is None:
                return ""
            result = await engine.recognize_async(bmp)
            return (result.text or "")[:MAX_TEXT_CHARS]

        return asyncio.run(_run())
    except Exception as e:
        logger.debug(f"screen OCR failed: {e}")
        return None


def _worker(task: Optional[str]) -> None:
    global _busy, _last_at, _last_result, _last_text
    try:
        text = _capture_sync()
        now = time.time()
        if text is None:
            _last_result = {
                "available": False, "relevance": 0.0, "matched": [],
                "chars": 0, "at": now,
            }
            return
        score, matched = _score_text(text, task)
        _last_text = text
        _last_result = {
            "available": True,
            "relevance": round(score, 3),
            "matched": matched[:5],
            "chars": len(text),
            "at": now,
        }
    except Exception:
        logger.exception("screen probe worker failed")
    finally:
        with _lock:
            _busy = False
            _last_at = time.time()


def request_capture(task: Optional[str]) -> None:
    """Fire-and-forget: queue an OCR capture scored against the task.
    Throttled to one per MIN_GAP_SEC; concurrent requests while a capture
    is in flight are dropped. Never raises."""
    global _busy, _last_at
    if not task:
        return
    now = time.time()
    with _lock:
        if _busy or (now - _last_at) < MIN_GAP_SEC:
            return
        _busy = True
    threading.Thread(target=_worker, args=(task,), daemon=True).start()


def latest() -> dict:
    """Last capture result (see _last_result shape). age_sec tells the
    caller how stale the signal is; relevance is 0 until a capture lands."""
    r = dict(_last_result)
    r["age_sec"] = round(time.time() - float(r.get("at") or 0), 1)
    return r


def clear() -> None:
    """Drop the in-memory OCR buffer and result (session end / logout)."""
    global _last_text, _last_result
    _last_text = ""
    _last_result = {
        "available": False, "relevance": 0.0, "matched": [],
        "chars": 0, "at": 0.0,
    }
