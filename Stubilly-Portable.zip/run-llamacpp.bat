@echo off
rem ============================================================
rem  Stubilly — llama.cpp mode  (port 8423)
rem  Requires: llama.cpp server running on :8080
rem  (llama-server -m your-model.gguf --port 8080)
rem  and setup.bat already completed.
rem ============================================================
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [ERROR] Setup not completed. Run setup.bat first.
    pause
    exit /b 1
)

rem Load .env into the environment (skip blank lines and comments)
for /f "usebackq eol=# tokens=1,* delims==" %%a in (".env") do if not "%%a"=="" set "%%a=%%b"

rem Pin this instance's identity
set STUBILLY_HOST=127.0.0.1
set STUBILLY_PORT=8423
set STUBILLY_LLM_BACKEND=llamacpp

echo.
echo === Stubilly (llama.cpp) starting on http://localhost:8423 ===
echo Keep this window open. Press Ctrl+C to stop.
echo Make sure llama-server is running on :8080 first.
echo.
call ".venv\Scripts\activate.bat"
cd backend
python -m uvicorn main:app --host %STUBILLY_HOST% --port %STUBILLY_PORT%
pause
