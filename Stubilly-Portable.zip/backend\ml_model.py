"""Learned on-task relevance: a tiny L2-regularized logistic regression
trained on the admin's own block/deny ticket history, whose prediction
FLOORS the live task-relevance score exactly like the screen-OCR and
URL-intel signals do (raises relevance, never lowers it). Runs entirely
on the student's machine; nothing leaves it.

How the "ML terms" map onto this model (honest mapping, no theatre):
  - L2 regularization (ridge): every weight is shrunk toward zero
    (lambda=0.1) so no single feature can dominate the prediction on its
    own — flatter, more stable coefficients, classic variance control.
  - Bias-variance dial: `ml_threshold` (default 0.5). The model's
    P(window is on-task) only contributes to the relevance floor when it
    is at least this confident. Lower it -> the model steers more windows
    (less bias toward ignoring it, more variance / more false guides).
    Raise it -> only strong learned patterns count (lower variance, more
    missed on-task windows). This is the ONE calibration knob.
  - Double descent does not apply and is deliberately not implemented:
    it is a test-error phenomenon of OVERparameterized networks (more
    parameters than training samples) where error falls again after the
    model can fit the training set perfectly. This model has 8 parameters
    (7 weights + bias) and needs >= 10 labeled samples to train at all —
    firmly in the classic underparameterized regime where the second
    descent cannot occur. Revisit only if the feature count ever grows
    toward the sample count.

Cold start: with fewer than MIN_LABELED admin decisions there is no
model; live_relevance returns 0.0 and the rule engine behaves exactly
as before this module existed.

Labels come only from DECIDED tickets: status "blocked" -> off-task
(y=0), "denied" -> on-task (y=1). "allowed_once" and "deferred" are
excluded — one-time exceptions and undecided cases are not truth.
Features are rebuilt from the same inputs the LIVE window tick knows at
decision time (confidence, local keyword relevance, URL intel, screen
OCR, video/game/browser signals) so the model can never peek at future
information (sightings count, quiz results) the live decision lacks.
"""
from __future__ import annotations

import json
import logging
import math
import threading
import time
from datetime import datetime
from typing import Optional

import intervention

logger = logging.getLogger("stubilly.ml_model")

FEATURE_NAMES = (
    "confidence",
    "local_relevance",
    "url_relevance",
    "screen_relevance",
    "is_video",
    "is_game",
    "is_browser",
)

MIN_LABELED = 10        # admin decisions required before first train
LAMBDA = 0.1            # L2 shrink strength
LR = 0.1                # full-batch gradient step size
EPOCHS = 300
HOLDOUT_MIN = 20        # with >= this many samples, hold out the last 20%
HOLDOUT_FRAC = 0.2
DEFAULT_THRESHOLD = 0.5
_CACHE_TTL = 60.0       # seconds to trust the in-memory snapshot per db read
_SETTING_KEY = "ml_model"
_VERSION = 1

_VIDEO_HOST_HINTS = ("youtube", "youtu.be", "twitch", "vimeo", "dailymotion", "ted.com")
_BROWSER_APP_HINTS = ("chrome", "msedge", "edge", "firefox", "brave", "opera", "vivaldi", "chromium", "browser")
_GAME_APP_HINTS = ("minecraft", "roblox", "steam", "valorant", "fortnite", "csgo", "leagueoflegends", "apexlegends", "epicgames", "brawlstars")

_lock = threading.Lock()
_state: dict = {
    "weights": None,          # list[float] | None
    "bias": 0.0,
    "threshold": DEFAULT_THRESHOLD,
    "n_samples": 0,
    "trained_at": None,
    "stats": {},
    "loaded_at": 0.0,
}


def _is_video(site: Optional[str]) -> bool:
    host = (site or "").strip().lower().split(":")[0]
    return any(h in host for h in _VIDEO_HOST_HINTS)


def _is_game(label: Optional[str], app: Optional[str]) -> bool:
    if (label or "").strip().lower() == "game":
        return True
    clean = (app or "").strip().lower()
    return any(g in clean for g in _GAME_APP_HINTS)


def _is_browser(app: Optional[str]) -> bool:
    clean = (app or "").strip().lower()
    return any(b in clean for b in _BROWSER_APP_HINTS)


def _unit(x) -> float:
    try:
        v = float(x or 0.0)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, v))


def build_features(
    task: Optional[str],
    app: Optional[str],
    site: Optional[str],
    title: Optional[str],
    label: Optional[str],
    confidence,
    url_rel=0.0,
    screen_rel=0.0,
) -> list[float]:
    """The 7 features the live tick actually has when it must decide.
    Same builder is used at train time (from ticket row + evidence)."""
    return [
        _unit(confidence),
        _unit(intervention.task_relevance(title, site, app, task)),
        _unit(url_rel),
        _unit(screen_rel),
        1.0 if _is_video(site) else 0.0,
        1.0 if _is_game(label, app) else 0.0,
        1.0 if _is_browser(app) else 0.0,
    ]


def _sigmoid(z: float) -> float:
    if z < -30.0:
        return 0.0
    if z > 30.0:
        return 1.0
    return 1.0 / (1.0 + math.exp(-z))


def _dot(w: list[float], x: list[float]) -> float:
    return sum(wi * xi for wi, xi in zip(w, x))


def train(samples: list[tuple[list[float], int]]) -> dict:
    """Full-batch L2 logistic regression on (features, y) pairs given in
    CHRONOLOGICAL order (newest 20% held out when n >= HOLDOUT_MIN —
    time-ordered holdout avoids leaking the future into the past).
    Deterministic: zero init, no shuffling. Returns stats dict with
    weights/bias/accuracies. Raises ValueError on empty input."""
    if len(samples) < 2:
        raise ValueError("need at least 2 samples to train")
    n = len(samples)
    holdout_n = int(n * HOLDOUT_FRAC) if n >= HOLDOUT_MIN else 0
    train_set = samples[: n - holdout_n] if holdout_n else samples
    hold_set = samples[n - holdout_n:] if holdout_n else []
    m = len(train_set)
    dim = len(train_set[0][0])
    w = [0.0] * dim
    b = 0.0
    for _ in range(EPOCHS):
        gw = [0.0] * dim
        gb = 0.0
        for x, y in train_set:
            err = _sigmoid(_dot(w, x) + b) - y
            for i in range(dim):
                gw[i] += err * x[i]
            gb += err
        for i in range(dim):
            w[i] -= LR * ((gw[i] / m) + LAMBDA * w[i])
        b -= LR * (gb / m)

    def _acc(data: list[tuple[list[float], int]]) -> Optional[float]:
        if not data:
            return None
        hits = sum(1 for x, y in data if (1.0 if _sigmoid(_dot(w, x) + b) >= 0.5 else 0) == y)
        return round(hits / len(data), 4)

    return {
        "weights": [round(v, 6) for v in w],
        "bias": round(b, 6),
        "n_train": m,
        "n_holdout": holdout_n,
        "train_acc": _acc(train_set),
        "holdout_acc": _acc(hold_set),
        "l2_lambda": LAMBDA,
        "epochs": EPOCHS,
    }


def _load_from_db(db) -> None:
    """Populate module state from the AppSetting row (or leave cold)."""
    try:
        import models
        row = db.get(models.AppSetting, _SETTING_KEY) if db is not None else None
        blob = json.loads(row.value) if row and row.value else None
    except Exception:
        blob = None
    with _lock:
        if isinstance(blob, dict) and blob.get("version") == _VERSION:
            _state["weights"] = blob.get("weights")
            _state["bias"] = float(blob.get("bias") or 0.0)
            _state["threshold"] = float(blob.get("threshold") or DEFAULT_THRESHOLD)
            _state["n_samples"] = int(blob.get("n_samples") or 0)
            _state["trained_at"] = blob.get("trained_at")
            _state["stats"] = blob.get("stats") or {}
            _state["label_counts"] = blob.get("label_counts") or {}
        _state["loaded_at"] = time.time()


def _ensure_loaded(db) -> None:
    with _lock:
        stale = time.time() - float(_state.get("loaded_at") or 0.0) > _CACHE_TTL
        has_model = _state.get("weights") is not None
    if stale and (db is not None or not has_model):
        # db is needed only on the first pull; later refreshes may reuse
        # whatever is already in memory if no session is available.
        try:
            _load_from_db(db)
        except Exception:
            logger.exception("ml_model load failed")
            with _lock:
                _state["loaded_at"] = time.time()


def live_relevance(
    db,
    task: Optional[str],
    app: Optional[str],
    site: Optional[str],
    title: Optional[str],
    label: Optional[str],
    confidence,
    url_rel: float = 0.0,
    screen_rel: float = 0.0,
) -> float:
    """Threshold-gated model contribution to the relevance floor.
    Returns 0.0 (a) cold start, (b) prediction below ml_threshold,
    (c) any error — callers just max() it into min_relevance."""
    try:
        _ensure_loaded(db)
        with _lock:
            w = _state["weights"]
            b = float(_state["bias"])
            thr = float(_state["threshold"])
        if not w:
            return 0.0
        x = build_features(task, app, site, title, label, confidence, url_rel, screen_rel)
        p = _sigmoid(_dot(w, x) + b)
        return float(p) if p >= thr else 0.0
    except Exception:
        logger.exception("ml_model live_relevance failed")
        return 0.0


def _persist(db, blob: dict) -> None:
    import models
    row = db.get(models.AppSetting, _SETTING_KEY)
    if row is None:
        row = models.AppSetting(key=_SETTING_KEY)
        db.add(row)
    row.value = json.dumps(blob, ensure_ascii=False)
    row.updated_at = datetime.utcnow()
    db.commit()


def maybe_train(db) -> dict:
    """Gather decided tickets (blocked/denied), rebuild features the same
    way the live tick does, retrain when there are enough labels AND the
    label count changed since the last model. Safe to call often."""
    import models
    rows = (
        db.query(models.BlockTicket)
        .filter(models.BlockTicket.status.in_(("blocked", "denied")))
        .order_by(models.BlockTicket.id.asc())
        .all()
    )
    samples: list[tuple[list[float], int]] = []
    label_counts = {"blocked": 0, "denied": 0}
    for r in rows:
        try:
            ev = json.loads(r.evidence or "{}") if r.evidence else {}
        except Exception:
            ev = {}
        if not isinstance(ev, dict):
            ev = {}
        x = build_features(
            ev.get("task") or r.task,
            r.app or "",
            r.site or "",
            ev.get("last_title") or r.title or "",
            r.label or "neutral",
            r.confidence or 0.0,
            ev.get("url_relevance") or 0.0,
            ev.get("screen_relevance") or 0.0,
        )
        y = 1 if r.status == "denied" else 0
        samples.append((x, y))
        label_counts[r.status] = label_counts.get(r.status, 0) + 1
    if len(samples) < MIN_LABELED:
        return {"skipped": f"only {len(samples)} labeled tickets (need {MIN_LABELED})"}
    with _lock:
        prev_n = int(_state.get("n_samples") or 0)
        prev_thr = float(_state.get("threshold") or DEFAULT_THRESHOLD)
    if len(samples) == prev_n:
        return {"skipped": "no new labeled tickets since last train"}
    stats = train(samples)
    blob = {
        "version": _VERSION,
        "weights": stats["weights"],
        "bias": stats["bias"],
        "threshold": prev_thr,
        "n_samples": len(samples),
        "trained_at": datetime.utcnow().isoformat(timespec="seconds"),
        "feature_names": list(FEATURE_NAMES),
        "label_counts": label_counts,
        "stats": {k: stats[k] for k in ("n_train", "n_holdout", "train_acc", "holdout_acc", "l2_lambda", "epochs")},
    }
    _persist(db, blob)
    with _lock:
        _state["weights"] = stats["weights"]
        _state["bias"] = stats["bias"]
        _state["threshold"] = prev_thr
        _state["n_samples"] = len(samples)
        _state["trained_at"] = blob["trained_at"]
        _state["stats"] = blob["stats"]
        _state["label_counts"] = label_counts
        _state["loaded_at"] = time.time()
    logger.info(
        "ml_model trained on %d samples (blocked=%d denied=%d) train_acc=%s holdout_acc=%s",
        len(samples), label_counts["blocked"], label_counts["denied"],
        stats["train_acc"], stats["holdout_acc"],
    )
    return blob


def schedule_retrain() -> None:
    """Fire-and-forget retrain in a daemon thread with its own DB session
    (same pattern as auth.py background work). Never raises; called after
    each admin block/deny decision."""

    def _run() -> None:
        db = None
        try:
            from database import SessionLocal
            db = SessionLocal()
            maybe_train(db)
        except Exception:
            logger.exception("ml_model background retrain failed")
        finally:
            if db is not None:
                try:
                    db.close()
                except Exception:
                    pass

    threading.Thread(target=_run, daemon=True).start()


def get_threshold() -> float:
    with _lock:
        return float(_state.get("threshold") or DEFAULT_THRESHOLD)


def set_threshold(db, value: float) -> float:
    """Persist the bias-variance dial (clamped to [0.05, 0.95])."""
    thr = max(0.05, min(0.95, float(value)))
    with _lock:
        w = _state.get("weights")
        b = float(_state.get("bias") or 0.0)
        n = int(_state.get("n_samples") or 0)
        trained_at = _state.get("trained_at")
        stats = dict(_state.get("stats") or {})
        labels = dict(_state.get("label_counts") or {})
    blob = {
        "version": _VERSION,
        "weights": w,
        "bias": b,
        "threshold": thr,
        "n_samples": n,
        "trained_at": trained_at,
        "feature_names": list(FEATURE_NAMES),
        "label_counts": labels,
        "stats": stats,
    }
    _persist(db, blob)
    with _lock:
        _state["threshold"] = thr
        _state["loaded_at"] = time.time()
    return thr


def model_info() -> dict:
    """Snapshot for /admin/ml-model, /admin/diagnostics and the SmartOps
    accuracy dashboard. No db access — reads the in-memory state only."""
    with _lock:
        return {
            "trained": _state.get("weights") is not None,
            "n_samples": int(_state.get("n_samples") or 0),
            "trained_at": _state.get("trained_at"),
            "threshold": float(_state.get("threshold") or DEFAULT_THRESHOLD),
            "feature_names": list(FEATURE_NAMES),
            "min_labeled_to_train": MIN_LABELED,
            "l2_lambda": LAMBDA,
            "label_counts": dict(_state.get("label_counts") or {}),
            "stats": dict(_state.get("stats") or {}),
        }


def reset_state() -> None:
    """Test helper: wipe the in-memory snapshot (DB row untouched)."""
    with _lock:
        _state.update({
            "weights": None, "bias": 0.0, "threshold": DEFAULT_THRESHOLD,
            "n_samples": 0, "trained_at": None, "stats": {}, "label_counts": {},
            "loaded_at": 0.0,
        })
